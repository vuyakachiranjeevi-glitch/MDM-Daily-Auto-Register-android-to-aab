import React, { useState, useEffect } from 'react';
import {
  AppSettings,
  CommodityItem,
  DailyEntry,
  MealRates,
  NavigationTab,
  SchoolProfile,
  StockTransaction,
  StudentClassStrength,
  User,
  AutomationSettings,
} from './types';
import {
  getStoredCommodities,
  getStoredDailyEntries,
  getStoredMealRates,
  getStoredMonthlyCommodityBalances,
  getStoredSchoolProfile,
  getStoredStockTransactions,
  getStoredStudentStrength,
  getStoredUser,
  getStoredAutomationSettings,
  saveStoredAutomationSettings,
  MonthlyCommodityOverrides,
  recalculateCommodityStock,
  resetAllApplicationData,
  saveStoredCommodities,
  saveStoredDailyEntries,
  saveStoredMealRates,
  saveStoredMonthlyCommodityBalances,
  saveStoredManualObMonth,
  saveStoredSchoolProfile,
  saveStoredStockTransactions,
  saveStoredStudentStrength,
  saveStoredUser,
  saveStudentStrengthForDate,
  saveStudentStrengthForMonth,
  syncWithCloud,
  getActiveSchoolId,
  setActiveSchoolId,
  normalizeSchoolId,
  getSchoolAccounts,
  DEFAULT_SCHOOL_ID,
} from './lib/storage';

import { Header } from './components/Header';
import { LoginModal } from './components/LoginModal';
import { DashboardView } from './components/DashboardView';
import { DailyEntryView } from './components/DailyEntryView';
import { StudentStrengthView } from './components/StudentStrengthView';
import { CommodityStockView } from './components/CommodityStockView';
import { MonthlySummaryView } from './components/MonthlySummaryView';
import { CashVoucherView } from './components/CashVoucherView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { SplashScreen } from './components/SplashScreen';
import { usePWA } from './hooks/usePWA';
import { PWAInstallModal } from './components/PWAInstallModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { PWAUpdateBanner } from './components/PWAUpdateBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { useNumberInputSelection } from './hooks/useNumberInputSelection';
import {
  logoutUser,
  checkSession,
  getStoredSessionToken,
  clearStoredSessionToken,
  saveDailyEntryBackend,
  fetchSchoolRecordsBackend,
  syncDataWithBackend,
} from './lib/authApi';
import { defaultSchoolProfile } from './lib/utils';

export default function App() {
  // Global auto-selection of number targets on focus/edit
  useNumberInputSelection();

  // PWA state & controls
  const {
    isInstallable,
    isInstalled,
    isIOS,
    isStandalone,
    showInstallModal,
    setShowInstallModal,
    updateAvailable,
    installApp,
    updateApp,
    hasDeferredPrompt,
  } = usePWA();

  // Navigation & UI State
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('mdm_dark_mode');
    return saved !== null ? JSON.parse(saved) : true;
  });
  const [isPrintMode, setIsPrintMode] = useState<boolean>(false);

  // User auth state: Restore authenticated session if previously logged in
  const [user, setUser] = useState<User>(() => {
    const stored = getStoredUser();
    const token = getStoredSessionToken();
    const rememberMe = localStorage.getItem('mdm_remembered_username') !== null;
    const shouldBeLoggedIn = Boolean(stored && stored.schoolId && (stored.isLoggedIn || (token && rememberMe)));
    return { ...stored, isLoggedIn: shouldBeLoggedIn };
  });
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isManualSplash, setIsManualSplash] = useState<boolean>(false);

  // Data States
  const [schoolProfile, setSchoolProfile] = useState<SchoolProfile>(() => getStoredSchoolProfile(getActiveSchoolId()));
  const [studentStrengths, setStudentStrengths] = useState<StudentClassStrength[]>(() => getStoredStudentStrength(getActiveSchoolId()));
  const [dailyEntries, setDailyEntries] = useState<DailyEntry[]>(() => getStoredDailyEntries(getActiveSchoolId()));
  const [baseCommodities, setBaseCommodities] = useState<CommodityItem[]>(() => getStoredCommodities(getActiveSchoolId()));
  const [stockTransactions, setStockTransactions] = useState<StockTransaction[]>(() => getStoredStockTransactions(getActiveSchoolId()));
  const [mealRates, setMealRates] = useState<MealRates>(() => getStoredMealRates(getActiveSchoolId()));
  const [monthlyOverrides, setMonthlyOverrides] = useState<MonthlyCommodityOverrides>(() =>
    getStoredMonthlyCommodityBalances(getActiveSchoolId())
  );
  const [automationSettings, setAutomationSettings] = useState<AutomationSettings>(() => getStoredAutomationSettings(getActiveSchoolId()));

  const handleUpdateAutomationSettings = (newSettings: AutomationSettings) => {
    setAutomationSettings(newSettings);
    saveStoredAutomationSettings(newSettings);
  };

  // Dynamic Commodity Stock calculation
  const commodities = recalculateCommodityStock(
    baseCommodities,
    dailyEntries,
    stockTransactions,
    undefined,
    monthlyOverrides
  );

  // Apply dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('mdm_dark_mode', JSON.stringify(darkMode));
  }, [darkMode]);

  // Comprehensive state refresher from storage & cloud
  const refreshAllDataState = (targetSchoolId?: string) => {
    const sId = targetSchoolId || getActiveSchoolId();
    setUser((prev) => {
      const stored = getStoredUser(sId);
      return { ...stored, isLoggedIn: prev.isLoggedIn };
    });
    setSchoolProfile(getStoredSchoolProfile(sId));
    setStudentStrengths(getStoredStudentStrength(sId));
    setAutomationSettings(getStoredAutomationSettings(sId));
    setDailyEntries(getStoredDailyEntries(sId));
    setBaseCommodities(getStoredCommodities(sId));
    setStockTransactions(getStoredStockTransactions(sId));
    setMealRates(getStoredMealRates(sId));
    setMonthlyOverrides(getStoredMonthlyCommodityBalances(sId));
  };

  // Comprehensive restore function pulling from backend persistent store and Firestore
  const restoreSchoolData = async (targetSchoolId: string) => {
    try {
      const res = await fetchSchoolRecordsBackend();
      if (res.success && res.data) {
        const d = res.data;
        if (Array.isArray(d.dailyEntries) && d.dailyEntries.length > 0) {
          const localEntries = getStoredDailyEntries(targetSchoolId);
          const mergedMap = new Map<string, DailyEntry>();
          d.dailyEntries.forEach((e: DailyEntry) => {
            if (e && e.date) mergedMap.set(e.date, e);
          });
          localEntries.forEach((e: DailyEntry) => {
            if (e && e.date) {
              const bEntry = mergedMap.get(e.date);
              if (!bEntry || e.isManual || (e.updatedAt && (!bEntry.updatedAt || e.updatedAt >= bEntry.updatedAt))) {
                mergedMap.set(e.date, e);
              }
            }
          });
          const merged = Array.from(mergedMap.values()).sort((a, b) => a.date.localeCompare(b.date));
          saveStoredDailyEntries(merged, targetSchoolId);
          setDailyEntries(merged);
        }
        if (Array.isArray(d.commodities) && d.commodities.length > 0) {
          saveStoredCommodities(d.commodities, targetSchoolId);
          setBaseCommodities(d.commodities);
        }
        if (Array.isArray(d.stockTransactions)) {
          saveStoredStockTransactions(d.stockTransactions, targetSchoolId);
          setStockTransactions(d.stockTransactions);
        }
        if (Array.isArray(d.studentStrengths) && d.studentStrengths.length > 0) {
          saveStoredStudentStrength(d.studentStrengths, targetSchoolId);
          setStudentStrengths(d.studentStrengths);
        }
        if (d.monthlyOverrides && typeof d.monthlyOverrides === 'object') {
          saveStoredMonthlyCommodityBalances(d.monthlyOverrides, targetSchoolId);
          setMonthlyOverrides(d.monthlyOverrides);
        }
        if (d.mealRates && typeof d.mealRates === 'object') {
          saveStoredMealRates(d.mealRates, targetSchoolId);
          setMealRates(d.mealRates);
        }
        if (d.schoolProfile && typeof d.schoolProfile === 'object') {
          saveStoredSchoolProfile(d.schoolProfile, targetSchoolId);
          setSchoolProfile(d.schoolProfile);
        }
      }
    } catch (e) {
      console.warn('Backend record restore error:', e);
    }

    // Sync with Cloud Firestore and refresh
    syncWithCloud(() => {
      refreshAllDataState(targetSchoolId);
    }, targetSchoolId);
  };

  // 1. Secure session verification and restoration on startup
  useEffect(() => {
    const token = getStoredSessionToken();
    if (token) {
      checkSession()
        .then((res) => {
          if (res.success && res.session) {
            const activeSchoolId = normalizeSchoolId(res.session.schoolId || getActiveSchoolId());
            setActiveSchoolId(activeSchoolId);
            const verifiedUser: User = {
              username: res.schoolProfile?.udiseCode || (res.session as any).udiseCode || res.session.username,
              name: res.session.name,
              role: res.session.role,
              isLoggedIn: true,
              schoolId: activeSchoolId,
              schoolName: res.schoolProfile?.schoolName,
              udiseCode: res.schoolProfile?.udiseCode,
            };
            setUser(verifiedUser);
            saveStoredUser(verifiedUser, activeSchoolId);

            if (res.schoolProfile) {
              const fullProf: SchoolProfile = {
                ...defaultSchoolProfile,
                schoolName: res.schoolProfile.schoolName || '',
                udiseCode: res.schoolProfile.udiseCode || '',
                headmasterName: res.schoolProfile.headmasterName || '',
                phoneNumber: (res.schoolProfile as any).headmasterMobile || (res.schoolProfile as any).phoneNumber || '',
                village: res.schoolProfile.village || '',
                mandal: res.schoolProfile.mandal || 'PALAKONDA',
                district: res.schoolProfile.district || 'PARVATHI PURAM MANYAM',
                state: res.schoolProfile.state || 'ANDHRA PRADESH',
                address: res.schoolProfile.address || `${res.schoolProfile.schoolName || ''}, ${res.schoolProfile.mandal || ''}`,
              };
              saveStoredSchoolProfile(fullProf, activeSchoolId);
              setSchoolProfile(fullProf);
            }

            refreshAllDataState(activeSchoolId);
            restoreSchoolData(activeSchoolId);
          } else {
            const storedUser = getStoredUser();
            if (storedUser && storedUser.schoolId && storedUser.isLoggedIn) {
              refreshAllDataState(storedUser.schoolId);
              restoreSchoolData(storedUser.schoolId);
            } else {
              clearStoredSessionToken();
              setUser((prev) => ({ ...prev, isLoggedIn: false }));
            }
          }
        })
        .catch(() => {
          // If server unreachable, permit cached session for previously authenticated account
          const storedUser = getStoredUser();
          if (storedUser && storedUser.schoolId && storedUser.isLoggedIn) {
            const activeSchoolId = normalizeSchoolId(storedUser.schoolId);
            setUser({ ...storedUser, schoolId: activeSchoolId, isLoggedIn: true });
            refreshAllDataState(activeSchoolId);
            restoreSchoolData(activeSchoolId);
          } else {
            setUser((prev) => ({ ...prev, isLoggedIn: false }));
          }
        });
    } else {
      const storedUser = getStoredUser();
      if (storedUser && storedUser.schoolId && storedUser.isLoggedIn) {
        refreshAllDataState(storedUser.schoolId);
        restoreSchoolData(storedUser.schoolId);
      }
    }
  }, []);

  // 2. Automatically restore saved cloud data when app reopens & user is authenticated
  useEffect(() => {
    const handleRestoreOnReopen = () => {
      if (document.visibilityState === 'visible' && user.isLoggedIn) {
        const currentActiveId = getActiveSchoolId();
        restoreSchoolData(currentActiveId);
      }
    };

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key && (e.key.startsWith('mdm_') || e.key.includes('__mdm_'))) {
        refreshAllDataState();
      }
    };

    document.addEventListener('visibilitychange', handleRestoreOnReopen);
    window.addEventListener('online', handleRestoreOnReopen);
    window.addEventListener('storage', handleStorageChange);

    return () => {
      document.removeEventListener('visibilitychange', handleRestoreOnReopen);
      window.removeEventListener('online', handleRestoreOnReopen);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [user.isLoggedIn]);

  // Total student strength
  const totalStudents = studentStrengths.reduce((sum, s) => sum + s.total, 0);

  // Auth Handlers - Automatically restore previous saved data on login
  const handleLogin = async (newUser: User) => {
    const targetSchoolId = normalizeSchoolId(newUser.schoolId || getActiveSchoolId());
    setActiveSchoolId(targetSchoolId);
    const resolvedUdise = newUser.udiseCode || (targetSchoolId.startsWith('school_') ? targetSchoolId.replace('school_', '') : targetSchoolId);
    const updatedUser: User = {
      ...newUser,
      schoolId: targetSchoolId,
      udiseCode: resolvedUdise,
      username: resolvedUdise, // Login details username as UDISE code only
    };
    setUser(updatedUser);
    saveStoredUser(updatedUser, targetSchoolId);

    // Initialize school profile for newly active school
    const existingProfile = getStoredSchoolProfile(targetSchoolId);
    const isMismatched = !existingProfile ||
      existingProfile.udiseCode !== resolvedUdise ||
      (targetSchoolId !== DEFAULT_SCHOOL_ID && existingProfile.schoolName === 'M. P. P. SCHOOL R.B.R.PETA');

    if (isMismatched) {
      const initialized: SchoolProfile = {
        ...defaultSchoolProfile,
        ...existingProfile,
        schoolName: newUser.schoolName || existingProfile?.schoolName || `School ${resolvedUdise}`,
        udiseCode: resolvedUdise,
        headmasterName: newUser.name || existingProfile?.headmasterName || '',
        phoneNumber: newUser.mobile || existingProfile?.phoneNumber || '',
        village: (newUser as any).village || existingProfile?.village || '',
        mandal: (newUser as any).mandal || existingProfile?.mandal || 'PALAKONDA',
        district: (newUser as any).district || existingProfile?.district || 'PARVATHI PURAM MANYAM',
        state: (newUser as any).state || existingProfile?.state || 'ANDHRA PRADESH',
        address: (newUser as any).address || existingProfile?.address || `${newUser.schoolName || ''}, PARVATHI PURAM MANYAM`,
      };
      saveStoredSchoolProfile(initialized, targetSchoolId);
      setSchoolProfile(initialized);
    } else {
      setSchoolProfile(existingProfile);
    }

    refreshAllDataState(targetSchoolId);

    // Pull authoritative saved records from backend store and Cloud Firestore
    restoreSchoolData(targetSchoolId);
  };

  const handleLogout = () => {
    logoutUser().catch(() => {});
    const sId = user.schoolId || getActiveSchoolId();
    const updated = { ...user, isLoggedIn: false };
    setUser(updated);
    saveStoredUser(updated, sId);
    clearStoredSessionToken();
    // Clear account-specific in-memory states to prevent data leakage between users
    setDailyEntries([]);
    setStockTransactions([]);
    setMonthlyOverrides({});
    setSchoolProfile(defaultSchoolProfile);
  };

  // Data Mutation Handlers with Local Persistence
  const handleSaveDailyEntry = (entry: DailyEntry) => {
    const sId = user.schoolId || getActiveSchoolId();
    const currentStored = getStoredDailyEntries(sId);
    const existingIndex = currentStored.findIndex((e) => e.date === entry.date);
    let updatedEntries: DailyEntry[];

    if (existingIndex >= 0) {
      updatedEntries = [...currentStored];
      updatedEntries[existingIndex] = entry;
    } else {
      updatedEntries = [...currentStored, entry];
    }

    saveStoredDailyEntries(updatedEntries, sId);
    setDailyEntries(updatedEntries);
    // Non-blocking background save with idempotency key
    saveDailyEntryBackend(entry, `entry_${entry.date}_${entry.id}`).catch(() => {});
    syncDataWithBackend({ dailyEntries: updatedEntries }).catch(() => {});
  };

  const handleDeleteDailyEntry = (entryId: string) => {
    const sId = user.schoolId || getActiveSchoolId();
    setDailyEntries((prev) => {
      const updated = prev.filter((e) => e.id !== entryId);
      saveStoredDailyEntries(updated, sId);
      syncDataWithBackend({ dailyEntries: updated }).catch(() => {});
      return updated;
    });
  };

  const handleSaveStudentStrengths = (strengths: StudentClassStrength[], dateOrMonth?: string) => {
    const sId = user.schoolId || getActiveSchoolId();
    if (dateOrMonth && dateOrMonth.length === 10) {
      saveStudentStrengthForDate(dateOrMonth, strengths);
    } else {
      const activeMonth = dateOrMonth || new Date().toISOString().substring(0, 7);
      saveStudentStrengthForMonth(activeMonth, strengths);
    }
    saveStoredStudentStrength(strengths, sId);
    setStudentStrengths(strengths);
    setDailyEntries(getStoredDailyEntries(sId));
    syncDataWithBackend({ studentStrengths: strengths }).catch(() => {});
  };

  const handleAddStockTransaction = (tx: StockTransaction | StockTransaction[]) => {
    const sId = user.schoolId || getActiveSchoolId();
    const newTxs = Array.isArray(tx) ? tx : [tx];
    setStockTransactions((prev) => {
      const updatedTxs = [...prev, ...newTxs];
      saveStoredStockTransactions(updatedTxs, sId);
      syncDataWithBackend({ stockTransactions: updatedTxs }).catch(() => {});
      return updatedTxs;
    });
  };

  const handleUpdateStockTransaction = (updatedTx: StockTransaction) => {
    const sId = user.schoolId || getActiveSchoolId();
    setStockTransactions((prev) => {
      const updatedTxs = prev.map((t) => (t.id === updatedTx.id ? updatedTx : t));
      saveStoredStockTransactions(updatedTxs, sId);
      syncDataWithBackend({ stockTransactions: updatedTxs }).catch(() => {});
      return updatedTxs;
    });
  };

  const handleDeleteStockTransaction = (txId: string) => {
    const sId = user.schoolId || getActiveSchoolId();
    setStockTransactions((prev) => {
      const updatedTxs = prev.filter((t) => t.id !== txId);
      saveStoredStockTransactions(updatedTxs, sId);
      syncDataWithBackend({ stockTransactions: updatedTxs }).catch(() => {});
      return updatedTxs;
    });
  };

  const handleSaveAllStockTransactions = (updatedTxs: StockTransaction[]) => {
    const sId = user.schoolId || getActiveSchoolId();
    setStockTransactions(updatedTxs);
    saveStoredStockTransactions(updatedTxs, sId);
    syncDataWithBackend({ stockTransactions: updatedTxs }).catch(() => {});
  };

  const handleUpdateSchoolProfile = (profile: SchoolProfile) => {
    const sId = user.schoolId || getActiveSchoolId();
    setSchoolProfile(profile);
    saveStoredSchoolProfile(profile, sId);
    syncDataWithBackend({ schoolProfile: profile }).catch(() => {});
  };

  const handleUpdateMealRates = (rates: MealRates) => {
    const sId = user.schoolId || getActiveSchoolId();
    setMealRates(rates);
    saveStoredMealRates(rates, sId);
    setDailyEntries(getStoredDailyEntries(sId));
    syncDataWithBackend({ mealRates: rates }).catch(() => {});
  };

  const handleSaveOpeningBalances = (updatedCommodities: CommodityItem[]) => {
    const sId = user.schoolId || getActiveSchoolId();
    setBaseCommodities(updatedCommodities);
    saveStoredCommodities(updatedCommodities, sId);

    // Keep August starting month and August 1st monthly overrides in sync
    const augOverrides: Record<string, number> = {};
    updatedCommodities.forEach((c) => {
      augOverrides[c.id] = c.openingBalance;
    });
    const updated = {
      ...monthlyOverrides,
      '2026-08': { ...(monthlyOverrides['2026-08'] || {}), ...augOverrides },
      '2026-08-01': { ...(monthlyOverrides['2026-08-01'] || {}), ...augOverrides },
    };
    setMonthlyOverrides(updated);
    saveStoredMonthlyCommodityBalances(updated, sId);
    syncDataWithBackend({ commodities: updatedCommodities, monthlyOverrides: updated }).catch(() => {});
  };

  const handleSaveMonthlyBalances = (monthOrDateStr: string, overrides: Record<string, number>) => {
    const sId = user.schoolId || getActiveSchoolId();
    const updated: MonthlyCommodityOverrides = { ...monthlyOverrides };
    updated[monthOrDateStr] = overrides;
    // If saving for YYYY-MM-01, also keep YYYY-MM in sync for convenience
    if (monthOrDateStr.length === 10 && monthOrDateStr.endsWith('-01')) {
      updated[monthOrDateStr.substring(0, 7)] = overrides;
    } else if (monthOrDateStr.length === 7) {
      updated[`${monthOrDateStr}-01`] = overrides;
    }
    setMonthlyOverrides(updated);
    saveStoredMonthlyCommodityBalances(updated, sId);
    syncDataWithBackend({ monthlyOverrides: updated }).catch(() => {});
    saveStoredManualObMonth(monthOrDateStr, true);

    // If saving for August (the baseline starting month) or August 1st, also synchronize base commodities
    if (monthOrDateStr === '2026-08' || monthOrDateStr === '2026-08-01' || monthOrDateStr.startsWith('2026-08')) {
      const currentBase = baseCommodities && baseCommodities.length > 0 ? baseCommodities : getStoredCommodities();
      const updatedCommodities = currentBase.map((c) => {
        if (overrides[c.id] !== undefined) {
          return {
            ...c,
            openingBalance: overrides[c.id],
          };
        }
        return c;
      });
      setBaseCommodities(updatedCommodities);
      saveStoredCommodities(updatedCommodities);
    }
  };

  const handleResetMonthlyOverride = (monthOrDateStr: string) => {
    const updated = { ...monthlyOverrides };
    delete updated[monthOrDateStr];
    if (monthOrDateStr.length === 7) {
      delete updated[`${monthOrDateStr}-01`];
      Object.keys(updated).forEach((key) => {
        if (key.startsWith(`${monthOrDateStr}-`)) {
          delete updated[key];
        }
      });
    } else if (monthOrDateStr.endsWith('-01')) {
      delete updated[monthOrDateStr.substring(0, 7)];
    }
    setMonthlyOverrides(updated);
    saveStoredMonthlyCommodityBalances(updated);
    saveStoredManualObMonth(monthOrDateStr, false);
  };

  const handleResetAllData = () => {
    resetAllApplicationData();
    setDailyEntries([]);
    setStockTransactions([]);
    setBaseCommodities(getStoredCommodities());
    setMonthlyOverrides({});
    setStudentStrengths(getStoredStudentStrength());
  };

  // Print Window Trigger with Orientation support
  const handleTriggerPrint = (orientation: 'landscape' | 'portrait' = 'landscape') => {
    let styleEl = document.getElementById('print-orientation-style');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'print-orientation-style';
      document.head.appendChild(styleEl);
    }
    styleEl.innerHTML = `@media print { @page { size: A4 ${orientation} !important; margin: 3mm !important; } }`;

    setIsPrintMode(true);
    setTimeout(() => {
      try {
        window.print();
      } catch (err) {
        console.error('Print dialog was blocked or failed:', err);
      }
    }, 150);
  };

  // Automatically reset print mode when print dialog closes
  useEffect(() => {
    const handleAfterPrint = () => {
      setIsPrintMode(false);
    };
    window.addEventListener('afterprint', handleAfterPrint);
    return () => {
      window.removeEventListener('afterprint', handleAfterPrint);
    };
  }, []);

  if (!user.isLoggedIn) {
    return (
      <>
        <LoginModal
          onLogin={handleLogin}
          schoolName={schoolProfile.schoolName}
          udiseCode={schoolProfile.udiseCode}
        />
        {showSplash && (
          <SplashScreen
            schoolProfile={schoolProfile}
            onFinish={() => {
              setShowSplash(false);
              setIsManualSplash(false);
            }}
            isManualPreview={isManualSplash}
          />
        )}
      </>
    );
  }

  return (
    <div className={`min-h-screen ${isPrintMode ? 'bg-white text-black' : 'bg-indigo-200/90 dark:bg-[#020512] text-slate-900 dark:text-slate-100'} flex flex-col font-sans transition-colors relative overflow-x-hidden selection:bg-indigo-500/30 selection:text-indigo-200 perspective-1000`}>
      {/* Ambient Deep 3D Indigo Dark Blue Mesh Background (hidden on print and in print mode) */}
      {!isPrintMode && (
        <>
          <div className="no-print fixed inset-0 pointer-events-none z-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-300/90 via-sky-300/80 to-blue-300/85 dark:from-[#0b1536] dark:via-[#050b22] dark:to-[#01030d]" />
          <div className="no-print fixed inset-0 pointer-events-none z-0 bg-[linear-gradient(to_right,#1e1b4b12_1px,transparent_1px),linear-gradient(to_bottom,#1e1b4b12_1px,transparent_1px)] dark:bg-[linear-gradient(to_right,#38bdf818_1px,transparent_1px),linear-gradient(to_bottom,#38bdf818_1px,transparent_1px)] bg-[size:24px_24px]" />
          <div className="no-print fixed top-0 left-1/4 w-[650px] h-[650px] bg-indigo-600/30 dark:bg-blue-600/30 rounded-full blur-[140px] pointer-events-none" />
          <div className="no-print fixed top-0 right-1/4 w-[550px] h-[550px] bg-blue-700/28 dark:bg-cyan-500/28 rounded-full blur-[140px] pointer-events-none" />
          <div className="no-print fixed bottom-10 right-10 w-[650px] h-[650px] bg-indigo-500/32 dark:bg-indigo-600/28 rounded-full blur-[160px] pointer-events-none" />
          <div className="no-print fixed top-1/3 left-10 w-[500px] h-[500px] bg-violet-600/25 dark:bg-sky-600/25 rounded-full blur-[150px] pointer-events-none" />
        </>
      )}

      {/* Official Top MDM Application Header (Includes prominent Theme toggle, School Info, and Settings) */}
      {!isPrintMode && (
        <Header
          schoolProfile={schoolProfile}
          user={user}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          onLogout={handleLogout}
          onOpenSettings={() => setActiveTab('settings')}
          showInstallButton={!isStandalone && !isInstalled}
          onInstallClick={installApp}
          onOpenFlashScreen={() => {
            setIsManualSplash(true);
            setShowSplash(true);
          }}
        />
      )}

      {/* Main Container with 3D Depth Layering */}
      <div className="flex-1 flex w-full max-w-[1920px] mx-auto relative z-10 preserve-3d">
        {/* View Content Area */}
        <main
          className={`flex-1 overflow-y-auto min-w-0 transition-all duration-300 ${isPrintMode ? 'p-0' : 'p-1 sm:p-2 md:p-2.5 lg:p-3 pb-16 sm:pb-24 md:pb-24 lg:pb-28'}`}
        >


          {activeTab === 'dashboard' && (
            <DashboardView
              schoolProfile={schoolProfile}
              dailyEntries={dailyEntries}
              mealRates={mealRates}
              commodities={commodities}
              baseCommodities={baseCommodities}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              studentStrengths={studentStrengths}
              onSaveEntry={handleSaveDailyEntry}
              onDeleteEntry={handleDeleteDailyEntry}
              onSaveStudentStrengths={handleSaveStudentStrengths}
              onNavigate={(tab) => setActiveTab(tab)}
              onPrintDashboard={handleTriggerPrint}
              onPrintRegister={handleTriggerPrint}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              onSaveStockTransactions={handleSaveAllStockTransactions}
              onUpdateMealRates={handleUpdateMealRates}
              onUpdateSchoolProfile={handleUpdateSchoolProfile}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
              onResetAllData={handleResetAllData}
              darkMode={darkMode}
              showInstallButton={!isStandalone && !isInstalled}
              onInstallClick={installApp}
            />
          )}

          {activeTab === 'daily-entry' && (
            <DailyEntryView
              dailyEntries={dailyEntries}
              studentStrengths={studentStrengths}
              commodities={commodities}
              baseCommodities={baseCommodities}
              mealRates={mealRates}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              onSaveEntry={handleSaveDailyEntry}
              onDeleteEntry={handleDeleteDailyEntry}
              onAddTransaction={handleAddStockTransaction}
              onUpdateTransaction={handleUpdateStockTransaction}
              onDeleteTransaction={handleDeleteStockTransaction}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              onNavigate={(tab) => setActiveTab(tab)}
              automationSettings={automationSettings}
            />
          )}

          {activeTab === 'student-strength' && (
            <StudentStrengthView
              studentStrengths={studentStrengths}
              onSaveStrengths={handleSaveStudentStrengths}
            />
          )}

          {activeTab === 'commodity-stock' && (
            <CommodityStockView
              commodities={commodities}
              baseCommodities={baseCommodities}
              dailyEntries={dailyEntries}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              onAddTransaction={handleAddStockTransaction}
              onUpdateTransaction={handleUpdateStockTransaction}
              onDeleteTransaction={handleDeleteStockTransaction}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              totalStudents={totalStudents}
            />
          )}

          {activeTab === 'monthly-summary' && (
            <MonthlySummaryView
              schoolProfile={schoolProfile}
              dailyEntries={dailyEntries}
              mealRates={mealRates}
              commodities={commodities}
              baseCommodities={baseCommodities}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              studentStrengths={studentStrengths}
              onSaveEntry={handleSaveDailyEntry}
              onDeleteEntry={handleDeleteDailyEntry}
              onSaveStudentStrengths={handleSaveStudentStrengths}
              onNavigate={(tab) => setActiveTab(tab)}
              onPrintRegister={handleTriggerPrint}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              onSaveStockTransactions={handleSaveAllStockTransactions}
              onUpdateMealRates={handleUpdateMealRates}
              onUpdateSchoolProfile={handleUpdateSchoolProfile}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
              onResetAllData={handleResetAllData}
              darkMode={darkMode}
              onClose={() => setActiveTab('dashboard')}
              showInstallButton={!isStandalone && !isInstalled}
              onInstallClick={installApp}
            />
          )}

          {activeTab === 'cash-voucher' && (
            <CashVoucherView
              schoolProfile={schoolProfile}
              dailyEntries={dailyEntries}
              mealRates={mealRates}
              commodities={commodities}
              baseCommodities={baseCommodities}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              studentStrengths={studentStrengths}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              onPrintVoucher={() => handleTriggerPrint('portrait')}
              onClose={() => setActiveTab('dashboard')}
              darkMode={darkMode}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView
              schoolProfile={schoolProfile}
              dailyEntries={dailyEntries}
              studentStrengths={studentStrengths}
              commodities={commodities}
              baseCommodities={baseCommodities}
              mealRates={mealRates}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              onPrintReport={handleTriggerPrint}
              darkMode={darkMode}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
              onClose={() => setActiveTab('dashboard')}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              schoolProfile={schoolProfile}
              mealRates={mealRates}
              darkMode={darkMode}
              onUpdateSchoolProfile={handleUpdateSchoolProfile}
              onUpdateMealRates={handleUpdateMealRates}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
              onResetAllData={handleResetAllData}
              onClose={() => setActiveTab('dashboard')}
              onOpenFlashScreen={() => {
                setIsManualSplash(true);
                setShowSplash(true);
              }}
              showInstallButton={!isStandalone && !isInstalled}
              onInstallClick={installApp}
              commodities={commodities}
              baseCommodities={baseCommodities}
              dailyEntries={dailyEntries}
              stockTransactions={stockTransactions}
              monthlyOverrides={monthlyOverrides}
              onSaveOpeningBalances={handleSaveOpeningBalances}
              onSaveMonthlyBalances={handleSaveMonthlyBalances}
              onResetMonthlyOverride={handleResetMonthlyOverride}
              onOpenFullModal={() => setActiveTab('commodity-stock')}
              automationSettings={automationSettings}
              onUpdateAutomationSettings={handleUpdateAutomationSettings}
              onSaveDailyEntry={handleSaveDailyEntry}
              onSwitchSchool={(newSchoolId) => {
                setActiveSchoolId(newSchoolId);
                refreshAllDataState(newSchoolId);
              }}
            />
          )}
        </main>
      </div>


      {/* Reserved Clean Bottom Clearance Space for Ads across All Devices */}
      {!isPrintMode && (
        <div
          id="bottom-ad-clearance-spacer"
          className="no-print w-full h-16 sm:h-20 md:h-24 lg:h-28 shrink-0 pointer-events-none"
          style={{ minHeight: 'calc(4.4rem + env(safe-area-inset-bottom, 0px))' }}
          aria-hidden="true"
        />
      )}

      {/* Startup & Manual Flash Screen */}
      {showSplash && (
        <SplashScreen
          schoolProfile={schoolProfile}
          onFinish={() => {
            setShowSplash(false);
            setIsManualSplash(false);
          }}
          isManualPreview={isManualSplash}
        />
      )}

      {/* Offline Connectivity Status Toast */}
      <OfflineIndicator />

      {/* PWA Update Ready Banner */}
      <PWAUpdateBanner show={updateAvailable} onUpdate={updateApp} />

      {/* PWA Floating Install Prompt Banner (Non-intrusive) */}
      <PWAInstallBanner
        hasDeferredPrompt={hasDeferredPrompt}
        isInstalled={isInstalled}
        isStandalone={isStandalone}
        onInstall={installApp}
        onOpenModal={() => setShowInstallModal(true)}
      />

      {/* PWA High-Polish Install Guidance & 1-Click Modal */}
      <PWAInstallModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
        onInstall={installApp}
        isIOS={isIOS}
        hasDeferredPrompt={hasDeferredPrompt}
      />
    </div>
  );
}
