import { AppSettings, CommodityItem, DailyEntry, MealRates, SchoolProfile, StockTransaction, StudentClassStrength } from '../types';

/**
 * Convert number to words in Indian Numbering System (Rupees)
 */
export function numToWords(amount: number): string {
  if (isNaN(amount) || amount === 0) return 'Rupees Zero Only';

  const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const double = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const convertTwoDigits = (num: number): string => {
    if (num < 10) return single[num];
    if (num < 20) return double[num - 10];
    const tenVal = Math.floor(num / 10);
    const unitVal = num % 10;
    return (tens[tenVal] + (unitVal > 0 ? ' ' + single[unitVal] : '')).trim();
  };

  const convertThreeDigits = (num: number): string => {
    const hundred = Math.floor(num / 100);
    const rest = num % 100;
    let str = '';
    if (hundred > 0) {
      str += single[hundred] + ' Hundred';
    }
    if (rest > 0) {
      str += (str.length > 0 ? ' ' : '') + convertTwoDigits(rest);
    }
    return str;
  };

  const integerPart = Math.floor(Math.abs(amount));
  const decimalPart = Math.round((Math.abs(amount) - integerPart) * 100);

  let rupeesStr = '';
  let temp = integerPart;

  if (temp >= 10000000) {
    const crore = Math.floor(temp / 10000000);
    rupeesStr += convertTwoDigits(crore) + ' Crore ';
    temp %= 10000000;
  }
  if (temp >= 100000) {
    const lakh = Math.floor(temp / 100000);
    rupeesStr += convertTwoDigits(lakh) + ' Lakh ';
    temp %= 100000;
  }
  if (temp >= 1000) {
    const thousand = Math.floor(temp / 1000);
    rupeesStr += convertTwoDigits(thousand) + ' Thousand ';
    temp %= 1000;
  }
  if (temp > 0) {
    rupeesStr += convertThreeDigits(temp);
  }

  rupeesStr = rupeesStr.trim() || 'Zero';

  let result = `Rupees ${rupeesStr}`;
  if (decimalPart > 0) {
    result += ` and ${convertTwoDigits(decimalPart)} Paise`;
  }
  return `${result} Only`;
}

/**
 * Format Currency (INR ₹)
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Format Date to readable Indian format (e.g. 01.Aug.26)
 */
export function formatDateReadable(dateStr: string): string {
  if (!dateStr) return '';
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    const dd = String(day).padStart(2, '0');
    const mmm = months[month] || '';
    const yy = String(year).slice(-2);
    return `${dd}.${mmm}.${yy}`;
  }
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;
  const dd = String(date.getDate()).padStart(2, '0');
  const mmm = months[date.getMonth()] || '';
  const yy = String(date.getFullYear()).slice(-2);
  return `${dd}.${mmm}.${yy}`;
}

export interface DayDetails {
  dayName: string;         // "Sunday", "Monday", ...
  shortDayName: string;    // "Sun", "Mon", ...
  dayOfWeek: number;       // 0 = Sun, 1 = Mon, ..., 6 = Sat
  formattedDate: string;   // "03 Aug 2026"
  isSunday: boolean;
  isHoliday: boolean;
  holidayName?: string;    // "Sunday", "Republic Day", etc.
  isWorkingDayOverride?: boolean;
}

export interface APHolidayInfo {
  date: string; // YYYY-MM-DD
  monthDay: string; // MM-DD
  name: string;
  teluguName?: string;
  category: 'NATIONAL' | 'STATE_FESTIVAL' | 'SCHOOL_VACATION';
  description?: string;
}

// Official School Education Holidays Map
// Notified under General Administration Department
// & School Education Department (Academic Calendar) for Teachers & Schools
export const AP_GOVERNMENT_HOLIDAYS_BY_DATE: Record<string, string> = {
  // --- 2024 Calendar (AP School Education & General Holidays) ---
  '2024-01-01': "New Year's Day",
  '2024-01-12': 'Sankranti Vacation Begins',
  '2024-01-13': 'Bhogi (Sankranti Festival)',
  '2024-01-14': 'Makara Sankranti / Pongal',
  '2024-01-15': 'Kanuma Festival',
  '2024-01-16': 'Sankranti Vacation',
  '2024-01-17': 'Sankranti Vacation Ends',
  '2024-01-26': 'Republic Day (National Holiday)',
  '2024-03-08': 'Maha Shivaratri',
  '2024-03-25': 'Holi Festival',
  '2024-03-29': 'Good Friday',
  '2024-04-05': 'Babu Jagjivan Ram Jayanti',
  '2024-04-09': 'Ugadi (Telugu New Year)',
  '2024-04-11': 'Eid-ul-Fitr (Ramzan)',
  '2024-04-14': 'Dr. B.R. Ambedkar Jayanti',
  '2024-04-17': 'Sri Rama Navami',
  '2024-05-01': 'May Day / Labour Day',
  '2024-06-17': 'Bakrid / Eid-ul-Adha',
  '2024-07-17': 'Moharrum',
  '2024-08-15': 'Independence Day (National Holiday)',
  '2024-08-16': 'Varalakshmi Vratham',
  '2024-09-07': 'Vinayaka Chavithi (Ganesh Chaturthi)',
  '2024-09-16': 'Eid Milad-un-Nabi',
  '2024-10-02': 'Mahatma Gandhi Jayanti (National Holiday)',
  '2024-10-11': 'Durgashtami / Mahanavami',
  '2024-10-12': 'Vijayadasami (Dasara Holiday)',
  '2024-10-31': 'Deepavali / Diwali Festival',
  '2024-11-01': 'Andhra Pradesh Formation Day',
  '2024-11-15': 'Guru Nanak Jayanti',
  '2024-12-25': 'Christmas (Public Holiday)',

  // --- 2025 Calendar (School Academic Calendar) ---
  '2025-01-01': "New Year's Day",
  '2025-01-11': 'Sankranti Vacation Begins',
  '2025-01-12': 'Sankranti Vacation',
  '2025-01-13': 'Bhogi (Sankranti Festival)',
  '2025-01-14': 'Makara Sankranti / Pongal',
  '2025-01-15': 'Kanuma Festival',
  '2025-01-16': 'Sankranti Vacation',
  '2025-01-17': 'Sankranti Vacation',
  '2025-01-18': 'Sankranti Vacation Ends',
  '2025-01-26': 'Republic Day (National Holiday)',
  '2025-02-26': 'Maha Shivaratri',
  '2025-03-14': 'Holi Festival',
  '2025-03-30': 'Ugadi (Telugu New Year)',
  '2025-03-31': 'Eid-ul-Fitr (Ramzan)',
  '2025-04-05': 'Babu Jagjivan Ram Jayanti',
  '2025-04-06': 'Sri Rama Navami',
  '2025-04-14': 'Dr. B.R. Ambedkar Jayanti',
  '2025-04-18': 'Good Friday',
  '2025-05-01': 'May Day / Labour Day',
  '2025-06-07': 'Bakrid / Eid-ul-Adha',
  '2025-07-06': 'Moharrum',
  '2025-08-15': 'Independence Day (National Holiday)',
  '2025-08-27': 'Vinayaka Chavithi (Ganesh Chaturthi)',
  '2025-09-05': 'Eid Milad-un-Nabi',
  '2025-09-24': 'Dasara Vacation Begins',
  '2025-09-25': 'Dasara Vacation Holiday',
  '2025-09-26': 'Dasara Vacation Holiday',
  '2025-09-27': 'Dasara Vacation Holiday',
  '2025-09-28': 'Dasara Vacation Holiday',
  '2025-09-29': 'Dasara Vacation Holiday',
  '2025-09-30': 'Dasara Vacation Holiday',
  '2025-10-01': 'Mahanavami / Durgashtami',
  '2025-10-02': 'Mahatma Gandhi Jayanti & Vijayadasami',
  '2025-10-20': 'Deepavali / Diwali Festival',
  '2025-11-01': 'Andhra Pradesh Formation Day',
  '2025-11-05': 'Guru Nanak Jayanti',
  '2025-12-25': 'Christmas (Public Holiday)',

  // --- 2026 Calendar (School Academic Calendar) ---
  '2026-01-01': "New Year's Day",
  '2026-01-10': 'Sankranti Vacation Begins',
  '2026-01-11': 'Sankranti Vacation',
  '2026-01-12': 'Sankranti Vacation',
  '2026-01-13': 'Sankranti Vacation',
  '2026-01-14': 'Bhogi (Sankranti Festival)',
  '2026-01-15': 'Makara Sankranti / Pongal',
  '2026-01-16': 'Kanuma Festival',
  '2026-01-17': 'Sankranti Vacation',
  '2026-01-18': 'Sankranti Vacation Ends',
  '2026-01-26': 'Republic Day (National Holiday)',
  '2026-02-15': 'Maha Shivaratri',
  '2026-03-03': 'Holi Festival',
  '2026-03-19': 'Ugadi (Telugu New Year)',
  '2026-03-20': 'Eid-ul-Fitr (Ramzan)',
  '2026-03-27': 'Sri Rama Navami',
  '2026-04-03': 'Good Friday',
  '2026-04-05': 'Babu Jagjivan Ram Jayanti',
  '2026-04-14': 'Dr. B.R. Ambedkar Jayanti',
  '2026-05-01': 'May Day / Labour Day',
  '2026-05-27': 'Bakrid / Eid-ul-Adha',
  '2026-06-25': 'Moharrum (9th Moharram)',
  '2026-06-26': 'Moharrum (10th Moharram / G.O. Rt. No. 2276)',
  '2026-08-15': 'Independence Day (National Holiday)',
  '2026-08-21': 'Varalakshmi Vratham',
  '2026-08-25': 'Eid Milad-un-Nabi',
  '2026-09-04': 'Sri Krishna Janmashtami',
  '2026-09-14': 'Vinayaka Chavithi (Ganesh Chaturthi)',
  '2026-10-02': 'Mahatma Gandhi Jayanti (National Holiday)',
  '2026-10-12': 'Dasara Vacation Begins',
  '2026-10-13': 'Dasara Vacation Holiday',
  '2026-10-14': 'Dasara Vacation Holiday',
  '2026-10-15': 'Dasara Vacation Holiday',
  '2026-10-16': 'Dasara Vacation Holiday',
  '2026-10-17': 'Dasara Vacation Holiday',
  '2026-10-18': 'Durgashtami / Mahanavami',
  '2026-10-19': 'Dasara Vacation Holiday',
  '2026-10-20': 'Vijayadasami (Dasara Holiday)',
  '2026-10-21': 'Dasara Vacation Ends',
  '2026-11-01': 'Andhra Pradesh Formation Day',
  '2026-11-08': 'Deepavali / Diwali Festival',
  '2026-11-09': 'Deepavali Holiday',
  '2026-11-24': 'Guru Nanak Jayanti',
  '2026-12-25': 'Christmas (Public Holiday)',

  // --- 2027 Calendar (AP School Education & General Holidays) ---
  '2027-01-01': "New Year's Day",
  '2027-01-11': 'Sankranti Vacation Begins',
  '2027-01-12': 'Sankranti Vacation',
  '2027-01-13': 'Sankranti Vacation',
  '2027-01-14': 'Bhogi (Sankranti Festival)',
  '2027-01-15': 'Makara Sankranti / Pongal',
  '2027-01-16': 'Kanuma Festival',
  '2027-01-17': 'Sankranti Vacation Ends',
  '2027-01-26': 'Republic Day (National Holiday)',
  '2027-03-06': 'Maha Shivaratri',
  '2027-03-10': 'Eid-ul-Fitr (Ramzan)',
  '2027-03-22': 'Holi Festival',
  '2027-03-26': 'Good Friday',
  '2027-04-05': 'Babu Jagjivan Ram Jayanti',
  '2027-04-07': 'Ugadi (Telugu New Year)',
  '2027-04-14': 'Dr. B.R. Ambedkar Jayanti',
  '2027-04-16': 'Sri Rama Navami',
  '2027-05-01': 'May Day / Labour Day',
  '2027-05-17': 'Bakrid / Eid-ul-Adha',
  '2027-06-15': 'Moharrum',
  '2027-08-15': 'Independence Day (National Holiday)',
  '2027-08-16': 'Eid Milad-un-Nabi',
  '2027-08-27': 'Sri Krishna Janmashtami',
  '2027-09-05': 'Vinayaka Chavithi (Ganesh Chaturthi)',
  '2027-10-02': 'Mahatma Gandhi Jayanti (National Holiday)',
  '2027-10-09': 'Vijayadasami (Dasara Holiday)',
  '2027-10-29': 'Deepavali / Diwali Festival',
  '2027-11-01': 'Andhra Pradesh Formation Day',
  '2027-12-25': 'Christmas (Public Holiday)',
};

// Recurring Fixed Date Holidays (Fall-back for any year)
export const AP_FIXED_ANNUAL_HOLIDAYS: Record<string, string> = {
  '01-01': "New Year's Day",
  '01-14': 'Bhogi (Sankranti Festival)',
  '01-15': 'Makara Sankranti / Pongal',
  '01-16': 'Kanuma Festival',
  '01-26': 'Republic Day (National Holiday)',
  '04-05': 'Babu Jagjivan Ram Jayanti',
  '04-14': 'Dr. B.R. Ambedkar Jayanti',
  '05-01': 'May Day / Labour Day',
  '08-15': 'Independence Day (National Holiday)',
  '10-02': 'Mahatma Gandhi Jayanti (National Holiday)',
  '11-01': 'Andhra Pradesh Formation Day',
  '12-25': 'Christmas (Public Holiday)',
};

/**
 * Returns structured official School Education holidays list for a specific year
 */
export function getAPOfficialHolidaysList(year: number): APHolidayInfo[] {
  const prefix = `${year}-`;
  const results: APHolidayInfo[] = [];

  // Match all entries for the year in AP_GOVERNMENT_HOLIDAYS_BY_DATE
  Object.entries(AP_GOVERNMENT_HOLIDAYS_BY_DATE).forEach(([date, name]) => {
    if (date.startsWith(prefix)) {
      const monthDay = date.substring(5);
      let category: APHolidayInfo['category'] = 'STATE_FESTIVAL';
      if (name.includes('National') || name.includes('Republic Day') || name.includes('Independence') || name.includes('Gandhi Jayanti')) {
        category = 'NATIONAL';
      } else if (name.includes('Vacation')) {
        category = 'SCHOOL_VACATION';
      }

      results.push({
        date,
        monthDay,
        name,
        category,
      });
    }
  });

  // If no specific dates for the year, provide standard annual fixed holidays
  if (results.length === 0) {
    Object.entries(AP_FIXED_ANNUAL_HOLIDAYS).forEach(([monthDay, name]) => {
      const date = `${year}-${monthDay}`;
      let category: APHolidayInfo['category'] = 'STATE_FESTIVAL';
      if (name.includes('National') || name.includes('Republic Day') || name.includes('Independence') || name.includes('Gandhi Jayanti')) {
        category = 'NATIONAL';
      }
      results.push({
        date,
        monthDay,
        name,
        category,
      });
    });
  }

  // Sort by date ascending
  return results.sort((a, b) => a.date.localeCompare(b.date));
}

/**
 * Get detailed day information including day name, Sunday & Holiday detection
 */
export function getDayDetails(dateStr: string): DayDetails {
  if (!dateStr) {
    return {
      dayName: '',
      shortDayName: '',
      dayOfWeek: 0,
      formattedDate: '',
      isSunday: false,
      isHoliday: false,
    };
  }

  const parts = dateStr.split('-');
  let dateObj: Date;
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    dateObj = new Date(year, month, day);
  } else {
    dateObj = new Date(dateStr);
  }

  const dayOfWeek = dateObj.getDay(); // 0 = Sun, 1 = Mon, ..., 6 = Sat

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const shortDayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const dayName = dayNames[dayOfWeek] || '';
  const shortDayName = shortDayNames[dayOfWeek] || '';

  const formattedDate = formatDateReadable(dateStr);

  const isSunday = dayOfWeek === 0;

  // Official School Education Holidays Map
  // Based on School Academic Calendar
  const keyYYYYMMDD = dateStr;
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const d = String(dateObj.getDate()).padStart(2, '0');
  const keyMMDD = `${m}-${d}`;

  const calendarHoliday = AP_GOVERNMENT_HOLIDAYS_BY_DATE[keyYYYYMMDD] || AP_FIXED_ANNUAL_HOLIDAYS[keyMMDD];

  const isSecondSaturday = dayOfWeek === 6 && Math.ceil(dateObj.getDate() / 7) === 2;

  let customHolidayName = '';
  try {
    if (typeof window !== 'undefined') {
      const sId = localStorage.getItem('mdm_active_school_id') || 'default';
      const stored = localStorage.getItem(`${sId}__mdm_custom_holidays`) || localStorage.getItem('mdm_custom_holidays');
      if (stored) {
        const customHolidaysMap = JSON.parse(stored);
        customHolidayName = customHolidaysMap[dateStr] || '';
      }
    }
  } catch (e) {
    console.error('Error reading custom holidays:', e);
  }

  let isHoliday = isSunday || isSecondSaturday || Boolean(calendarHoliday) || Boolean(customHolidayName);

  let holidayName: string | undefined = undefined;
  if (isSunday) {
    holidayName = 'Sunday Holiday';
  } else if (isSecondSaturday) {
    holidayName = 'Second Saturday';
  } else if (calendarHoliday) {
    holidayName = calendarHoliday;
  }

  let isWorkingDayOverride = false;
  if (customHolidayName) {
    if (customHolidayName === 'WORKING_DAY') {
      isHoliday = false;
      holidayName = undefined;
      isWorkingDayOverride = true;
    } else {
      isHoliday = true;
      holidayName = customHolidayName;
    }
  }

  return {
    dayName,
    shortDayName,
    dayOfWeek,
    formattedDate,
    isSunday: isWorkingDayOverride ? false : isSunday,
    isHoliday,
    holidayName,
    isWorkingDayOverride,
  };
}

export interface DailyStockItem {
  ob: number;
  rec: number;
  used: number;
  spoiled: number;
  cb: number;
  prevDate?: string;
  lastActiveDate?: string;
  lastActiveCb?: number;
  sourceType?: 'INITIAL' | 'CARRIED_FORWARD' | 'MONTHLY_OVERRIDE' | 'ADJUSTMENT';
  sourceDescription?: string;
  isValid?: boolean;
  expectedOpening?: number;
  difference?: number;
}

export interface DayCommodityStockMap {
  [dateStr: string]: {
    [commodityId: string]: DailyStockItem;
  };
}

/**
 * Decimal-safe 3-decimal rounding helper to eliminate floating point artifacts like 3.624999999
 * Robustly preserves negative values (-5, -10, -3, etc.) and eliminates negative zero (-0)
 */
export function safeRound3(val: number | undefined | null): number {
  if (val === undefined || val === null || isNaN(val)) return 0;
  if (val === 0) return 0;
  const sign = val < 0 ? -1 : 1;
  const rounded = sign * (Math.round((Math.abs(val) + Number.EPSILON) * 1000) / 1000);
  return rounded === 0 ? 0 : rounded;
}

/**
 * Format quantity numbers cleanly supporting minus numbers and decimal precision (up to 3 decimal places)
 * Displays negative values directly (e.g. -5, -10, -3, -8) without converting to zero, blank, or absolute value
 */
export function formatQtyVal(val: number | undefined | null): string {
  if (val === undefined || val === null || isNaN(val)) return '0';
  const rounded = safeRound3(val);
  if (rounded === 0) return '0';
  return rounded.toString();
}

/**
 * Generate a continuous list of YYYY-MM months with no gaps between min and max month
 */
export function generateContinuousMonthRange(monthsList: string[]): string[] {
  if (monthsList.length === 0) {
    const current = new Date().toISOString().substring(0, 7);
    return [current];
  }

  const validMonths = monthsList
    .filter((m) => m && m.length === 7 && m.includes('-'))
    .sort();

  if (validMonths.length === 0) {
    return [new Date().toISOString().substring(0, 7)];
  }

  const minM = validMonths[0];
  const maxM = validMonths[validMonths.length - 1];

  const [minY, minMo] = minM.split('-').map((n) => parseInt(n, 10));
  const [maxY, maxMo] = maxM.split('-').map((n) => parseInt(n, 10));

  const startY = minY;
  const startMo = minMo;
  const endY = maxY;
  const endMo = maxMo;

  const continuous: string[] = [];
  let curY = startY;
  let curMo = startMo;

  while (curY < endY || (curY === endY && curMo <= endMo)) {
    continuous.push(`${curY}-${String(curMo).padStart(2, '0')}`);
    curMo++;
    if (curMo > 12) {
      curMo = 1;
      curY++;
    }
  }

  return continuous;
}

/**
 * Calculates day-by-day Opening Balance, Received, Used, Spoiled, and Closing Balance
 * for all commodities based on initial opening balances, stock transactions, and daily entries.
 * Automatically carries forward the previous day's closing balance as today's opening balance continuously day-by-day.
 * 
 * CORE RULES:
 * 1. Opening Balance of today = Closing Balance of previous day.
 * 2. Month boundaries never reset balances: 31-08-2026 Closing Balance automatically carries to 01-09-2026 Opening Balance.
 * 3. Skipped dates: If dates have no entries/transactions, balance carries across unbroken.
 * 4. Historical edits/deletions immediately cascade forward to all subsequent dates.
 * 5. Uses strict 3-decimal math with audit trail metadata.
 */
export function calculateDailyCommodityStock(
  allDailyEntries: DailyEntry[],
  stockTransactions: StockTransaction[],
  commodities: CommodityItem[],
  monthlyOverrides: Record<string, Record<string, number>> = {},
  extraMonthsOrDates: string[] = [],
  manualObMonths: Record<string, boolean> = {}
): DayCommodityStockMap {
  const result: DayCommodityStockMap = {};

  const initialOBMap: Record<string, number> = {};
  commodities.forEach((c) => {
    initialOBMap[c.id] = safeRound3(c.openingBalance ?? 0);
  });
  if (initialOBMap['ragi'] !== undefined && (commodities.some(c => c.id === 'jaggery'))) {
    initialOBMap['jaggery'] = initialOBMap['ragi'];
  }

  const commIds = commodities.map((c) => c.id);

  // Collect all months mentioned in entries, transactions, overrides, extra dates, and current calendar
  const rawMonths = new Set<string>();
  const currentMonthStr = new Date().toISOString().substring(0, 7);
  rawMonths.add(currentMonthStr);
  rawMonths.add('2026-08'); // Baseline starting academic month to guarantee continuous unbroken stock cascade

  allDailyEntries.forEach((e) => {
    if (e.date && e.date.length >= 7) rawMonths.add(e.date.substring(0, 7));
  });
  stockTransactions.forEach((tx) => {
    if (tx.date && tx.date.length >= 7) rawMonths.add(tx.date.substring(0, 7));
  });
  Object.keys(monthlyOverrides).forEach((m) => {
    if (m && m.length >= 7) rawMonths.add(m.substring(0, 7));
  });
  extraMonthsOrDates.forEach((d) => {
    if (d && d.length >= 7) rawMonths.add(d.substring(0, 7));
  });

  // Generate completely continuous sequence of months without any gap
  const sortedMonths = generateContinuousMonthRange(Array.from(rawMonths));

  // Pre-index entries by date
  const entryByDate: Record<string, DailyEntry> = {};
  allDailyEntries.forEach((e) => {
    entryByDate[e.date] = e;
  });

  // Pre-index transactions by date and commodity
  // Support RECEIVED, SPOILED, and ADJUSTMENT types
  const txByDateAndComm: Record<string, Record<string, { rec: number; spoiled: number; adjustment?: number; remarks?: string }>> = {};
  stockTransactions.forEach((tx) => {
    // Ignore legacy mid-month opening balance adjustments that were wrongly placed on previous day
    if (tx.id?.startsWith('tx-ob-adj-') || (tx.remarks && tx.remarks.startsWith('Opening balance for '))) {
      return;
    }
    if (!txByDateAndComm[tx.date]) txByDateAndComm[tx.date] = {};
    if (!txByDateAndComm[tx.date][tx.commodityId]) {
      txByDateAndComm[tx.date][tx.commodityId] = { rec: 0, spoiled: 0 };
    }
    const qty = safeRound3(tx.quantity);
    if (tx.type === 'RECEIVED') {
      txByDateAndComm[tx.date][tx.commodityId].rec = safeRound3(txByDateAndComm[tx.date][tx.commodityId].rec + qty);
    } else if (tx.type === 'SPOILED') {
      txByDateAndComm[tx.date][tx.commodityId].spoiled = safeRound3(txByDateAndComm[tx.date][tx.commodityId].spoiled + qty);
    } else if (tx.type === 'ADJUSTMENT') {
      txByDateAndComm[tx.date][tx.commodityId].adjustment = qty;
      txByDateAndComm[tx.date][tx.commodityId].remarks = tx.remarks || tx.adjustmentReason;
    }
  });

  // Mirror stock transactions for Jaggery from Ragi to ensure identical receipts and spoils
  Object.keys(txByDateAndComm).forEach((dStr) => {
    if (txByDateAndComm[dStr]['ragi']) {
      txByDateAndComm[dStr]['jaggery'] = { ...txByDateAndComm[dStr]['ragi'] };
    }
  });

  const getUsedOnDate = (_dateStr: string, entry: DailyEntry | undefined, commId: string): number => {
    if (entry) {
      if (entry.commodityUsage && typeof entry.commodityUsage[commId] === 'number') {
        return safeRound3(entry.commodityUsage[commId]);
      }
      switch (commId) {
        case 'rice': return safeRound3(entry.riceUsedKg || 0);
        case 'oil': return safeRound3(entry.oilUsedLitres || 0);
        case 'pulses': return safeRound3(entry.pulsesUsedKg || 0);
        case 'egg': return safeRound3(entry.eggUsedQty || 0);
        case 'chikki': return safeRound3(entry.chikkiUsedQty || 0);
        case 'ragi': return safeRound3(entry.ragiUsedKg || 0);
        case 'jaggery': {
          const rUsed = safeRound3(entry.ragiUsedKg || 0);
          const jUsed = safeRound3(entry.jaggeryUsedKg || 0);
          return rUsed > 0 ? rUsed : jUsed;
        }
        case 'condiments': return safeRound3(entry.condimentsUsedKg || 0);
        default: return 0;
      }
    }
    // If no entry exists for this date, usage is 0 (no unrecorded phantom usage)
    return 0;
  };

  const currentBalance: Record<string, number> = { ...initialOBMap };
  const lastActiveDateMap: Record<string, string> = {};
  const lastActiveCbMap: Record<string, number> = {};

  // Traverse all months and all days chronologically so that yesterday's closing balance
  // is seamlessly carried forward to today's opening balance
  sortedMonths.forEach((monthStr, monthIdx) => {
    const parts = monthStr.split('-');
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const daysInMonth = isNaN(year) || isNaN(month) ? 30 : new Date(year, month, 0).getDate();

    if (monthIdx === 0) {
      // First month begins with the base commodities opening balances or monthly override if provided
      commIds.forEach((commId) => {
        const mOverride = monthlyOverrides[monthStr]?.[commId] ?? monthlyOverrides[`${monthStr}-01`]?.[commId];
        currentBalance[commId] = typeof mOverride === 'number' ? safeRound3(mOverride) : (initialOBMap[commId] || 0);
      });
      if (currentBalance['ragi'] !== undefined && (commIds.includes('jaggery') || commodities.some(c => c.id === 'jaggery'))) {
        currentBalance['jaggery'] = currentBalance['ragi'];
      }
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${monthStr}-${String(d).padStart(2, '0')}`;
      const entry = entryByDate[dateStr];
      const dateTxs = txByDateAndComm[dateStr] || {};

      // Compute immediate previous calendar date
      const dateObj = new Date(`${dateStr}T12:00:00`);
      dateObj.setDate(dateObj.getDate() - 1);
      const prevDate = dateObj.toISOString().split('T')[0];

      result[dateStr] = {};

      commIds.forEach((commId) => {
        const commMeta = commodities.find((c) => c.id === commId);
        const unit = commMeta?.unit || 'Kg';

        // Check if there is an explicit Opening Balance override for this date or month-start
        let dateObOverride: number | undefined = undefined;

        if (monthlyOverrides[dateStr] && typeof monthlyOverrides[dateStr][commId] === 'number') {
          dateObOverride = safeRound3(monthlyOverrides[dateStr][commId]);
        } else if (d === 1) {
          const isBaseline = monthStr === '2026-08' || monthIdx === 0;
          const hasManualFlag = Boolean(manualObMonths[monthStr] || manualObMonths[`${monthStr}-01`] || manualObMonths[dateStr]);
          const hasManualMap = Object.keys(manualObMonths).length > 0;
          const shouldOverride = !hasManualMap ? true : (isBaseline || hasManualFlag);

          if (shouldOverride) {
            if (typeof monthlyOverrides[monthStr]?.[commId] === 'number') {
              dateObOverride = safeRound3(monthlyOverrides[monthStr][commId]);
            } else if (typeof monthlyOverrides[`${monthStr}-01`]?.[commId] === 'number') {
              dateObOverride = safeRound3(monthlyOverrides[`${monthStr}-01`][commId]);
            }
          }
        }

        const hasOverride = typeof dateObOverride === 'number';
        if (hasOverride) {
          currentBalance[commId] = dateObOverride!;
        }

        // Today's Opening Balance is strictly equal to current balance (which is yesterday's Closing Balance or override)
        const ob = currentBalance[commId] !== undefined ? safeRound3(currentBalance[commId]) : (initialOBMap[commId] || 0);
        const expectedOpening = ob;

        const dateTx = dateTxs[commId];
        const rec = dateTx ? dateTx.rec : 0;
        const spoiled = dateTx ? dateTx.spoiled : 0;
        const used = getUsedOnDate(dateStr, entry, commId);

        let cb = safeRound3(ob + rec - used - spoiled);

        let sourceType: 'INITIAL' | 'CARRIED_FORWARD' | 'MONTHLY_OVERRIDE' | 'ADJUSTMENT' = 'CARRIED_FORWARD';
        let sourceDescription = '';

        const isLastDayTargetComm = (d === daysInMonth || d === 31) && ['rice', 'egg', 'chikki', 'ragi', 'jaggery'].includes(commId);

        if (hasOverride) {
          sourceType = 'MONTHLY_OVERRIDE';
          sourceDescription = d === 1 ? `Monthly Opening Stock Override (${ob} ${unit})` : `Opening Stock Override for ${dateStr} (${ob} ${unit})`;
        } else if (monthIdx === 0 && d === 1) {
          sourceType = 'INITIAL';
          sourceDescription = `Initial Starting Stock (${ob} ${unit})`;
        } else if (dateTx && typeof dateTx.adjustment === 'number' && !isLastDayTargetComm) {
          sourceType = 'ADJUSTMENT';
          sourceDescription = dateTx.remarks ? `Adjustment: ${dateTx.remarks}` : `Manual Adjustment to ${dateTx.adjustment} ${unit}`;
          cb = safeRound3(dateTx.adjustment);
        } else {
          sourceType = 'CARRIED_FORWARD';
          sourceDescription = `Auto carried forward from ${prevDate} (Closing: ${ob} ${unit})`;
        }

        // On month-end row, balance strictly equals ob + rec - used - spoiled for rice, egg, chikki, ragi, jaggery
        if (isLastDayTargetComm) {
          cb = safeRound3(ob + rec - used - spoiled);
        }

        const isValid = true;
        const difference = 0;

        // If today had activity (receipts, meals, spoilage, override, or adjustment), mark today as last active
        if (rec > 0 || used > 0 || spoiled > 0 || hasOverride || (dateTx && typeof dateTx.adjustment === 'number') || (monthIdx === 0 && d === 1)) {
          lastActiveDateMap[commId] = dateStr;
          lastActiveCbMap[commId] = cb;
        }

        result[dateStr][commId] = {
          ob,
          rec,
          used,
          spoiled,
          cb,
          prevDate,
          lastActiveDate: lastActiveDateMap[commId] || prevDate,
          lastActiveCb: lastActiveCbMap[commId] !== undefined ? lastActiveCbMap[commId] : ob,
          sourceType,
          sourceDescription,
          isValid,
          expectedOpening,
          difference,
        };

        // Carry forward to next day
        currentBalance[commId] = cb;
      });

      // Strictly synchronize Jaggery with Ragi across all metrics (OB, Received, Used, Spoiled, Closing Balance)
      if (result[dateStr]['ragi'] && result[dateStr]['jaggery']) {
        const ragiStock = result[dateStr]['ragi'];
        result[dateStr]['jaggery'] = {
          ...ragiStock,
          sourceDescription: ragiStock.sourceDescription.replace(/Ragi/gi, 'Jaggery'),
        };
        currentBalance['jaggery'] = currentBalance['ragi'];
        if (lastActiveDateMap['ragi']) lastActiveDateMap['jaggery'] = lastActiveDateMap['ragi'];
        if (lastActiveCbMap['ragi'] !== undefined) lastActiveCbMap['jaggery'] = lastActiveCbMap['ragi'];
      }
    }
  });

  return result;
}

/**
 * Helper to fetch day-specific stock status (Opening Balance, Received, Used, Spoiled, Closing Balance)
 * for any given date with optional live usage overrides (for immediate real-time feedback).
 * Provides rich audit and verification data.
 */
export function getDailyCommodityBalanceForDate(
  targetDate: string,
  allDailyEntries: DailyEntry[],
  stockTransactions: StockTransaction[],
  commodities: CommodityItem[],
  monthlyOverrides: Record<string, Record<string, number>> = {},
  liveUsage?: Record<string, number>
): Record<string, DailyStockItem> {
  const targetMonth = targetDate ? targetDate.substring(0, 7) : '';
  const extraMonths: string[] = [targetDate];
  if (targetMonth) {
    extraMonths.push(targetMonth);
    const [y, m] = targetMonth.split('-').map(Number);
    if (!isNaN(y) && !isNaN(m)) {
      const prevDate = new Date(y, m - 2, 1);
      extraMonths.push(`${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`);
    }
  }
  const stockMap = calculateDailyCommodityStock(
    allDailyEntries,
    stockTransactions,
    commodities,
    monthlyOverrides,
    extraMonths
  );
  const targetDayStock = stockMap[targetDate];

  const targetDateObj = new Date(`${targetDate}T12:00:00`);
  targetDateObj.setDate(targetDateObj.getDate() - 1);
  const prevDate = targetDateObj.toISOString().split('T')[0];

  const result: Record<string, DailyStockItem> = {};

  commodities.forEach((c) => {
    const defaultData = targetDayStock?.[c.id] || {
      ob: safeRound3(c.openingBalance ?? 0),
      rec: 0,
      used: 0,
      spoiled: 0,
      cb: safeRound3(c.openingBalance ?? 0),
      prevDate,
      sourceType: 'INITIAL',
      sourceDescription: `Initial Base Opening Stock`,
      isValid: true,
      expectedOpening: safeRound3(c.openingBalance ?? 0),
      difference: 0,
    };

    const ob = defaultData.ob;
    const rec = defaultData.rec;
    const spoiled = defaultData.spoiled;
    const used = liveUsage && typeof liveUsage[c.id] === 'number' ? safeRound3(liveUsage[c.id]) : defaultData.used;
    const cb = safeRound3(ob + rec - used - spoiled);

    result[c.id] = {
      ...defaultData,
      ob,
      rec,
      used,
      spoiled,
      cb,
      prevDate: defaultData.prevDate || prevDate,
    };
  });

  if (result['ragi'] && result['jaggery']) {
    result['jaggery'] = {
      ...result['ragi'],
      sourceDescription: result['ragi'].sourceDescription.replace(/Ragi/gi, 'Jaggery'),
    };
  }

  return result;
}

/**
 * Validates month-end carry-forward continuity for a given month
 */
export function validateMonthEndCarryForward(
  monthStr: string,
  commodities: CommodityItem[],
  dailyEntries: DailyEntry[],
  stockTransactions: StockTransaction[],
  monthlyOverrides: Record<string, Record<string, number>> = {}
): Array<{
  commodityId: string;
  commodityName: string;
  unit: string;
  monthClosingBalance: number;
  nextMonthOpeningBalance: number;
  isCarryForwardCorrect: boolean;
  status: 'VALID' | 'MISMATCH';
  message: string;
}> {
  const parts = monthStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const daysInMonth = isNaN(year) || isNaN(month) ? 30 : new Date(year, month, 0).getDate();

  let nextYear = year;
  let nextMonth = month + 1;
  if (nextMonth > 12) {
    nextMonth = 1;
    nextYear++;
  }
  const nextMonthStr = `${nextYear}-${String(nextMonth).padStart(2, '0')}`;
  const lastDayStr = `${monthStr}-${String(daysInMonth).padStart(2, '0')}`;
  const firstNextDayStr = `${nextMonthStr}-01`;

  const stockMap = calculateDailyCommodityStock(dailyEntries, stockTransactions, commodities, monthlyOverrides);

  return commodities.map((c) => {
    const monthLastDayData = stockMap[lastDayStr]?.[c.id];
    const nextMonthFirstDayData = stockMap[firstNextDayStr]?.[c.id];

    const monthCb = monthLastDayData ? monthLastDayData.cb : safeRound3(c.closingBalance);
    const nextOb = nextMonthFirstDayData ? nextMonthFirstDayData.ob : monthCb;

    const isCarryForwardCorrect = safeRound3(monthCb) === safeRound3(nextOb);

    return {
      commodityId: c.id,
      commodityName: c.name,
      unit: c.unit,
      monthClosingBalance: monthCb,
      nextMonthOpeningBalance: nextOb,
      isCarryForwardCorrect,
      status: isCarryForwardCorrect ? 'VALID' : 'MISMATCH',
      message: isCarryForwardCorrect
        ? `✓ ${c.name} closing balance of ${monthCb} ${c.unit} successfully carries into ${nextMonthStr}`
        : `⚠ ${c.name} mismatch: Closing (${monthCb}) differs from Next Month Opening (${nextOb})`,
    };
  });
}

/**
 * Automated Test Suite to verify all 7 Test Scenarios from the specification:
 * TEST 1: 31-08-2026 Rice Closing = 3.625 => 01-09-2026 Rice Opening must = 3.625
 * TEST 2: 31-08-2026 Rice Closing = 3.625, 03-09-2026 with skipped 01/02 => Opening must = 3.625
 * TEST 3: Multi-commodity independence (Rice = 3.625, Dal = 2.500 => Next OB = 3.625 & 2.500)
 * TEST 4: Previous Closing = 3.625, Rec = 2.000, Issued = 1.000 => Closing must = 4.625
 * TEST 5: Change 31-08-2026 closing from 3.625 to 4.125 => Verify dependent subsequent records recalculate correctly
 * TEST 6: Delete previous record => Verify next valid record recalculates correctly
 * TEST 7: First-ever Rice record => Manual initial opening balance supported
 */
export function runStockCarryForwardSelfTest(): {
  allPassed: boolean;
  results: Array<{ testName: string; passed: boolean; details: string }>;
} {
  const results: Array<{ testName: string; passed: boolean; details: string }> = [];

  const testCommodities: CommodityItem[] = [
    {
      id: 'rice',
      name: 'Rice',
      unit: 'Kg',
      openingBalance: 10.0,
      received: 0,
      used: 0,
      spoiled: 0,
      closingBalance: 10.0,
      minThreshold: 50,
      normPerStudentGramOrUnitPrimary: 100,
      normPerStudentGramOrUnitUpperPrimary: 150,
    },
    {
      id: 'pulses',
      name: 'Pulses / Dal',
      unit: 'Kg',
      openingBalance: 5.0,
      received: 0,
      used: 0,
      spoiled: 0,
      closingBalance: 5.0,
      minThreshold: 20,
      normPerStudentGramOrUnitPrimary: 20,
      normPerStudentGramOrUnitUpperPrimary: 30,
    },
  ];

  const mockEntry = (partial: Partial<DailyEntry> & { id: string; date: string }): DailyEntry => ({
    primaryAttendance: 0,
    upperPrimaryAttendance: 0,
    highSchoolAttendance: 0,
    totalAttendance: 0,
    mealsServed: 0,
    riceUsedKg: 0,
    eggUsedQty: 0,
    chikkiUsedQty: 0,
    ragiUsedKg: 0,
    jaggeryUsedKg: 0,
    remarks: '',
    ...partial,
  });

  // TEST 1: 31-08-2026 Rice Closing = 3.625 => 01-09-2026 Rice Opening must = 3.625
  try {
    const dailyEntriesT1: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-08-31',
        date: '2026-08-31',
        primaryAttendance: 10,
        upperPrimaryAttendance: 10,
        totalAttendance: 20,
        mealsServed: 20,
        riceUsedKg: 6.375, // 10.0 - 6.375 = 3.625
        remarks: 'Test 1 Entry',
      }),
    ];
    const mapT1 = calculateDailyCommodityStock(dailyEntriesT1, [], testCommodities, {});
    const aug31Cb = mapT1['2026-08-31']?.rice?.cb;
    const sep01Ob = mapT1['2026-09-01']?.rice?.ob;
    const passed1 = aug31Cb === 3.625 && sep01Ob === 3.625;
    results.push({
      testName: 'TEST 1: Month Boundary Carry Forward (31-08-2026 -> 01-09-2026)',
      passed: passed1,
      details: `Aug 31 Closing = ${aug31Cb}, Sep 01 Opening = ${sep01Ob} (Expected 3.625)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 1', passed: false, details: String(e) });
  }

  // TEST 2: 31-08-2026 Rice Closing = 3.625, 03-09-2026 with no 01/02 Sept records => Opening must = 3.625
  try {
    const dailyEntriesT2: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-08-31',
        date: '2026-08-31',
        riceUsedKg: 6.375,
        remarks: 'Test 2',
      }),
      // 01-09 and 02-09 have no records
      mockEntry({
        id: 'e-2026-09-03',
        date: '2026-09-03',
        riceUsedKg: 1.0,
        remarks: 'Test 2 Entry on 03-09',
      }),
    ];
    const mapT2 = calculateDailyCommodityStock(dailyEntriesT2, [], testCommodities, {});
    const sep03Ob = mapT2['2026-09-03']?.rice?.ob;
    const passed2 = sep03Ob === 3.625;
    results.push({
      testName: 'TEST 2: Skipped-Date Handling (31-08 -> 03-09)',
      passed: passed2,
      details: `Sep 03 Opening = ${sep03Ob} (Expected 3.625)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 2', passed: false, details: String(e) });
  }

  // TEST 3: Multi-commodity independence (Rice = 3.625, Dal = 2.500 => 01-09 Rice Opening = 3.625, Dal Opening = 2.500)
  try {
    const dailyEntriesT3: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-08-31',
        date: '2026-08-31',
        riceUsedKg: 6.375, // 10.0 - 6.375 = 3.625
        pulsesUsedKg: 2.5, // 5.0 - 2.5 = 2.500
        remarks: 'Test 3 Multi Commodity',
      }),
    ];
    const mapT3 = calculateDailyCommodityStock(dailyEntriesT3, [], testCommodities, {});
    const riceOb = mapT3['2026-09-01']?.rice?.ob;
    const dalOb = mapT3['2026-09-01']?.pulses?.ob;
    const passed3 = riceOb === 3.625 && dalOb === 2.5;
    results.push({
      testName: 'TEST 3: Commodity-Wise Independent Carry Forward',
      passed: passed3,
      details: `Rice Opening = ${riceOb} (Exp 3.625), Dal Opening = ${dalOb} (Exp 2.500)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 3', passed: false, details: String(e) });
  }

  // TEST 4: Previous Closing = 3.625, Received = 2.000, Issued = 1.000 => Closing must = 4.625
  try {
    const txsT4: StockTransaction[] = [
      {
        id: 'tx-1',
        date: '2026-09-01',
        commodityId: 'rice',
        type: 'RECEIVED',
        quantity: 2.0,
      },
    ];
    const dailyEntriesT4: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-08-31',
        date: '2026-08-31',
        riceUsedKg: 6.375, // closing 3.625
        remarks: 'Test 4',
      }),
      mockEntry({
        id: 'e-2026-09-01',
        date: '2026-09-01',
        riceUsedKg: 1.0, // issue 1.0
        remarks: 'Test 4 Sep 1',
      }),
    ];
    const mapT4 = calculateDailyCommodityStock(dailyEntriesT4, txsT4, testCommodities, {});
    const closingT4 = mapT4['2026-09-01']?.rice?.cb;
    const passed4 = closingT4 === 4.625;
    results.push({
      testName: 'TEST 4: Correct Formula (3.625 + 2.000 - 1.000 = 4.625)',
      passed: passed4,
      details: `Sep 01 Closing = ${closingT4} (Expected 4.625)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 4', passed: false, details: String(e) });
  }

  // TEST 5: Change 31-08-2026 closing from 3.625 to 4.125 => Verify dependent subsequent records recalculate correctly
  try {
    const dailyEntriesT5: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-08-31',
        date: '2026-08-31',
        riceUsedKg: 5.875, // 10.0 - 5.875 = 4.125
        remarks: 'Test 5 Edited Record',
      }),
      mockEntry({
        id: 'e-2026-09-01',
        date: '2026-09-01',
        riceUsedKg: 1.0,
        remarks: 'Test 5 Sep 1',
      }),
    ];
    const mapT5 = calculateDailyCommodityStock(dailyEntriesT5, [], testCommodities, {});
    const sep01Ob = mapT5['2026-09-01']?.rice?.ob;
    const sep01Cb = mapT5['2026-09-01']?.rice?.cb;
    const passed5 = sep01Ob === 4.125 && sep01Cb === 3.125;
    results.push({
      testName: 'TEST 5: Editing Previous Record Cascades Forward',
      passed: passed5,
      details: `Sep 01 Opening = ${sep01Ob} (Exp 4.125), Closing = ${sep01Cb} (Exp 3.125)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 5', passed: false, details: String(e) });
  }

  // TEST 6: Delete the previous record => Verify next valid record recalculates correctly
  try {
    // If Aug 31 entry is deleted, initial 10.0 kg carries through
    const dailyEntriesT6: DailyEntry[] = [
      mockEntry({
        id: 'e-2026-09-01',
        date: '2026-09-01',
        riceUsedKg: 2.0,
        remarks: 'Test 6 Entry',
      }),
    ];
    const mapT6 = calculateDailyCommodityStock(dailyEntriesT6, [], testCommodities, {});
    const sep01Ob = mapT6['2026-09-01']?.rice?.ob;
    const passed6 = sep01Ob === 10.0;
    results.push({
      testName: 'TEST 6: Deleting Previous Record Recalculates Balance',
      passed: passed6,
      details: `Sep 01 Opening after delete = ${sep01Ob} (Expected 10.0)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 6', passed: false, details: String(e) });
  }

  // TEST 7: First-ever Rice record manual initial opening balance
  try {
    const customComm: CommodityItem[] = [
      {
        id: 'rice',
        name: 'Rice',
        unit: 'Kg',
        openingBalance: 10.0,
        received: 0,
        used: 0,
        spoiled: 0,
        closingBalance: 10.0,
        minThreshold: 50,
        normPerStudentGramOrUnitPrimary: 100,
        normPerStudentGramOrUnitUpperPrimary: 150,
      },
    ];
    const txsT7: StockTransaction[] = [
      { id: 'tx-7-rec', date: '2026-09-01', commodityId: 'rice', type: 'RECEIVED', quantity: 5.0 },
    ];
    const entriesT7: DailyEntry[] = [
      mockEntry({
        id: 'e-7',
        date: '2026-09-01',
        riceUsedKg: 2.0,
        remarks: 'First ever entry',
      }),
    ];
    const mapT7 = calculateDailyCommodityStock(entriesT7, txsT7, customComm, {});
    const day1 = mapT7['2026-09-01']?.rice;
    const day2 = mapT7['2026-09-02']?.rice;
    const passed7 = day1?.ob === 10.0 && day1?.cb === 13.0 && day2?.ob === 13.0;
    results.push({
      testName: 'TEST 7: First-Ever Record Initial Opening Balance Flow',
      passed: passed7,
      details: `Day 1 OB = ${day1?.ob}, CB = ${day1?.cb}, Day 2 OB = ${day2?.ob} (Expected 10.0 -> 13.0 -> 13.0)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 7', passed: false, details: String(e) });
  }

  // TEST 8: August Month Last Working Day Closing Balance -> September First Working Day Opening Balance Carry-Forward
  try {
    const augLastWorkingEntry = mockEntry({
      id: 'e-2026-08-31',
      date: '2026-08-31',
      riceUsedKg: 4.5, // 10.0 - 4.5 = 5.5
      remarks: 'August Last Working Day',
    });
    const mapT8 = calculateDailyCommodityStock([augLastWorkingEntry], [], testCommodities, {}, ['2026-08', '2026-09']);
    const aug31Cb = mapT8['2026-08-31']?.rice?.cb;
    const sep01Ob = mapT8['2026-09-01']?.rice?.ob;
    const passed8 = aug31Cb === 5.5 && sep01Ob === 5.5;
    results.push({
      testName: 'TEST 8: August Last Working Day CB to September First Working Day OB Automatic Carry Forward',
      passed: passed8,
      details: `August 31 CB = ${aug31Cb}, September 01 OB = ${sep01Ob} (Expected 5.5)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 8', passed: false, details: String(e) });
  }

  // TEST 9: Carry-Forward across Month Boundary Holiday (Sep 01 Holiday -> Sep 02 First Working Day)
  try {
    const augLastWorkingEntry = mockEntry({
      id: 'e-2026-08-31',
      date: '2026-08-31',
      riceUsedKg: 3.0, // 10.0 - 3.0 = 7.0
      remarks: 'August Last Working Day',
    });
    const sep01HolidayEntry = mockEntry({
      id: 'e-2026-09-01',
      date: '2026-09-01',
      riceUsedKg: 0,
      remarks: 'School Holiday',
    });
    const mapT9 = calculateDailyCommodityStock([augLastWorkingEntry, sep01HolidayEntry], [], testCommodities, {}, ['2026-08', '2026-09']);
    const aug31Cb = mapT9['2026-08-31']?.rice?.cb;
    const sep01Ob = mapT9['2026-09-01']?.rice?.ob;
    const sep01Cb = mapT9['2026-09-01']?.rice?.cb;
    const sep02Ob = mapT9['2026-09-02']?.rice?.ob;
    const passed9 = aug31Cb === 7.0 && sep01Ob === 7.0 && sep01Cb === 7.0 && sep02Ob === 7.0;
    results.push({
      testName: 'TEST 9: Holiday on Month Boundary Maintains Continuous Opening Balance Cascade',
      passed: passed9,
      details: `Aug 31 CB = ${aug31Cb}, Sep 01 (Holiday) OB = ${sep01Ob} CB = ${sep01Cb}, Sep 02 (First Working Day) OB = ${sep02Ob} (Expected 7.0)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 9', passed: false, details: String(e) });
  }

  // TEST 10: User Reference Test: August 2026 month rice closing balance 3.375 kg => 01-09-2026 rice OB must automatically = 3.375 kg
  try {
    const aug30Entry = mockEntry({
      id: 'e-2026-08-30',
      date: '2026-08-30',
      riceUsedKg: 6.275, // 10.0 - 6.275 = 3.725
      remarks: 'August 30 Entry',
    });
    const aug31Entry = mockEntry({
      id: 'e-2026-08-31',
      date: '2026-08-31',
      riceUsedKg: 0.350, // 3.725 - 0.350 = 3.375
      remarks: 'August 31 Entry (Closing = 3.375)',
    });

    // 1. Without override, Sep 01 OB must strictly equal 3.375 (auto cascade)
    const mapT10Auto = calculateDailyCommodityStock([aug30Entry, aug31Entry], [], testCommodities, {}, ['2026-08', '2026-09']);
    const aug31Cb = mapT10Auto['2026-08-31']?.rice?.cb;
    const sep01ObAuto = mapT10Auto['2026-09-01']?.rice?.ob;

    // 2. If August 31 closing updates (e.g. riceUsed becomes 0.150 => closing = 3.575), Sep 01 OB must automatically update to 3.575
    const aug31UpdatedEntry = mockEntry({
      id: 'e-2026-08-31',
      date: '2026-08-31',
      riceUsedKg: 0.150, // 3.725 - 0.150 = 3.575
      remarks: 'August 31 Updated Entry',
    });
    const mapT10Updated = calculateDailyCommodityStock([aug30Entry, aug31UpdatedEntry], [], testCommodities, {}, ['2026-08', '2026-09']);
    const sep01ObUpdated = mapT10Updated['2026-09-01']?.rice?.ob;

    // 3. If user explicitly saves custom override for Sep 01 (e.g. 5.0), custom value is respected
    const customSepOverrides = { '2026-09': { rice: 5.0 } };
    const mapT10Custom = calculateDailyCommodityStock([aug30Entry, aug31Entry], [], testCommodities, customSepOverrides, ['2026-08', '2026-09']);
    const sep01ObCustom = mapT10Custom['2026-09-01']?.rice?.ob;

    const passed10 =
      aug31Cb === 3.375 &&
      sep01ObAuto === 3.375 &&
      sep01ObUpdated === 3.575 &&
      sep01ObCustom === 5.0;

    results.push({
      testName: 'TEST 10: August 2026 Rice Closing = 3.375 kg -> 01-09-2026 Rice OB Automatically = 3.375 kg (User Reference Scenario)',
      passed: passed10,
      details: `Aug 31 CB = ${aug31Cb}, Sep 01 Auto OB = ${sep01ObAuto} (Expected 3.375), Updated Aug 31 CB -> Sep 01 OB = ${sep01ObUpdated} (Expected 3.575), Custom Override OB = ${sep01ObCustom} (Expected 5.0)`,
    });
  } catch (e) {
    results.push({ testName: 'TEST 10', passed: false, details: String(e) });
  }

  const allPassed = results.every((r) => r.passed);
  return { allPassed, results };
}

export function formatLocalDateStr(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Get YYYY-MM-DD string for today or given offset days in local time
 */
export function getFormattedDate(offsetDays: number = 0): string {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  return formatLocalDateStr(date);
}

/**
 * Initial Default School Profile
 */
export const defaultSchoolProfile: SchoolProfile = {
  schoolName: 'M. P. P. SCHOOL R.B.R.PETA',
  udiseCode: '28140100101',
  headmasterName: 'V. CHIRANJEEVI',
  bankName: 'State Bank of India',
  accountNumber: '38940129482',
  ifscCode: 'SBIN0002741',
  implementingAgency: 'School Management Committee (SMC)',
  address: 'Main Road, R.B.R.PETA',
  village: 'R.B.R.PETA',
  mandal: 'PALAKONDA',
  district: 'PARVATHI PURAM MANYAM',
  state: 'ANDHRA PRADESH',
  pincode: '532462',
  phoneNumber: '+91 98480 12345',
  schoolPhotoUrl: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&q=80&w=800',
  academicYear: '2026-2027',
};

/**
 * Initial Default Meal Rates & Norms
 */
export const defaultMealRates: MealRates = {
  primaryRatePerMeal: 5.45,
  upperPrimaryRatePerMeal: 8.17,
  highSchoolRatePerMeal: 8.17,
  eggRate: 6.00,
  chikkiRate: 5.00,
  ragiRatePerKg: 35.00,
  jaggeryRatePerKg: 60.00,
  riceNormPrimaryGrams: 100,
  riceNormUpperPrimaryGrams: 150,
  oilNormPrimaryGrams: 5,
  oilNormUpperPrimaryGrams: 7.5,
  pulsesNormPrimaryGrams: 20,
  pulsesNormUpperPrimaryGrams: 30,
  eggNormQty: 1,
  chikkiNormQty: 1,
  ragiNormGrams: 10,
  jaggeryNormGrams: 10,
  condimentsNormPrimaryGrams: 2,
  condimentsNormUpperPrimaryGrams: 3,
};

/**
 * Initial Student Strength (Classes 1 to 8)
 */
export const defaultStudentStrength: StudentClassStrength[] = [
  { classLevel: 'Class 1', category: 'Primary', boys: 14, girls: 16, total: 30 },
  { classLevel: 'Class 2', category: 'Primary', boys: 18, girls: 15, total: 33 },
  { classLevel: 'Class 3', category: 'Primary', boys: 16, girls: 19, total: 35 },
  { classLevel: 'Class 4', category: 'Primary', boys: 20, girls: 17, total: 37 },
  { classLevel: 'Class 5', category: 'Primary', boys: 15, girls: 20, total: 35 },
  { classLevel: 'Class 6', category: 'Upper Primary', boys: 22, girls: 21, total: 43 },
  { classLevel: 'Class 7', category: 'Upper Primary', boys: 25, girls: 23, total: 48 },
  { classLevel: 'Class 8', category: 'Upper Primary', boys: 21, girls: 24, total: 45 },
];

/**
 * Initial Commodities Setup
 */
export const defaultCommodities: CommodityItem[] = [
  {
    id: 'rice',
    name: 'Rice',
    unit: 'Kg',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 100,
    normPerStudentGramOrUnitPrimary: 100, // 100g per primary student
    normPerStudentGramOrUnitUpperPrimary: 150, // 150g per upper primary student
  },
  {
    id: 'oil',
    name: 'Cooking Oil',
    unit: 'Litres',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 15,
    normPerStudentGramOrUnitPrimary: 5, // 5g / ml per primary student
    normPerStudentGramOrUnitUpperPrimary: 7.5, // 7.5g / ml per upper primary student
  },
  {
    id: 'pulses',
    name: 'Pulses / Dal',
    unit: 'Kg',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 20,
    normPerStudentGramOrUnitPrimary: 20, // 20g dal per primary student
    normPerStudentGramOrUnitUpperPrimary: 30, // 30g dal per upper primary student
  },
  {
    id: 'egg',
    name: 'Eggs',
    unit: 'Qty',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 200,
    normPerStudentGramOrUnitPrimary: 1, // 1 egg on scheduled days
    normPerStudentGramOrUnitUpperPrimary: 1,
  },
  {
    id: 'chikki',
    name: 'Chikki',
    unit: 'Packs',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 150,
    normPerStudentGramOrUnitPrimary: 1, // 1 pack per student on scheduled days
    normPerStudentGramOrUnitUpperPrimary: 1,
  },
  {
    id: 'ragi',
    name: 'Ragi Flour',
    unit: 'Kg',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 25,
    normPerStudentGramOrUnitPrimary: 10, // 10g ragi (0.01 kg)
    normPerStudentGramOrUnitUpperPrimary: 10, // 10g ragi (0.01 kg)
  },
  {
    id: 'jaggery',
    name: 'Jaggery Powder',
    unit: 'Kg',
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
    minThreshold: 15,
    normPerStudentGramOrUnitPrimary: 10, // 10g jaggery (0.01 kg)
    normPerStudentGramOrUnitUpperPrimary: 10, // 10g jaggery (0.01 kg)
  },
];

/**
 * Generate Realistic Sample Past Daily Entries for the Current Month
 */
export function generateSampleDailyEntries(): DailyEntry[] {
  const entries: DailyEntry[] = [];
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // Current month

  // Primary total ~170, Upper Primary ~136 (Total ~306)
  let dayCounter = 1;
  const currentDay = today.getDate();

  for (let d = 1; d <= currentDay; d++) {
    const testDate = new Date(year, month, d);
    const dayOfWeek = testDate.getDay();
    // Skip Sundays (0)
    if (dayOfWeek === 0) continue;

    const dateStr = formatLocalDateStr(testDate);
    
    // Vary attendance slightly between 90% and 98%
    const pAtt = Math.floor(170 * (0.91 + (d % 7) * 0.01));
    const upAtt = Math.floor(136 * (0.90 + (d % 5) * 0.015));
    const totalAtt = pAtt + upAtt;
    const meals = totalAtt; // All present students served

    // Calculate commodity usage based on norms
    // Rice: (pAtt * 100g + upAtt * 150g) / 1000 = Kg
    const riceKg = Number(((pAtt * 0.1) + (upAtt * 0.15)).toFixed(2));

    // Eggs served on Monday to Friday
    const isEggDay = (dayOfWeek >= 1 && dayOfWeek <= 5);
    const eggQty = isEggDay ? meals : 0;

    // Chikki served on Mon, Wed, Fri
    const isChikkiDay = (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5);
    const chikkiQty = isChikkiDay ? meals : 0;

    // Ragi Java & Jaggery served on Tue, Thu, Sat (0.01 kg / 10g norm)
    const isRagiDay = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6);
    const ragiKg = isRagiDay ? Number(((pAtt * 0.01) + (upAtt * 0.01)).toFixed(2)) : 0;
    const jaggeryKg = isRagiDay ? Number(((pAtt * 0.01) + (upAtt * 0.01)).toFixed(2)) : 0;

    entries.push({
      id: `mdm-entry-${dateStr}`,
      date: dateStr,
      primaryAttendance: pAtt,
      upperPrimaryAttendance: upAtt,
      highSchoolAttendance: 0,
      totalAttendance: totalAtt,
      mealsServed: meals,
      riceUsedKg: riceKg,
      eggUsedQty: eggQty,
      chikkiUsedQty: chikkiQty,
      ragiUsedKg: ragiKg,
      jaggeryUsedKg: jaggeryKg,
      remarks: isRagiDay ? 'Egg & Ragi Malt served.' : isChikkiDay ? 'Egg & Chikki served.' : 'Egg served.',
      createdAt: new Date(testDate.getTime() + 14 * 3600 * 1000).toISOString(),
      updatedAt: new Date(testDate.getTime() + 14 * 3600 * 1000).toISOString(),
    });

    dayCounter++;
  }

  return entries;
}

/**
 * Initial Sample Stock Transactions
 */
export const defaultStockTransactions: StockTransaction[] = [];

/**
 * Cleanly distributes target Primary and Upper Primary student totals
 * across existing class structures while preserving boy/girl proportions.
 */
export function distributeStudentStrengths(
  baseStrengths: StudentClassStrength[],
  targetPrimary: number,
  targetUpperPrimary: number
): StudentClassStrength[] {
  const source = (baseStrengths && baseStrengths.length > 0) ? baseStrengths : defaultStudentStrength;
  const result: StudentClassStrength[] = source.map((s) => ({ ...s }));

  const primaryClasses = result.filter(
    (s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i))
  );
  const upperClasses = result.filter(
    (s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i))
  );

  // 1. Distribute Primary Classes
  if (primaryClasses.length > 0) {
    const curTotal = primaryClasses.reduce((sum, s) => sum + s.total, 0);
    let allocated = 0;
    primaryClasses.forEach((c, idx) => {
      let count = 0;
      if (idx === primaryClasses.length - 1) {
        count = Math.max(0, targetPrimary - allocated);
      } else {
        count = curTotal > 0
          ? Math.round(targetPrimary * (c.total / curTotal))
          : Math.floor(targetPrimary / primaryClasses.length);
        allocated += count;
      }
      const boysRatio = (c.boys + c.girls) > 0 ? c.boys / (c.boys + c.girls) : 0.5;
      const boys = Math.round(count * boysRatio);
      const girls = Math.max(0, count - boys);
      c.boys = boys;
      c.girls = girls;
      c.total = count;
    });
  }

  // 2. Distribute Upper Primary Classes
  if (upperClasses.length > 0) {
    const curTotal = upperClasses.reduce((sum, s) => sum + s.total, 0);
    let allocated = 0;
    upperClasses.forEach((c, idx) => {
      let count = 0;
      if (idx === upperClasses.length - 1) {
        count = Math.max(0, targetUpperPrimary - allocated);
      } else {
        count = curTotal > 0
          ? Math.round(targetUpperPrimary * (c.total / curTotal))
          : Math.floor(targetUpperPrimary / upperClasses.length);
        allocated += count;
      }
      const boysRatio = (c.boys + c.girls) > 0 ? c.boys / (c.boys + c.girls) : 0.5;
      const boys = Math.round(count * boysRatio);
      const girls = Math.max(0, count - boys);
      c.boys = boys;
      c.girls = girls;
      c.total = count;
    });
  }

  return result;
}

export interface DailyMenuIndentCommodities {
  dayOfWeek: number; // 0 = Sun, 1 = Mon, ..., 6 = Sat
  dayName: string;
  isEggDay: boolean;
  isChikkiDay: boolean;
  isRagiDay: boolean;
  isJaggeryDay: boolean;
  menuDescription: string;
  menuBadges: string[];
  eggUsedQty: number;
  chikkiUsedQty: number;
  ragiUsedKg: number;
  jaggeryUsedKg: number;
  riceUsedKg: number;
  oilUsedLitres: number;
  pulsesUsedKg: number;
  condimentsUsedKg: number;
}

/**
 * Official Daily Menu Indent calculation for AP MDM commodities:
 * - Eggs: Monday, Tuesday, Wednesday, Thursday, Friday (1, 2, 3, 4, 5)
 * - Chikki: Monday, Wednesday, Friday (1, 3, 5)
 * - Ragi & Jaggery: Tuesday, Thursday, Saturday (2, 4, 6)
 * - Sunday / Holiday: None (0)
 */
export function calculateDailyMenuIndent(
  dateStr: string,
  primaryAtt: number,
  upperPrimaryAtt: number,
  highSchoolAtt: number = 0,
  mealRates?: MealRates,
  isHolidayOverride?: boolean
): DailyMenuIndentCommodities {
  const dayDetails = getDayDetails(dateStr);
  const dayOfWeek = dayDetails.dayOfWeek;
  const isHoliday = isHolidayOverride !== undefined ? isHolidayOverride : (dayDetails.isSunday || dayDetails.isHoliday);
  const totalMeals = isHoliday ? 0 : Math.max(0, primaryAtt + upperPrimaryAtt + highSchoolAtt);

  // Commodity Day Flags
  const isEggDay = !isHoliday && (dayOfWeek >= 1 && dayOfWeek <= 5);
  const isChikkiDay = !isHoliday && (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5);
  const isRagiDay = !isHoliday && (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6);
  const isJaggeryDay = isRagiDay;

  // Commodity Norms
  const ricePrimaryNormKg = (mealRates?.riceNormPrimaryGrams ?? 100) / 1000;
  const riceUpperPrimaryNormKg = (mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000;
  const riceUsedKg = isHoliday ? 0 : Number(((primaryAtt * ricePrimaryNormKg) + ((upperPrimaryAtt + highSchoolAtt) * riceUpperPrimaryNormKg)).toFixed(2));

  const oilPrimaryNormL = (mealRates?.oilNormPrimaryGrams ?? 5) / 1000;
  const oilUpperPrimaryNormL = (mealRates?.oilNormUpperPrimaryGrams ?? 7.5) / 1000;
  const oilUsedLitres = isHoliday ? 0 : Number(((primaryAtt * oilPrimaryNormL) + ((upperPrimaryAtt + highSchoolAtt) * oilUpperPrimaryNormL)).toFixed(3));

  const pulsesPrimaryNormKg = (mealRates?.pulsesNormPrimaryGrams ?? 20) / 1000;
  const pulsesUpperPrimaryNormKg = (mealRates?.pulsesNormUpperPrimaryGrams ?? 30) / 1000;
  const pulsesUsedKg = isHoliday ? 0 : Number(((primaryAtt * pulsesPrimaryNormKg) + ((upperPrimaryAtt + highSchoolAtt) * pulsesUpperPrimaryNormKg)).toFixed(3));

  const condimentsPrimaryNormKg = (mealRates?.condimentsNormPrimaryGrams ?? 2) / 1000;
  const condimentsUpperPrimaryNormKg = (mealRates?.condimentsNormUpperPrimaryGrams ?? 3) / 1000;
  const condimentsUsedKg = isHoliday ? 0 : Number(((primaryAtt * condimentsPrimaryNormKg) + ((upperPrimaryAtt + highSchoolAtt) * condimentsUpperPrimaryNormKg)).toFixed(3));

  const eggNorm = mealRates?.eggNormQty ?? 1;
  const eggUsedQty = isEggDay ? totalMeals * eggNorm : 0;

  const chikkiNorm = mealRates?.chikkiNormQty ?? 1;
  const chikkiUsedQty = isChikkiDay ? totalMeals * chikkiNorm : 0;

  const ragiNormKg = (mealRates?.ragiNormGrams ?? 10) / 1000;
  const jaggeryNormKg = (mealRates?.jaggeryNormGrams ?? 10) / 1000;
  const ragiUsedKg = isRagiDay ? Number((totalMeals * ragiNormKg).toFixed(2)) : 0;
  const jaggeryUsedKg = isJaggeryDay ? Number((totalMeals * jaggeryNormKg).toFixed(2)) : 0;

  const menuBadges: string[] = [];
  if (isEggDay) menuBadges.push('🥚 Boiled Egg (Mon–Fri)');
  if (isChikkiDay) menuBadges.push('🥜 Peanut Chikki (Mon, Wed, Fri)');
  if (isRagiDay) menuBadges.push('🌾 Ragi Java (Tue, Thu, Sat)');
  if (isJaggeryDay) menuBadges.push('🍯 Jaggery (Tue, Thu, Sat)');

  let menuDescription = '';
  switch (dayOfWeek) {
    case 1:
      menuDescription = 'Monday: Boiled Egg + Peanut Chikki (Rice, Sambar/Dal)';
      break;
    case 2:
      menuDescription = 'Tuesday: Boiled Egg + Ragi Java with Jaggery (Rice, Veg Curry)';
      break;
    case 3:
      menuDescription = 'Wednesday: Boiled Egg + Peanut Chikki (Rice, Dal)';
      break;
    case 4:
      menuDescription = 'Thursday: Boiled Egg + Ragi Java with Jaggery (Rice, Sambar)';
      break;
    case 5:
      menuDescription = 'Friday: Boiled Egg + Peanut Chikki (Rice, Dal/Curry)';
      break;
    case 6:
      menuDescription = 'Saturday: Ragi Java with Jaggery (Rice, Sambar) — No Eggs, No Chikki';
      break;
    default:
      menuDescription = 'Sunday: School Holiday — No MDM';
      break;
  }

  return {
    dayOfWeek,
    dayName: dayDetails.dayName,
    isEggDay,
    isChikkiDay,
    isRagiDay,
    isJaggeryDay,
    menuDescription,
    menuBadges,
    eggUsedQty,
    chikkiUsedQty,
    ragiUsedKg,
    jaggeryUsedKg,
    riceUsedKg,
    oilUsedLitres,
    pulsesUsedKg,
    condimentsUsedKg,
  };
}

/**
 * Automatically update and align daily entries with the official menu indent commodities
 */
export function syncDailyEntriesWithMenuIndent(
  entries: DailyEntry[],
  mealRates?: MealRates
): { updatedEntries: DailyEntry[]; changedCount: number } {
  let changedCount = 0;
  const updatedEntries = entries.map((entry) => {
    const dayDetails = getDayDetails(entry.date);
    const isHoliday = dayDetails.isSunday || dayDetails.isHoliday || ((entry.mealsServed ?? 0) === 0 && (entry.totalAttendance ?? 0) === 0);

    if (isHoliday) {
      const hadUsage = (entry.eggUsedQty ?? 0) > 0 || (entry.chikkiUsedQty ?? 0) > 0 || (entry.ragiUsedKg ?? 0) > 0 || (entry.jaggeryUsedKg ?? 0) > 0;
      if (hadUsage) {
        changedCount++;
        return {
          ...entry,
          eggUsedQty: 0,
          chikkiUsedQty: 0,
          ragiUsedKg: 0,
          jaggeryUsedKg: 0,
        };
      }
      return entry;
    }

    const p = entry.primaryAttendance ?? 0;
    const up = entry.upperPrimaryAttendance ?? 0;
    const hs = entry.highSchoolAttendance ?? 0;
    const indent = calculateDailyMenuIndent(entry.date, p, up, hs, mealRates, false);

    const hasMismatch =
      entry.eggUsedQty !== indent.eggUsedQty ||
      entry.chikkiUsedQty !== indent.chikkiUsedQty ||
      entry.ragiUsedKg !== indent.ragiUsedKg ||
      entry.jaggeryUsedKg !== indent.jaggeryUsedKg;

    if (hasMismatch) {
      changedCount++;
      return {
        ...entry,
        eggUsedQty: indent.eggUsedQty,
        chikkiUsedQty: indent.chikkiUsedQty,
        ragiUsedKg: indent.ragiUsedKg,
        jaggeryUsedKg: indent.jaggeryUsedKg,
        updatedAt: new Date().toISOString(),
      };
    }
    return entry;
  });

  return { updatedEntries, changedCount };
}

