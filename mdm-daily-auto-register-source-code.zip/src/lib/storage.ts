import {
  AppSettings,
  AutomationSettings,
  CashVoucher,
  CommodityItem,
  DailyEntry,
  MealRates,
  RoleCredential,
  SchoolProfile,
  StockTransaction,
  StoredCredentials,
  StudentClassStrength,
  StudentStrengthUpdateRecord,
  User,
  DailyClassAttendance,
  SchoolAccount,
} from '../types';

export type { RoleCredential, StoredCredentials, SchoolAccount };
import {
  defaultCommodities,
  defaultMealRates,
  defaultSchoolProfile,
  defaultStockTransactions,
  defaultStudentStrength,
  generateSampleDailyEntries,
  numToWords,
  getDayDetails,
  calculateDailyCommodityStock,
  generateContinuousMonthRange,
  safeRound3,
  DayCommodityStockMap,
  distributeStudentStrengths,
} from './utils';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function isOfflineError(error: unknown): boolean {
  if (!error) return false;
  const code = (error as any)?.code || '';
  if (code === 'unavailable' || code === 'deadline-exceeded' || code === 'failed-precondition') {
    return true;
  }
  const msg = (error instanceof Error ? error.message : String(error)).toLowerCase();
  return (
    msg.includes('offline') ||
    msg.includes('unavailable') ||
    msg.includes('could not reach cloud firestore backend') ||
    msg.includes('backend didn\'t respond') ||
    msg.includes('client is offline') ||
    msg.includes('failed-precondition') ||
    msg.includes('network') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('deadline-exceeded')
  );
}

function withTimeout<T>(promise: Promise<T>, timeoutMs = 2500): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Firestore operation timed out (offline fallback)'));
    }, timeoutMs);
    promise
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map((p) => ({
        providerId: p.providerId,
        email: p.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.warn('Firestore fallback: ', JSON.stringify(errInfo));
}

export function recordLocalUpdate(key: string): void {
  try {
    localStorage.setItem(`${key}_updatedAt`, new Date().toISOString());
  } catch {
    // Ignore storage quota errors
  }
}

export const DEFAULT_SCHOOL_ID = 'school_28261800503';

export const defaultCredentials: StoredCredentials = {
  headmaster: {
    role: 'HEADMASTER',
    name: 'V. CHIRANJEEVI',
    username: '28261800503',
    mobile: '9848012345',
    password: 'Password@123',
  },
  incharge: {
    role: 'MDM_INCHARGE',
    name: 'MDM Incharge',
    username: '28261800503',
    mobile: '9848054321',
    password: 'Password@123',
  },
};

export const DEFAULT_SCHOOL_ACCOUNT: SchoolAccount = {
  schoolId: DEFAULT_SCHOOL_ID,
  schoolName: 'M. P. P. SCHOOL R.B.R.PETA',
  udiseCode: '28261800503',
  village: 'R.B.R.PETA',
  mandal: 'PALAKONDA',
  district: 'PARVATHI PURAM MANYAM',
  state: 'ANDHRA PRADESH',
  headmasterName: 'V. CHIRANJEEVI',
  headmasterMobile: '9848012345',
  credentials: defaultCredentials,
  createdAt: '2026-01-01T00:00:00.000Z',
};

export function normalizeMobileNumber(input: string): string {
  const digits = (input || '').replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits.substring(2);
  }
  if (digits.length === 11 && digits.startsWith('0')) {
    return digits.substring(1);
  }
  return digits;
}

export function normalizeSchoolId(id?: string): string {
  if (!id || !id.trim()) {
    try {
      const active = localStorage.getItem('mdm_active_school_id');
      if (active && active.trim()) return active.trim();
    } catch {}
    return DEFAULT_SCHOOL_ID;
  }
  const clean = id.trim();
  if (clean === 'global') return 'global';
  if (clean.startsWith('school_')) return clean;
  if (/^\d+$/.test(clean)) return `school_${clean}`;
  return clean;
}

export function getActiveSchoolId(): string {
  try {
    const id = localStorage.getItem('mdm_active_school_id');
    if (id && id.trim()) return normalizeSchoolId(id.trim());
  } catch {
    // Ignore storage error
  }
  return DEFAULT_SCHOOL_ID;
}

export function setActiveSchoolId(schoolId: string): void {
  try {
    if (schoolId && schoolId.trim()) {
      const normId = normalizeSchoolId(schoolId.trim());
      localStorage.setItem('mdm_active_school_id', normId);
    }
  } catch (e) {
    console.error('Failed setting active school ID', e);
  }
}

export function getSchoolAccounts(): SchoolAccount[] {
  try {
    const data = localStorage.getItem('mdm_school_accounts');
    if (data) {
      const parsed: SchoolAccount[] = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const hasDef = parsed.some((s) => s.schoolId === DEFAULT_SCHOOL_ID || s.udiseCode === '28261800503');
        if (!hasDef) {
          parsed.unshift(DEFAULT_SCHOOL_ACCOUNT);
        }
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading school accounts', e);
  }
  return [DEFAULT_SCHOOL_ACCOUNT];
}

export function saveSchoolAccounts(accounts: SchoolAccount[]): void {
  try {
    localStorage.setItem('mdm_school_accounts', JSON.stringify(accounts));
    recordLocalUpdate('mdm_school_accounts');
    saveToCloud('school_accounts', accounts, 'global').catch(() => {});
  } catch (e) {
    console.error('Failed saving school accounts', e);
  }
}

export function getScopedKey(key: string, schoolId?: string): string {
  const sId = normalizeSchoolId(schoolId);
  return `${sId}__${key}`;
}

export function getItemForSchool(key: string, schoolId?: string): string | null {
  const normId = normalizeSchoolId(schoolId);
  const rawId = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  const scopedKey = `${normId}__${key}`;
  const rawKey = `${rawId}__${key}`;
  try {
    let val = localStorage.getItem(scopedKey);
    if (val !== null) return val;
    if (rawKey !== scopedKey) {
      val = localStorage.getItem(rawKey);
      if (val !== null) return val;
    }
    // Fallback for default school: check legacy un-scoped key
    if (normId === DEFAULT_SCHOOL_ID) {
      const legacy = localStorage.getItem(key);
      if (legacy !== null) {
        try {
          localStorage.setItem(scopedKey, legacy);
        } catch {
          // Ignore
        }
        return legacy;
      }
    }
  } catch (e) {
    console.error('Failed reading key from storage', scopedKey, e);
  }
  return null;
}

export function setItemForSchool(key: string, value: string, schoolId?: string): void {
  const normId = normalizeSchoolId(schoolId);
  const rawId = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  const scopedKey = `${normId}__${key}`;
  const now = new Date().toISOString();
  try {
    localStorage.setItem(scopedKey, value);
    localStorage.setItem(`${scopedKey}_updatedAt`, now);
    if (rawId !== normId) {
      localStorage.setItem(`${rawId}__${key}`, value);
      localStorage.setItem(`${rawId}__${key}_updatedAt`, now);
    }
    // If default school, also write legacy un-scoped key for full backward compatibility
    if (normId === DEFAULT_SCHOOL_ID) {
      localStorage.setItem(key, value);
      localStorage.setItem(`${key}_updatedAt`, now);
    }
  } catch (e) {
    console.error('Failed writing key to storage', scopedKey, e);
  }
}

export async function saveToCloud(key: string, data: any, schoolId?: string): Promise<void> {
  const normId = normalizeSchoolId(schoolId);
  const sId = schoolId === 'global' ? 'global' : normId;
  const rawId = sId.startsWith('school_') ? sId.replace('school_', '') : sId;
  const docKey = sId === 'global' ? key : `${sId}__${key}`;
  const fullPath = `school_data/${docKey}`;
  try {
    const docRef = doc(db, 'school_data', docKey);
    const cleanData = data !== undefined ? JSON.parse(JSON.stringify(data)) : null;
    await withTimeout(
      setDoc(docRef, {
        data: cleanData,
        updatedAt: new Date().toISOString(),
        schoolId: sId,
        _backendAuthToken: 'mdm_backend_secure_token_71a44c73_prod',
      }),
      6000
    );

    // Also mirror to raw UDISE doc key for bidirectional lookup
    if (sId !== 'global' && rawId !== sId) {
      const rawRef = doc(db, 'school_data', `${rawId}__${key}`);
      setDoc(rawRef, {
        data: cleanData,
        updatedAt: new Date().toISOString(),
        schoolId: sId,
        _backendAuthToken: 'mdm_backend_secure_token_71a44c73_prod',
      }).catch(() => {});
    }

    // If default school and not global, keep legacy un-scoped doc in sync as well
    if (sId === DEFAULT_SCHOOL_ID) {
      const legacyRef = doc(db, 'school_data', key);
      setDoc(legacyRef, {
        data: cleanData,
        updatedAt: new Date().toISOString(),
        _backendAuthToken: 'mdm_backend_secure_token_71a44c73_prod',
      }).catch(() => {});
    }
  } catch (error) {
    if (isOfflineError(error)) {
      return;
    }
    console.warn(`Firestore save deferred for ${fullPath}:`, error);
  }
}

export async function loadFromCloud(key: string, schoolId?: string): Promise<{ data: any; updatedAt?: string } | null> {
  const normId = normalizeSchoolId(schoolId);
  const sId = schoolId === 'global' ? 'global' : normId;
  const rawId = sId.startsWith('school_') ? sId.replace('school_', '') : sId;
  const docKey = sId === 'global' ? key : `${sId}__${key}`;
  const fullPath = `school_data/${docKey}`;
  try {
    const docRef = doc(db, 'school_data', docKey);
    const snap = await withTimeout(getDoc(docRef), 6000);
    if (snap && snap.exists()) {
      const docData = snap.data();
      return { data: docData?.data, updatedAt: docData?.updatedAt };
    }
    // Also try rawId__key if docKey was not found
    if (sId !== 'global' && rawId !== sId) {
      const rawRef = doc(db, 'school_data', `${rawId}__${key}`);
      const rawSnap = await withTimeout(getDoc(rawRef), 6000);
      if (rawSnap && rawSnap.exists()) {
        const docData = rawSnap.data();
        return { data: docData?.data, updatedAt: docData?.updatedAt };
      }
    }
    // Fallback for default school: check legacy un-scoped doc
    if (sId === DEFAULT_SCHOOL_ID) {
      const legacyRef = doc(db, 'school_data', key);
      const legSnap = await withTimeout(getDoc(legacyRef), 6000);
      if (legSnap && legSnap.exists()) {
        const docData = legSnap.data();
        if (docData?.data !== undefined) {
          saveToCloud(key, docData.data, sId).catch(() => {});
        }
        return { data: docData?.data, updatedAt: docData?.updatedAt };
      }
    }
  } catch (error) {
    if (isOfflineError(error)) {
      return null;
    }
    handleFirestoreError(error, OperationType.GET, fullPath);
  }
  return null;
}

const STORAGE_KEYS = {
  USER: 'mdm_user',
  CREDENTIALS: 'mdm_credentials',
  PROFILE: 'mdm_school_profile',
  STUDENT_STRENGTH: 'mdm_student_strength',
  DAILY_ENTRIES: 'mdm_daily_entries',
  COMMODITIES: 'mdm_commodities',
  STOCK_TRANSACTIONS: 'mdm_stock_transactions',
  MEAL_RATES: 'mdm_meal_rates',
  CASH_VOUCHERS: 'mdm_cash_vouchers',
  SETTINGS: 'mdm_settings',
  MONTHLY_COMMODITIES: 'mdm_monthly_commodity_balances',
};

export function getStoredCredentials(schoolId?: string): StoredCredentials {
  const sId = schoolId || getActiveSchoolId();
  const normId = normalizeSchoolId(sId);
  const rawUdise = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  const accounts = getSchoolAccounts();
  const acc = accounts.find((a) => a.schoolId === normId || a.udiseCode === rawUdise || a.schoolId === `school_${rawUdise}`);
  const resolvedUdise = acc?.udiseCode || (rawUdise && /^\d+$/.test(rawUdise) ? rawUdise : '28261800503');

  try {
    const data = getItemForSchool(STORAGE_KEYS.CREDENTIALS, sId);
    if (data) {
      const parsed = JSON.parse(data);
      const merged: StoredCredentials = {
        headmaster: { ...defaultCredentials.headmaster, ...(parsed.headmaster || {}), username: resolvedUdise },
        incharge: { ...defaultCredentials.incharge, ...(parsed.incharge || {}), username: resolvedUdise },
      };
      // Check legacy portal password if default school
      const legacyPwd = localStorage.getItem('mdm_portal_password');
      if (legacyPwd && !parsed.headmaster?.password && sId === DEFAULT_SCHOOL_ID) {
        merged.headmaster.password = legacyPwd;
      }
      return merged;
    }
  } catch (e) {
    console.error('Failed reading credentials from storage', e);
  }

  // Check from registered accounts list
  if (acc && acc.credentials) {
    return {
      headmaster: { ...acc.credentials.headmaster, username: resolvedUdise },
      incharge: { ...acc.credentials.incharge, username: resolvedUdise },
    };
  }

  return {
    headmaster: { ...defaultCredentials.headmaster, username: resolvedUdise },
    incharge: { ...defaultCredentials.incharge, username: resolvedUdise },
  };
}

export function saveStoredCredentials(creds: StoredCredentials, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.CREDENTIALS, JSON.stringify(creds), sId);
    recordLocalUpdate(STORAGE_KEYS.CREDENTIALS);

    // Also update SchoolAccount record in registry
    const accounts = getSchoolAccounts();
    const accIndex = accounts.findIndex((a) => a.schoolId === sId);
    if (accIndex >= 0) {
      accounts[accIndex].credentials = creds;
      if (creds.headmaster?.name) accounts[accIndex].headmasterName = creds.headmaster.name;
      if (creds.headmaster?.mobile) accounts[accIndex].headmasterMobile = creds.headmaster.mobile;
      saveSchoolAccounts(accounts);
    }
  } catch (e) {
    console.error('Failed saving credentials', e);
  }
}

export function registerNewSchool(params: {
  schoolName: string;
  udiseCode: string;
  headmasterName: string;
  headmasterMobile?: string;
  username?: string;
  password: string;
  village?: string;
  mandal?: string;
  district?: string;
}): { success: boolean; message: string; schoolAccount?: SchoolAccount; user?: User } {
  const cleanUdise = params.udiseCode.trim();
  const cleanMobile = params.headmasterMobile ? normalizeMobileNumber(params.headmasterMobile) : '';
  const cleanUsername = cleanUdise; // Login details username as UDISE code only

  if (cleanUdise.length < 6) {
    return { success: false, message: 'Please enter a valid School UDISE code (e.g. 11 digits).' };
  }
  if (!params.password || params.password.length < 4) {
    return { success: false, message: 'Password must be at least 4 characters long.' };
  }

  const existingAccounts = getSchoolAccounts();
  const duplicate = existingAccounts.find(
    (s) => s.udiseCode === cleanUdise || s.schoolId === `school_${cleanUdise}`
  );
  if (duplicate) {
    return {
      success: false,
      message: `An account with UDISE code ${cleanUdise} already exists (${duplicate.schoolName}). Only one account is permitted per UDISE code.`,
    };
  }

  const schoolId = `school_${cleanUdise}`;
  const newCreds: StoredCredentials = {
    headmaster: {
      role: 'HEADMASTER',
      name: params.headmasterName.trim() || 'Headmaster',
      username: cleanUsername,
      mobile: cleanMobile,
      password: params.password,
      updatedAt: new Date().toISOString(),
    },
    incharge: {
      role: 'MDM_INCHARGE',
      name: 'MDM Incharge',
      username: cleanUsername,
      mobile: '',
      password: params.password,
      updatedAt: new Date().toISOString(),
    },
  };

  const newSchoolAccount: SchoolAccount = {
    schoolId,
    schoolName: params.schoolName.trim().toUpperCase(),
    udiseCode: cleanUdise,
    village: params.village?.trim().toUpperCase() || '',
    mandal: params.mandal?.trim().toUpperCase() || 'PALAKONDA',
    district: params.district?.trim().toUpperCase() || 'PARVATHI PURAM MANYAM',
    state: 'ANDHRA PRADESH',
    headmasterName: params.headmasterName.trim(),
    headmasterMobile: cleanMobile,
    credentials: newCreds,
    createdAt: new Date().toISOString(),
  };

  existingAccounts.push(newSchoolAccount);
  saveSchoolAccounts(existingAccounts);

  // Initialize isolated individual school data
  const newProfile: SchoolProfile = {
    ...defaultSchoolProfile,
    schoolName: newSchoolAccount.schoolName,
    udiseCode: newSchoolAccount.udiseCode,
    headmasterName: newSchoolAccount.headmasterName,
    phoneNumber: cleanMobile,
    village: newSchoolAccount.village,
    mandal: newSchoolAccount.mandal,
    district: newSchoolAccount.district,
    state: 'ANDHRA PRADESH',
    address: `${newSchoolAccount.schoolName}, ${newSchoolAccount.mandal}, ${newSchoolAccount.district}`,
  };

  saveStoredSchoolProfile(newProfile, schoolId);
  saveStoredCredentials(newCreds, schoolId);
  saveStoredCommodities(defaultCommodities, schoolId);
  saveStoredMealRates(defaultMealRates, schoolId);
  saveStoredStudentStrength(defaultStudentStrength, schoolId);
  saveStoredBaselineStudentStrength(defaultStudentStrength, schoolId);
  saveStoredDailyEntries([], schoolId);
  saveStoredStockTransactions([], schoolId);

  // Set active school
  setActiveSchoolId(schoolId);

  const user: User = {
    username: cleanUsername,
    mobile: cleanMobile,
    name: newCreds.headmaster.name,
    role: 'HEADMASTER',
    isLoggedIn: true,
    schoolId,
    schoolName: newSchoolAccount.schoolName,
    udiseCode: newSchoolAccount.udiseCode,
  };

  saveStoredUser(user, schoolId);

  return {
    success: true,
    message: `School "${newSchoolAccount.schoolName}" registered successfully with dedicated data isolation!`,
    schoolAccount: newSchoolAccount,
    user,
  };
}

export function verifyLoginCredentials(
  identifier: string,
  passwordInput: string,
  specificSchoolId?: string
): {
  success: boolean;
  user?: User;
  error?: string;
} {
  const accounts = getSchoolAccounts();
  const trimmedIdent = (identifier || '').trim();
  const digitsIdent = normalizeMobileNumber(trimmedIdent);

  // Require valid UDISE code - School login username is ONLY School UDISE CODE
  if (!digitsIdent || digitsIdent.length < 6) {
    return {
      success: false,
      error: 'School login username must be your School UDISE Code.',
    };
  }

  // Target specific school if specified, or search all registered schools
  const targetAccounts = specificSchoolId
    ? accounts.filter((a) => a.schoolId === specificSchoolId || a.udiseCode === specificSchoolId)
    : accounts;

  // Prioritize non-default registered accounts over default demo school
  const nonDefault = targetAccounts.filter((a) => a.schoolId !== DEFAULT_SCHOOL_ID && a.udiseCode !== '28261800503');
  const defaultAccs = targetAccounts.filter((a) => a.schoolId === DEFAULT_SCHOOL_ID || a.udiseCode === '28261800503');
  const orderedAccounts = [...nonDefault, ...defaultAccs];

  for (const acc of orderedAccounts) {
    const isExactUdise =
      (digitsIdent.length >= 6 && digitsIdent === acc.udiseCode) ||
      trimmedIdent === acc.udiseCode ||
      trimmedIdent === acc.schoolId ||
      (acc.credentials?.headmaster?.username && trimmedIdent.toLowerCase() === acc.credentials.headmaster.username.toLowerCase());

    if (!isExactUdise) {
      continue;
    }

    const creds = getStoredCredentials(acc.schoolId);
    const profile = getStoredSchoolProfile(acc.schoolId);
    const isDefaultSchool = acc.schoolId === DEFAULT_SCHOOL_ID || acc.udiseCode === '28261800503';

    const isPwdCorrect =
      (Boolean(creds.headmaster.password) && passwordInput === creds.headmaster.password) ||
      (Boolean(creds.incharge.password) && passwordInput === creds.incharge.password) ||
      (!creds.headmaster.password) ||
      (isDefaultSchool && (passwordInput === 'Password@123' || passwordInput === '123456' || passwordInput === '28261800503'));

    if (isPwdCorrect) {
      if ((!creds.headmaster.password || isDefaultSchool) && passwordInput) {
        creds.headmaster.password = passwordInput;
        saveStoredCredentials(creds, acc.schoolId);
      }

      setActiveSchoolId(acc.schoolId);
      acc.lastLoginAt = new Date().toISOString();
      saveSchoolAccounts(accounts);

      const user: User = {
        username: acc.udiseCode, // Login username as UDISE code only
        mobile: creds.headmaster.mobile || acc.headmasterMobile,
        name: creds.headmaster.name || acc.headmasterName,
        role: 'HEADMASTER',
        isLoggedIn: true,
        schoolId: acc.schoolId,
        schoolName: profile?.schoolName || acc.schoolName,
        udiseCode: acc.udiseCode,
      };
      saveStoredUser(user, acc.schoolId);

      return {
        success: true,
        user,
      };
    } else {
      return {
        success: false,
        error: 'Invalid password. Please enter your valid password.',
      };
    }
  }

  return {
    success: false,
    error: 'Invalid School UDISE code or password. School login username must be your School UDISE Code.',
  };
}

/**
 * Local / Offline OTP Login Request
 */
export function requestLoginOtpLocal(
  identifier: string,
  role?: 'HEADMASTER' | 'MDM_INCHARGE',
  specificSchoolId?: string
): {
  success: boolean;
  schoolId?: string;
  schoolName?: string;
  mobile?: string;
  maskedMobile?: string;
  testOtp?: string;
  error?: string;
  role?: 'HEADMASTER' | 'MDM_INCHARGE';
} {
  const accounts = getSchoolAccounts();
  const trimmed = (identifier || '').trim();
  const lower = trimmed.toLowerCase();
  const digits = normalizeMobileNumber(trimmed);

  const targetAccounts = specificSchoolId
    ? accounts.filter((a) => a.schoolId === specificSchoolId)
    : accounts;

  for (const acc of targetAccounts) {
    const creds = getStoredCredentials(acc.schoolId);
    const hmMobileDigits = normalizeMobileNumber(creds.headmaster.mobile || acc.headmasterMobile || '');
    const incMobileDigits = normalizeMobileNumber(creds.incharge.mobile || '');
    const hmUser = (creds.headmaster.username || '').toLowerCase();
    const incUser = (creds.incharge.username || '').toLowerCase();

    const isHmMatch =
      lower === hmUser ||
      (digits.length >= 8 && digits === hmMobileDigits) ||
      (digits.length >= 8 && digits === acc.udiseCode) ||
      trimmed === acc.udiseCode;

    const isIncMatch =
      lower === incUser ||
      (digits.length >= 8 && digits === incMobileDigits);

    if (isHmMatch || isIncMatch) {
      const targetRole: 'HEADMASTER' | 'MDM_INCHARGE' = role || (isIncMatch && !isHmMatch ? 'MDM_INCHARGE' : 'HEADMASTER');
      const targetMobile = targetRole === 'HEADMASTER'
        ? (creds.headmaster.mobile || acc.headmasterMobile)
        : (creds.incharge.mobile || creds.headmaster.mobile || acc.headmasterMobile);

      // Generate a 6-digit numeric OTP
      const testOtp = Math.floor(100000 + Math.random() * 900000).toString();
      const maskedMobile = targetMobile && targetMobile.length >= 10
        ? `+91-${targetMobile.slice(0, 2)}******${targetMobile.slice(-2)}`
        : targetMobile;

      try {
        sessionStorage.setItem(`mdm_local_otp_${acc.schoolId}`, JSON.stringify({
          otp: testOtp,
          mobile: targetMobile,
          schoolId: acc.schoolId,
          role: targetRole,
          expiresAt: Date.now() + 5 * 60 * 1000,
        }));
      } catch {
        // ignore session storage errors
      }

      return {
        success: true,
        schoolId: acc.schoolId,
        schoolName: acc.schoolName,
        mobile: targetMobile,
        maskedMobile,
        testOtp,
        role: targetRole,
      };
    }
  }

  return {
    success: false,
    error: 'No registered school found with this username or UDISE code.',
  };
}

/**
 * Local / Offline OTP Login Verification
 */
export function verifyLoginOtpLocal(
  mobileOrSchoolId: string,
  otp: string,
  role?: 'HEADMASTER' | 'MDM_INCHARGE'
): {
  success: boolean;
  user?: User;
  error?: string;
} {
  const cleanOtp = (otp || '').trim();
  const accounts = getSchoolAccounts();

  // Check stored session OTP
  let matchedSession: any = null;
  try {
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (key && key.startsWith('mdm_local_otp_')) {
        const raw = sessionStorage.getItem(key);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && (parsed.schoolId === mobileOrSchoolId || normalizeMobileNumber(parsed.mobile) === normalizeMobileNumber(mobileOrSchoolId))) {
            matchedSession = parsed;
            break;
          }
        }
      }
    }
  } catch {
    // ignore
  }

  const acc = matchedSession
    ? accounts.find((a) => a.schoolId === matchedSession.schoolId)
    : accounts.find(
        (a) =>
          a.schoolId === mobileOrSchoolId ||
          normalizeMobileNumber(a.headmasterMobile) === normalizeMobileNumber(mobileOrSchoolId)
      ) || accounts[0];

  if (!acc) {
    return { success: false, error: 'School account not found.' };
  }

  // If session OTP exists, verify match & expiry
  if (matchedSession) {
    if (Date.now() > matchedSession.expiresAt) {
      return { success: false, error: 'OTP has expired. Please request a new OTP.' };
    }
    if (matchedSession.otp !== cleanOtp) {
      return { success: false, error: 'Invalid OTP code. Please enter the correct code.' };
    }
  } else {
    // If no session OTP saved, accept valid 6-digit OTP
    if (cleanOtp.length !== 6 || !/^\d{6}$/.test(cleanOtp)) {
      return { success: false, error: 'Enter valid 6-digit numeric OTP code.' };
    }
  }

  const creds = getStoredCredentials(acc.schoolId);
  const targetRole = role || matchedSession?.role || 'HEADMASTER';
  const isHm = targetRole === 'HEADMASTER';
  const roleCred = isHm ? creds.headmaster : creds.incharge;

  setActiveSchoolId(acc.schoolId);
  acc.lastLoginAt = new Date().toISOString();
  saveSchoolAccounts(accounts);

  const user: User = {
    username: roleCred.username,
    mobile: roleCred.mobile || (isHm ? acc.headmasterMobile : ''),
    name: roleCred.name || (isHm ? acc.headmasterName : 'MDM Incharge'),
    role: isHm ? 'HEADMASTER' : 'MDM_INCHARGE',
    isLoggedIn: true,
    schoolId: acc.schoolId,
    schoolName: acc.schoolName,
    udiseCode: acc.udiseCode,
  };
  saveStoredUser(user, acc.schoolId);

  try {
    sessionStorage.removeItem(`mdm_local_otp_${acc.schoolId}`);
  } catch {
    // ignore
  }

  return {
    success: true,
    user,
  };
}

export function updateLoginCredentials(
  role: 'HEADMASTER' | 'MDM_INCHARGE',
  updates: {
    username?: string;
    mobile?: string;
    password?: string;
    name?: string;
  },
  schoolId?: string
): { success: boolean; message: string; updatedCreds: StoredCredentials } {
  const sId = schoolId || getActiveSchoolId();
  const creds = getStoredCredentials(sId);
  const roleKey = role === 'HEADMASTER' ? 'headmaster' : 'incharge';
  const target = creds[roleKey];

  if (updates.username && updates.username.trim().length < 3) {
    return { success: false, message: 'Username must be at least 3 characters long', updatedCreds: creds };
  }
  if (updates.mobile) {
    const digits = normalizeMobileNumber(updates.mobile);
    if (digits.length !== 10) {
      return { success: false, message: 'Mobile number must be a valid 10-digit number', updatedCreds: creds };
    }
  }
  if (updates.password !== undefined && updates.password !== '' && updates.password.length < 4) {
    return { success: false, message: 'Password must be at least 4 characters long', updatedCreds: creds };
  }

  const rawUdise = sId.startsWith('school_') ? sId.replace('school_', '') : sId;
  creds[roleKey] = {
    ...target,
    username: rawUdise || target.username,
    mobile: updates.mobile !== undefined ? updates.mobile.trim() : target.mobile,
    password: updates.password !== undefined && updates.password !== '' ? updates.password : target.password,
    name: updates.name !== undefined ? updates.name.trim() : target.name,
    updatedAt: new Date().toISOString(),
  };

  saveStoredCredentials(creds, sId);

  // If Headmaster mobile changed, also update schoolProfile phone number for consistency
  if (role === 'HEADMASTER' && updates.mobile) {
    try {
      const profile = getStoredSchoolProfile(sId);
      if (profile) {
        profile.phoneNumber = updates.mobile.trim();
        saveStoredSchoolProfile(profile, sId);
      }
    } catch {
      // Ignore
    }
  }

  return {
    success: true,
    message: `${role === 'HEADMASTER' ? 'Headmaster' : 'MDM Incharge'} login credentials updated successfully for this school!`,
    updatedCreds: creds,
  };
}

// Initial state getters with localStorage fallbacks
export function getStoredUser(schoolId?: string): User {
  const normId = normalizeSchoolId(schoolId);
  const rawUdise = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  try {
    const data = getItemForSchool(STORAGE_KEYS.USER, normId);
    if (data) {
      const parsed: User = JSON.parse(data);
      if (parsed.name === 'K. Sitarama Raju' && normId === DEFAULT_SCHOOL_ID) {
        parsed.name = 'V. CHIRANJEEVI';
        saveStoredUser(parsed, normId);
      }
      return {
        ...parsed,
        schoolId: normId,
        username: (normId !== DEFAULT_SCHOOL_ID && rawUdise) ? rawUdise : (parsed.username || rawUdise),
      };
    }
  } catch (e) {
    console.error('Failed reading user from storage', e);
  }

  // Find school account info
  const accounts = getSchoolAccounts();
  const acc = accounts.find((a) => a.schoolId === normId || a.udiseCode === rawUdise || a.schoolId === `school_${rawUdise}`) || DEFAULT_SCHOOL_ACCOUNT;
  const creds = getStoredCredentials(normId);

  return {
    username: (normId !== DEFAULT_SCHOOL_ID && rawUdise) ? rawUdise : (creds.headmaster.username || acc.udiseCode || 'headmaster'),
    mobile: creds.headmaster.mobile || acc.headmasterMobile,
    name: creds.headmaster.name || acc.headmasterName,
    role: 'HEADMASTER',
    isLoggedIn: false, // Require credentials login every time at first
    schoolId: acc.schoolId || normId,
    schoolName: acc.schoolName,
    udiseCode: acc.udiseCode || rawUdise,
  };
}

export function saveStoredUser(user: User, schoolId?: string): void {
  const normId = normalizeSchoolId(schoolId || user.schoolId);
  try {
    setItemForSchool(STORAGE_KEYS.USER, JSON.stringify(user), normId);
    recordLocalUpdate(STORAGE_KEYS.USER);
    saveToCloud(STORAGE_KEYS.USER, user, normId);
  } catch (e) {
    console.error('Failed saving user', e);
  }
}

export function getStoredSchoolProfile(schoolId?: string): SchoolProfile {
  const normId = normalizeSchoolId(schoolId);
  const rawUdise = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  try {
    const data = getItemForSchool(STORAGE_KEYS.PROFILE, normId);
    if (data) {
      const parsed: SchoolProfile = JSON.parse(data);
      const merged: SchoolProfile = { ...defaultSchoolProfile, ...parsed };
      let updated = false;
      if (normId === DEFAULT_SCHOOL_ID) {
        if (parsed.schoolName === 'M.P.P. School (Main)' || parsed.schoolName === 'M. P. P. SCHOOL R. B. R. PETA') {
          merged.schoolName = 'M. P. P. SCHOOL R.B.R.PETA';
          updated = true;
        }
        if (parsed.headmasterName === 'K. Sitarama Raju') {
          merged.headmasterName = 'V. CHIRANJEEVI';
          updated = true;
        }
        if (parsed.village === undefined) {
          merged.village = defaultSchoolProfile.village || 'R.B.R.PETA';
          updated = true;
        }
        if (parsed.mandal === undefined) {
          merged.mandal = defaultSchoolProfile.mandal || 'PALAKONDA';
          updated = true;
        }
        if (parsed.district === undefined) {
          merged.district = defaultSchoolProfile.district || 'PARVATHI PURAM MANYAM';
          updated = true;
        }
        if (parsed.state === undefined) {
          merged.state = defaultSchoolProfile.state || 'ANDHRA PRADESH';
          updated = true;
        }
      } else {
        // Individual school: strictly ensure demo school details never leak
        if (merged.udiseCode === '28140100101' || merged.udiseCode === '28261800503' || !merged.udiseCode) {
          merged.udiseCode = rawUdise;
          updated = true;
        }
        if (merged.schoolName === 'M. P. P. SCHOOL R.B.R.PETA') {
          const accounts = getSchoolAccounts();
          const acc = accounts.find((a) => a.schoolId === normId || a.udiseCode === rawUdise || a.schoolId === `school_${rawUdise}`);
          if (acc && acc.schoolName && acc.schoolName !== 'M. P. P. SCHOOL R.B.R.PETA') {
            merged.schoolName = acc.schoolName;
            merged.udiseCode = acc.udiseCode || rawUdise;
            if (acc.headmasterName) merged.headmasterName = acc.headmasterName;
            if (acc.headmasterMobile) merged.phoneNumber = acc.headmasterMobile;
            if (acc.village) merged.village = acc.village;
            if (acc.mandal) merged.mandal = acc.mandal;
            if (acc.district) merged.district = acc.district;
            updated = true;
          }
        }
      }
      if (updated) {
        saveStoredSchoolProfile(merged, normId);
      }
      return merged;
    }
  } catch (e) {
    console.error('Failed reading school profile', e);
  }

  // If not found in storage, initialize from SchoolAccount
  const accounts = getSchoolAccounts();
  const acc = accounts.find((a) => a.schoolId === normId || a.udiseCode === rawUdise || a.schoolId === `school_${rawUdise}`);
  if (acc) {
    const prof: SchoolProfile = {
      ...defaultSchoolProfile,
      schoolName: acc.schoolName,
      udiseCode: acc.udiseCode || rawUdise,
      headmasterName: acc.headmasterName,
      phoneNumber: acc.headmasterMobile,
      village: acc.village || '',
      mandal: acc.mandal || 'PALAKONDA',
      district: acc.district || 'PARVATHI PURAM MANYAM',
      state: acc.state || 'ANDHRA PRADESH',
      address: `${acc.schoolName}, ${acc.mandal || 'PALAKONDA'}, ${acc.district || 'PARVATHI PURAM MANYAM'}`,
    };
    saveStoredSchoolProfile(prof, normId);
    return prof;
  }

  // For non-default school with no account, return isolated baseline with rawUdise
  if (normId !== DEFAULT_SCHOOL_ID) {
    const prof: SchoolProfile = {
      ...defaultSchoolProfile,
      schoolName: `School ${rawUdise}`,
      udiseCode: rawUdise,
      village: '',
      address: `School ${rawUdise}`,
    };
    saveStoredSchoolProfile(prof, normId);
    return prof;
  }

  return defaultSchoolProfile;
}

export function saveStoredSchoolProfile(profile: SchoolProfile, schoolId?: string): void {
  const normId = normalizeSchoolId(schoolId);
  const rawUdise = normId.startsWith('school_') ? normId.replace('school_', '') : normId;
  try {
    setItemForSchool(STORAGE_KEYS.PROFILE, JSON.stringify(profile), normId);
    recordLocalUpdate(STORAGE_KEYS.PROFILE);
    saveToCloud(STORAGE_KEYS.PROFILE, profile, normId);

    // Also update SchoolAccount record in registry if school details changed
    const accounts = getSchoolAccounts();
    const accIndex = accounts.findIndex((a) => a.schoolId === normId || a.udiseCode === rawUdise || a.schoolId === `school_${rawUdise}`);
    if (accIndex >= 0) {
      accounts[accIndex].schoolName = profile.schoolName;
      accounts[accIndex].udiseCode = profile.udiseCode;
      accounts[accIndex].headmasterName = profile.headmasterName;
      accounts[accIndex].headmasterMobile = profile.phoneNumber;
      accounts[accIndex].village = profile.village;
      accounts[accIndex].mandal = profile.mandal;
      accounts[accIndex].district = profile.district;
      saveSchoolAccounts(accounts);
    }
  } catch (e) {
    console.error('Failed saving school profile', e);
  }
}

export function getStoredBaselineStudentStrength(schoolId?: string): StudentClassStrength[] {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_baseline_student_strength', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading baseline student strength', e);
  }
  return defaultStudentStrength;
}

export function saveStoredBaselineStudentStrength(strengths: StudentClassStrength[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_baseline_student_strength', JSON.stringify(strengths), sId);
    recordLocalUpdate('mdm_baseline_student_strength');
    saveToCloud('mdm_baseline_student_strength', strengths, sId);
  } catch (e) {
    console.error('Failed saving baseline student strength', e);
  }
}

export function getStoredStudentStrength(schoolId?: string): StudentClassStrength[] {
  const sId = schoolId || getActiveSchoolId();
  // 1. Check latest effective recorded update from daily & monthly maps so changes persist across app restart
  try {
    const dailyMap = getStoredDailyStudentStrengths(sId);
    const monthlyMap = getStoredMonthlyStudentStrengths(sId);

    const combinedMap: Record<string, StudentClassStrength[]> = { ...dailyMap };
    Object.keys(monthlyMap).forEach((m) => {
      const monthFirstDay = `${m}-01`;
      if (!combinedMap[monthFirstDay]) {
        combinedMap[monthFirstDay] = monthlyMap[m];
      }
    });

    const dates = Object.keys(combinedMap).sort();
    if (dates.length > 0) {
      const today = new Date().toISOString().substring(0, 10);
      const effectiveDates = dates.filter((d) => d <= today);
      if (effectiveDates.length > 0) {
        return combinedMap[effectiveDates[effectiveDates.length - 1]];
      }
      return combinedMap[dates[dates.length - 1]];
    }
  } catch (e) {
    console.error('Failed reading student strength from maps', e);
  }

  // 2. Fallback to direct stored strength
  try {
    const data = getItemForSchool(STORAGE_KEYS.STUDENT_STRENGTH, sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading student strength', e);
  }
  if (sId !== DEFAULT_SCHOOL_ID) {
    const entries = getStoredDailyEntries(sId);
    if (entries && entries.length > 0) {
      const latest = entries[entries.length - 1];
      const pAtt = latest.primaryAttendance || 0;
      const upAtt = latest.upperPrimaryAttendance || 0;
      if (pAtt > 0 || upAtt > 0) {
        return [
          { classLevel: 'Class 1', category: 'Primary', boys: Math.ceil(pAtt / 10), girls: Math.floor(pAtt / 10), total: Math.ceil(pAtt / 5) },
          { classLevel: 'Class 2', category: 'Primary', boys: Math.ceil(pAtt / 10), girls: Math.floor(pAtt / 10), total: Math.ceil(pAtt / 5) },
          { classLevel: 'Class 3', category: 'Primary', boys: Math.ceil(pAtt / 10), girls: Math.floor(pAtt / 10), total: Math.ceil(pAtt / 5) },
          { classLevel: 'Class 4', category: 'Primary', boys: Math.ceil(pAtt / 10), girls: Math.floor(pAtt / 10), total: Math.ceil(pAtt / 5) },
          { classLevel: 'Class 5', category: 'Primary', boys: Math.ceil(pAtt / 10), girls: Math.floor(pAtt / 10), total: pAtt - (Math.ceil(pAtt / 5) * 4) > 0 ? pAtt - (Math.ceil(pAtt / 5) * 4) : Math.ceil(pAtt / 5) },
          { classLevel: 'Class 6', category: 'Upper Primary', boys: Math.ceil(upAtt / 6), girls: Math.floor(upAtt / 6), total: Math.ceil(upAtt / 3) },
          { classLevel: 'Class 7', category: 'Upper Primary', boys: Math.ceil(upAtt / 6), girls: Math.floor(upAtt / 6), total: Math.ceil(upAtt / 3) },
          { classLevel: 'Class 8', category: 'Upper Primary', boys: Math.ceil(upAtt / 6), girls: Math.floor(upAtt / 6), total: upAtt - (Math.ceil(upAtt / 3) * 2) > 0 ? upAtt - (Math.ceil(upAtt / 3) * 2) : Math.ceil(upAtt / 3) },
        ];
      }
    }
  }
  return defaultStudentStrength;
}

export function saveStoredStudentStrength(strength: StudentClassStrength[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.STUDENT_STRENGTH, JSON.stringify(strength), sId);
    recordLocalUpdate(STORAGE_KEYS.STUDENT_STRENGTH);
    saveToCloud(STORAGE_KEYS.STUDENT_STRENGTH, strength, sId);
  } catch (e) {
    console.error('Failed saving student strength', e);
  }
}

export function getStoredMonthlyStudentStrengths(schoolId?: string): Record<string, StudentClassStrength[]> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_student_strength_monthly', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading monthly student strengths', e);
  }
  return {};
}

export function saveStoredMonthlyStudentStrengths(monthlyStrengths: Record<string, StudentClassStrength[]>, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_student_strength_monthly', JSON.stringify(monthlyStrengths), sId);
    recordLocalUpdate('mdm_student_strength_monthly');
    saveToCloud('mdm_student_strength_monthly', monthlyStrengths, sId);
  } catch (e) {
    console.error('Failed saving monthly student strengths', e);
  }
}

export function getStoredDailyStudentStrengths(schoolId?: string): Record<string, StudentClassStrength[]> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_student_strength_daily', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading daily student strengths', e);
  }
  return {};
}

export function saveStoredDailyStudentStrengths(dailyStrengths: Record<string, StudentClassStrength[]>, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_student_strength_daily', JSON.stringify(dailyStrengths), sId);
    recordLocalUpdate('mdm_student_strength_daily');
    saveToCloud('mdm_student_strength_daily', dailyStrengths, sId);
  } catch (e) {
    console.error('Failed saving daily student strengths', e);
  }
}

/**
 * Retrieves student strength effective on a given date (YYYY-MM-DD).
 * Finds the latest strength update recorded on or before dateStr.
 * That strength update remains effective from that day onwards until the next update occurs.
 */
export function getStudentStrengthForDate(dateStr: string, schoolId?: string): StudentClassStrength[] {
  const sId = schoolId || getActiveSchoolId();
  const dailyMap = getStoredDailyStudentStrengths(sId);
  const monthlyMap = getStoredMonthlyStudentStrengths(sId);

  // Combine dailyMap keys and monthlyMap keys (as YYYY-MM-01) for seamless backward compatibility
  const combinedMap: Record<string, StudentClassStrength[]> = { ...dailyMap };
  Object.keys(monthlyMap).forEach((m) => {
    const monthFirstDay = `${m}-01`;
    if (!combinedMap[monthFirstDay]) {
      combinedMap[monthFirstDay] = monthlyMap[m];
    }
  });

  const dates = Object.keys(combinedMap).sort();

  // 1. Check for exact or latest update on or before dateStr
  const validDates = dates.filter((d) => d <= dateStr);
  if (validDates.length > 0) {
    const latestEffectiveDate = validDates[validDates.length - 1];
    return combinedMap[latestEffectiveDate];
  }

  // 2. Fallback to baseline stored strength if dateStr is before all recorded updates
  return getStoredBaselineStudentStrength(sId);
}

export function getStoredStudentStrengthRemarks(schoolId?: string): Record<string, string> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_student_strength_remarks', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading student strength remarks', e);
  }
  return {};
}

export function saveStoredStudentStrengthRemarks(remarks: Record<string, string>, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_student_strength_remarks', JSON.stringify(remarks), sId);
    recordLocalUpdate('mdm_student_strength_remarks');
    saveToCloud('mdm_student_strength_remarks', remarks, sId);
  } catch (e) {
    console.error('Failed saving student strength remarks', e);
  }
}

export function getStudentStrengthRemarkForDate(dateStr: string, schoolId?: string): string {
  const remarksMap = getStoredStudentStrengthRemarks(schoolId);
  return remarksMap[dateStr] || '';
}

export function saveStudentStrengthRemarkForDate(dateStr: string, remark: string, schoolId?: string): void {
  const remarksMap = getStoredStudentStrengthRemarks(schoolId);
  remarksMap[dateStr] = remark;
  saveStoredStudentStrengthRemarks(remarksMap, schoolId);
}

/**
 * Automatically propagates a student roll change to subsequent daily entries up to the next update date.
 * If the entry was tracking the previous roll or was non-manual, attendance, meals served, and commodity usages
 * are updated to match the new roll. Any manual entries exceeding the new roll are capped.
 */
export function updateNextDaysForRollChange(
  dateStr: string,
  newStrengths: StudentClassStrength[],
  oldStrengths?: StudentClassStrength[]
): DailyEntry[] {
  const dailyEntries = getStoredDailyEntries();
  const dailyMap = getStoredDailyStudentStrengths();

  const newPrimaryRoll = newStrengths
    .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
    .reduce((sum, s) => sum + s.total, 0);
  const newUpperPrimaryRoll = newStrengths
    .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
    .reduce((sum, s) => sum + s.total, 0);

  const oldPrimaryRoll = oldStrengths
    ? oldStrengths
        .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
        .reduce((sum, s) => sum + s.total, 0)
    : undefined;
  const oldUpperPrimaryRoll = oldStrengths
    ? oldStrengths
        .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
        .reduce((sum, s) => sum + s.total, 0)
    : undefined;

  // A future date in dailyMap is only a genuine "next update" if its roll differs from both old and new roll
  const allUpdateDates = Object.keys(dailyMap).sort();
  const nextUpdateDate = allUpdateDates.find((d) => {
    if (d <= dateStr) return false;
    const futureStrengths = dailyMap[d];
    if (!futureStrengths || futureStrengths.length === 0) return false;
    const p = futureStrengths
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.total, 0);
    const up = futureStrengths
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.total, 0);
    // If it equals the new roll or the old roll, it's not a different subsequent update
    return (p !== newPrimaryRoll || up !== newUpperPrimaryRoll) && (oldPrimaryRoll === undefined || p !== oldPrimaryRoll || up !== oldUpperPrimaryRoll);
  });

  let hasChanges = false;
  const updatedEntries = dailyEntries.map((entry) => {
    // Only update entries strictly after dateStr and strictly before the next update date
    if (entry.date > dateStr && (!nextUpdateDate || entry.date < nextUpdateDate)) {
      const dayInfo = getDayDetails(entry.date);
      const isHol =
        dayInfo.isSunday ||
        dayInfo.isHoliday ||
        (entry.mealsServed === 0 &&
          Boolean(entry.remarks && (entry.remarks.toLowerCase().includes('holiday') || entry.remarks.toLowerCase().includes('sunday'))));

      if (isHol) {
        return entry;
      }

      const dayOfWeek = dayInfo.dayOfWeek;
      let pAtt = entry.primaryAttendance;
      let upAtt = entry.upperPrimaryAttendance;

      // Preserve manually edited entries (isManual: true) - never revert or change them!
      if (entry.isManual) {
        pAtt = Math.min(pAtt, newPrimaryRoll);
        upAtt = Math.min(upAtt, newUpperPrimaryRoll);
      } else {
        // Non-manual entries follow the roll
        pAtt = newPrimaryRoll;
        upAtt = newUpperPrimaryRoll;
      }

      const totalAtt = pAtt + upAtt + (entry.highSchoolAttendance || 0);
      let mealsServed = entry.mealsServed;
      if (entry.isManual) {
        mealsServed = Math.min(mealsServed, totalAtt);
      } else {
        mealsServed = totalAtt;
      }

      const rice =
        mealsServed > 0 && totalAtt > 0
          ? Number((((pAtt * 0.1) + (upAtt * 0.15)) * (mealsServed / totalAtt)).toFixed(2))
          : Number(((pAtt * 0.1) + (upAtt * 0.15)).toFixed(2));
      const egg = dayOfWeek >= 1 && dayOfWeek <= 5 ? mealsServed : 0;
      const chikki = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5 ? mealsServed : 0;
      const ragi = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6 ? Number((mealsServed * 0.01).toFixed(2)) : 0;
      const jaggery = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6 ? Number((mealsServed * 0.01).toFixed(2)) : 0;
      const oil = Number((mealsServed * 0.005).toFixed(2));
      const pulses = Number((mealsServed * 0.02).toFixed(2));

      hasChanges = true;
      return {
        ...entry,
        primaryAttendance: pAtt,
        upperPrimaryAttendance: upAtt,
        totalAttendance: totalAtt,
        mealsServed: mealsServed,
        riceUsedKg: rice,
        eggUsedQty: egg,
        chikkiUsedQty: chikki,
        ragiUsedKg: ragi,
        jaggeryUsedKg: jaggery,
        oilUsedKg: oil,
        dalUsedKg: pulses,
        updatedAt: new Date().toISOString(),
      };
    }
    return entry;
  });

  if (hasChanges) {
    saveStoredDailyEntries(updatedEntries);
  }
  return updatedEntries;
}

/**
 * Save student strength effective for a specific date (YYYY-MM-DD).
 * This update automatically carries forward for all subsequent days up to the next update,
 * while STRICTLY preserving previous days so earlier rolls are never overwritten.
 */
export function saveStudentStrengthForDate(dateStr: string, strengths: StudentClassStrength[], remark?: string): void {
  const dailyMap = getStoredDailyStudentStrengths();
  const remarksMap = getStoredStudentStrengthRemarks();
  const monthlyMap = getStoredMonthlyStudentStrengths();

  // 1. Determine the effective strength on the day immediately preceding dateStr
  const prevDateObj = new Date(dateStr + 'T00:00:00Z');
  prevDateObj.setUTCDate(prevDateObj.getUTCDate() - 1);
  const dayBeforeStr = prevDateObj.toISOString().substring(0, 10);
  const oldStrengths = getStudentStrengthForDate(dayBeforeStr);

  const oldPrimary = oldStrengths
    .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
    .reduce((sum, s) => sum + s.total, 0);
  const oldUpper = oldStrengths
    .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
    .reduce((sum, s) => sum + s.total, 0);

  const monthStr = dateStr.substring(0, 7);
  const monthFirstDay = `${monthStr}-01`;

  // 2. Safeguard previous days so their roll NEVER changes:
  // (a) If editing after the 1st of the month (e.g. 2026-08-10), ensure the 1st of this month
  // is explicitly recorded in dailyMap with the strength that was active at the start of this month.
  if (dateStr > monthFirstDay && !dailyMap[monthFirstDay]) {
    const monthStartStrength = getStudentStrengthForDate(monthFirstDay);
    dailyMap[monthFirstDay] = monthStartStrength;
    if (!remarksMap[monthFirstDay]) {
      remarksMap[monthFirstDay] = 'Month baseline roll';
    }
  }

  // (b) If there are no recorded updates strictly before dateStr anywhere in history,
  // anchor the baseline start of the school year / period so all prior dates permanently retain oldStrengths.
  const existingRecordedDates = Array.from(new Set([
    ...Object.keys(dailyMap),
    ...Object.keys(monthlyMap).map((m) => `${m}-01`),
  ])).sort();
  const priorRecordedDates = existingRecordedDates.filter((d) => d < dateStr);

  if (priorRecordedDates.length === 0) {
    const baselineDate = dateStr > '2026-06-01' ? '2026-06-01' : (dateStr > monthFirstDay ? monthFirstDay : '2026-01-01');
    if (baselineDate < dateStr && !dailyMap[baselineDate]) {
      dailyMap[baselineDate] = oldStrengths;
      if (!remarksMap[baselineDate]) {
        remarksMap[baselineDate] = 'Initial baseline roll';
      }
    }
  }

  // 3. Clean up any subsequent stale entries in dailyMap that had the old roll or were auto-generated
  // so they don't block the new roll from propagating forward to next days!
  Object.keys(dailyMap).forEach((d) => {
    if (d > dateStr) {
      const futureStrengths = dailyMap[d];
      if (futureStrengths) {
        const fp = futureStrengths
          .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
          .reduce((sum, s) => sum + s.total, 0);
        const fup = futureStrengths
          .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
          .reduce((sum, s) => sum + s.total, 0);
        const rk = remarksMap[d] || '';
        if ((fp === oldPrimary && fup === oldUpper) || rk.includes('Register Roll updated')) {
          delete dailyMap[d];
          delete remarksMap[d];
        }
      }
    }
  });

  // 4. Save this date's new strength
  dailyMap[dateStr] = strengths;
  saveStoredDailyStudentStrengths(dailyMap);

  if (remark !== undefined) {
    saveStudentStrengthRemarkForDate(dateStr, remark);
  }

  // 5. Monthly map updates:
  // monthlyMap represents the roll effective as of the FIRST day of that month (YYYY-MM-01).
  // If dateStr === monthFirstDay, the update is for the 1st of the month, so monthlyMap[monthStr] is updated.
  // If dateStr > monthFirstDay, monthlyMap[monthStr] MUST NOT be updated to the new strength (as that would backdate to the 1st).
  // Instead, monthlyMap[monthStr] retains the strength at the start of that month.
  if (dateStr === monthFirstDay) {
    monthlyMap[monthStr] = strengths;
  } else if (!monthlyMap[monthStr]) {
    monthlyMap[monthStr] = dailyMap[monthFirstDay] || oldStrengths;
  }

  // Also update any future months in monthlyMap that had the old roll so future months inherit the new roll
  Object.keys(monthlyMap).forEach((m) => {
    if (m > monthStr) {
      const ms = monthlyMap[m];
      const mp = ms
        .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
        .reduce((sum, s) => sum + s.total, 0);
      const mup = ms
        .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
        .reduce((sum, s) => sum + s.total, 0);
      if (mp === oldPrimary && mup === oldUpper) {
        monthlyMap[m] = strengths;
      }
    }
  });
  saveStoredMonthlyStudentStrengths(monthlyMap);

  // Keep the active global stored student strength updated with latest roll
  saveStoredStudentStrength(strengths);

  // 6. Automatically propagate the roll change to next days up to the next genuine update!
  updateNextDaysForRollChange(dateStr, strengths, oldStrengths);
}

export function deleteStudentStrengthForDate(dateStr: string): void {
  const dailyMap = getStoredDailyStudentStrengths();
  delete dailyMap[dateStr];
  saveStoredDailyStudentStrengths(dailyMap);

  const remarksMap = getStoredStudentStrengthRemarks();
  delete remarksMap[dateStr];
  saveStoredStudentStrengthRemarks(remarksMap);

  // Re-synchronize next days to the now effective strength
  const effectiveStrengths = getStudentStrengthForDate(dateStr);
  updateNextDaysForRollChange(dateStr, effectiveStrengths);
}

/**
 * Calculates and returns the list of ONLY dates where student strength was explicitly updated/changed.
 * For each updated date, returns class-wise, sex-wise totals, subtotals, and differences vs previous recorded strength.
 * If monthStr is provided, filters for updates in that month.
 */
export function getStudentStrengthUpdatesList(monthStr?: string): StudentStrengthUpdateRecord[] {
  const dailyMap = getStoredDailyStudentStrengths();
  const monthlyMap = getStoredMonthlyStudentStrengths();
  const remarksMap = getStoredStudentStrengthRemarks();

  // Combine dailyMap keys and monthlyMap keys (as YYYY-MM-01) for seamless backward compatibility
  const combinedMap: Record<string, StudentClassStrength[]> = { ...dailyMap };
  Object.keys(monthlyMap).forEach((m) => {
    const monthFirstDay = `${m}-01`;
    if (!combinedMap[monthFirstDay]) {
      combinedMap[monthFirstDay] = monthlyMap[m];
    }
  });

  const dates = Object.keys(combinedMap).sort();
  if (dates.length === 0) {
    // If no daily updates are saved yet, check if default student strength exists as initial baseline
    const defaultStrengths = getStoredStudentStrength();
    const todayStr = new Date().toISOString().substring(0, 10);
    combinedMap[todayStr] = defaultStrengths;
    dates.push(todayStr);
  }

  const updateRecords: StudentStrengthUpdateRecord[] = [];
  let prevStrengths: StudentClassStrength[] | null = null;
  let prevDate: string | undefined = undefined;

  dates.forEach((dateStr) => {
    const strengths = combinedMap[dateStr];

    // Compute category subtotals and totals
    let primaryBoys = 0;
    let primaryGirls = 0;
    let upperBoys = 0;
    let upperGirls = 0;

    strengths.forEach((s) => {
      const isPrimary = s.category === 'Primary' || Boolean(s.classLevel && s.classLevel.match(/class\s*[1-5]/i));
      if (isPrimary) {
        primaryBoys += s.boys;
        primaryGirls += s.girls;
      } else {
        upperBoys += s.boys;
        upperGirls += s.girls;
      }
    });

    const primaryTotal = primaryBoys + primaryGirls;
    const upperTotal = upperBoys + upperGirls;
    const totalBoys = primaryBoys + upperBoys;
    const totalGirls = primaryGirls + upperGirls;
    const grandTotal = totalBoys + totalGirls;

    // Detect changes vs prevStrengths
    let isChanged = false;
    const diffs: string[] = [];

    if (!prevStrengths) {
      isChanged = true; // First recorded update entry
    } else {
      strengths.forEach((curr) => {
        const prev = prevStrengths!.find((p) => p.classLevel === curr.classLevel);
        if (prev) {
          const boysDiff = curr.boys - prev.boys;
          const girlsDiff = curr.girls - prev.girls;
          if (boysDiff !== 0 || girlsDiff !== 0) {
            isChanged = true;
            const diffParts: string[] = [];
            if (boysDiff > 0) diffParts.push(`+${boysDiff} Boys`);
            else if (boysDiff < 0) diffParts.push(`${boysDiff} Boys`);
            if (girlsDiff > 0) diffParts.push(`+${girlsDiff} Girls`);
            else if (girlsDiff < 0) diffParts.push(`${girlsDiff} Girls`);
            diffs.push(`${curr.classLevel}: ${diffParts.join(', ')}`);
          }
        } else {
          isChanged = true;
          diffs.push(`Added ${curr.classLevel}`);
        }
      });
    }

    // ONLY create/add a row if there was an actual strength update on this date!
    if (isChanged) {
      updateRecords.push({
        id: `strength_upd_${dateStr}`,
        date: dateStr,
        strengths,
        remarks: remarksMap[dateStr] || (prevStrengths ? 'Enrolment Updated' : 'Initial Enrolment Record'),
        previousDate: prevDate,
        primaryBoys,
        primaryGirls,
        primaryTotal,
        upperBoys,
        upperGirls,
        upperTotal,
        totalBoys,
        totalGirls,
        grandTotal,
        changesSummary: diffs.length > 0 ? diffs.join('; ') : 'Initial Enrolment',
        updatedAt: dateStr,
      });

      prevStrengths = strengths;
      prevDate = dateStr;
    }
  });

  // Filter by month if provided and not 'ALL'
  let filtered = updateRecords;
  if (monthStr && monthStr !== 'ALL') {
    filtered = updateRecords.filter((r) => r.date.startsWith(monthStr));
  }

  // Sort descending by date (newest change row first)
  return filtered.sort((a, b) => b.date.localeCompare(a.date));
}

export function getStudentStrengthForMonth(monthStr: string): StudentClassStrength[] {
  const monthLastDay = `${monthStr}-31`;
  return getStudentStrengthForDate(monthLastDay);
}

export function saveStudentStrengthForMonth(monthStr: string, strengths: StudentClassStrength[]): void {
  const monthFirstDay = `${monthStr}-01`;
  saveStudentStrengthForDate(monthFirstDay, strengths);
}

export function getStoredDailyEntries(schoolId?: string): DailyEntry[] {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.DAILY_ENTRIES, sId);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading daily entries', e);
  }
  return [];
}

export function saveStoredDailyEntries(entries: DailyEntry[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.DAILY_ENTRIES, JSON.stringify(entries), sId);
    recordLocalUpdate(STORAGE_KEYS.DAILY_ENTRIES);
    saveToCloud(STORAGE_KEYS.DAILY_ENTRIES, entries, sId);
  } catch (e) {
    console.error('Failed saving daily entries', e);
  }
}

export function getStoredCommodities(schoolId?: string): CommodityItem[] {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.COMMODITIES, sId);
    if (data) {
      const parsed: CommodityItem[] = JSON.parse(data);
      let updated = false;

      // Merge default commodities (e.g. oil, pulses) if missing
      defaultCommodities.forEach((defComm) => {
        if (!parsed.some((c) => c.id === defComm.id)) {
          parsed.push(defComm);
          updated = true;
        }
      });

      parsed.forEach((c) => {
        if (c.name.toLowerCase().includes('sona masuri')) {
          c.name = 'Rice';
          updated = true;
        }
        if (c.name.toLowerCase().includes('boiled')) {
          c.name = c.name.replace(/boiled\s*/i, '');
          if (!c.name.trim()) c.name = 'Eggs';
          updated = true;
        }
        if (c.name.toLowerCase().includes('peanut')) {
          c.name = c.name.replace(/peanut\s*/i, '');
          if (!c.name.trim()) c.name = 'Chikki';
          updated = true;
        }
        // Ensure physical opening balances are never negative, EXCEPT for legitimate negative balances in Eggs and Chikki
        const isEggOrChikki = c.id === 'egg' || c.id === 'chikki' || c.name.toLowerCase().includes('egg') || c.name.toLowerCase().includes('chikki');
        if (!isEggOrChikki && typeof c.openingBalance === 'number' && c.openingBalance < 0) {
          c.openingBalance = 0;
          updated = true;
        }
      });

      // Synchronize Jaggery with Ragi if requested (same OB, received, used, spoils, balance)
      const ragiComm = parsed.find((c) => c.id === 'ragi');
      const jaggeryComm = parsed.find((c) => c.id === 'jaggery');
      if (ragiComm && jaggeryComm) {
        if (jaggeryComm.openingBalance !== ragiComm.openingBalance) {
          jaggeryComm.openingBalance = ragiComm.openingBalance;
          updated = true;
        }
        if (jaggeryComm.minThreshold !== ragiComm.minThreshold) {
          jaggeryComm.minThreshold = ragiComm.minThreshold;
          updated = true;
        }
      }
      if (updated) {
        saveStoredCommodities(parsed, sId);
      }
      return parsed;
    }
  } catch (e) {
    console.error('Failed reading commodities', e);
  }
  if (sId !== DEFAULT_SCHOOL_ID) {
    return defaultCommodities.map((c) => ({
      ...c,
      openingBalance: 0,
      receivedQuantity: 0,
      consumedQuantity: 0,
      currentBalance: 0,
    }));
  }
  return defaultCommodities;
}

export function saveStoredCommodities(commodities: CommodityItem[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    const sanitized = commodities.map((c) => ({
      ...c,
      openingBalance: safeRound3(c.openingBalance ?? 0),
    }));
    setItemForSchool(STORAGE_KEYS.COMMODITIES, JSON.stringify(sanitized), sId);
    recordLocalUpdate(STORAGE_KEYS.COMMODITIES);
    saveToCloud(STORAGE_KEYS.COMMODITIES, sanitized, sId);
  } catch (e) {
    console.error('Failed saving commodities', e);
  }
}

export function getStoredStockTransactions(schoolId?: string): StockTransaction[] {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.STOCK_TRANSACTIONS, sId);
    if (data) {
      const parsed: StockTransaction[] = JSON.parse(data);
      // Clean out legacy test adjustments if present
      const filtered = parsed.filter((tx) => {
        if (tx.id === 'tx-106') return false;
        if (tx.id && tx.id.startsWith('tx-adj-2026-08-31')) return false;
        return true;
      });

      if (filtered.length !== parsed.length) {
        saveStoredStockTransactions(filtered, sId);
      }
      return filtered;
    }
  } catch (e) {
    console.error('Failed reading stock transactions', e);
  }
  return defaultStockTransactions;
}

export function saveStoredStockTransactions(txs: StockTransaction[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.STOCK_TRANSACTIONS, JSON.stringify(txs), sId);
    recordLocalUpdate(STORAGE_KEYS.STOCK_TRANSACTIONS);
    saveToCloud(STORAGE_KEYS.STOCK_TRANSACTIONS, txs, sId);
  } catch (e) {
    console.error('Failed saving stock transactions', e);
  }
}

export function getStoredMealRates(schoolId?: string): MealRates {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.MEAL_RATES, sId);
    if (data) {
      const parsed = JSON.parse(data);
      return { ...defaultMealRates, ...parsed };
    }
  } catch (e) {
    console.error('Failed reading meal rates', e);
  }
  return defaultMealRates;
}

export function saveStoredMealRates(rates: MealRates, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.MEAL_RATES, JSON.stringify(rates), sId);
    recordLocalUpdate(STORAGE_KEYS.MEAL_RATES);
    saveToCloud(STORAGE_KEYS.MEAL_RATES, rates, sId);
  } catch (e) {
    console.error('Failed saving meal rates', e);
  }
}

export const defaultAutomationSettings: AutomationSettings = {
  autoCalculateNorms: true,
  autoSave: true,
  autoMorningAttendanceRoll: true,
  morningRollCutoffTime: '07:30',
  autoCarryForwardStock: true,
  autoCloudSync: true,
  autoFillFullAttendanceOnNewDay: true,
  autoMenuIndentAlignment: true,
  autoCalculateExpenditure: true,
};

export function getStoredAutomationSettings(schoolId?: string): AutomationSettings {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.SETTINGS, sId);
    if (data) {
      const parsed = JSON.parse(data);
      return { ...defaultAutomationSettings, ...(parsed.automation || parsed) };
    }
  } catch (e) {
    console.error('Failed reading automation settings', e);
  }
  return defaultAutomationSettings;
}

export function saveStoredAutomationSettings(settings: AutomationSettings, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.SETTINGS, JSON.stringify(settings), sId);
    recordLocalUpdate(STORAGE_KEYS.SETTINGS);
    saveToCloud(STORAGE_KEYS.SETTINGS, settings, sId);
  } catch (e) {
    console.error('Failed saving automation settings', e);
  }
}

export function getStoredAppSettings(schoolId?: string): AppSettings {
  const sId = schoolId || getActiveSchoolId();
  return {
    schoolProfile: getStoredSchoolProfile(sId),
    mealRates: getStoredMealRates(sId),
    academicYear: getStoredSchoolProfile(sId).academicYear || '2026-2027',
    darkMode: true,
    autoCalculateStock: true,
    autoSave: getStoredAutomationSettings(sId).autoSave,
    automation: getStoredAutomationSettings(sId),
  };
}

export function saveStoredAppSettings(settings: AppSettings, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  if (settings.schoolProfile) saveStoredSchoolProfile(settings.schoolProfile, sId);
  if (settings.mealRates) saveStoredMealRates(settings.mealRates, sId);
  if (settings.automation) saveStoredAutomationSettings(settings.automation, sId);
}

export type MonthlyCommodityOverrides = Record<string, Record<string, number>>;

export function getStoredMonthlyCommodityBalances(schoolId?: string): MonthlyCommodityOverrides {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool(STORAGE_KEYS.MONTHLY_COMMODITIES, sId);
    if (data) {
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object') {
        const sanitized: MonthlyCommodityOverrides = {};
        Object.entries(parsed).forEach(([key, val]) => {
          if (!val || typeof val !== 'object') return;
          const sanitizeValues = (vObj: Record<string, number>): Record<string, number> => {
            const clean: Record<string, number> = {};
            Object.entries(vObj).forEach(([commId, num]) => {
              if (typeof num === 'number' && !isNaN(num)) {
                clean[commId] = safeRound3(num);
              }
            });
            if (clean['ragi'] !== undefined) {
              clean['jaggery'] = clean['ragi'];
            }
            return clean;
          };

          const monthKey = key.length === 10 ? key.substring(0, 7) : key;
          const manualMap = getStoredManualObMonths(sId);
          const isManual = Boolean(manualMap[monthKey] || manualMap[key]);
          const isBaselineMonth = monthKey === '2026-08';

          // If not baseline and not an explicit manual edit, filter out stale unflagged overrides
          // so that automatic carry-forward from previous month closing balance is strictly preserved
          if (!isBaselineMonth && !isManual) {
            return; // Skip stale unflagged override to ensure automatic continuous carry-forward
          }

          // Valid month key e.g. "2026-08" or valid date key e.g. "2026-09-05"
          if (key.length === 7 && key.includes('-')) {
            sanitized[key] = sanitizeValues(val as Record<string, number>);
          } else if (key.length === 10 && key.includes('-')) {
            sanitized[key] = sanitizeValues(val as Record<string, number>);
            // First day of month override e.g. "2026-08-01", also map to "2026-08" if not present
            if (key.endsWith('-01')) {
              if (!sanitized[monthKey]) {
                sanitized[monthKey] = sanitizeValues(val as Record<string, number>);
              }
            }
          }
        });
        return sanitized;
      }
    }
  } catch (e) {
    console.error('Failed reading monthly commodity balances', e);
  }
  return {};
}

export function getStoredManualObMonths(schoolId?: string): Record<string, boolean> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_manual_ob_months', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading manual ob months', e);
  }
  return {};
}

export function saveStoredManualObMonth(monthOrDate: string, isManual: boolean, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    const current = getStoredManualObMonths(sId);
    const monthKey = monthOrDate.length === 10 ? monthOrDate.substring(0, 7) : monthOrDate;
    if (isManual) {
      current[monthKey] = true;
      current[monthOrDate] = true;
    } else {
      delete current[monthKey];
      delete current[`${monthKey}-01`];
      delete current[monthOrDate];
      Object.keys(current).forEach((k) => {
        if (k.startsWith(`${monthKey}-`)) delete current[k];
      });
    }
    setItemForSchool('mdm_manual_ob_months', JSON.stringify(current), sId);
    recordLocalUpdate('mdm_manual_ob_months');
    saveToCloud('mdm_manual_ob_months', current, sId);
  } catch (e) {
    console.error('Failed saving manual ob month', e);
  }
}

export function saveStoredMonthlyCommodityBalances(overrides: MonthlyCommodityOverrides, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    const sanitized: MonthlyCommodityOverrides = {};
    if (overrides && typeof overrides === 'object') {
      Object.entries(overrides).forEach(([key, val]) => {
        if (!val || typeof val !== 'object') return;
        if ((key.length === 7 || key.length === 10) && key.includes('-')) {
          const clean: Record<string, number> = {};
          Object.entries(val).forEach(([commId, num]) => {
            if (typeof num === 'number' && !isNaN(num)) {
              clean[commId] = safeRound3(num);
            }
          });
          if (clean['ragi'] !== undefined) {
            clean['jaggery'] = clean['ragi'];
          }
          sanitized[key] = clean;
        }
      });
    }
    setItemForSchool(STORAGE_KEYS.MONTHLY_COMMODITIES, JSON.stringify(sanitized), sId);
    recordLocalUpdate(STORAGE_KEYS.MONTHLY_COMMODITIES);
    saveToCloud(STORAGE_KEYS.MONTHLY_COMMODITIES, sanitized, sId);
  } catch (e) {
    console.error('Failed saving monthly commodity balances', e);
  }
}

/**
 * Calculates month-by-month stock balance carrying forward closing balance automatically
 */
export function calculateMonthlyCommodityStock(
  monthStr: string, // e.g. "2026-08"
  baseCommodities: CommodityItem[],
  dailyEntries: DailyEntry[],
  stockTxs: StockTransaction[],
  monthlyOverrides: MonthlyCommodityOverrides = {}
): CommodityItem[] {
  const parts = monthStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const daysInMonth = isNaN(year) || isNaN(month) ? 30 : new Date(year, month, 0).getDate();

  const prevDate = new Date(year, month - 2, 1);
  const prevMonthStr = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;

  const hasPrevMonthData =
    dailyEntries.some((e) => e.date && e.date.startsWith(prevMonthStr)) ||
    stockTxs.some((tx) => tx.date && tx.date.startsWith(prevMonthStr)) ||
    Boolean(monthlyOverrides[prevMonthStr] || monthlyOverrides[`${prevMonthStr}-01`]);

  const monthsToCalculate = generateContinuousMonthRange(['2026-08', prevMonthStr, monthStr]);

  const dailyStockMap = calculateDailyCommodityStock(
    dailyEntries,
    stockTxs,
    baseCommodities,
    monthlyOverrides,
    monthsToCalculate,
    getStoredManualObMonths()
  );

  const items = baseCommodities.map((item) => {
    const firstDayStr = `${monthStr}-01`;
    const lastDayStr = `${monthStr}-${String(daysInMonth).padStart(2, '0')}`;

    const firstDayStock = dailyStockMap[firstDayStr]?.[item.id];
    const lastDayStock = dailyStockMap[lastDayStr]?.[item.id];

    const ob = firstDayStock ? safeRound3(firstDayStock.ob) : safeRound3(item.openingBalance || 0);

    let received = 0;
    let used = 0;
    let spoiled = 0;

    for (let d = 1; d <= daysInMonth; d++) {
      const dStr = `${monthStr}-${String(d).padStart(2, '0')}`;
      const dayStock = dailyStockMap[dStr]?.[item.id];
      if (dayStock) {
        received = safeRound3(received + dayStock.rec);
        used = safeRound3(used + dayStock.used);
        spoiled = safeRound3(spoiled + dayStock.spoiled);
      }
    }

    received = safeRound3(received);
    used = safeRound3(used);
    spoiled = safeRound3(spoiled);
    const closing = lastDayStock ? safeRound3(lastDayStock.cb) : safeRound3(ob + received - used - spoiled);

    return {
      ...item,
      openingBalance: ob,
      received,
      used,
      spoiled,
      closingBalance: closing,
    };
  });

  const ragiItem = items.find((c) => c.id === 'ragi');
  const jaggeryItem = items.find((c) => c.id === 'jaggery');
  if (ragiItem && jaggeryItem) {
    jaggeryItem.openingBalance = ragiItem.openingBalance;
    jaggeryItem.received = ragiItem.received;
    jaggeryItem.used = ragiItem.used;
    jaggeryItem.spoiled = ragiItem.spoiled;
    jaggeryItem.closingBalance = ragiItem.closingBalance;
  }

  return items;
}

/**
 * Deterministic full-history stock recalculation and data migration engine.
 * Ensures:
 * 1. For each commodity, historical records are ordered chronologically.
 * 2. Opening Balance strictly equals previous valid record's Closing Balance.
 * 3. Month transitions (e.g. 31-08 -> 01-09) carry forward without resetting.
 * 4. User inputs (received, used, spoiled) are strictly preserved.
 */
export function recalculateAllBalances(): {
  dailyStockMap: DayCommodityStockMap;
  repairedCount: number;
} {
  const dailyEntries = getStoredDailyEntries();
  const stockTxs = getStoredStockTransactions();
  const baseCommodities = getStoredCommodities();

  const dailyStockMap = calculateDailyCommodityStock(
    dailyEntries,
    stockTxs,
    baseCommodities
  );

  return {
    dailyStockMap,
    repairedCount: dailyEntries.length,
  };
}

/**
 * Re-calculate dynamic Commodity Stock Levels for current or selected month
 */
export function recalculateCommodityStock(
  baseCommodities: CommodityItem[],
  dailyEntries: DailyEntry[],
  stockTxs: StockTransaction[],
  selectedMonth?: string,
  monthlyOverrides?: MonthlyCommodityOverrides
): CommodityItem[] {
  const month = selectedMonth || new Date().toISOString().substring(0, 7);
  return calculateMonthlyCommodityStock(month, baseCommodities, dailyEntries, stockTxs, monthlyOverrides || {});
}

/**
 * Automatically Generate or Get Cash Voucher for a Given Month (YYYY-MM)
 */
export function calculateCashVoucherForMonth(
  monthStr: string, // e.g. "2026-07"
  dailyEntries: DailyEntry[],
  mealRates: MealRates
): CashVoucher {
  const monthEntries = dailyEntries.filter((e) => e.date.startsWith(monthStr));
  const workingDays = monthEntries.length;

  let totalMeals = 0;
  let primaryAmt = 0;
  let upperPrimaryAmt = 0;
  let totalEggQty = 0;
  let totalChikkiQty = 0;
  let totalRagiKg = 0;
  let totalJaggeryKg = 0;

  monthEntries.forEach((e) => {
    totalMeals += e.mealsServed;
    totalEggQty += e.eggUsedQty;
    totalChikkiQty += e.chikkiUsedQty;
    totalRagiKg += e.ragiUsedKg;
    totalJaggeryKg += e.jaggeryUsedKg;

    if (e.mealsServed && e.mealsServed > 0) {
      const pAtt = e.primaryAttendance || 0;
      const upAtt = (e.upperPrimaryAttendance || 0) + (e.highSchoolAttendance || 0);
      const totalAtt = pAtt + upAtt;

      if (totalAtt > 0) {
        const scale = e.mealsServed / totalAtt;
        primaryAmt += (pAtt * scale) * mealRates.primaryRatePerMeal;
        upperPrimaryAmt += (upAtt * scale) * mealRates.upperPrimaryRatePerMeal;
      } else {
        primaryAmt += e.mealsServed * mealRates.primaryRatePerMeal;
      }
    }
  });

  const eggAmt = totalEggQty * mealRates.eggRate;
  const chikkiAmt = totalChikkiQty * mealRates.chikkiRate;
  const ragiJaggeryAmt = totalRagiKg * mealRates.ragiRatePerKg + totalJaggeryKg * mealRates.jaggeryRatePerKg;

  // Monthly expenses only what is the mdm meals served cooking cost amount only, don't add extra commodity expenses to the total
  const grandTotal = Number((primaryAmt + upperPrimaryAmt).toFixed(2));

  const monthFormatted = new Date(`${monthStr}-01`).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  return {
    id: `voucher-${monthStr}`,
    voucherNo: `MDM/${monthStr.replace('-', '/')}/001`,
    month: monthFormatted,
    workingDays,
    totalMealsServed: totalMeals,
    primaryAmount: Number(primaryAmt.toFixed(2)),
    upperPrimaryAmount: Number(upperPrimaryAmt.toFixed(2)),
    eggAmount: Number(eggAmt.toFixed(2)),
    chikkiAmount: Number(chikkiAmt.toFixed(2)),
    ragiJaggeryAmount: Number(ragiJaggeryAmt.toFixed(2)),
    totalAmount: grandTotal,
    amountInWords: numToWords(grandTotal),
    generatedAt: new Date().toISOString(),
    status: 'PAID',
  };
}

/**
 * Backup all local storage data as downloadable JSON
 */
export function exportBackupData(schoolId?: string): string {
  const sId = schoolId || getActiveSchoolId();
  const monthlyOverrides = getStoredMonthlyCommodityBalances(sId);
  const customHolidays = getStoredCustomHolidays(sId);
  const dailyClassAttendance = getStoredDailyClassAttendance(sId);
  const monthlyStudentStrengths = getStoredMonthlyStudentStrengths(sId);
  const dailyStudentStrengths = getStoredDailyStudentStrengths(sId);

  const backup = {
    schoolId: sId,
    profile: getStoredSchoolProfile(sId),
    studentStrength: getStoredStudentStrength(sId),
    monthlyStudentStrengths,
    dailyStudentStrengths,
    dailyEntries: getStoredDailyEntries(sId),
    commodities: getStoredCommodities(sId),
    stockTransactions: getStoredStockTransactions(sId),
    mealRates: getStoredMealRates(sId),
    monthlyOverrides,
    customHolidays,
    dailyClassAttendance,
    version: '2.0',
    timestamp: new Date().toISOString(),
  };
  return JSON.stringify(backup, null, 2);
}

/**
 * Restore data from JSON string
 */
export function importRestoreData(jsonStr: string, schoolId?: string): boolean {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = JSON.parse(jsonStr);
    if (data.profile) saveStoredSchoolProfile(data.profile, sId);
    if (data.studentStrength) saveStoredStudentStrength(data.studentStrength, sId);
    if (data.monthlyStudentStrengths) saveStoredMonthlyStudentStrengths(data.monthlyStudentStrengths, sId);
    if (data.dailyStudentStrengths) saveStoredDailyStudentStrengths(data.dailyStudentStrengths, sId);
    if (data.dailyEntries) saveStoredDailyEntries(data.dailyEntries, sId);
    if (data.commodities) saveStoredCommodities(data.commodities, sId);
    if (data.stockTransactions) saveStoredStockTransactions(data.stockTransactions, sId);
    if (data.mealRates) saveStoredMealRates(data.mealRates, sId);
    if (data.monthlyOverrides) saveStoredMonthlyCommodityBalances(data.monthlyOverrides, sId);
    if (data.customHolidays) saveStoredCustomHolidays(data.customHolidays, sId);
    if (data.dailyClassAttendance) saveStoredDailyClassAttendance(data.dailyClassAttendance, sId);
    return true;
  } catch (e) {
    console.error('Failed to restore backup', e);
    return false;
  }
}

export function getStoredDailyClassAttendance(schoolId?: string): Record<string, DailyClassAttendance[]> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const data = getItemForSchool('mdm_daily_class_attendance', sId);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error('Failed reading daily class attendance', e);
  }
  return {};
}

export function saveStoredDailyClassAttendance(data: Record<string, DailyClassAttendance[]>, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_daily_class_attendance', JSON.stringify(data), sId);
    recordLocalUpdate('mdm_daily_class_attendance');
    saveToCloud('mdm_daily_class_attendance', data, sId);
  } catch (e) {
    console.error('Failed saving daily class attendance', e);
  }
}

export function getStoredCustomHolidays(schoolId?: string): Record<string, string> {
  const sId = schoolId || getActiveSchoolId();
  try {
    const stored = getItemForSchool('mdm_custom_holidays', sId);
    return stored ? JSON.parse(stored) : {};
  } catch (e) {
    console.error('Failed reading custom holidays', e);
    return {};
  }
}

export function saveStoredCustomHolidays(holidays: Record<string, string>, schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool('mdm_custom_holidays', JSON.stringify(holidays), sId);
    recordLocalUpdate('mdm_custom_holidays');
    saveToCloud('mdm_custom_holidays', holidays, sId);
  } catch (e) {
    console.error('Failed saving custom holidays', e);
  }
}

export async function syncWithCloud(onSyncComplete?: () => void, schoolId?: string): Promise<boolean> {
  const sId = schoolId || getActiveSchoolId();
  try {
    // 1. Sync global School Accounts Registry first
    const SCHOOLS_REG_KEY = 'mdm_school_accounts';
    try {
      const cloudRegistryDoc = await loadFromCloud('school_accounts');
      if (cloudRegistryDoc && cloudRegistryDoc.data && Array.isArray(cloudRegistryDoc.data)) {
        const localAccounts = getSchoolAccounts();
        const mergedAccounts = [...localAccounts];
        cloudRegistryDoc.data.forEach((cloudAcc: any) => {
          if (!mergedAccounts.some((m) => m.schoolId === cloudAcc.schoolId || m.udiseCode === cloudAcc.udiseCode)) {
            mergedAccounts.push(cloudAcc);
          }
        });
        localStorage.setItem(SCHOOLS_REG_KEY, JSON.stringify(mergedAccounts));
        saveToCloud('school_accounts', mergedAccounts, 'global').catch(() => {});
      } else {
        // Upload local registry to cloud if empty in cloud
        const localAccounts = getSchoolAccounts();
        saveToCloud('school_accounts', localAccounts, 'global').catch(() => {});
      }
    } catch (regErr) {
      console.warn('Could not sync school accounts registry:', regErr);
    }

    // 2. Sync school data for active schoolId
    const keys = [
      STORAGE_KEYS.PROFILE,
      STORAGE_KEYS.STUDENT_STRENGTH,
      'mdm_baseline_student_strength',
      'mdm_student_strength_monthly',
      'mdm_student_strength_daily',
      'mdm_student_strength_remarks',
      STORAGE_KEYS.DAILY_ENTRIES,
      STORAGE_KEYS.COMMODITIES,
      STORAGE_KEYS.STOCK_TRANSACTIONS,
      STORAGE_KEYS.MEAL_RATES,
      STORAGE_KEYS.SETTINGS,
      STORAGE_KEYS.MONTHLY_COMMODITIES,
      'mdm_daily_class_attendance',
      'mdm_custom_holidays'
    ];

    let hasChanges = false;

    // Fetch all collections in parallel for instant restoration on app reopen or login
    const results = await Promise.allSettled(
      keys.map(async (key) => {
        const cloudDoc = await loadFromCloud(key, sId);
        return { key, cloudDoc };
      })
    );

    for (const res of results) {
      if (res.status === 'fulfilled' && res.value) {
        const { key, cloudDoc } = res.value;
        const cloudData = cloudDoc ? cloudDoc.data : null;
        const cloudUpdatedAt = cloudDoc?.updatedAt;

        const localDataStr = getItemForSchool(key, sId);
        const scopedKey = getScopedKey(key, sId);
        const localUpdatedAt = localStorage.getItem(`${scopedKey}_updatedAt`);

        if (cloudData !== null && cloudData !== undefined) {
          let shouldApplyCloud = false;

          if (!localDataStr) {
            // Local is completely empty, restore from cloud
            shouldApplyCloud = true;
          } else {
            try {
              const localParsed = JSON.parse(localDataStr);

              // If local has items and cloud is an empty array, preserve local and sync up to cloud
              if (Array.isArray(localParsed) && localParsed.length > 0 && Array.isArray(cloudData) && cloudData.length === 0) {
                shouldApplyCloud = false;
                saveToCloud(key, localParsed, sId).catch(() => {});
              }
              // If local has keys and cloud is an empty object, preserve local and sync up to cloud
              else if (
                localParsed && typeof localParsed === 'object' && !Array.isArray(localParsed) && Object.keys(localParsed).length > 0 &&
                cloudData && typeof cloudData === 'object' && !Array.isArray(cloudData) && Object.keys(cloudData).length === 0
              ) {
                shouldApplyCloud = false;
                saveToCloud(key, localParsed, sId).catch(() => {});
              }
              // Check timestamps
              else if (localUpdatedAt && cloudUpdatedAt) {
                if (cloudUpdatedAt > localUpdatedAt) {
                  shouldApplyCloud = true;
                } else if (localUpdatedAt > cloudUpdatedAt) {
                  shouldApplyCloud = false;
                  // Local is strictly newer, sync local to cloud
                  saveToCloud(key, localParsed, sId).catch(() => {});
                } else {
                  shouldApplyCloud = false;
                }
              } else if (localUpdatedAt && !cloudUpdatedAt) {
                // Local was recently modified by the user, keep local!
                shouldApplyCloud = false;
                saveToCloud(key, localParsed, sId).catch(() => {});
              } else if (!localUpdatedAt && cloudUpdatedAt) {
                shouldApplyCloud = true;
              } else {
                // Fallback: keep local data safe so user data is never reverted on restart
                shouldApplyCloud = false;
                saveToCloud(key, localParsed, sId).catch(() => {});
              }
            } catch {
              shouldApplyCloud = true;
            }
          }

          if (shouldApplyCloud) {
            setItemForSchool(key, JSON.stringify(cloudData), sId);
            if (cloudUpdatedAt) {
              localStorage.setItem(`${scopedKey}_updatedAt`, cloudUpdatedAt);
            }
            hasChanges = true;
          }
        } else {
          // Cloud has no data, upload local data to cloud
          try {
            if (localDataStr) {
              const localParsed = JSON.parse(localDataStr);
              if (localParsed) {
                saveToCloud(key, localParsed, sId).catch(() => {});
              }
            }
          } catch {
            // Ignore parse errors on seed
          }
        }
      }
    }

    if (onSyncComplete) {
      onSyncComplete();
    }
    return hasChanges;
  } catch (e) {
    console.error('Error syncing with cloud:', e);
    if (onSyncComplete) {
      onSyncComplete();
    }
    return false;
  }
}

/**
 * Convenience helper to restore all application data from storage and cloud
 */
export async function restoreAllSavedData(schoolId?: string): Promise<{
  user: User;
  schoolProfile: SchoolProfile;
  studentStrengths: StudentClassStrength[];
  dailyEntries: DailyEntry[];
  baseCommodities: CommodityItem[];
  stockTransactions: StockTransaction[];
  mealRates: MealRates;
  monthlyOverrides: MonthlyCommodityOverrides;
}> {
  const sId = schoolId || getActiveSchoolId();
  await syncWithCloud(undefined, sId);
  return {
    user: getStoredUser(sId),
    schoolProfile: getStoredSchoolProfile(sId),
    studentStrengths: getStoredStudentStrength(sId),
    dailyEntries: getStoredDailyEntries(sId),
    baseCommodities: getStoredCommodities(sId),
    stockTransactions: getStoredStockTransactions(sId),
    mealRates: getStoredMealRates(sId),
    monthlyOverrides: getStoredMonthlyCommodityBalances(sId),
  };
}

export function getDailyClassAttendanceForDate(dateStr: string, schoolId?: string): DailyClassAttendance[] {
  const sId = schoolId || getActiveSchoolId();
  const stored = getStoredDailyClassAttendance(sId);
  const todayDetails = getDayDetails(dateStr);
  const classStrengths = getStudentStrengthForDate(dateStr, sId);

  if (stored[dateStr] && stored[dateStr].length > 0) {
    return stored[dateStr];
  }

  // Check if an existing daily entry was recorded/edited for this date
  const dailyEntries = getStoredDailyEntries(sId);
  const existing = dailyEntries.find((e) => e.date === dateStr);
  if (existing) {
    const pAtt = existing.primaryAttendance || 0;
    const upAtt = (existing.upperPrimaryAttendance || 0) + (existing.highSchoolAttendance || 0);
    return distributeStudentStrengths(classStrengths, pAtt, upAtt).map((cs) => ({
      classLevel: cs.classLevel,
      category: cs.category,
      boysPresent: cs.boys,
      girlsPresent: cs.girls,
      totalPresent: cs.total,
    }));
  }
  
  if (todayDetails.isHoliday) {
    return classStrengths.map((cs) => ({
      classLevel: cs.classLevel,
      category: cs.category,
      boysPresent: 0,
      girlsPresent: 0,
      totalPresent: 0,
    }));
  }

  // Automatically set attendance to 100% of active student strength day-by-day
  return classStrengths.map((cs) => ({
    classLevel: cs.classLevel,
    category: cs.category,
    boysPresent: cs.boys,
    girlsPresent: cs.girls,
    totalPresent: cs.total,
  }));
}

export function saveDailyClassAttendanceForDate(dateStr: string, attendance: DailyClassAttendance[], schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  const allAttendance = getStoredDailyClassAttendance(sId);
  allAttendance[dateStr] = attendance;
  saveStoredDailyClassAttendance(allAttendance, sId);
}

/**
 * Reset all application data to a clean state for a new user / school.
 */
export function resetAllApplicationData(schoolId?: string): void {
  const sId = schoolId || getActiveSchoolId();
  try {
    setItemForSchool(STORAGE_KEYS.DAILY_ENTRIES, JSON.stringify([]), sId);
    saveToCloud(STORAGE_KEYS.DAILY_ENTRIES, [], sId);

    setItemForSchool(STORAGE_KEYS.STOCK_TRANSACTIONS, JSON.stringify([]), sId);
    saveToCloud(STORAGE_KEYS.STOCK_TRANSACTIONS, [], sId);

    const resetCommodities = defaultCommodities.map((c) => ({
      ...c,
      openingBalance: 0,
      received: 0,
      used: 0,
      spoiled: 0,
      closingBalance: 0,
    }));
    setItemForSchool(STORAGE_KEYS.COMMODITIES, JSON.stringify(resetCommodities), sId);
    saveToCloud(STORAGE_KEYS.COMMODITIES, resetCommodities, sId);

    setItemForSchool(STORAGE_KEYS.MONTHLY_COMMODITIES, JSON.stringify({}), sId);
    saveToCloud(STORAGE_KEYS.MONTHLY_COMMODITIES, {}, sId);

    setItemForSchool('mdm_student_strength_daily', JSON.stringify({}), sId);
    saveToCloud('mdm_student_strength_daily', {}, sId);

    setItemForSchool('mdm_student_strength_monthly', JSON.stringify({}), sId);
    saveToCloud('mdm_student_strength_monthly', {}, sId);

    setItemForSchool('mdm_daily_class_attendance', JSON.stringify({}), sId);
    saveToCloud('mdm_daily_class_attendance', {}, sId);

    setItemForSchool('mdm_custom_holidays', JSON.stringify({}), sId);
    saveToCloud('mdm_custom_holidays', {}, sId);

    setItemForSchool('mdm_fresh_user_reset', 'true', sId);
  } catch (e) {
    console.error('Failed resetting application data', e);
  }
}

