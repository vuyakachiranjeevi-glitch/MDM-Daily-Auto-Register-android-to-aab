import { User, SchoolAccount, SchoolProfile } from '../types';

export const SESSION_TOKEN_KEY = 'mdm_session_token';

export function getStoredSessionToken(): string | null {
  try {
    return localStorage.getItem(SESSION_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredSessionToken(token: string): void {
  try {
    localStorage.setItem(SESSION_TOKEN_KEY, token);
  } catch (e) {
    console.error('Failed saving session token', e);
  }
}

export function clearStoredSessionToken(): void {
  try {
    localStorage.removeItem(SESSION_TOKEN_KEY);
    // Security clean-up: Ensure any legacy plaintext passwords are permanently purged
    localStorage.removeItem('mdm_portal_password');
  } catch (e) {
    console.error('Failed clearing session token', e);
  }
}

export interface ApiResponse<T = any> {
  success: boolean;
  error?: string;
  message?: string;
  data?: T;
  token?: string;
  user?: User;
  session?: {
    username: string;
    role: 'HEADMASTER' | 'MDM_INCHARGE';
    name: string;
    schoolId: string;
    status: string;
  };
  schoolProfile?: Partial<SchoolProfile> | null;
  schoolAccount?: SchoolAccount;
  maskedMobile?: string;
  mobile?: string;
  cooldownSeconds?: number;
  resetToken?: string;
  remainingAttempts?: number;
  provider?: string;
  requestId?: string;
  isConfigError?: boolean;
  isTestMode?: boolean;
  testOtp?: string;
  diagnostics?: any;
}

export const API_BASE = ((import.meta as any).env?.VITE_API_URL || '').replace(/\/$/, '');

async function request<T = any>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
  const token = getStoredSessionToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Session-Token'] = token;
  }

  try {
    const res = await fetch(`${API_BASE}/api/auth${endpoint}`, {
      ...options,
      headers,
    });

    const body = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        success: false,
        error: body?.error || `Request failed with status ${res.status}`,
        cooldownSeconds: body?.cooldownSeconds,
        remainingAttempts: body?.remainingAttempts,
        isConfigError: body?.isConfigError,
        provider: body?.provider,
        requestId: body?.requestId,
      };
    }

    return body || { success: true };
  } catch (err: any) {
    console.warn(`Auth API call failed to ${endpoint}:`, err);
    return {
      success: false,
      error: 'Network connectivity issue or backend server unreachable.',
    };
  }
}

/**
 * Direct registration without OTP requirement
 */
export async function registerDirect(params: {
  name: string;
  username?: string;
  udiseCode: string;
  mobile?: string;
  password: string;
  confirmPassword?: string;
  schoolName: string;
  village?: string;
  mandal?: string;
  district?: string;
  state?: string;
  address?: string;
  headmasterSurname?: string;
  headmasterEmail?: string;
  headmasterDesignation?: string;
}): Promise<ApiResponse> {
  const result = await request('/register', {
    method: 'POST',
    body: JSON.stringify(params),
  });
  if (result.success && result.token) {
    setStoredSessionToken(result.token);
  }
  return result;
}

export const registerSchoolDirect = registerDirect;

/**
 * Initiates user registration by sending OTP to the registered mobile
 */
export async function registerInitiate(params: {
  name: string;
  username: string;
  udiseCode: string;
  mobile: string;
  password: string;
  confirmPassword: string;
  schoolName: string;
  village?: string;
  mandal?: string;
  district?: string;
  state?: string;
  address?: string;
  headmasterSurname?: string;
  headmasterEmail?: string;
  headmasterDesignation?: string;
  forceTestMode?: boolean;
}): Promise<ApiResponse> {
  return request('/register-initiate', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

/**
 * Verifies registration OTP and completes account activation
 */
export async function registerVerifyOtp(mobile: string, otp: string): Promise<ApiResponse> {
  const result = await request('/register-verify-otp', {
    method: 'POST',
    body: JSON.stringify({ mobile, otp }),
  });
  if (result.success && result.token) {
    setStoredSessionToken(result.token);
  }
  return result;
}

/**
 * Resends OTP with rate limiting & cooldown
 */
export async function resendOtp(
  mobile: string,
  purpose: 'REGISTRATION' | 'FORGOT_PASSWORD' | 'CHANGE_CREDENTIALS' = 'REGISTRATION',
  forceTestMode?: boolean
): Promise<ApiResponse> {
  return request('/resend-otp', {
    method: 'POST',
    body: JSON.stringify({ mobile, purpose, forceTestMode }),
  });
}

/**
 * Production-grade secure backend login
 */
export async function loginUser(identifier: string, password: string): Promise<ApiResponse> {
  const result = await request('/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  });
  if (result.success && result.token) {
    setStoredSessionToken(result.token);
  }
  return result;
}

/**
 * Step 1 of Mobile OTP Login: Send OTP to registered mobile number
 */
export async function loginInitiateOtp(
  identifier: string,
  role?: 'HEADMASTER' | 'MDM_INCHARGE',
  forceTestMode?: boolean
): Promise<ApiResponse> {
  return request('/login-initiate-otp', {
    method: 'POST',
    body: JSON.stringify({ identifier, role, forceTestMode }),
  });
}

/**
 * Step 2 of Mobile OTP Login: Verify 6-digit OTP and sign in
 */
export async function loginVerifyOtp(
  mobile: string,
  otp: string,
  role?: 'HEADMASTER' | 'MDM_INCHARGE'
): Promise<ApiResponse> {
  const result = await request('/login-verify-otp', {
    method: 'POST',
    body: JSON.stringify({ mobile, otp, role }),
  });
  if (result.success && result.token) {
    setStoredSessionToken(result.token);
  }
  return result;
}

/**
 * Step 1 of Forgot Password: verify account & send OTP to registered mobile
 */
export async function forgotPasswordInitiate(identifier: string, forceTestMode?: boolean): Promise<ApiResponse> {
  return request('/forgot-password-initiate', {
    method: 'POST',
    body: JSON.stringify({ identifier, forceTestMode }),
  });
}

/**
 * Step 2 of Forgot Password: verify OTP and receive single-use reset token
 */
export async function forgotPasswordVerifyOtp(mobile: string, otp: string): Promise<ApiResponse> {
  return request('/forgot-password-verify-otp', {
    method: 'POST',
    body: JSON.stringify({ mobile, otp }),
  });
}

/**
 * Step 3 of Forgot Password: consume reset token and set new password
 */
export async function forgotPasswordReset(
  resetToken: string,
  newPassword: string,
  confirmPassword: string
): Promise<ApiResponse> {
  return request('/forgot-password-reset', {
    method: 'POST',
    body: JSON.stringify({ resetToken, newPassword, confirmPassword }),
  });
}

/**
  * Direct reset without OTP requirement
  */
export async function forgotPasswordDirectReset(
  identifier: string,
  newPassword: string,
  confirmPassword?: string
): Promise<ApiResponse> {
  return request('/forgot-password-direct-reset', {
    method: 'POST',
    body: JSON.stringify({ identifier, newPassword, confirmPassword: confirmPassword || newPassword }),
  });
}

/**
 * Update credentials (username, mobile, password)
 */
export async function changeCredentialsApi(params: {
  schoolId?: string;
  role: 'HEADMASTER' | 'MDM_INCHARGE';
  updates: { username?: string; mobile?: string; password?: string; name?: string };
  currentPassword?: string;
  verificationOtp?: string;
}): Promise<ApiResponse> {
  return request('/change-credentials', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

/**
 * Get active session
 */
export async function checkSession(): Promise<ApiResponse> {
  return request('/session', { method: 'GET' });
}

/**
 * Revoke current session
 */
export async function logoutUser(): Promise<void> {
  await request('/logout', { method: 'POST' }).catch(() => {});
  clearStoredSessionToken();
}

/**
 * Revoke all sessions
 */
export async function logoutAllSessions(): Promise<ApiResponse> {
  const res = await request('/logout-all', { method: 'POST' });
  clearStoredSessionToken();
  return res;
}

/**
 * Change mobile number: Step 1 - Send OTP to new mobile
 */
export async function changeMobileInitiate(newMobile: string): Promise<ApiResponse> {
  return request('/change-mobile-initiate', {
    method: 'POST',
    body: JSON.stringify({ newMobile }),
  });
}

/**
 * Change mobile number: Step 2 - Verify OTP & confirm change
 */
export async function changeMobileVerify(newMobile: string, otp: string): Promise<ApiResponse> {
  return request('/change-mobile-verify', {
    method: 'POST',
    body: JSON.stringify({ newMobile, otp }),
  });
}

/**
 * Fetch simulated SMS delivery log (useful for sandbox / preview testing)
 */
export async function getSimulatedSmsMessages(mobile?: string): Promise<{ success: boolean; messages: any[] }> {
  const query = mobile ? `?mobile=${encodeURIComponent(mobile)}` : '';
  const res = await request(`/dev-simulated-sms${query}`, { method: 'GET' });
  return { success: res.success, messages: (res as any).messages || [] };
}

/**
 * Fetch real SMS Gateway Diagnostics (safe inspection without secrets)
 */
export async function getSmsDiagnostics(): Promise<ApiResponse> {
  return request('/sms-diagnostics', { method: 'GET' });
}

/**
 * Sync data with backend secure store
 */
export async function syncDataWithBackend(snapshot: any): Promise<ApiResponse> {
  const token = getStoredSessionToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Session-Token'] = token;
  }
  try {
    const res = await fetch(`${API_BASE}/api/data/sync`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ snapshot }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to backend' };
  }
}

/**
 * Save daily entry to backend with idempotency protection
 */
export async function saveDailyEntryBackend(entry: any, idempotencyKey?: string): Promise<ApiResponse> {
  const token = getStoredSessionToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Session-Token'] = token;
  }
  if (idempotencyKey) {
    headers['X-Idempotency-Key'] = idempotencyKey;
  }
  try {
    const res = await fetch(`${API_BASE}/api/data/daily-entry`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ entry, idempotencyKey }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to backend' };
  }
}

/**
 * Save cash voucher to backend with idempotency protection
 */
export async function saveCashVoucherBackend(voucher: any, idempotencyKey?: string): Promise<ApiResponse> {
  const token = getStoredSessionToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Session-Token'] = token;
  }
  if (idempotencyKey) {
    headers['X-Idempotency-Key'] = idempotencyKey;
  }
  try {
    const res = await fetch(`${API_BASE}/api/data/cash-voucher`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ voucher, idempotencyKey }),
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to backend' };
  }
}

/**
 * Fetch authenticated school records from backend store
 */
export async function fetchSchoolRecordsBackend(): Promise<ApiResponse> {
  const token = getStoredSessionToken();
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Session-Token'] = token;
  }
  try {
    const res = await fetch(`${API_BASE}/api/data/records`, {
      method: 'GET',
      headers,
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed connecting to backend' };
  }
}

/**
 * Permanently delete authenticated user account (Google Play Compliance)
 */
export async function deleteAccountApi(confirmationText: string, purgeSchoolData?: boolean): Promise<ApiResponse> {
  const result = await request('/delete-account', {
    method: 'POST',
    body: JSON.stringify({ confirmationText, purgeSchoolData }),
  });
  if (result.success) {
    clearStoredSessionToken();
  }
  return result;
}

