import React, { useState, useEffect } from 'react';
import {
  School,
  User,
  Lock,
  Building2,
  CheckCircle2,
  AlertCircle,
  X,
  ShieldCheck,
  RefreshCw,
  Check,
  KeyRound,
  ArrowLeft,
} from 'lucide-react';
import { registerSchoolDirect } from '../lib/authApi';
import { registerNewSchool, getSchoolAccounts } from '../lib/storage';
import { User as UserType } from '../types';

interface RegisterSchoolModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSchoolRegistered: (user: UserType) => void;
}

export const RegisterSchoolModal: React.FC<RegisterSchoolModalProps> = ({
  isOpen,
  onClose,
  onSchoolRegistered,
}) => {
  // Registration Fields
  const [headmasterName, setHeadmasterName] = useState('');
  const [udiseCode, setUdiseCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // School profile info
  const [schoolName, setSchoolName] = useState('');
  const [district] = useState('PARVATHI PURAM MANYAM');
  const [state] = useState('ANDHRA PRADESH');

  // Status
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleResetModal = () => {
    setHeadmasterName('');
    setUdiseCode('');
    setPassword('');
    setConfirmPassword('');
    setSchoolName('');
    setError(null);
    setSuccessMsg(null);
    setIsSubmitting(false);
    onClose();
  };

  // Direct School Registration & Profile Activation (No OTP required)
  const handleRegisterSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    const cleanUdise = udiseCode.trim().replace(/\D/g, '');
    const cleanUsername = cleanUdise;

    if (!schoolName.trim()) {
      setError('Please enter the School Name.');
      return;
    }
    if (cleanUdise.length < 6) {
      setError('Please enter a valid School UDISE Code (at least 6 digits).');
      return;
    }

    // Strictly enforce: One UDISE code, One account details - Don't allow new another account same UDISE code
    const existingAccounts = getSchoolAccounts();
    if (existingAccounts.some((a) => a.udiseCode === cleanUdise || a.schoolId === `school_${cleanUdise}`)) {
      setError(`An account with UDISE code ${cleanUdise} already exists. Only one account is permitted per UDISE code.`);
      return;
    }

    if (!headmasterName.trim()) {
      setError('Please enter Headmaster / Teacher in-charge Name.');
      return;
    }
    if (!password || password.length < 4) {
      setError('Password must be at least 4 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Direct Server Registration (Enforces unique UDISE)
      let registeredUser: UserType | null = null;
      try {
        const apiRes = await registerSchoolDirect({
          name: headmasterName.trim(),
          username: cleanUsername,
          udiseCode: cleanUdise,
          password,
          confirmPassword,
          schoolName: schoolName.trim(),
          district: district.trim(),
          state: state.trim(),
        });
        if (apiRes.success && apiRes.user) {
          registeredUser = apiRes.user;
        } else if (apiRes.error) {
          setError(apiRes.error);
          setIsSubmitting(false);
          return;
        }
      } catch (e: any) {
        if (e?.message && e.message.includes('already exists')) {
          setError(e.message);
          setIsSubmitting(false);
          return;
        }
        console.warn('Backend registration fallback to local storage:', e);
      }

      // 2. Reliable Local Registration & Partition Initialization
      const localResult = registerNewSchool({
        schoolName: schoolName.trim(),
        udiseCode: cleanUdise,
        headmasterName: headmasterName.trim(),
        password,
        district: district.trim(),
      });

      if (!localResult.success) {
        setError(localResult.message || `An account with UDISE code ${cleanUdise} already exists.`);
        setIsSubmitting(false);
        return;
      }

      const finalUser = registeredUser || localResult.user;
      if (finalUser) {
        setSuccessMsg('School profile registered successfully! Logging in...');
        setTimeout(() => {
          setIsSubmitting(false);
          onSchoolRegistered(finalUser);
          handleResetModal();
        }, 400);
      } else {
        setError(localResult.message || 'Failed to register school.');
        setIsSubmitting(false);
      }
    } catch (err: any) {
      setError(err?.message || 'Registration failed. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-4 pb-8 sm:pb-10 md:pb-12 bg-black/75 backdrop-blur-md overflow-y-auto animate-fadeIn">
      {/* Blurry App Icon in background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden z-0">
        <img
          src="/app-logo.png"
          alt=""
          aria-hidden="true"
          className={`w-72 h-72 sm:w-96 sm:h-96 rounded-full object-cover select-none transition-all duration-700 ${
            isSubmitting
              ? 'opacity-40 blur-2xl scale-110 animate-pulse'
              : 'opacity-25 blur-xl scale-100'
          }`}
        />
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl sm:rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-700 max-w-[420px] sm:max-w-lg w-full overflow-hidden my-0.5 sm:my-3 mb-7 sm:mb-8 md:mb-10 max-h-[calc(100dvh-3.5rem)] sm:max-h-[calc(100dvh-4rem)] flex flex-col justify-between relative z-10">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 px-3.5 sm:px-6 py-2 sm:py-4 text-white relative shrink-0 flex items-center h-[68px] sm:h-[130px]">
          <button
            onClick={handleResetModal}
            className="absolute top-2 right-2 sm:top-4 sm:right-4 p-1 sm:p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="p-1.5 sm:p-2.5 bg-white/20 rounded-lg sm:rounded-2xl backdrop-blur-md shadow-md">
              <Building2 className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h2 className="text-sm sm:text-lg font-bold tracking-tight">Register New School</h2>
              <p className="text-[9.5px] sm:text-xs text-emerald-100">
                Simple School Profile Registration & Password Setup
              </p>
            </div>
          </div>
        </div>

        {/* Feature Highlights Banner */}
        <div className="px-3 sm:px-6 py-1 sm:py-2 bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-100 dark:border-emerald-800/50 flex flex-wrap items-center justify-between gap-1 text-xs text-emerald-800 dark:text-emerald-300 shrink-0">
          <div className="flex items-center gap-1 font-semibold text-[10px] sm:text-xs">
            <ShieldCheck className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>Verified School Account:</span>
          </div>
          <div className="flex items-center gap-1 text-[9.5px] sm:text-[11px] font-bold">
            <span className="inline-flex items-center gap-0.5 bg-emerald-100 dark:bg-emerald-900/60 px-1 py-0.5 rounded text-emerald-800 dark:text-emerald-200">
              <Check className="w-2.5 h-2.5 text-emerald-600 dark:text-emerald-400" />
              Direct Setup
            </span>
            <span className="inline-flex items-center gap-0.5 bg-teal-100 dark:bg-teal-900/60 px-1 py-0.5 rounded text-teal-800 dark:text-teal-200">
              <Check className="w-2.5 h-2.5 text-teal-600 dark:text-teal-400" />
              Isolated Data
            </span>
          </div>
        </div>

        {/* Feedback Alerts */}
        {(error || successMsg) && (
          <div className="px-3 pt-1.5 shrink-0">
            {error && (
              <div className="p-1.5 sm:p-2.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg sm:rounded-xl flex items-start space-x-1.5 text-[11px] sm:text-xs text-red-700 dark:text-red-300">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <span className="font-semibold">{error}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-1.5 sm:p-2.5 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-lg sm:rounded-xl flex items-center space-x-1.5 text-[11px] sm:text-xs text-emerald-700 dark:text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="font-semibold">{successMsg}</span>
              </div>
            )}
          </div>
        )}

        {/* REGISTRATION FORM (No OTP) */}
        <form onSubmit={handleRegisterSchool} className="p-2.5 sm:p-5 space-y-1.5 sm:space-y-3 overflow-y-auto">
          {/* School Name */}
          <div>
            <label className="block text-[10px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 mb-0.5">
              School Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <School className="w-3.5 h-3.5 absolute left-2.5 top-2 text-gray-400" />
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value.toUpperCase())}
                placeholder="e.g. M. P. P. SCHOOL VANGARA"
                required
                className="w-full pl-8 pr-3 h-[34px] sm:h-[40px] text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-lg sm:rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 uppercase font-medium"
              />
            </div>
          </div>

          {/* UDISE Code */}
          <div>
            <label className="block text-[10px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 mb-0.5">
              UDISE Code <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={udiseCode}
              onChange={(e) => setUdiseCode(e.target.value.replace(/\D/g, '').slice(0, 11))}
              placeholder="e.g. 28261800512"
              required
              maxLength={11}
              className="w-full px-2.5 h-[34px] sm:h-[40px] text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-lg sm:rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 font-mono"
            />
          </div>

          {/* Headmaster / In-Charge Name */}
          <div>
            <label className="block text-[10px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 mb-0.5">
              Headmaster / In-Charge Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <User className="w-3.5 h-3.5 absolute left-2.5 top-2 text-gray-400" />
              <input
                type="text"
                value={headmasterName}
                onChange={(e) => setHeadmasterName(e.target.value)}
                placeholder="e.g. V. CHIRANJEEVI"
                required
                className="w-full pl-8 pr-3 h-[34px] sm:h-[40px] text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-lg sm:rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Password & Confirm */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-3">
            <div>
              <label className="block text-[10px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 mb-0.5">
                Password (Your Choice) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 absolute left-2.5 top-2 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  required
                  minLength={6}
                  className="w-full pl-8 pr-3 h-[34px] sm:h-[40px] text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-lg sm:rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 mb-0.5">
                Confirm Password <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 absolute left-2.5 top-2 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-type password"
                  required
                  minLength={6}
                  className="w-full pl-8 pr-3 h-[34px] sm:h-[40px] text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-lg sm:rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-0">
            <label className="flex items-center space-x-1.5 text-[10px] sm:text-xs text-gray-600 dark:text-gray-400 cursor-pointer">
              <input
                type="checkbox"
                checked={showPassword}
                onChange={(e) => setShowPassword(e.target.checked)}
                className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 w-3 h-3 sm:w-3.5 sm:h-3.5"
              />
              <span>Show password</span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="pt-1 flex space-x-2 sm:space-x-3 shrink-0 items-center">
            <button
              type="button"
              onClick={handleResetModal}
              className="py-1.5 sm:py-2.5 px-3 sm:px-4 text-[11px] sm:text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg sm:rounded-xl transition-colors cursor-pointer flex items-center justify-center h-[36px] sm:h-[44px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-1.5 sm:py-2.5 px-3 sm:px-4 font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-lg sm:rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center justify-center space-x-1.5 cursor-pointer h-[38px] sm:h-[48px]"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                  <span className="text-[11px] sm:text-sm">Registering School...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span className="text-[11px] sm:text-sm">Register School Profile</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
