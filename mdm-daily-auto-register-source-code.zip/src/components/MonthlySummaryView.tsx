import React, { useState, useEffect, useRef } from 'react';
import { CommodityItem, DailyEntry, MealRates, SchoolProfile, StockTransaction, StudentClassStrength } from '../types';
import {
  formatCurrency,
  formatDateReadable,
  numToWords,
  getDayDetails,
  calculateDailyCommodityStock,
  formatQtyVal,
  distributeStudentStrengths,
  safeRound3,
  generateContinuousMonthRange,
} from '../lib/utils';
import {
  getStudentStrengthForMonth,
  getStudentStrengthForDate,
  saveStudentStrengthForDate,
  getDailyClassAttendanceForDate,
  saveDailyClassAttendanceForDate,
  MonthlyCommodityOverrides,
  getStoredCustomHolidays,
  saveStoredCustomHolidays,
  saveStoredStockTransactions,
  saveStoredMonthlyCommodityBalances,
  saveStoredCommodities,
  getStoredManualObMonths,
  saveStoredManualObMonth,
} from '../lib/storage';
import { OpeningBalanceModal } from './OpeningBalanceModal';
import { CashVoucherView } from './CashVoucherView';
import { ReportsView, ReportType } from './ReportsView';
import { SettingsView } from './SettingsView';
import { ChangeSchoolImageModal } from './ChangeSchoolImageModal';
import {
  CalendarCheck,
  Printer,
  FileSpreadsheet,
  Download,
  Receipt,
  Boxes,
  Calendar,
  Utensils,
  Wheat,
  Egg,
  Cookie,
  Flame,
  Sun,
  Moon,
  Sparkles,
  School,
  CheckCircle2,
  Package,
  Edit3,
  Edit2,
  FileText,
  X,
  HelpCircle,
  Check,
  FileDown,
  Share2,
  Eye,
  EyeOff,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  Sliders,
  Save,
  Plus,
  Minus,
  Percent,
  ArrowRight,
  AlertCircle,
  AlertTriangle,
  RefreshCw,
  Info,
  ChevronDown,
  Edit,
  Coins,
  IndianRupee,
  Settings,
  LogOut,
  Users,
  Palette,
  Briefcase,
} from 'lucide-react';

interface MonthlySummaryViewProps {
  schoolProfile: SchoolProfile;
  dailyEntries: DailyEntry[];
  mealRates: MealRates;
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  studentStrengths?: StudentClassStrength[];
  darkMode?: boolean;
  onSaveEntry?: (entry: DailyEntry) => void;
  onDeleteEntry?: (id: string) => void;
  onSaveStudentStrengths?: (strengths: StudentClassStrength[], monthStr?: string) => void;
  onNavigate?: (tab: any, date?: string) => void;
  onPrintRegister: (orientation?: 'landscape' | 'portrait') => void;
  onSaveOpeningBalances?: (updated: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onSaveStockTransactions?: (txs: StockTransaction[]) => void;
  onUpdateMealRates?: (rates: MealRates) => void;
  onUpdateSchoolProfile?: (profile: SchoolProfile) => void;
  onToggleDarkMode?: () => void;
  onResetAllData?: () => void;
  onClose?: () => void;
  showInstallButton?: boolean;
  onInstallClick?: () => void;
}

export const MonthlySummaryView: React.FC<MonthlySummaryViewProps> = ({
  schoolProfile,
  dailyEntries,
  mealRates,
  commodities,
  baseCommodities = commodities,
  stockTransactions = [],
  monthlyOverrides = {},
  studentStrengths,
  darkMode,
  onSaveEntry,
  onDeleteEntry,
  onSaveStudentStrengths,
  onNavigate,
  onPrintRegister,
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  onSaveStockTransactions,
  onUpdateMealRates,
  onUpdateSchoolProfile,
  onToggleDarkMode,
  onResetAllData,
  onClose,
  showInstallButton = false,
  onInstallClick,
}) => {
  const now = new Date();
  const todayYear = now.getFullYear();
  const todayMonth = String(now.getMonth() + 1).padStart(2, '0');
  const todayDay = String(now.getDate()).padStart(2, '0');
  const todayStr = `${todayYear}-${todayMonth}-${todayDay}`;
  const currentMonthStr = `${todayYear}-${todayMonth}`;
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthStr); // "YYYY-MM"
  const isCurrentMonth = selectedMonth === currentMonthStr;
  const [registerMode, setRegisterMode] = useState<'auto' | 'custom'>('auto'); // 'auto' = continuous auto update, 'custom' = manual edit
  const [showOpeningModal, setShowOpeningModal] = useState<boolean>(false);
  const [showObCheckModal, setShowObCheckModal] = useState<boolean>(false);
  const [showMealRatesModal, setShowMealRatesModal] = useState<boolean>(false);
  const [editingMealRates, setEditingMealRates] = useState<MealRates>({ ...mealRates });
  const [rawEditingRates, setRawEditingRates] = useState<Record<string, string>>(() => ({
    primaryRatePerMeal: String(mealRates.primaryRatePerMeal ?? 5.45),
    upperPrimaryRatePerMeal: String(mealRates.upperPrimaryRatePerMeal ?? 8.17),
    highSchoolRatePerMeal: String(mealRates.highSchoolRatePerMeal ?? 8.17),
    eggRate: String(mealRates.eggRate ?? 6.00),
    chikkiRate: String(mealRates.chikkiRate ?? 5.00),
    ragiRatePerKg: String(mealRates.ragiRatePerKg ?? 35.00),
    jaggeryRatePerKg: String(mealRates.jaggeryRatePerKg ?? 60.00),
  }));

  const handleUpdateEditingRate = (field: keyof MealRates, valStr: string) => {
    const sanitized = valStr.replace(/[^0-9.]/g, '');
    const parts = sanitized.split('.');
    const cleanStr = parts.length > 2 ? `${parts[0]}.${parts.slice(1).join('')}` : sanitized;

    setRawEditingRates((prev) => ({ ...prev, [field]: cleanStr }));
    const parsed = parseFloat(cleanStr);
    const num = isNaN(parsed) ? 0 : parsed;
    setEditingMealRates((prev) => ({ ...prev, [field]: num }));
  };
  const [showPdfGuideModal, setShowPdfGuideModal] = useState<boolean>(false);
  const [showPrintPreview, setShowPrintPreview] = useState<boolean>(false);
  const [previewZoom, setPreviewZoom] = useState<number>(100);
  const [previewOrientation, setPreviewOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [showMarginGuides, setShowMarginGuides] = useState<boolean>(true);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [settingsInitialSection, setSettingsInitialSection] = useState<'profile' | 'rates' | 'security' | 'backup' | 'reset' | 'all'>('all');
  
  // Register Glassware Background Theme State
  type RegisterBgTheme = 'sapphire' | 'emerald' | 'amber' | 'amethyst' | 'rose' | 'cosmic' | 'crystal';
  const [registerBgTheme, setRegisterBgTheme] = useState<RegisterBgTheme>(() => {
    try {
      const saved = localStorage.getItem('mdm_register_bg_theme');
      return (saved as RegisterBgTheme) || 'sapphire';
    } catch {
      return 'sapphire';
    }
  });
  const [showBgThemePicker, setShowBgThemePicker] = useState<boolean>(false);

  const handleSelectRegisterBgTheme = (theme: RegisterBgTheme) => {
    setRegisterBgTheme(theme);
    try {
      localStorage.setItem('mdm_register_bg_theme', theme);
    } catch (e) {
      console.error(e);
    }
    setShowBgThemePicker(false);
  };
  
  // Register Data Font Size State ('standard' | 'large' | 'xlarge')
  type TableDataFontSize = 'standard' | 'large' | 'xlarge';
  const [tableDataFontSize, setTableDataFontSize] = useState<TableDataFontSize>(() => {
    try {
      const saved = localStorage.getItem('mdm_register_data_font_size');
      return (saved as TableDataFontSize) || 'large';
    } catch {
      return 'large';
    }
  });

  const handleSelectTableDataFontSize = (size: TableDataFontSize) => {
    setTableDataFontSize(size);
    try {
      localStorage.setItem('mdm_register_data_font_size', size);
    } catch (e) {
      console.error(e);
    }
  };

  // Inline Cell/Row Editor State (In-place editing without popup modal)
  interface InlineCommodityStock {
    ob: number;
    rec: number;
    spoiled: number;
    cb?: number;
  }

  const [inlineEditingDate, setInlineEditingDate] = useState<string | null>(null);
  const [inlineActiveField, setInlineActiveField] = useState<string | null>(null);
  const [inlineRawInputs, setInlineRawInputs] = useState<Record<string, string>>({});
  const [showDecimalHelper, setShowDecimalHelper] = useState<boolean>(true);
  const [inlineEditState, setInlineEditState] = useState<{
    date: string;
    primaryRoll: number;
    upperPrimaryRoll: number;
    initialPrimaryRoll?: number;
    initialUpperPrimaryRoll?: number;
    isRollManuallyChanged?: boolean;
    primaryAttendance: number;
    upperPrimaryAttendance: number;
    mealsServed: number;
    isMealsCustomized?: boolean;
    rice: InlineCommodityStock;
    egg: InlineCommodityStock;
    chikki: InlineCommodityStock;
    ragi: InlineCommodityStock;
    jaggery: InlineCommodityStock;
    isHoliday: boolean;
    holidayName: string;
    remarks: string;
  } | null>(null);
  const [inlineAutoSavedTime, setInlineAutoSavedTime] = useState<string | null>(null);
  const [isAutoSaving, setIsAutoSaving] = useState<boolean>(false);
  const inlineIsDirtyRef = useRef<boolean>(false);
  const inlineEditStateRef = useRef<typeof inlineEditState>(null);
  inlineEditStateRef.current = inlineEditState;
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showQuickFillMenu, setShowQuickFillMenu] = useState<boolean>(false);

  // Cash Voucher & Report Print Modal State
  const [showVoucherModal, setShowVoucherModal] = useState<boolean>(false);
  const [activeReportModal, setActiveReportModal] = useState<ReportType | null>(null);
  const [showChangeImageModal, setShowChangeImageModal] = useState<boolean>(false);
  const [isTableScrolledX, setIsTableScrolledX] = useState<boolean>(false);
  const [rollUpdateCounter, setRollUpdateCounter] = useState<number>(0);
  const [holidayUpdateCounter, setHolidayUpdateCounter] = useState<number>(0);
  const [activeHolidayRowDate, setActiveHolidayRowDate] = useState<string | null>(null);
  const [freezeLeft, setFreezeLeft] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_freeze_left_columns');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [freezeRow, setFreezeRow] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_freeze_row');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [showSummaryCards, setShowSummaryCards] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_show_monthly_summary_cards');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [showToolbar, setShowToolbar] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_show_monthly_toolbar');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const toggleSummaryCards = () => {
    setShowSummaryCards((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('mdm_show_monthly_summary_cards', String(next));
      } catch (err) {
        console.error('Failed to save summary cards preference', err);
      }
      showToast(next ? 'Summary Cards: Shown' : 'Summary Cards: Hidden');
      return next;
    });
  };

  const toggleToolbar = () => {
    setShowToolbar((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('mdm_show_monthly_toolbar', String(next));
      } catch (err) {
        console.error('Failed to save toolbar preference', err);
      }
      showToast(next ? 'Toolbar: Shown' : 'Toolbar: Hidden');
      return next;
    });
  };

  const toggleFreezeRow = () => {
    setFreezeRow((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('mdm_freeze_row', String(next));
      } catch (err) {
        console.error('Failed to save freeze row preference', err);
      }
      showToast(next ? 'Freeze on Row: ON' : 'Freeze on Row: OFF');
      return next;
    });
  };

  const toggleFreezeLeft = () => {
    setFreezeLeft((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('mdm_freeze_left_columns', String(next));
      } catch (err) {
        console.error('Failed to save freeze left preference', err);
      }
      showToast(next ? 'Freeze: ON' : 'Freeze: OFF');
      return next;
    });
  };


  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const formatAsDDMMYY = (dateStr: string) => {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const y = parts[0].slice(-2); // YY
      const m = parts[1]; // MM
      const d = parts[2]; // DD
      return `${d}-${m}-${y}`;
    }
    return dateStr;
  };

  // Helper to synthesize complete daily entries for any month for unbroken stock cascading
  const synthesizeEntriesForMonth = (mStr: string): DailyEntry[] => {
    const mParts = mStr.split('-');
    const mY = parseInt(mParts[0], 10);
    const mMo = parseInt(mParts[1], 10);
    const daysInM = isNaN(mY) || isNaN(mMo) ? 30 : new Date(mY, mMo, 0).getDate();

    const mEntriesMap = new Map<string, DailyEntry>();
    dailyEntries.forEach((e) => {
      if (e.date && e.date.startsWith(mStr)) {
        mEntriesMap.set(e.date, e);
      }
    });

    const entries: DailyEntry[] = [];
    for (let d = 1; d <= daysInM; d++) {
      const dateStr = `${mStr}-${String(d).padStart(2, '0')}`;
      if (mEntriesMap.has(dateStr)) {
        const item = mEntriesMap.get(dateStr)!;
        entries.push({
          ...item,
          id: item.id || `entry-${dateStr}`,
        });
      } else {
        const dayInfo = getDayDetails(dateStr);
        const isSunday = dayInfo.isSunday;
        const isHoliday = dayInfo.isHoliday;

        let pAtt = 0;
        let upAtt = 0;
        let hsAtt = 0;
        let totalMeals = 0;
        let calculatedRice = 0;
        let eggUsedQty = 0;
        let chikkiUsedQty = 0;
        let ragiUsedKg = 0;
        let jaggeryUsedKg = 0;

        if (!isSunday && !isHoliday && dateStr <= todayStr) {
          const classAtt = getDailyClassAttendanceForDate ? getDailyClassAttendanceForDate(dateStr) : [];
          if (classAtt && classAtt.length > 0) {
            pAtt = classAtt
              .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

            upAtt = classAtt
              .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

            hsAtt = classAtt
              .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);
          } else {
            const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(mStr);
            pAtt = classStrengths
              .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
              .reduce((sum, s) => sum + s.total, 0);

            upAtt = classStrengths
              .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.total, 0);

            hsAtt = classStrengths
              .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.total, 0);
          }

          totalMeals = pAtt + upAtt + hsAtt;

          calculatedRice = Number(((pAtt * 0.1) + (upAtt * 0.15) + (hsAtt * 0.15)).toFixed(2));

          const dayOfWeek = dayInfo.dayOfWeek;
          if (dayOfWeek >= 1 && dayOfWeek <= 5) {
            eggUsedQty = totalMeals;
          }

          if (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5) {
            chikkiUsedQty = totalMeals;
          }

          if (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) {
            ragiUsedKg = Number((totalMeals * 0.01).toFixed(2));
            jaggeryUsedKg = Number((totalMeals * 0.01).toFixed(2));
          }
        }

        const synthesizedEntry: DailyEntry = {
          id: `synth-${dateStr}`,
          date: dateStr,
          primaryAttendance: pAtt,
          upperPrimaryAttendance: upAtt,
          highSchoolAttendance: hsAtt,
          totalAttendance: pAtt + upAtt + hsAtt,
          mealsServed: totalMeals,
          riceUsedKg: calculatedRice,
          eggUsedQty: eggUsedQty,
          chikkiUsedQty: chikkiUsedQty,
          ragiUsedKg: ragiUsedKg,
          jaggeryUsedKg: jaggeryUsedKg,
          primaryRatePerMeal: mealRates.primaryRatePerMeal,
          upperPrimaryRatePerMeal: mealRates.upperPrimaryRatePerMeal,
          remarks: isSunday ? 'Sunday Holiday' : isHoliday ? (dayInfo.holidayName || 'Holiday') : (dateStr > todayStr ? 'Future Date' : ''),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        entries.push(synthesizedEntry);
      }
    }
    return entries;
  };

  // Generate entries for the current month and preceding months
  const parts = selectedMonth.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const daysInMonth = isNaN(year) || isNaN(month) ? 30 : new Date(year, month, 0).getDate();

  const [selYear, selMo] = selectedMonth.split('-').map(Number);
  const prevMonthDate = new Date(selYear, selMo - 2, 1);
  const prevMonthStr = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}`;
  const prevMonthLabel = prevMonthDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  const currMonthLabel = new Date(selYear, selMo - 1, 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

  // Gather all relevant months up to selectedMonth to create an unbroken daily stock cascade
  const relevantMonthsSet = new Set<string>();
  relevantMonthsSet.add('2026-08'); // Baseline starting academic month
  relevantMonthsSet.add(prevMonthStr);
  relevantMonthsSet.add(selectedMonth);

  dailyEntries.forEach((e) => {
    if (e.date && e.date.length >= 7 && e.date.substring(0, 7) <= selectedMonth) {
      relevantMonthsSet.add(e.date.substring(0, 7));
    }
  });
  stockTransactions.forEach((tx) => {
    if (tx.date && tx.date.length >= 7 && tx.date.substring(0, 7) <= selectedMonth) {
      relevantMonthsSet.add(tx.date.substring(0, 7));
    }
  });
  Object.keys(monthlyOverrides).forEach((m) => {
    if (m && m.length >= 7 && m.substring(0, 7) <= selectedMonth) {
      relevantMonthsSet.add(m.substring(0, 7));
    }
  });

  const continuousMonths = generateContinuousMonthRange(Array.from(relevantMonthsSet));

  const allSynthesizedEntries: DailyEntry[] = [];
  continuousMonths.forEach((mStr) => {
    allSynthesizedEntries.push(...synthesizeEntriesForMonth(mStr));
  });

  const monthEntries: DailyEntry[] = synthesizeEntriesForMonth(selectedMonth);

  const monthEntriesMap = new Map<string, DailyEntry>();
  dailyEntries.forEach((e) => {
    if (e.date.startsWith(selectedMonth)) {
      monthEntriesMap.set(e.date, e);
    }
  });

  // Start Single-Cell Targeted Inline Edit (Only the clicked cell activates with cursor)
  const startSingleCellEdit = (dateStr: string, field: string) => {
    // Prevent activating closing commodity balances for editing (CB is strictly auto-calculated: OB + Rec - Used - Spoiled)
    const blockedBalanceFields = new Set([
      'rice.cb', 'rice-cb',
      'egg.cb', 'egg-cb',
      'chikki.cb', 'chikki-cb',
      'ragi.cb', 'ragi-cb',
      'jaggery.cb', 'jaggery-cb',
    ]);
    if (blockedBalanceFields.has(field)) {
      return;
    }

    // If there is an active row being edited on another date with unsaved changes, flush it first!
    if (inlineEditingDate && inlineEditingDate !== dateStr && inlineIsDirtyRef.current && inlineEditStateRef.current) {
      commitInlineEdit(inlineEditStateRef.current, false);
    }

    if (!inlineEditState || inlineEditingDate !== dateStr) {
      const existing = monthEntriesMap.get(dateStr);
      const dayInfo = getDayDetails(dateStr);
      const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(dateStr.substring(0, 7));

      const pRoll = classStrengths
        .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
        .reduce((sum, s) => sum + s.total, 0);

      const upRoll = classStrengths
        .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
        .reduce((sum, s) => sum + s.total, 0);

      const dayStock = dailyStockMap[dateStr];

      const initialCommodities = {
        rice: {
          ob: dayStock?.rice?.ob ?? 0,
          rec: dayStock?.rice?.rec ?? 0,
          spoiled: dayStock?.rice?.spoiled ?? 0,
          cb: undefined,
        },
        egg: {
          ob: dayStock?.egg?.ob ?? 0,
          rec: dayStock?.egg?.rec ?? 0,
          spoiled: dayStock?.egg?.spoiled ?? 0,
          cb: undefined,
        },
        chikki: {
          ob: dayStock?.chikki?.ob ?? 0,
          rec: dayStock?.chikki?.rec ?? 0,
          spoiled: dayStock?.chikki?.spoiled ?? 0,
          cb: undefined,
        },
        ragi: {
          ob: dayStock?.ragi?.ob ?? 0,
          rec: dayStock?.ragi?.rec ?? 0,
          spoiled: dayStock?.ragi?.spoiled ?? 0,
          cb: undefined,
        },
        jaggery: {
          ob: dayStock?.jaggery?.ob ?? 0,
          rec: dayStock?.jaggery?.rec ?? 0,
          spoiled: dayStock?.jaggery?.spoiled ?? 0,
          cb: undefined,
        },
      };

      let initialState: NonNullable<typeof inlineEditState>;
      if (existing) {
        const isSun = !dayInfo.isWorkingDayOverride && dayInfo.isSunday;
        const isHol = !dayInfo.isWorkingDayOverride && (existing.mealsServed === 0 && Boolean(existing.remarks && (existing.remarks.toLowerCase().includes('holiday') || existing.remarks.toLowerCase().includes('closed') || existing.remarks.toLowerCase().includes('sunday'))));

        initialState = {
          date: dateStr,
          primaryRoll: pRoll,
          upperPrimaryRoll: upRoll,
          initialPrimaryRoll: pRoll,
          initialUpperPrimaryRoll: upRoll,
          isRollManuallyChanged: false,
          primaryAttendance: existing.primaryAttendance,
          upperPrimaryAttendance: existing.upperPrimaryAttendance,
          mealsServed: existing.mealsServed,
          isMealsCustomized: existing.mealsServed !== (existing.primaryAttendance + existing.upperPrimaryAttendance),
          ...initialCommodities,
          isHoliday: isHol || isSun,
          holidayName: existing.remarks || (dayInfo.holidayName || (isSun ? 'Sunday' : 'School Holiday')),
          remarks: isHol || isSun ? '' : (existing.remarks || ''),
        };
      } else {
        const isSun = !dayInfo.isWorkingDayOverride && dayInfo.isSunday;
        const isHol = !dayInfo.isWorkingDayOverride && dayInfo.isHoliday;
        const pAtt = isSun || isHol ? 0 : pRoll;
        const upAtt = isSun || isHol ? 0 : upRoll;
        const totalAtt = pAtt + upAtt;

        initialState = {
          date: dateStr,
          primaryRoll: pRoll,
          upperPrimaryRoll: upRoll,
          initialPrimaryRoll: pRoll,
          initialUpperPrimaryRoll: upRoll,
          isRollManuallyChanged: false,
          primaryAttendance: pAtt,
          upperPrimaryAttendance: upAtt,
          mealsServed: totalAtt,
          isMealsCustomized: false,
          ...initialCommodities,
          isHoliday: isSun || isHol,
          holidayName: isSun ? 'Sunday' : (dayInfo.holidayName || 'Holiday'),
          remarks: '',
        };
      }

      setInlineRawInputs({});
      setInlineEditState(initialState);
      inlineEditStateRef.current = initialState;
      inlineIsDirtyRef.current = false;
      setInlineAutoSavedTime(null);
      setInlineEditingDate(dateStr);
    }

    setInlineActiveField(field);
  };

  const startInlineEdit = (dateStr: string, targetField: string = 'primaryAttendance') => {
    startSingleCellEdit(dateStr, targetField);
  };

  // Commit and persist inline row changes (saves automatically as entries are typed/modified)
  const commitInlineEdit = (target: NonNullable<typeof inlineEditState>, closeEditor: boolean = false) => {
    if (!target) return;
    const isHol = target.isHoliday;
    const dayInfo = getDayDetails(target.date);
    const dayOfWeek = dayInfo.dayOfWeek;

    // Save updated Student Roll ONLY if explicitly changed by the user
    const rollActuallyChanged =
      target.isRollManuallyChanged ||
      (target.initialPrimaryRoll !== undefined &&
        (target.primaryRoll !== target.initialPrimaryRoll || target.upperPrimaryRoll !== target.initialUpperPrimaryRoll));

    if (rollActuallyChanged && target.primaryRoll !== undefined && target.upperPrimaryRoll !== undefined) {
      const currentStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(target.date) : [];
      const updatedStrengths = distributeStudentStrengths(
        currentStrengths.length > 0 ? currentStrengths : (studentStrengths || []),
        target.primaryRoll,
        target.upperPrimaryRoll
      );
      saveStudentStrengthForDate(target.date, updatedStrengths, target.remarks?.trim() || 'Register Roll updated');
      if (onSaveStudentStrengths) {
        onSaveStudentStrengths(updatedStrengths, target.date);
      }
      setRollUpdateCounter((v) => v + 1);
      target.initialPrimaryRoll = target.primaryRoll;
      target.initialUpperPrimaryRoll = target.upperPrimaryRoll;
      target.isRollManuallyChanged = false;
    }

    const pAtt = isHol ? 0 : target.primaryAttendance;
    const upAtt = isHol ? 0 : target.upperPrimaryAttendance;
    const totalAttendance = pAtt + upAtt;
    const mealsServed = isHol ? 0 : target.mealsServed;

    // Automatically calculate commodity usage by standard government norms
    const rice = isHol ? 0 : (mealsServed > 0 && totalAttendance > 0
      ? Number((((pAtt * 0.1) + (upAtt * 0.15)) * (mealsServed / totalAttendance)).toFixed(2))
      : Number(((pAtt * 0.1) + (upAtt * 0.15)).toFixed(2)));
    const egg = isHol ? 0 : (dayOfWeek >= 1 && dayOfWeek <= 5 ? mealsServed : 0);
    const chikki = isHol ? 0 : (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5 ? mealsServed : 0);
    const ragi = isHol ? 0 : (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6 ? Number((mealsServed * 0.01).toFixed(2)) : 0);
    const jaggery = isHol ? 0 : (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6 ? Number((mealsServed * 0.01).toFixed(2)) : 0);
    const oil = isHol ? 0 : Number((mealsServed * 0.005).toFixed(2));
    const pulses = isHol ? 0 : Number((mealsServed * 0.02).toFixed(2));

    const entryToSave: DailyEntry = {
      id: `entry-${target.date}`,
      date: target.date,
      primaryAttendance: pAtt,
      upperPrimaryAttendance: upAtt,
      highSchoolAttendance: 0,
      totalAttendance: totalAttendance,
      mealsServed: mealsServed,
      riceUsedKg: rice,
      eggUsedQty: egg,
      chikkiUsedQty: chikki,
      ragiUsedKg: ragi,
      jaggeryUsedKg: jaggery,
      oilUsedLitres: oil,
      pulsesUsedKg: pulses,
      remarks: isHol ? (target.holidayName || 'Holiday') : (target.remarks?.trim() || 'MDM Served'),
      customCookingCost: undefined,
      primaryRatePerMeal: mealRates.primaryRatePerMeal,
      upperPrimaryRatePerMeal: mealRates.upperPrimaryRatePerMeal,
      eggRate: mealRates.eggRate,
      chikkiRate: mealRates.chikkiRate,
      ragiRatePerKg: mealRates.ragiRatePerKg,
      jaggeryRatePerKg: mealRates.jaggeryRatePerKg,
      isManual: true,
    };

    if (onSaveEntry) {
      onSaveEntry(entryToSave);
    }

    // Keep daily class attendance strictly in sync with the edited entry so attendance never reverts
    try {
      const classStrengthsForDate = getStudentStrengthForDate ? getStudentStrengthForDate(target.date) : getStudentStrengthForMonth(target.date.substring(0, 7));
      const distributedClassAtt = distributeStudentStrengths(classStrengthsForDate, pAtt, upAtt).map((s) => ({
        classLevel: s.classLevel,
        category: s.category,
        boysPresent: s.boys,
        girlsPresent: s.girls,
        totalPresent: s.total,
      }));
      saveDailyClassAttendanceForDate(target.date, distributedClassAtt);
    } catch (e) {
      console.warn('Failed syncing daily class attendance for date', e);
    }

    // Save Stock Transactions for Received & Spoiled and any explicit Closing Balance overrides
    const commIds = ['rice', 'egg', 'chikki', 'ragi', 'jaggery'] as const;
    const remainingTxs = stockTransactions.filter(
      (tx) =>
        !tx.id?.startsWith('tx-adj-2026-08-31') &&
        !(tx.remarks && tx.remarks.includes('31.8.2026')) &&
        !(tx.date === target.date && (tx.type === 'RECEIVED' || tx.type === 'SPOILED' || tx.type === 'ADJUSTMENT') && commIds.includes(tx.commodityId as any))
    );
    const newTxs: StockTransaction[] = [];
    commIds.forEach((cId) => {
      const cData = target[cId];
      if (cData && cData.rec > 0) {
        newTxs.push({
          id: `tx-rec-${target.date}-${cId}-${Date.now()}`,
          date: target.date,
          commodityId: cId,
          type: 'RECEIVED',
          quantity: cData.rec,
          remarks: 'Register Entry (Received)',
        });
      }
      if (cData && cData.spoiled > 0) {
        newTxs.push({
          id: `tx-spoil-${target.date}-${cId}-${Date.now()}`,
          date: target.date,
          commodityId: cId,
          type: 'SPOILED',
          quantity: cData.spoiled,
          remarks: 'Register Entry (Spoiled)',
        });
      }
      // If user explicitly typed a custom closing balance
      if (cData && cData.cb !== undefined) {
        newTxs.push({
          id: `tx-adj-${target.date}-${cId}`,
          date: target.date,
          commodityId: cId,
          type: 'ADJUSTMENT',
          quantity: cData.cb,
          remarks: `Closing Balance verified on ${target.date}`,
        });
      }
    });

    const allUpdatedTxs = [...remainingTxs, ...newTxs];
    if (onSaveStockTransactions) {
      onSaveStockTransactions(allUpdatedTxs);
      saveStoredStockTransactions(allUpdatedTxs);
    }

    // Persist Opening Balances for this entry
    const entryMonth = target.date.substring(0, 7) || selectedMonth;
    const isFirstDayOrWorkingDay =
      target.date.endsWith('-01') ||
      (monthEntries.length > 0 && target.date === monthEntries[0].date) ||
      target.date === firstWorkingDayDateStr ||
      target.date === '2026-08-01';

    const existingStock = dailyStockMap[target.date];
    const baseAutoRiceOB = isFirstDayOrWorkingDay ? prevRiceCB : (existingStock ? existingStock.rice.ob : prevRiceCB);
    const baseAutoEggOB = isFirstDayOrWorkingDay ? prevEggCB : (existingStock ? existingStock.egg.ob : prevEggCB);
    const baseAutoChikkiOB = isFirstDayOrWorkingDay ? prevChikkiCB : (existingStock ? existingStock.chikki.ob : prevChikkiCB);
    const baseAutoRagiOB = isFirstDayOrWorkingDay ? prevRagiCB : (existingStock ? existingStock.ragi.ob : prevRagiCB);
    const baseAutoJaggeryOB = isFirstDayOrWorkingDay ? prevJaggeryCB : (existingStock ? existingStock.jaggery.ob : prevJaggeryCB);

    const hasRawOBInput = Boolean(
      (inlineRawInputs['rice.ob'] !== undefined && inlineRawInputs['rice.ob'].trim() !== '') ||
      (inlineRawInputs['egg.ob'] !== undefined && inlineRawInputs['egg.ob'].trim() !== '') ||
      (inlineRawInputs['chikki.ob'] !== undefined && inlineRawInputs['chikki.ob'].trim() !== '') ||
      (inlineRawInputs['ragi.ob'] !== undefined && inlineRawInputs['ragi.ob'].trim() !== '') ||
      (inlineRawInputs['jaggery.ob'] !== undefined && inlineRawInputs['jaggery.ob'].trim() !== '')
    );

    const isOBManuallyChanged =
      hasRawOBInput && (
        Math.abs(target.rice.ob - baseAutoRiceOB) > 0.001 ||
        Math.abs(target.egg.ob - baseAutoEggOB) > 0.001 ||
        Math.abs(target.chikki.ob - baseAutoChikkiOB) > 0.001 ||
        Math.abs(target.ragi.ob - baseAutoRagiOB) > 0.001 ||
        Math.abs(target.jaggery.ob - baseAutoJaggeryOB) > 0.001
      );

    if (isOBManuallyChanged) {
      saveStoredManualObMonth(entryMonth, true);
      const updatedOB: Record<string, number> = {
        rice: target.rice.ob,
        egg: target.egg.ob,
        chikki: target.chikki.ob,
        ragi: target.ragi.ob,
        jaggery: target.jaggery.ob,
      };

      if (isFirstDayOrWorkingDay || target.date === '2026-08-01' || target.date.endsWith('-01')) {
        const currentMonthOverrides = monthlyOverrides[entryMonth] || {};
        const newMonthOverrides = {
          ...currentMonthOverrides,
          ...updatedOB,
        };

        if (onSaveMonthlyBalances) {
          onSaveMonthlyBalances(entryMonth, newMonthOverrides);
          onSaveMonthlyBalances(`${entryMonth}-01`, newMonthOverrides);
          if (target.date !== `${entryMonth}-01`) {
            onSaveMonthlyBalances(target.date, newMonthOverrides);
          }
        }
        saveStoredMonthlyCommodityBalances({
          ...monthlyOverrides,
          [entryMonth]: newMonthOverrides,
          [`${entryMonth}-01`]: newMonthOverrides,
          [target.date]: newMonthOverrides,
        });

        // Also persist to base commodities opening balances if August or base month
        if (entryMonth === '2026-08' || target.date.startsWith('2026-08')) {
          const updatedBase = (baseCommodities || []).map((c) => {
            if (updatedOB[c.id] !== undefined) {
              return {
                ...c,
                openingBalance: updatedOB[c.id],
              };
            }
            return c;
          });
          if (onSaveOpeningBalances) {
            onSaveOpeningBalances(updatedBase);
          }
          saveStoredCommodities(updatedBase);
        }
      } else {
        // If modified on any other day in the month:
        // Set date override on target.date so yesterday's entered data is NOT changed ("don't change upto edit")
        // and today's new closing balance automatically continues updating forward from this entry!
        const currentDateOverrides = monthlyOverrides[target.date] || {};
        const newDateOverrides = {
          ...currentDateOverrides,
          ...updatedOB,
        };

        if (onSaveMonthlyBalances) {
          onSaveMonthlyBalances(target.date, newDateOverrides);
        }
        saveStoredMonthlyCommodityBalances({
          ...monthlyOverrides,
          [target.date]: newDateOverrides,
        });
      }
    }

    const customMap = getStoredCustomHolidays();
    if (isHol) {
      customMap[target.date] = target.holidayName?.trim() || 'School Holiday';
    } else {
      customMap[target.date] = 'WORKING_DAY';
    }
    saveStoredCustomHolidays(customMap);

    inlineIsDirtyRef.current = false;
    setIsAutoSaving(false);
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setInlineAutoSavedTime(timeStr);

    if (closeEditor) {
      showToast(`Saved register for ${formatDateReadable(target.date)} (attendance, served meals & stock updated)`);
      setInlineEditingDate(null);
      setInlineEditState(null);
      setInlineActiveField(null);
    }
  };

  // Keep inlineEditStateRef synchronized with latest state
  useEffect(() => {
    inlineEditStateRef.current = inlineEditState;
  }, [inlineEditState]);

  // Debounced auto-save effect for inline cell editing
  useEffect(() => {
    if (!inlineIsDirtyRef.current || !inlineEditState) return;

    setIsAutoSaving(true);
    const timer = setTimeout(() => {
      if (inlineEditStateRef.current && inlineIsDirtyRef.current) {
        commitInlineEdit(inlineEditStateRef.current, false);
      }
    }, 450);

    return () => clearTimeout(timer);
  }, [inlineEditState]);

  // Flush any pending auto-saves when unmounting
  useEffect(() => {
    return () => {
      if (inlineIsDirtyRef.current && inlineEditStateRef.current) {
        commitInlineEdit(inlineEditStateRef.current, false);
      }
    };
  }, []);

  // Editable fields order for keyboard Tab navigation (OB commodities are editable, CB is auto-calculated)
  const editableFieldsOrder = [
    'primaryRoll',
    'upperPrimaryRoll',
    'primaryAttendance',
    'upperPrimaryAttendance',
    'mealsServed',
    'rice.ob',
    'rice.rec',
    'rice.spoiled',
    'egg.ob',
    'egg.rec',
    'egg.spoiled',
    'chikki.ob',
    'chikki.rec',
    'chikki.spoiled',
    'ragi.ob',
    'ragi.rec',
    'ragi.spoiled',
    'jaggery.ob',
    'jaggery.rec',
    'jaggery.spoiled',
    'remarks',
  ];

  // Save on blur immediately if leaving the table
  const handleInlineBlur = (e?: React.FocusEvent) => {
    if (e && e.relatedTarget && (
      e.currentTarget?.parentElement?.contains(e.relatedTarget as Node) ||
      (e.relatedTarget as HTMLElement).closest('table') ||
      (e.relatedTarget as HTMLElement).closest('.decimal-helper-bar')
    )) {
      return;
    }
    const stateToSave = inlineEditStateRef.current || inlineEditState;
    if (inlineIsDirtyRef.current && stateToSave) {
      commitInlineEdit(stateToSave, false);
    }
    setInlineActiveField(null);
  };

  // Done button or Enter key to finish editing this row
  const saveInlineEdit = () => {
    const stateToSave = inlineEditStateRef.current || inlineEditState;
    if (!stateToSave) {
      setInlineActiveField(null);
      return;
    }
    commitInlineEdit(stateToSave, true);
    setInlineActiveField(null);
  };

  // Cancel inline editing
  const cancelInlineEdit = () => {
    setInlineEditingDate(null);
    setInlineEditState(null);
    setInlineActiveField(null);
    inlineIsDirtyRef.current = false;
  };

  // Handle keyboard shortcut (Enter to save/finish, Escape to cancel, Tab to cycle fields)
  const handleInlineKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveInlineEdit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      cancelInlineEdit();
    } else if (e.key === 'Tab') {
      if (inlineActiveField) {
        e.preventDefault();
        const currentIndex = editableFieldsOrder.indexOf(inlineActiveField);
        if (currentIndex >= 0) {
          const nextIndex = e.shiftKey ? currentIndex - 1 : currentIndex + 1;
          if (nextIndex >= 0 && nextIndex < editableFieldsOrder.length) {
            setInlineActiveField(editableFieldsOrder[nextIndex]);
          } else {
            saveInlineEdit();
          }
        }
      }
    }
  };

  // Check if current active field is an editable commodity field
  const isCommodityField = (field: string | null): boolean => {
    if (!field) return false;
    return [
      'rice.ob', 'rice.rec', 'rice.spoiled',
      'egg.ob', 'egg.rec', 'egg.spoiled',
      'chikki.ob', 'chikki.rec', 'chikki.spoiled',
      'ragi.ob', 'ragi.rec', 'ragi.spoiled',
      'jaggery.ob', 'jaggery.rec', 'jaggery.spoiled',
    ].includes(field);
  };

  const getCommodityFieldMeta = (field: string | null): { name: string; type: string; unit: string } => {
    if (!field) return { name: '', type: '', unit: '' };
    const [c, p] = field.split('.');
    const names: Record<string, string> = {
      rice: 'Rice',
      egg: 'Egg',
      chikki: 'Chikki',
      ragi: 'Ragi Flour',
      jaggery: 'Jaggery',
    };
    const units: Record<string, string> = {
      rice: 'Kg',
      egg: 'Qty',
      chikki: 'Qty',
      ragi: 'Kg',
      jaggery: 'Kg',
    };
    const types: Record<string, string> = {
      ob: 'Opening Balance (OB)',
      rec: 'Received (+)',
      spoiled: 'Spoiled (-)',
    };
    return {
      name: names[c] || c,
      type: types[p] || p,
      unit: units[c] || '',
    };
  };

  const handleCommodityInlineChange = (
    fieldKey: string,
    rawStr: string,
    comm: 'rice' | 'egg' | 'chikki' | 'ragi' | 'jaggery',
    prop: 'ob' | 'rec' | 'spoiled'
  ) => {
    setInlineRawInputs((prev) => ({ ...prev, [fieldKey]: rawStr }));
    inlineIsDirtyRef.current = true;
    const parsed = (rawStr === '' || rawStr === '-' || rawStr === '.') ? 0 : (prop === 'ob' ? (parseFloat(rawStr) || 0) : Math.max(0, parseFloat(rawStr) || 0));
    setInlineEditState((prev) => {
      if (!prev) return prev;
      const updated = {
        ...prev,
        [comm]: {
          ...prev[comm],
          [prop]: parsed,
        },
      };
      inlineEditStateRef.current = updated;
      return updated;
    });
  };

  const handleApplyDecimalOffset = (offset: number) => {
    if (!inlineActiveField || !inlineEditState) return;
    const parts = inlineActiveField.split('.');
    if (parts.length !== 2) return;
    const comm = parts[0] as 'rice' | 'egg' | 'chikki' | 'ragi' | 'jaggery';
    const prop = parts[1] as 'ob' | 'rec' | 'spoiled';
    const currentVal = inlineEditState[comm]?.[prop] ?? 0;
    const nextVal = prop === 'ob' ? Number((currentVal + offset).toFixed(3)) : Math.max(0, Number((currentVal + offset).toFixed(3)));
    setInlineRawInputs((prev) => ({ ...prev, [inlineActiveField]: String(nextVal) }));
    inlineIsDirtyRef.current = true;
    setInlineEditState((prev) => {
      if (!prev) return prev;
      const updated = {
        ...prev,
        [comm]: {
          ...prev[comm],
          [prop]: nextVal,
        },
      };
      inlineEditStateRef.current = updated;
      return updated;
    });
  };

  const handleSetDecimalDirect = (val: number | string) => {
    if (!inlineActiveField || !inlineEditState) return;
    const parts = inlineActiveField.split('.');
    if (parts.length !== 2) return;
    const comm = parts[0] as 'rice' | 'egg' | 'chikki' | 'ragi' | 'jaggery';
    const prop = parts[1] as 'ob' | 'rec' | 'spoiled';
    const num = typeof val === 'number' ? val : parseFloat(val) || 0;
    setInlineRawInputs((prev) => ({ ...prev, [inlineActiveField]: String(val) }));
    inlineIsDirtyRef.current = true;
    setInlineEditState((prev) => {
      if (!prev) return prev;
      const updated = {
        ...prev,
        [comm]: {
          ...prev[comm],
          [prop]: num,
        },
      };
      inlineEditStateRef.current = updated;
      return updated;
    });
  };

  const handleAppendDecimalDot = () => {
    if (!inlineActiveField || !inlineEditState) return;
    const parts = inlineActiveField.split('.');
    if (parts.length !== 2) return;
    const comm = parts[0] as 'rice' | 'egg' | 'chikki' | 'ragi' | 'jaggery';
    const prop = parts[1] as 'ob' | 'rec' | 'spoiled';
    const currentRaw = inlineRawInputs[inlineActiveField] !== undefined
      ? inlineRawInputs[inlineActiveField]
      : (inlineEditState[comm]?.[prop] ? String(inlineEditState[comm][prop]) : '');
    if (!currentRaw.includes('.')) {
      const nextRaw = currentRaw === '' ? '0.' : currentRaw + '.';
      setInlineRawInputs((prev) => ({ ...prev, [inlineActiveField]: nextRaw }));
    }
  };

  // Reset a specific day back to dynamic auto calculations
  const handleResetDayToAuto = (dateStr: string) => {
    const existing = monthEntriesMap.get(dateStr);
    if (existing && onDeleteEntry) {
      onDeleteEntry(existing.id);
      showToast(`Reverted ${formatDateReadable(dateStr)} to dynamic auto-calculations.`);
    }
    const customMap = getStoredCustomHolidays();
    if (customMap[dateStr]) {
      delete customMap[dateStr];
      saveStoredCustomHolidays(customMap);
    }
    setHolidayUpdateCounter((v) => v + 1);
    setInlineEditingDate(null);
    setInlineEditState(null);
  };

  // Convert a holiday to a working day and immediately start inline editing
  const handleConvertHolidayToWorkingDay = (dateStr: string) => {
    // 1. Mark in custom holidays as WORKING_DAY
    const customMap = getStoredCustomHolidays();
    customMap[dateStr] = 'WORKING_DAY';
    saveStoredCustomHolidays(customMap);

    // 2. Fetch enrollment strength for this date
    const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(selectedMonth);
    const pRoll = classStrengths
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.total, 0) || primaryEnrolled;
    const upRoll = classStrengths
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.total, 0) || upperPrimaryEnrolled;
    const totalAtt = pRoll + upRoll;
    const mealsServed = totalAtt;

    const dayInfo = getDayDetails(dateStr);
    const dayOfWeek = dayInfo.dayOfWeek;
    const calculatedRice = Number(((pRoll * 0.1) + (upRoll * 0.15)).toFixed(2));
    const eggUsedQty = dayOfWeek >= 1 && dayOfWeek <= 5 ? mealsServed : 0;
    const chikkiUsedQty = (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5) ? mealsServed : 0;
    const ragiUsedKg = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((mealsServed * 0.01).toFixed(2)) : 0;
    const jaggeryUsedKg = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((mealsServed * 0.01).toFixed(2)) : 0;
    const oil = Number((mealsServed * 0.005).toFixed(2));
    const pulses = Number((mealsServed * 0.02).toFixed(2));

    const entryToSave: DailyEntry = {
      id: `entry-${dateStr}`,
      date: dateStr,
      primaryAttendance: pRoll,
      upperPrimaryAttendance: upRoll,
      highSchoolAttendance: 0,
      totalAttendance: totalAtt,
      mealsServed: mealsServed,
      riceUsedKg: calculatedRice,
      eggUsedQty: eggUsedQty,
      chikkiUsedQty: chikkiUsedQty,
      ragiUsedKg: ragiUsedKg,
      jaggeryUsedKg: jaggeryUsedKg,
      oilUsedLitres: oil,
      pulsesUsedKg: pulses,
      remarks: 'Working Day',
      primaryRatePerMeal: mealRates.primaryRatePerMeal,
      upperPrimaryRatePerMeal: mealRates.upperPrimaryRatePerMeal,
      eggRate: mealRates.eggRate,
      chikkiRate: mealRates.chikkiRate,
      ragiRatePerKg: mealRates.ragiRatePerKg,
      jaggeryRatePerKg: mealRates.jaggeryRatePerKg,
      isManual: true,
    };

    if (onSaveEntry) {
      onSaveEntry(entryToSave);
    }

    setHolidayUpdateCounter((v) => v + 1);
    showToast(`Converted ${formatDateReadable(dateStr)} to Working Day. You can now edit attendance and meals.`);

    setTimeout(() => {
      startSingleCellEdit(dateStr, 'primaryAttendance');
    }, 50);
  };

  // Revert a converted working day back to holiday
  const handleRevertWorkingDayToHoliday = (dateStr: string, reason?: string) => {
    const dayInfo = getDayDetails(dateStr);
    const holidayReason = reason || (dayInfo.dayOfWeek === 0 ? 'Sunday Holiday' : 'School Holiday');

    const customMap = getStoredCustomHolidays();
    delete customMap[dateStr];
    const naturalDay = getDayDetails(dateStr);
    if (!naturalDay.isHoliday) {
      customMap[dateStr] = holidayReason;
    }
    saveStoredCustomHolidays(customMap);

    const entryToSave: DailyEntry = {
      id: `entry-${dateStr}`,
      date: dateStr,
      primaryAttendance: 0,
      upperPrimaryAttendance: 0,
      highSchoolAttendance: 0,
      totalAttendance: 0,
      mealsServed: 0,
      riceUsedKg: 0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      oilUsedLitres: 0,
      pulsesUsedKg: 0,
      remarks: holidayReason,
      primaryRatePerMeal: mealRates.primaryRatePerMeal,
      upperPrimaryRatePerMeal: mealRates.upperPrimaryRatePerMeal,
      isManual: true,
    };

    if (onSaveEntry) {
      onSaveEntry(entryToSave);
    }

    if (inlineEditingDate === dateStr) {
      setInlineEditingDate(null);
      setInlineEditState(null);
      setInlineActiveField(null);
    }

    setHolidayUpdateCounter((v) => v + 1);
    showToast(`Reverted ${formatDateReadable(dateStr)} to Holiday (${holidayReason}).`);
  };

  // Quick edit for holiday reason/name
  const handleEditHolidayReason = (dateStr: string, currentReason: string) => {
    const newReason = window.prompt(`Edit Holiday Name / Reason for ${formatDateReadable(dateStr)}:`, currentReason);
    if (newReason !== null && newReason.trim() !== '') {
      const trimmed = newReason.trim();
      const customMap = getStoredCustomHolidays();
      customMap[dateStr] = trimmed;
      saveStoredCustomHolidays(customMap);

      const existing = monthEntriesMap.get(dateStr);
      if (existing && onSaveEntry) {
        onSaveEntry({
          ...existing,
          remarks: trimmed,
          updatedAt: new Date().toISOString(),
        });
      }

      setHolidayUpdateCounter((v) => v + 1);
      showToast(`Updated holiday name to "${trimmed}".`);
    }
  };

  // Auto-Fill all working days of the month with a specific attendance percentage
  const handleBatchAutoFillMonth = (percent: number) => {
    setShowQuickFillMenu(false);
    const classStrengths = getStudentStrengthForMonth(selectedMonth);
    const pRoll = classStrengths
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.total, 0);
    const upRoll = classStrengths
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.total, 0);

    const targetPAtt = Math.round((pRoll * percent) / 100);
    const targetUpAtt = Math.round((upRoll * percent) / 100);
    const targetMeals = targetPAtt + targetUpAtt;

    let savedCount = 0;
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${selectedMonth}-${String(d).padStart(2, '0')}`;
      const dayInfo = getDayDetails(dateStr);
      if (!dayInfo.isSunday && !dayInfo.isHoliday) {
        const dayOfWeek = dayInfo.dayOfWeek;
        const rice = Number(((targetPAtt * 0.1) + (targetUpAtt * 0.15)).toFixed(2));
        const egg = (dayOfWeek >= 1 && dayOfWeek <= 5) ? targetMeals : 0;
        const chikki = (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5) ? targetMeals : 0;
        const ragi = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((targetMeals * 0.01).toFixed(2)) : 0;
        const jaggery = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((targetMeals * 0.01).toFixed(2)) : 0;

        const entry: DailyEntry = {
          id: `entry-${dateStr}`,
          date: dateStr,
          primaryAttendance: targetPAtt,
          upperPrimaryAttendance: targetUpAtt,
          highSchoolAttendance: 0,
          totalAttendance: targetMeals,
          mealsServed: targetMeals,
          riceUsedKg: rice,
          eggUsedQty: egg,
          chikkiUsedQty: chikki,
          ragiUsedKg: ragi,
          jaggeryUsedKg: jaggery,
          remarks: `Auto-filled at ${percent}% attendance`,
          isManual: true,
        };

        if (onSaveEntry) {
          onSaveEntry(entry);
          savedCount++;
        }
      }
    }
    showToast(`Updated ${savedCount} working days in ${selectedMonth} with ${percent}% attendance!`);
  };

  // Reset all custom daily entries for the month so it continuously auto-updates based on current enrolled strength
  const handleResetMonthToAuto = () => {
    if (confirm(`Reset all custom edited records for ${selectedMonth}? The official register will dynamically update day-by-day based on active student strength.`)) {
      dailyEntries
        .filter((e) => e.date.startsWith(selectedMonth))
        .forEach((e) => {
          if (onDeleteEntry) {
            onDeleteEntry(e.id);
          }
        });
      showToast(`Month ${selectedMonth} reset to continuous dynamic auto-calculation.`);
    }
  };

  // Calculate day-by-day stock map for all entries and transactions, continuous across all preceding months
  const dailyStockMap = calculateDailyCommodityStock(
    allSynthesizedEntries,
    stockTransactions,
    baseCommodities,
    monthlyOverrides,
    continuousMonths
  );

  // Month entries for calculations and displayed rows
  // Calculate data up to today only for the current/future months; past months show full month
  const entriesForCalculations = monthEntries.filter((e) => e.date <= todayStr);
  const displayedEntries = monthEntries;

  // Auto Calculations
  const workingDays = entriesForCalculations.filter((e) => (e.mealsServed || 0) > 0 && (e.totalAttendance || 0) > 0).length;

  let totalPrimaryAttendance = 0;
  let totalUpperPrimaryAttendance = 0;
  let totalAttendance = 0;
  let totalMealsServed = 0;
  let totalRiceUsed = 0;
  let totalEggUsed = 0;
  let totalChikkiUsed = 0;
  let totalRagiUsed = 0;
  let totalJaggeryUsed = 0;

  let totalRiceRec = 0;
  let totalEggRec = 0;
  let totalChikkiRec = 0;
  let totalRagiRec = 0;
  let totalJaggeryRec = 0;

  let totalRiceSpoils = 0;
  let totalEggSpoils = 0;
  let totalChikkiSpoils = 0;
  let totalRagiSpoils = 0;
  let totalJaggerySpoils = 0;

  // Helper to extract day attendance synced with class-wise attendance
  const getDayAttendanceMetrics = (e: DailyEntry) => {
    const dayPrimaryAtt = e.primaryAttendance || 0;
    const dayUpperPrimaryAtt = (e.upperPrimaryAttendance || 0) + (e.highSchoolAttendance || 0);
    const dayTotalAtt = dayPrimaryAtt + dayUpperPrimaryAtt;

    return { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt };
  };

  entriesForCalculations.forEach((e) => {
    const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
    totalPrimaryAttendance += dayPrimaryAtt;
    totalUpperPrimaryAttendance += dayUpperPrimaryAtt;
    totalAttendance += dayTotalAtt;
    totalMealsServed += e.mealsServed;
    totalRiceUsed += e.riceUsedKg;
    totalEggUsed += e.eggUsedQty;
    totalChikkiUsed += e.chikkiUsedQty;
    totalRagiUsed += e.ragiUsedKg;

    const dayStock = dailyStockMap[e.date];
    totalJaggeryUsed += (dayStock && dayStock.jaggery ? dayStock.jaggery.used : (e.ragiUsedKg || e.jaggeryUsedKg));

    if (dayStock) {
      totalRiceRec += dayStock.rice.rec;
      totalEggRec += dayStock.egg.rec;
      totalChikkiRec += dayStock.chikki.rec;
      totalRagiRec += dayStock.ragi.rec;
      totalJaggeryRec += dayStock.jaggery ? dayStock.jaggery.rec : dayStock.ragi.rec;

      totalRiceSpoils += dayStock.rice.spoiled;
      totalEggSpoils += dayStock.egg.spoiled;
      totalChikkiSpoils += dayStock.chikki.spoiled;
      totalRagiSpoils += dayStock.ragi.spoiled;
      totalJaggerySpoils += dayStock.jaggery ? dayStock.jaggery.spoiled : dayStock.ragi.spoiled;
    }
  });

  // Audit & Verification: Check Opening Balance automatically updates from previous month's total row closing balance
  const prevMonthDays = new Date(selYear, selMo - 1, 0).getDate();
  const prevMonthLastDateStr = `${prevMonthStr}-${String(prevMonthDays).padStart(2, '0')}`;
  let prevMonthLastWorkingDateStr = prevMonthLastDateStr;
  for (let d = prevMonthDays; d >= 1; d--) {
    const dStr = `${prevMonthStr}-${String(d).padStart(2, '0')}`;
    const dayInfo = getDayDetails(dStr);
    if (!dayInfo.isSunday && !dayInfo.isHoliday) {
      prevMonthLastWorkingDateStr = dStr;
      break;
    }
  }

  const prevMonthClosingStock = dailyStockMap[prevMonthLastDateStr] || dailyStockMap[prevMonthLastWorkingDateStr];

  const getBaseCommOB = (commId: string) => {
    const item = (baseCommodities || commodities || []).find((c) => c.id === commId);
    return item?.openingBalance ?? 0;
  };

  const prevRiceCB = prevMonthClosingStock ? prevMonthClosingStock.rice.cb : getBaseCommOB('rice');
  const prevEggCB = prevMonthClosingStock ? prevMonthClosingStock.egg.cb : getBaseCommOB('egg');
  const prevChikkiCB = prevMonthClosingStock ? prevMonthClosingStock.chikki.cb : getBaseCommOB('chikki');
  const prevRagiCB = prevMonthClosingStock ? prevMonthClosingStock.ragi.cb : getBaseCommOB('ragi');
  const prevJaggeryCB = prevMonthClosingStock && prevMonthClosingStock.jaggery ? prevMonthClosingStock.jaggery.cb : prevRagiCB;

  const monthFirstDayStr = `${selectedMonth}-01`;
  const daysInSelMonth = new Date(selYear, selMo, 0).getDate();
  const monthLastDayStr = `${selectedMonth}-${String(daysInSelMonth).padStart(2, '0')}`;

  const manualObMonths = getStoredManualObMonths();
  const isOverrideActiveOnSelectedMonth = Boolean(
    manualObMonths[selectedMonth] &&
    (monthlyOverrides[selectedMonth] || monthlyOverrides[`${selectedMonth}-01`])
  );

  const firstDayStock = dailyStockMap[monthFirstDayStr] || (monthEntries.length > 0 ? dailyStockMap[monthEntries[0].date] : null);
  if (!isOverrideActiveOnSelectedMonth && selectedMonth !== '2026-08' && firstDayStock) {
    firstDayStock.rice.ob = prevRiceCB;
    firstDayStock.rice.cb = safeRound3(prevRiceCB + firstDayStock.rice.rec - firstDayStock.rice.used - firstDayStock.rice.spoiled);
    firstDayStock.egg.ob = prevEggCB;
    firstDayStock.egg.cb = safeRound3(prevEggCB + firstDayStock.egg.rec - firstDayStock.egg.used - firstDayStock.egg.spoiled);
    firstDayStock.chikki.ob = prevChikkiCB;
    firstDayStock.chikki.cb = safeRound3(prevChikkiCB + firstDayStock.chikki.rec - firstDayStock.chikki.used - firstDayStock.chikki.spoiled);
    firstDayStock.ragi.ob = prevRagiCB;
    firstDayStock.ragi.cb = safeRound3(prevRagiCB + firstDayStock.ragi.rec - firstDayStock.ragi.used - firstDayStock.ragi.spoiled);
    if (firstDayStock.jaggery && firstDayStock.ragi) {
      firstDayStock.jaggery.ob = firstDayStock.ragi.ob;
      firstDayStock.jaggery.rec = firstDayStock.ragi.rec;
      firstDayStock.jaggery.used = firstDayStock.ragi.used;
      firstDayStock.jaggery.spoiled = firstDayStock.ragi.spoiled;
      firstDayStock.jaggery.cb = firstDayStock.ragi.cb;
    }
  }

  const monthStartRiceOB = (isOverrideActiveOnSelectedMonth || selectedMonth === '2026-08')
    ? (firstDayStock ? firstDayStock.rice.ob : prevRiceCB)
    : prevRiceCB;
  const monthStartEggOB = (isOverrideActiveOnSelectedMonth || selectedMonth === '2026-08')
    ? (firstDayStock ? firstDayStock.egg.ob : prevEggCB)
    : prevEggCB;
  const monthStartChikkiOB = (isOverrideActiveOnSelectedMonth || selectedMonth === '2026-08')
    ? (firstDayStock ? firstDayStock.chikki.ob : prevChikkiCB)
    : prevChikkiCB;
  const monthStartRagiOB = (isOverrideActiveOnSelectedMonth || selectedMonth === '2026-08')
    ? (firstDayStock ? firstDayStock.ragi.ob : prevRagiCB)
    : prevRagiCB;
  const monthStartJaggeryOB = monthStartRagiOB;

  // For current month, effective closing stock reflects data up to today only; for past months, the full month
  const latestDateForClosing = selectedMonth === currentMonthStr
    ? (entriesForCalculations.length > 0 ? entriesForCalculations[entriesForCalculations.length - 1].date : todayStr)
    : monthLastDayStr;
  const lastDayStock = dailyStockMap[latestDateForClosing] || (entriesForCalculations.length > 0 ? dailyStockMap[entriesForCalculations[entriesForCalculations.length - 1].date] : null) || dailyStockMap[monthLastDayStr];
  const effectiveClosingStock = lastDayStock;

  const monthEndRiceCB = effectiveClosingStock ? effectiveClosingStock.rice.cb : 0;
  const monthEndEggCB = effectiveClosingStock ? effectiveClosingStock.egg.cb : 0;
  const monthEndChikkiCB = effectiveClosingStock ? effectiveClosingStock.chikki.cb : 0;
  const monthEndRagiCB = effectiveClosingStock ? effectiveClosingStock.ragi.cb : 0;
  const monthEndJaggeryCB = effectiveClosingStock && effectiveClosingStock.jaggery ? effectiveClosingStock.jaggery.cb : monthEndRagiCB;

  // Identify the first working day of the current selected month
  const firstWorkingDayEntry = monthEntries.find((e) => {
    const dayInfo = getDayDetails(e.date);
    return !dayInfo.isSunday && !dayInfo.isHoliday;
  }) || monthEntries[0];
  const firstWorkingDayDateStr = firstWorkingDayEntry?.date || `${selectedMonth}-01`;

  const firstWorkingDayStock = dailyStockMap[firstWorkingDayDateStr];
  const firstWorkingRiceOB = firstWorkingDayStock ? firstWorkingDayStock.rice.ob : monthStartRiceOB;
  const firstWorkingEggOB = firstWorkingDayStock ? firstWorkingDayStock.egg.ob : monthStartEggOB;
  const firstWorkingChikkiOB = firstWorkingDayStock ? firstWorkingDayStock.chikki.ob : monthStartChikkiOB;
  const firstWorkingRagiOB = firstWorkingDayStock ? firstWorkingDayStock.ragi.ob : monthStartRagiOB;
  const firstWorkingJaggeryOB = firstWorkingDayStock ? firstWorkingDayStock.jaggery.ob : monthStartJaggeryOB;

  const isRiceSynced = Math.abs(monthStartRiceOB - prevRiceCB) < 0.001;
  const isEggSynced = Math.abs(monthStartEggOB - prevEggCB) < 0.001;
  const isChikkiSynced = Math.abs(monthStartChikkiOB - prevChikkiCB) < 0.001;
  const isRagiSynced = Math.abs(monthStartRagiOB - prevRagiCB) < 0.001;
  const isJaggerySynced = Math.abs(monthStartJaggeryOB - prevJaggeryCB) < 0.001;

  const allCommoditiesAutoFollow = isRiceSynced && isEggSynced && isChikkiSynced && isRagiSynced && isJaggerySynced;
  const allCommoditiesSynced = allCommoditiesAutoFollow || isOverrideActiveOnSelectedMonth;

  // Automatically carry forward present month commodities OB from previous month's total row closing balance
  const hasPriorMonthInContinuous = continuousMonths.length > 1 && continuousMonths.indexOf(selectedMonth) > 0;

  const handleAutoSyncObWithLastMonth = () => {
    saveStoredManualObMonth(selectedMonth, false);
    if (onResetMonthlyOverride) {
      onResetMonthlyOverride(selectedMonth);
      onResetMonthlyOverride(`${selectedMonth}-01`);
    }
    const cleanOverrides = { ...monthlyOverrides };
    delete cleanOverrides[selectedMonth];
    delete cleanOverrides[`${selectedMonth}-01`];
    Object.keys(cleanOverrides).forEach((k) => {
      if (k.startsWith(`${selectedMonth}-`)) {
        delete cleanOverrides[k];
      }
    });
    saveStoredMonthlyCommodityBalances(cleanOverrides);
    showToast(`✓ Opening Balances for ${currMonthLabel} automatically synced from ${prevMonthLabel} Total Row Closing Balance!`);
  };

  // Helper to compute daily cooking cost / expenditure
  const calculateDayCookingCost = (e: DailyEntry) => {
    if (!e.mealsServed || e.mealsServed === 0) return 0;
    if (typeof e.customCookingCost === 'number') {
      return e.customCookingCost;
    }
    const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
    const priRate = e.primaryRatePerMeal ?? mealRates.primaryRatePerMeal ?? 5.45;
    const upRate = e.upperPrimaryRatePerMeal ?? mealRates.upperPrimaryRatePerMeal ?? 8.17;
    const cch = e.cchCost || 0;
    const other = e.otherCost || 0;

    if (dayTotalAtt > 0) {
      const scale = e.mealsServed / dayTotalAtt;
      return Number((((dayPrimaryAtt * scale) * priRate) + ((dayUpperPrimaryAtt * scale) * upRate) + cch + other).toFixed(2));
    } else {
      return Number(((e.mealsServed * priRate) + cch + other).toFixed(2));
    }
  };

  let primaryCost = 0;
  let upperPrimaryCost = 0;
  let customExtraCost = 0;
  entriesForCalculations.forEach((e) => {
    if (e.mealsServed && e.mealsServed > 0) {
      const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
      const priRate = e.primaryRatePerMeal ?? mealRates.primaryRatePerMeal ?? 5.45;
      const upRate = e.upperPrimaryRatePerMeal ?? mealRates.upperPrimaryRatePerMeal ?? 8.17;

      if (typeof e.customCookingCost === 'number') {
        if (dayTotalAtt > 0) {
          primaryCost += e.customCookingCost * (dayPrimaryAtt / dayTotalAtt);
          upperPrimaryCost += e.customCookingCost * (dayUpperPrimaryAtt / dayTotalAtt);
        } else {
          primaryCost += e.customCookingCost;
        }
      } else {
        if (dayTotalAtt > 0) {
          const scale = e.mealsServed / dayTotalAtt;
          primaryCost += (dayPrimaryAtt * scale) * priRate;
          upperPrimaryCost += (dayUpperPrimaryAtt * scale) * upRate;
        } else {
          primaryCost += e.mealsServed * priRate;
        }
        if (e.cchCost) customExtraCost += e.cchCost;
        if (e.otherCost) customExtraCost += e.otherCost;
      }
    }
  });
  primaryCost = Number(primaryCost.toFixed(2));
  upperPrimaryCost = Number(upperPrimaryCost.toFixed(2));
  const totalCookingCost = Number((primaryCost + upperPrimaryCost + customExtraCost).toFixed(2));
  const eggCost = totalEggUsed * (mealRates.eggRate ?? 6.00);
  const chikkiCost = totalChikkiUsed * (mealRates.chikkiRate ?? 5.00);
  const ragiCost = totalRagiUsed * (mealRates.ragiRatePerKg ?? 35.00);
  const jaggeryCost = totalJaggeryUsed * (mealRates.jaggeryRatePerKg ?? 60.00);

  const grandTotalAmount = totalCookingCost;

  const amountInWordsStr = numToWords(grandTotalAmount);

  const activeStudentStrengths = getStudentStrengthForMonth(selectedMonth);

  let primaryEnrolled = 0;
  let upperPrimaryEnrolled = 0;

  activeStudentStrengths.forEach((s) => {
    if (s.category === 'Primary' || (s.classLevel && s.classLevel.match(/class\s*[1-5]/i))) {
      primaryEnrolled += s.total;
    } else {
      upperPrimaryEnrolled += s.total;
    }
  });

  if (primaryEnrolled === 0 && upperPrimaryEnrolled === 0) {
    primaryEnrolled = 170;
    upperPrimaryEnrolled = 136;
  }

  const totalEnrolled = primaryEnrolled + upperPrimaryEnrolled;

  const overallPrimaryAttPercent = (primaryEnrolled > 0 && workingDays > 0) ? ((totalPrimaryAttendance / (primaryEnrolled * workingDays)) * 100).toFixed(1) + '%' : '0.0%';
  const overallUpperPrimaryAttPercent = (upperPrimaryEnrolled > 0 && workingDays > 0) ? ((totalUpperPrimaryAttendance / (upperPrimaryEnrolled * workingDays)) * 100).toFixed(1) + '%' : '0.0%';
  const overallTotalAttPercent = (totalEnrolled > 0 && workingDays > 0) ? ((totalAttendance / (totalEnrolled * workingDays)) * 100).toFixed(1) + '%' : '0.0%';

  const monthLabel = new Date(`${selectedMonth}-01`).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  // Export CSV
  const handleExportCSV = () => {
    let csv = `Date,Day,Roll Primary,Roll Upper Primary,Total Roll,Primary Attn,Upper Primary Attn,Total Attn,Meals Served,Expenditure / Day (₹),Rice OB (Kg),Rice Rec (Kg),Rice Used (Kg),Rice Spoils (Kg),Rice Balance (Kg),Egg OB (Pcs),Egg Rec (Pcs),Egg Used (Pcs),Egg Spoils (Pcs),Egg Balance (Pcs),Chikki OB (Pcs),Chikki Rec (Pcs),Chikki Used (Pcs),Chikki Spoils (Pcs),Chikki Balance (Pcs),Ragi OB (Kg),Ragi Rec (Kg),Ragi Used (Kg),Ragi Spoils (Kg),Ragi Balance (Kg),Jaggery OB (Kg),Jaggery Rec (Kg),Jaggery Used (Kg),Jaggery Spoils (Kg),Jaggery Balance (Kg),Remarks\n`;
    displayedEntries.forEach((e, idx) => {
      const dayInfo = getDayDetails(e.date);
      const stock = dailyStockMap[e.date] || {
        rice: { ob: 0, rec: 0, used: e.riceUsedKg, spoiled: 0, cb: 0 },
        egg: { ob: 0, rec: 0, used: e.eggUsedQty, spoiled: 0, cb: 0 },
        chikki: { ob: 0, rec: 0, used: e.chikkiUsedQty, spoiled: 0, cb: 0 },
        ragi: { ob: 0, rec: 0, used: e.ragiUsedKg, spoiled: 0, cb: 0 },
        jaggery: { ob: 0, rec: 0, used: e.ragiUsedKg || e.jaggeryUsedKg, spoiled: 0, cb: 0 },
      };

      // If day 1 and not custom saved override, ensure OB strictly follows previous month total row closing balance
      const isDayOneCsv = idx === 0 || e.date.endsWith('-01');
      if (isDayOneCsv && !isOverrideActiveOnSelectedMonth && selectedMonth !== '2026-08' && stock) {
        if (stock.rice) {
          stock.rice.ob = prevRiceCB;
          stock.rice.cb = safeRound3(prevRiceCB + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
        }
        if (stock.egg) {
          stock.egg.ob = prevEggCB;
          stock.egg.cb = safeRound3(prevEggCB + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
        }
        if (stock.chikki) {
          stock.chikki.ob = prevChikkiCB;
          stock.chikki.cb = safeRound3(prevChikkiCB + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
        }
        if (stock.ragi) {
          stock.ragi.ob = prevRagiCB;
          stock.ragi.cb = safeRound3(prevRagiCB + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
        }
        if (stock.jaggery && stock.ragi) {
          stock.jaggery.ob = stock.ragi.ob;
          stock.jaggery.rec = stock.ragi.rec;
          stock.jaggery.used = stock.ragi.used;
          stock.jaggery.spoiled = stock.ragi.spoiled;
          stock.jaggery.cb = stock.ragi.cb;
        }
      }

      // In month-end row (or 31 row): balance = ob + recieve - used - spoils for rice, egg, chikki, ragi, jaggery
      const isMonthEndRowCsv = idx + 1 === daysInSelMonth || e.date.endsWith('-31') || e.date.endsWith(`-${String(daysInSelMonth).padStart(2, '0')}`);
      if (isMonthEndRowCsv && stock) {
        if (stock.rice) stock.rice.cb = safeRound3(stock.rice.ob + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
        if (stock.egg) stock.egg.cb = safeRound3(stock.egg.ob + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
        if (stock.chikki) stock.chikki.cb = safeRound3(stock.chikki.ob + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
        if (stock.ragi) stock.ragi.cb = safeRound3(stock.ragi.ob + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
        if (stock.jaggery && stock.ragi) {
          stock.jaggery.ob = stock.ragi.ob;
          stock.jaggery.rec = stock.ragi.rec;
          stock.jaggery.used = stock.ragi.used;
          stock.jaggery.spoiled = stock.ragi.spoiled;
          stock.jaggery.cb = stock.ragi.cb;
        }
      }
      const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
      const dayCookingCost = calculateDayCookingCost(e);

      const rOB = e.mealsServed > 0 ? stock.rice.ob : '-';
      const rCB = e.mealsServed > 0 ? stock.rice.cb : '-';
      const eOB = e.mealsServed > 0 ? stock.egg.ob : '-';
      const eCB = e.mealsServed > 0 ? stock.egg.cb : '-';
      const cOB = e.mealsServed > 0 ? stock.chikki.ob : '-';
      const cCB = e.mealsServed > 0 ? stock.chikki.cb : '-';
      const rgOB = e.mealsServed > 0 ? stock.ragi.ob : '-';
      const rgCB = e.mealsServed > 0 ? stock.ragi.cb : '-';
      const jOB = e.mealsServed > 0 ? stock.jaggery.ob : '-';
      const jCB = e.mealsServed > 0 ? stock.jaggery.cb : '-';
      const jUsedVal = e.mealsServed > 0 ? (stock.jaggery.used || e.ragiUsedKg || e.jaggeryUsedKg) : 0;

      const dayStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(e.date) : [];
      let dayPrimaryEnrolled = 0;
      let dayUpperPrimaryEnrolled = 0;
      dayStrengths.forEach((s) => {
        if (s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i))) {
          dayPrimaryEnrolled += s.total;
        } else {
          dayUpperPrimaryEnrolled += s.total;
        }
      });
      if (dayPrimaryEnrolled === 0 && dayUpperPrimaryEnrolled === 0) {
        dayPrimaryEnrolled = 170;
        dayUpperPrimaryEnrolled = 130;
      }
      const dayTotalEnrolled = dayPrimaryEnrolled + dayUpperPrimaryEnrolled;

      csv += `"${e.date}","${dayInfo.dayName}",${dayPrimaryEnrolled},${dayUpperPrimaryEnrolled},${dayTotalEnrolled},${dayPrimaryAtt},${dayUpperPrimaryAtt},${dayTotalAtt},${e.mealsServed},${dayCookingCost},${rOB},${stock.rice.rec},${e.riceUsedKg},${stock.rice.spoiled},${rCB},${eOB},${stock.egg.rec},${e.eggUsedQty},${stock.egg.spoiled},${eCB},${cOB},${stock.chikki.rec},${e.chikkiUsedQty},${stock.chikki.spoiled},${cCB},${rgOB},${stock.ragi.rec},${e.ragiUsedKg},${stock.ragi.spoiled},${rgCB},${jOB},${stock.jaggery.rec},${jUsedVal},${stock.jaggery.spoiled},${jCB},"${e.remarks || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MDM_Monthly_Register_${selectedMonth}.csv`;
    a.click();
  };

  return (
    <div className="space-y-2 sm:space-y-2.5 pb-14 sm:pb-16 md:pb-20 lg:pb-24">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900/95 text-white px-4 py-3 rounded-xl shadow-2xl border border-purple-500/40 flex items-center gap-2.5 animate-in slide-in-from-top-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}        {/* Official Government Printable Register Table */}
        <div
          id="printable-monthly-register"
          className={`w-full register-glass-canvas register-theme-${registerBgTheme} ${freezeRow ? 'freeze-row' : ''} backdrop-blur-xl rounded-2xl border border-white/85 dark:border-slate-800/85 shadow-2xl overflow-hidden transition-all duration-300`}
        >
        {/* Printable Official Header (Visible on print) */}
        <div className="hidden print:block official-print-header p-2 sm:p-4 border-b-2 border-slate-900 font-sans text-slate-900">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[11px] sm:text-xs font-black uppercase tracking-wider">
                SCHOOL EDUCATION DEPARTMENT
              </h1>
              <h2 className="text-xs sm:text-sm font-black text-purple-950 uppercase mt-0.5">
                MID DAY MEAL (MDM) / PM-POSHAN MONTHLY CONSOLIDATED REGISTER
              </h2>
              <p className="text-[9.5px] sm:text-[10px] font-bold text-slate-700 mt-0.5">
                School: <span className="font-extrabold">{schoolProfile.schoolName}</span> | UDISE Code: <span className="font-extrabold">{schoolProfile.udiseCode}</span> | Month: <span className="font-extrabold">{monthLabel}</span>
              </p>
            </div>
            <div className="text-right text-[8.5px] sm:text-[9.5px] font-semibold border-l border-slate-400 pl-3">
              <div>Working Days: <strong>{workingDays} Days</strong></div>
              <div>Attendance: <strong>{totalAttendance}</strong> | Served: <strong>{totalMealsServed}</strong></div>
              <div>Meals Not Served: <strong className="text-rose-700">{Math.max(0, totalAttendance - totalMealsServed)}</strong></div>
              <div>Total Expenditure: <strong>{formatCurrency(grandTotalAmount)}</strong></div>
            </div>
          </div>
        </div>

        {/* Responsive Monthly Summary Tiles (User Friendly KPI Cards - with Hide Option) */}
        {showSummaryCards && (
          <div
            className="p-1 sm:p-1.5 md:p-2.5 border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-800/40 no-print transition-all duration-300"
          >
            <div
              style={{ lineHeight: '25.560001px' }}
              className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-1 sm:gap-1.5 md:gap-2"
            >
              {/* Tile 1: Working Days */}
              <div
                style={{ height: '28px', lineHeight: '3.5600009999999997px', width: '128.125px', marginLeft: '6px' }}
                className="glass-3d-tile p-1 sm:p-1.5 md:p-2 rounded-sm sm:rounded-lg md:rounded-xl border border-slate-200/90 dark:border-slate-700/80 flex items-center space-x-1.5 sm:space-x-2 shadow-2xs"
              >
                <div className="w-5 h-5 sm:w-6.5 sm:h-6.5 md:w-8 md:h-8 rounded-xs sm:rounded-md md:rounded-lg bg-blue-500/15 text-blue-700 dark:text-blue-300 flex items-center justify-center shrink-0">
                  <Calendar className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </div>
                <div style={{ lineHeight: '-3.439999px' }} className="min-w-0 flex-1">
                  <span style={{ marginRight: '-6px', marginLeft: '-3px', marginTop: '2px', fontSize: '9.280001px' }} className="text-[7px] sm:text-[8.5px] md:text-xs text-slate-500 dark:text-slate-400 font-semibold block leading-tight truncate">Working Days</span>
                  <span style={{ fontSize: '11.16px', paddingTop: '0px' }} className="text-[8.5px] sm:text-[10.5px] md:text-sm font-black text-slate-900 dark:text-white leading-tight">{workingDays} Days</span>
                </div>
              </div>

              {/* Tile 3: Total Cooking Cost - Brought after Working Days */}
              <div
                style={{ height: '29px', lineHeight: '12.560001px', width: '149.125px', marginLeft: '-2px' }}
                className="glass-3d-tile p-1 sm:p-1.5 md:p-2 rounded-sm sm:rounded-lg md:rounded-xl border border-slate-200/90 dark:border-slate-700/80 flex items-center space-x-1.5 sm:space-x-2 shadow-2xs"
              >
                <div className="w-5 h-5 sm:w-6.5 sm:h-6.5 md:w-8 md:h-8 rounded-xs sm:rounded-md md:rounded-lg bg-purple-500/15 text-purple-700 dark:text-purple-300 flex items-center justify-center shrink-0">
                  <IndianRupee className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </div>
                <div style={{ lineHeight: '-1.439999px' }} className="min-w-0 flex-1">
                  <span style={{ fontSize: '10.280001px', marginTop: '-1px' }} className="text-[7px] sm:text-[8.5px] md:text-xs text-slate-500 dark:text-slate-400 font-semibold block leading-tight truncate">Cooking Cost</span>
                  <span style={{ fontSize: '11.16px', paddingLeft: '0px', paddingTop: '-3px', paddingRight: '22px', marginLeft: '0px', marginTop: '9px' }} className="text-[8.5px] sm:text-[10.5px] md:text-sm font-black text-purple-900 dark:text-purple-200 leading-tight truncate">{formatCurrency(grandTotalAmount)}</span>
                </div>
              </div>

              {/* Tile 2: Meals Served */}
              <div
                style={{ height: '31px', lineHeight: '5.560001px', width: '140.125px', marginLeft: '-2px', paddingTop: '6.52px' }}
                className="glass-3d-tile p-1 sm:p-1.5 md:p-2 rounded-sm sm:rounded-lg md:rounded-xl border border-slate-200/90 dark:border-slate-700/80 flex items-center space-x-1.5 sm:space-x-2 shadow-2xs"
              >
                <div className="w-5 h-5 sm:w-6.5 sm:h-6.5 md:w-8 md:h-8 rounded-xs sm:rounded-md md:rounded-lg bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                  <Users className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </div>
                <div style={{ lineHeight: '0.5600010000000002px' }} className="min-w-0 flex-1">
                  <span style={{ fontSize: '9.280001px' }} className="text-[7px] sm:text-[8.5px] md:text-xs text-slate-500 dark:text-slate-400 font-semibold block leading-tight truncate">Meals / Attn</span>
                  <span style={{ fontSize: '11.16px' }} className="text-[8.5px] sm:text-[10.5px] md:text-sm font-black text-slate-900 dark:text-white leading-tight truncate">
                    {totalMealsServed} <span className="text-[7px] sm:text-[8px] md:text-[10px] font-bold text-slate-500 dark:text-slate-400">/ {totalAttendance}</span>
                  </span>
                </div>
              </div>

              {/* Tile 4: Stock Balances Highlights */}
              <div
                style={{ height: '30.796875px', lineHeight: '3.5600009999999997px', fontSize: '15.040001px', width: '168.125px', marginLeft: '-15px' }}
                className="glass-3d-tile p-1 sm:p-1.5 md:p-2 rounded-sm sm:rounded-lg md:rounded-xl border border-slate-200/90 dark:border-slate-700/80 flex items-center space-x-1.5 sm:space-x-2 shadow-2xs"
              >
                <div className="w-5 h-5 sm:w-6.5 sm:h-6.5 md:w-8 md:h-8 rounded-xs sm:rounded-md md:rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                  <Package className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <span style={{ fontSize: '9.280001px' }} className="text-[7px] sm:text-[8.5px] md:text-xs text-slate-500 dark:text-slate-400 font-semibold block leading-tight truncate">Month End Stock</span>
                  <span style={{ fontSize: '10.280001px' }} className="text-[8px] sm:text-[9.5px] md:text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight block truncate">
                    R: <strong className="font-extrabold text-amber-900 dark:text-amber-200">{formatQtyVal(monthEndRiceCB)}k</strong> | E: <strong style={{ fontSize: '11.280001px' }} className="font-extrabold text-amber-900 dark:text-amber-200">{formatQtyVal(monthEndEggCB)}</strong>
                  </span>
                </div>
              </div>

              {/* Tile 5: Opening Balances / Cascade Status */}
              <div
                onClick={() => setShowObCheckModal(true)}
                style={{ minHeight: '40.796875px', height: 'auto', lineHeight: 'normal' }}
                className="glass-3d-tile p-1 sm:p-1.5 md:p-2 rounded-sm sm:rounded-lg md:rounded-xl border border-slate-200/90 dark:border-slate-700/80 flex items-center space-x-1.5 sm:space-x-2 shadow-2xs cursor-pointer hover:scale-[1.01] active:scale-98 transition-all col-span-2 sm:col-span-4 lg:col-span-1 w-full max-w-full"
                title={`Opening Balance automatically carried forward from ${prevMonthLabel} Total Row Closing Balance (Rice: ${formatQtyVal(prevRiceCB)} Kg, Egg: ${formatQtyVal(prevEggCB)}, Chikki: ${formatQtyVal(prevChikkiCB)}, Ragi: ${formatQtyVal(prevRagiCB)} Kg, Jaggery: ${formatQtyVal(prevJaggeryCB)} Kg). Click to view continuous Opening Balances cascade.`}
              >
                <div className={`w-5 h-5 sm:w-6.5 sm:h-6.5 md:w-8 md:h-8 rounded-xs sm:rounded-md md:rounded-lg flex items-center justify-center shrink-0 ${allCommoditiesSynced ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300' : 'bg-amber-500/15 text-amber-700 dark:text-amber-300'}`}>
                  {allCommoditiesSynced ? <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" /> : <AlertTriangle className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />}
                </div>
                <div style={{ minHeight: '38px', height: 'auto' }} className="min-w-0 flex-1 w-full">
                  <span
                    style={{ fontSize: '9.280001px', color: allCommoditiesSynced ? '#047857' : '#b45309', lineHeight: '11px', marginTop: '1px', marginBottom: '1px', marginLeft: '0px', marginRight: '0px', textAlign: 'left', whiteSpace: 'normal', overflowWrap: 'break-word' }}
                    className="text-[7px] sm:text-[8.5px] md:text-xs font-semibold block leading-tight whitespace-normal break-words line-clamp-1 w-full"
                    title={`Opening Balance auto-carried forward from ${prevMonthLabel} Total Row Closing Balance.`}
                  >
                    {isOverrideActiveOnSelectedMonth
                      ? `Custom Saved OB (${currMonthLabel})`
                      : allCommoditiesSynced
                      ? `Auto-carried from ${prevMonthLabel} Total Row Closing Balance`
                      : `Auto-syncing Opening Balance from ${prevMonthLabel} Closing Balance...`}
                  </span>
                  <span
                    style={{ fontSize: '7.8px', lineHeight: '9.5px', paddingTop: '0px', paddingLeft: '0px', paddingBottom: '0px', paddingRight: '0px', marginBottom: '0px', marginRight: '0px', whiteSpace: 'normal', overflowWrap: 'break-word' }}
                    className={`font-bold leading-tight block ${allCommoditiesSynced ? 'text-emerald-700 dark:text-emerald-300' : 'text-amber-700 dark:text-amber-300'}`}
                    title="NOTE !… Auto Synchronise OB where isn’t after Holiday(s) Change once holiday(s) as WORKING DAY then change back WORKING DAY, It will be DONE."
                  >
                    NOTE !… Auto Synchronise OB where isn’t after Holiday(s) Change once holiday(s) as WORKING DAY then change back WORKING DAY, It will be DONE.
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Screen Interactive Register Toolbar (with Hide Option) */}
        {showToolbar ? (
          <div className="toolbar-3d-glass p-1 sm:p-1.5 md:p-2 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-1 sm:gap-1.5 md:gap-2 no-print w-full transition-all">
            {/* Left: Month Selection */}
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5 shrink-0">
              <div
                style={{ height: '30px', minHeight: '30px', maxHeight: '30px', width: '150px', minWidth: '150px', marginTop: '-11px', padding: '0px 10px', borderRadius: '8px' }}
                className="flex items-center space-x-1.5 btn-glass-month-input shrink-0"
                title="Select Month for Register"
              >
                <Calendar className="text-blue-900 dark:text-blue-200 shrink-0" style={{ width: '18px', height: '18px', minWidth: '18px', minHeight: '18px' }} />
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  style={{
                    fontSize: '13.5px',
                    marginLeft: '-11px',
                    marginRight: '0px',
                    marginTop: '0px',
                    marginBottom: '2px',
                    paddingTop: '5px',
                    paddingBottom: '1px',
                    paddingLeft: '0px',
                    paddingRight: '-5px',
                    width: '111.875px',
                    height: '26px',
                  }}
                  className="bg-transparent border-none text-blue-950 dark:text-blue-50 font-bold focus:outline-hidden cursor-pointer"
                  title="Select Month for Register"
                />
              </div>
            </div>

            {/* Right: All Responsive Action Buttons (50% Decreased) */}
            <div className="flex flex-wrap items-center gap-0.5 sm:gap-1 md:gap-1.5 w-full md:w-auto">
              {/* Cash Voucher Button */}
              <button
                type="button"
                style={{ height: '22.90625px' }}
                onClick={() => onNavigate('cash-voucher')}
                className="btn-3d-glass-emerald flex items-center justify-center space-x-0.5 px-1 sm:px-1.5 md:px-2 py-0 rounded-sm sm:rounded-md font-bold shrink-0 cursor-pointer whitespace-nowrap active:scale-95"
                title="Open Official Mid-Day Meal Cash Voucher"
              >
                <IndianRupee className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 text-emerald-800 dark:text-emerald-200 shrink-0" />
                <span style={{ fontSize: '10.5px' }}>Cash Voucher</span>
              </button>

              {/* Reports Button */}
              <button
                type="button"
                style={{ height: '22px' }}
                onClick={() => onNavigate('reports')}
                className="btn-3d-glass-blue flex items-center justify-center space-x-0.5 px-1 sm:px-1.5 md:px-2 py-0 rounded-sm sm:rounded-md font-bold shrink-0 cursor-pointer whitespace-nowrap active:scale-95"
                title="Open Official MDM Reports & Analytics"
              >
                <FileText className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 text-blue-800 dark:text-blue-200 shrink-0" />
                <span style={{ fontSize: '10.5px' }}>Reports</span>
              </button>


              {/* Freeze on Row Toggle - Brought after Print button */}
              <button
                type="button"
                onClick={toggleFreezeRow}
                style={{ height: '23.671875px' }}
                className={`flex items-center justify-center px-1 sm:px-1.5 md:px-2 py-0 rounded-sm sm:rounded-md text-[6.5px] sm:text-[7.5px] md:text-[9.5px] font-bold shrink-0 cursor-pointer whitespace-nowrap active:scale-95 transition-all shadow-xs h-4.5 sm:h-5 md:h-5.5 ${
                  freezeRow
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border border-amber-600 shadow-amber-500/20'
                    : 'bg-slate-200/90 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600'
                }`}
                title={freezeRow ? 'Freeze on Row is ON (Click to turn OFF)' : 'Freeze on Row is OFF (Click to turn ON)'}
              >
                <span>Freeze Row: <strong className="uppercase">{freezeRow ? 'ON' : 'OFF'}</strong></span>
              </button>

              {/* Data Font Size Toggle - Placed directly after Print button */}
              <div
                style={{ height: '23.671875px' }}
                className="flex items-center space-x-0.5 px-1 sm:px-1.5 py-0 rounded-sm sm:rounded-md bg-slate-200/90 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-[6.5px] sm:text-[7.5px] md:text-[9.5px] font-bold shrink-0 shadow-xs h-4.5 sm:h-5 md:h-5.5"
                title="Adjust Data Font Size"
              >
                <span className="text-slate-600 dark:text-slate-300 mr-0.5">Font:</span>
                <button
                  type="button"
                  onClick={() => handleSelectTableDataFontSize('standard')}
                  className={`px-1 py-0.2 rounded font-black cursor-pointer transition-all ${
                    tableDataFontSize === 'standard'
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                  }`}
                  title="Standard Font Size (15px)"
                >
                  A
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectTableDataFontSize('large')}
                  className={`px-1 py-0.2 rounded font-black cursor-pointer transition-all ${
                    tableDataFontSize === 'large'
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                  }`}
                  title="Large Font Size (17px - Default)"
                >
                  A+
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectTableDataFontSize('xlarge')}
                  className={`px-1 py-0.2 rounded font-black cursor-pointer transition-all ${
                    tableDataFontSize === 'xlarge'
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                  }`}
                  title="Extra Large Font Size (19.5px)"
                >
                  A++
                </button>
              </div>

              {/* Toggle Summary Cards (Option to Hide / Show) */}
              <button
                type="button"
                onClick={toggleSummaryCards}
                style={{ height: '23.671875px' }}
                className={`flex items-center justify-center space-x-0.5 sm:space-x-1 px-1 sm:px-1.5 md:px-2 py-0 rounded-sm sm:rounded-md text-[6.5px] sm:text-[7.5px] md:text-[9.5px] font-bold shrink-0 cursor-pointer whitespace-nowrap active:scale-95 transition-all shadow-xs h-4.5 sm:h-5 md:h-5.5 ${
                  !showSummaryCards
                    ? 'bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-600 shadow-sky-500/20'
                    : 'bg-slate-200/90 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600'
                }`}
                title={showSummaryCards ? 'Click to hide Summary Cards' : 'Click to show Summary Cards'}
              >
                {showSummaryCards ? (
                  <>
                    <EyeOff className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 text-slate-600 dark:text-slate-300 shrink-0" />
                    <span>Summary: <strong>Hide</strong></span>
                  </>
                ) : (
                  <>
                    <Eye className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 text-white shrink-0" />
                    <span>Summary: <strong>Show</strong></span>
                  </>
                )}
              </button>

              {/* Option to Hide Toolbar */}
              <button
                type="button"
                onClick={toggleToolbar}
                style={{ height: '23.671875px' }}
                className="bg-slate-200/90 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 flex items-center justify-center space-x-0.5 px-1 sm:px-1.5 md:px-2 py-0 rounded-sm sm:rounded-md text-[6.5px] sm:text-[7.5px] md:text-[9.5px] font-bold shrink-0 cursor-pointer whitespace-nowrap active:scale-95 shadow-xs h-4.5 sm:h-5 md:h-5.5 transition-all"
                title="Hide Toolbar to maximize table view"
              >
                <EyeOff className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 text-slate-500 dark:text-slate-400 shrink-0" />
                <span>Hide Bar</span>
              </button>
            </div>
          </div>
        ) : (
          /* Compact Minimal Bar when Toolbar is Hidden */
          <div className="flex items-center justify-between px-2 sm:px-3 py-1 bg-slate-100/95 dark:bg-slate-800/95 border-b border-slate-200/80 dark:border-slate-700/80 text-[10px] sm:text-[11px] no-print transition-all">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-extrabold text-slate-700 dark:text-slate-200 uppercase tracking-wide text-[8.5px] sm:text-[10px]">
                Month: <strong className="text-blue-600 dark:text-blue-400">{monthLabel}</strong>
              </span>
              <span className="text-[7.5px] sm:text-[8.5px] text-slate-400 dark:text-slate-500 hidden xs:inline">
                • Toolbar hidden for maximum table height
              </span>
            </div>
            <button
              type="button"
              onClick={toggleToolbar}
              style={{ width: '100.796875px', height: '13.140625px', fontSize: '8px' }}
              className="flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded font-extrabold bg-sky-600 hover:bg-sky-700 text-white text-[8px] shadow-xs cursor-pointer active:scale-95 transition-all"
              title="Click to restore full interactive toolbar"
            >
              <Eye className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
              <span>Show Toolbar</span>
            </button>
          </div>
        )}

        <div
          className={`${
            freezeRow
              ? (!showSummaryCards && !showToolbar)
                ? 'max-h-[calc(100vh-105px)] overflow-y-auto'
                : !showSummaryCards || !showToolbar
                ? 'max-h-[calc(100vh-155px)] overflow-y-auto'
                : 'max-h-[calc(100vh-210px)] overflow-y-auto'
              : ''
          } overflow-x-auto scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-600 print:max-h-none print:overflow-visible`}
          onScroll={(e) => setIsTableScrolledX(e.currentTarget.scrollLeft > 10)}
        >
          <table className={`w-full text-left border-collapse table-data-font-${tableDataFontSize} text-[15px] sm:text-[16.5px] md:text-[18px]`}>
            <thead className={freezeRow ? 'sticky top-0 z-30 shadow-md backdrop-blur-md' : ''}>
              <tr className="glass-header-ribbon font-extrabold border-b border-sky-300/60 dark:border-sky-700/60 text-[15px] sm:text-[16px] md:text-[17px] uppercase tracking-wider">
                <th
                  rowSpan={2}
                  style={{
                    width: isTableScrolledX ? '40px' : '36px',
                    ...(freezeLeft ? { left: 0 } : {}),
                  }}
                  className={`${
                    freezeLeft
                      ? 'sticky left-0 z-30 bg-sky-100/95 dark:bg-slate-800/95 text-sky-950 dark:text-sky-100 backdrop-blur-md'
                      : 'bg-sky-100/90 dark:bg-slate-800/90 text-sky-950 dark:text-sky-100'
                  } border-r border-sky-200/80 dark:border-slate-700 text-center transition-all duration-300 ease-in-out ${
                    isTableScrolledX
                      ? 'px-0.5 py-1 text-[12px] min-w-[40px] max-w-[40px] font-black'
                      : 'px-1 py-1.5 text-[14.5px] min-w-[36px] max-w-[36px] font-extrabold'
                  }`}
                  title={isTableScrolledX ? 'Date' : 'Serial Number'}
                >
                  {isTableScrolledX ? 'Date' : 'S.No'}
                </th>
                <th
                  rowSpan={2}
                  style={{
                    width: isTableScrolledX ? '0px' : '72px',
                    ...(freezeLeft ? { left: isTableScrolledX ? '40px' : '36px' } : {}),
                    display: isTableScrolledX ? 'none' : undefined,
                  }}
                  className={`${isTableScrolledX ? 'hidden' : ''} ${
                    freezeLeft
                      ? 'sticky z-30 bg-sky-100/95 dark:bg-slate-800/95 text-sky-950 dark:text-sky-100 backdrop-blur-md'
                      : 'bg-sky-100/90 dark:bg-slate-800/90 text-sky-950 dark:text-sky-100'
                  } border-r border-sky-200/80 dark:border-slate-700 text-center whitespace-nowrap transition-all duration-300 ease-in-out px-1 py-1 text-[12px] min-w-[62px] max-w-[68px] font-extrabold`}
                  title="Date"
                >
                  Date
                </th>
                <th
                  rowSpan={2}
                  style={{
                    width: isTableScrolledX ? '32px' : '36px',
                    ...(freezeLeft ? { left: isTableScrolledX ? '40px' : '108px' } : {}),
                  }}
                  className={`${
                    freezeLeft
                      ? 'sticky z-30 bg-sky-100/95 dark:bg-slate-800/95 text-sky-950 dark:text-sky-100 backdrop-blur-md shadow-[2px_0_4px_-1px_rgba(0,0,0,0.12)]'
                      : 'bg-sky-100/90 dark:bg-slate-800/90 text-sky-950 dark:text-sky-100'
                  } border-r-2 border-sky-300/80 dark:border-slate-700 text-center transition-all duration-300 ease-in-out ${
                    isTableScrolledX
                      ? 'px-0.5 py-1 text-[11px] min-w-[32px] max-w-[32px] font-black'
                      : 'px-0.5 py-1 text-[12px] min-w-[36px] max-w-[36px] font-extrabold'
                  }`}
                  title="Day of Week"
                >
                  Day
                </th>
                <th colSpan={3} className="px-1.5 py-1.5 border-r border-indigo-200/60 dark:border-indigo-800/60 text-center bg-gradient-to-b from-indigo-100/90 to-indigo-200/80 dark:from-indigo-950/80 dark:to-indigo-900/80 text-indigo-950 dark:text-indigo-100 font-black text-[15px]">Roll (Enrolled)</th>
                <th colSpan={3} className="px-1.5 py-1.5 border-r border-blue-200/60 dark:border-blue-800/60 text-center bg-gradient-to-b from-blue-100/90 to-blue-200/80 dark:from-blue-950/80 dark:to-blue-900/80 text-blue-950 dark:text-blue-100 font-black text-[15px]">Attendance</th>
                <th rowSpan={2} className="px-1.5 py-1.5 border-r border-emerald-200/60 dark:border-emerald-800/60 text-center bg-gradient-to-b from-emerald-100/90 to-emerald-200/80 dark:from-emerald-950/80 dark:to-emerald-900/80 text-emerald-950 dark:text-emerald-100 text-[15px] font-black">Meals Served</th>
                <th rowSpan={2} className="px-1.5 py-1.5 border-r border-teal-200/60 dark:border-teal-800/60 text-center bg-gradient-to-b from-teal-100/90 to-teal-200/80 dark:from-teal-950/80 dark:to-teal-900/80 text-teal-950 dark:text-teal-100 font-black text-[13px] uppercase whitespace-normal leading-tight min-w-[95px] max-w-[110px] relative group/hdr">
                  <div className="flex items-center justify-center gap-1">
                    <span>Expenditure / Day (₹)</span>
                    <button
                      onClick={(ev) => {
                        ev.stopPropagation();
                        setEditingMealRates({ ...mealRates });
                        setRawEditingRates({
                          primaryRatePerMeal: String(mealRates.primaryRatePerMeal ?? 5.45),
                          upperPrimaryRatePerMeal: String(mealRates.upperPrimaryRatePerMeal ?? 8.17),
                          highSchoolRatePerMeal: String(mealRates.highSchoolRatePerMeal ?? 8.17),
                          eggRate: String(mealRates.eggRate ?? 6.00),
                          chikkiRate: String(mealRates.chikkiRate ?? 5.00),
                          ragiRatePerKg: String(mealRates.ragiRatePerKg ?? 35.00),
                          jaggeryRatePerKg: String(mealRates.jaggeryRatePerKg ?? 60.00),
                        });
                        setShowMealRatesModal(true);
                      }}
                      title="Edit Expenditure Norms"
                      className="no-print p-0.5 rounded hover:bg-emerald-200/60 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="text-[11.5px] font-bold normal-case text-emerald-800 dark:text-emerald-300 mt-0.5">
                    Pri ₹{(mealRates.primaryRatePerMeal ?? 5.45).toFixed(2)} | Up ₹{(mealRates.upperPrimaryRatePerMeal ?? 8.17).toFixed(2)}/head
                  </div>
                </th>
                <th colSpan={5} className="px-1.5 py-1.5 border-r border-amber-200/60 dark:border-amber-800/60 text-center bg-gradient-to-b from-amber-100/90 to-amber-200/80 dark:from-amber-950/80 dark:to-amber-900/80 text-amber-950 dark:text-amber-100 font-black text-[15px]">
                  <span>Rice (Kg)</span>
                </th>
                <th colSpan={5} className="px-1.5 py-1.5 border-r border-yellow-200/60 dark:border-yellow-800/60 text-center bg-gradient-to-b from-yellow-100/90 to-yellow-200/80 dark:from-yellow-950/80 dark:to-yellow-900/80 text-yellow-950 dark:text-yellow-100 font-black text-[15px]">
                  <div className="flex flex-col items-center">
                    <span>Egg (Pcs)</span>
                    <span className="text-[10px] normal-case font-bold tracking-tight text-yellow-900/80 dark:text-yellow-200/80">OB + Rec - Used - Spoils = Bal</span>
                  </div>
                </th>
                <th colSpan={5} className="px-1.5 py-1.5 border-r border-orange-200/60 dark:border-orange-800/60 text-center bg-gradient-to-b from-orange-100/90 to-orange-200/80 dark:from-orange-950/80 dark:to-orange-900/80 text-orange-950 dark:text-orange-100 font-black text-[15px]">
                  <div className="flex flex-col items-center">
                    <span>Chikki (Pcs)</span>
                    <span className="text-[10px] normal-case font-bold tracking-tight text-orange-900/80 dark:text-orange-200/80">OB + Rec - Used - Spoils = Bal</span>
                  </div>
                </th>
                <th colSpan={5} className="px-1.5 py-1.5 border-r border-purple-200/60 dark:border-purple-800/60 text-center bg-gradient-to-b from-purple-100/90 to-purple-200/80 dark:from-purple-950/80 dark:to-purple-900/80 text-purple-950 dark:text-purple-100 font-black text-[15px]">
                  <span>Ragi (Kg)</span>
                </th>
                <th colSpan={5} className="px-1.5 py-1.5 border-r border-pink-200/60 dark:border-pink-800/60 text-center bg-gradient-to-b from-pink-100/90 to-pink-200/80 dark:from-pink-950/80 dark:to-pink-900/80 text-pink-950 dark:text-pink-100 font-black text-[15px]">
                  <span>Jaggery (Kg)</span>
                </th>
                <th rowSpan={2} className="px-2 py-1.5 text-left text-[14px] bg-gradient-to-b from-slate-100/90 to-slate-200/80 dark:from-slate-800/80 dark:to-slate-850/80 text-slate-900 dark:text-slate-100 font-black">Remarks</th>
              </tr>
              <tr className="bg-gradient-to-r from-slate-100/90 via-sky-50/80 to-slate-100/90 dark:from-slate-850/90 dark:via-slate-800/90 dark:to-slate-850/90 text-slate-800 dark:text-slate-200 font-extrabold border-b-2 border-sky-300/70 dark:border-sky-700/70 text-[13.5px] uppercase whitespace-nowrap backdrop-blur-md">
                {/* Roll sub-cols */}
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">Pri</th>
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">Up.Pri</th>
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 font-black text-slate-950 dark:text-white whitespace-nowrap">Total</th>

                {/* Attendance sub-cols */}
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">Pri</th>
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">Up.Pri</th>
                <th className="p-1 text-center border-r border-slate-200 dark:border-slate-700 font-black text-slate-950 dark:text-white whitespace-nowrap">Total</th>

                {/* Rice sub-cols */}
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 font-black whitespace-nowrap">
                  OB
                </th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 font-bold whitespace-nowrap">Rec</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-blue-700 dark:text-blue-300 font-black whitespace-nowrap">Used</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 font-bold whitespace-nowrap">Spoils</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-cyan-800 dark:text-cyan-300 font-black whitespace-nowrap">Bal</th>

                {/* Egg sub-cols */}
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 font-black whitespace-nowrap" title="Opening Balance (OB)">
                  OB
                </th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 font-bold whitespace-nowrap" title="Received Stock (+)">Rec</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-amber-700 dark:text-amber-300 font-black whitespace-nowrap" title="Used / Consumed (-)">Used</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 font-bold whitespace-nowrap" title="Spoiled Stock (-)">Spoils</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-cyan-800 dark:text-cyan-300 font-black whitespace-nowrap" title="Balance = OB + Rec - Used - Spoiled">Bal</th>

                {/* Chikki sub-cols */}
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 font-black whitespace-nowrap" title="Opening Balance (OB)">
                  OB
                </th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 font-bold whitespace-nowrap" title="Received Stock (+)">Rec</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-orange-700 dark:text-orange-300 font-black whitespace-nowrap" title="Used / Consumed (-)">Used</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 font-bold whitespace-nowrap" title="Spoiled Stock (-)">Spoils</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-cyan-800 dark:text-cyan-300 font-black whitespace-nowrap" title="Balance = OB + Rec - Used - Spoiled">Bal</th>

                {/* Ragi sub-cols */}
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 font-black whitespace-nowrap">
                  OB
                </th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 font-bold whitespace-nowrap">Rec</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-purple-700 dark:text-purple-300 font-black whitespace-nowrap">Used</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 font-bold whitespace-nowrap">Spoils</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-cyan-800 dark:text-cyan-300 font-black whitespace-nowrap">Bal</th>

                {/* Jaggery sub-cols */}
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 font-black whitespace-nowrap">
                  OB
                </th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 font-bold whitespace-nowrap">Rec</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-pink-700 dark:text-pink-300 font-black whitespace-nowrap">Used</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 font-bold whitespace-nowrap">Spoils</th>
                <th className="p-1 text-right border-r border-slate-200 dark:border-slate-700 text-cyan-800 dark:text-cyan-300 font-black whitespace-nowrap">Bal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-[15px] sm:text-[16.5px] md:text-[18px]">
              {displayedEntries.length === 0 ? (
                <tr>
                  <td colSpan={isTableScrolledX ? 36 : 37} className="p-8 text-center text-slate-400">
                    No entries recorded for {monthLabel}. Go to Daily Entry to record meals.
                  </td>
                </tr>
              ) : (
                displayedEntries.map((e, idx) => {
                  const dayInfo = getDayDetails(e.date);
                  const dayStrengths = getStudentStrengthForDate(e.date);
                  let dayPrimaryEnrolled = 0;
                  let dayUpperPrimaryEnrolled = 0;
                  dayStrengths.forEach((s) => {
                    if (s.category === 'Primary' || (s.classLevel && s.classLevel.match(/class\s*[1-5]/i))) {
                      dayPrimaryEnrolled += s.total;
                    } else {
                      dayUpperPrimaryEnrolled += s.total;
                    }
                  });
                  if (dayPrimaryEnrolled === 0 && dayUpperPrimaryEnrolled === 0) {
                    dayPrimaryEnrolled = 170;
                    dayUpperPrimaryEnrolled = 130;
                  }
                  const dayTotalEnrolled = dayPrimaryEnrolled + dayUpperPrimaryEnrolled;

                  const stock = dailyStockMap[e.date] || {
                    rice: { ob: 0, rec: 0, used: e.riceUsedKg, spoiled: 0, cb: 0 },
                    egg: { ob: 0, rec: 0, used: e.eggUsedQty, spoiled: 0, cb: 0 },
                    chikki: { ob: 0, rec: 0, used: e.chikkiUsedQty, spoiled: 0, cb: 0 },
                    ragi: { ob: 0, rec: 0, used: e.ragiUsedKg, spoiled: 0, cb: 0 },
                    jaggery: { ob: 0, rec: 0, used: e.ragiUsedKg || e.jaggeryUsedKg, spoiled: 0, cb: 0 },
                  };

                  // If day 1 and not custom saved override, ensure OB strictly follows previous month total row closing balance
                  const isDayOne = idx === 0 || e.date.endsWith('-01');
                  if (isDayOne && !isOverrideActiveOnSelectedMonth && selectedMonth !== '2026-08' && stock) {
                    if (stock.rice) {
                      stock.rice.ob = prevRiceCB;
                      stock.rice.cb = safeRound3(prevRiceCB + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
                    }
                    if (stock.egg) {
                      stock.egg.ob = prevEggCB;
                      stock.egg.cb = safeRound3(prevEggCB + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
                    }
                    if (stock.chikki) {
                      stock.chikki.ob = prevChikkiCB;
                      stock.chikki.cb = safeRound3(prevChikkiCB + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
                    }
                    if (stock.ragi) {
                      stock.ragi.ob = prevRagiCB;
                      stock.ragi.cb = safeRound3(prevRagiCB + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
                    }
                    if (stock.jaggery && stock.ragi) {
                      stock.jaggery.ob = stock.ragi.ob;
                      stock.jaggery.rec = stock.ragi.rec;
                      stock.jaggery.used = stock.ragi.used;
                      stock.jaggery.spoiled = stock.ragi.spoiled;
                      stock.jaggery.cb = stock.ragi.cb;
                    }
                  }

                  // In month-end row (or 31 row): balance = ob + recieve - used - spoils for columns rice, egg, chikki, ragi, jaggery
                  const isMonthEndRow = idx + 1 === daysInSelMonth || e.date.endsWith('-31') || e.date.endsWith(`-${String(daysInSelMonth).padStart(2, '0')}`);
                  if (isMonthEndRow && stock) {
                    if (stock.rice) stock.rice.cb = safeRound3(stock.rice.ob + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
                    if (stock.egg) stock.egg.cb = safeRound3(stock.egg.ob + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
                    if (stock.chikki) stock.chikki.cb = safeRound3(stock.chikki.ob + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
                    if (stock.ragi) stock.ragi.cb = safeRound3(stock.ragi.ob + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
                    if (stock.jaggery && stock.ragi) {
                      stock.jaggery.ob = stock.ragi.ob;
                      stock.jaggery.rec = stock.ragi.rec;
                      stock.jaggery.used = stock.ragi.used;
                      stock.jaggery.spoiled = stock.ragi.spoiled;
                      stock.jaggery.cb = stock.ragi.cb;
                    }
                  }
                  const isZeroMeals = !e.mealsServed || e.mealsServed === 0;
                  const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
                  const dayCookingCost = calculateDayCookingCost(e);

                  const isHolidayRow = !dayInfo.isWorkingDayOverride && (
                    dayInfo.isHoliday ||
                    (e.mealsServed === 0 && Boolean(e.remarks && (e.remarks.toLowerCase().includes('holiday') || e.remarks.toLowerCase().includes('closed') || e.remarks.toLowerCase().includes('sunday'))))
                  );
                  const holidayText = dayInfo.holidayName ||
                    (e.remarks && (e.remarks.toLowerCase().includes('holiday') || e.remarks.toLowerCase().includes('closed')) ? e.remarks : 'School Holiday');

                  const isCustomSaved = monthEntriesMap.has(e.date);
                  const isEditingThisRow = inlineEditingDate === e.date && Boolean(inlineEditState);
                  const isFirstWorkingDay = e.date === firstWorkingDayDateStr;
                  const isHolidayTouched = isHolidayRow && activeHolidayRowDate === e.date;

                  return (
                    <tr
                      key={e.id ? `row-${e.id}-${e.date || idx}` : `row-${e.date || idx}`}
                      onClick={() => {
                        if (isHolidayRow) {
                          setActiveHolidayRowDate((prev) => (prev === e.date ? null : e.date));
                        }
                      }}
                      className={`group transition-colors ${
                        isEditingThisRow
                          ? 'bg-amber-50/40 dark:bg-amber-950/20'
                          : isHolidayRow
                          ? isHolidayTouched
                            ? 'bg-red-100/90 dark:bg-red-950/80 ring-1 ring-inset ring-red-400 dark:ring-red-600'
                            : 'bg-red-50/70 dark:bg-red-950/40'
                          : isCustomSaved
                          ? 'bg-amber-50/40 dark:bg-amber-950/20'
                          : isFirstWorkingDay
                          ? 'bg-emerald-50/40 dark:bg-emerald-950/20 ring-1 ring-inset ring-emerald-500/20'
                          : isZeroMeals
                          ? 'bg-white dark:bg-slate-900'
                          : 'bg-white dark:bg-slate-900'
                      }`}
                      title={isFirstWorkingDay ? `1st Working Day: Commodities automatically carried forward from ${prevMonthLabel} last working day closing balance` : undefined}
                    >
                      <td
                        style={{
                          width: isTableScrolledX ? '40px' : '32px',
                          ...(freezeLeft ? { left: 0 } : {}),
                        }}
                        className={`${
                          freezeLeft ? 'sticky left-0 z-20' : ''
                        } transition-all duration-300 ease-in-out ${
                          isEditingThisRow
                            ? 'bg-amber-200 dark:bg-amber-900'
                            : isCustomSaved
                            ? 'bg-amber-50 dark:bg-amber-950/80 group-hover:bg-amber-100 dark:group-hover:bg-amber-900 text-slate-500 dark:text-slate-400'
                            : isFirstWorkingDay
                            ? 'bg-emerald-50 dark:bg-emerald-950/80 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900 text-slate-500 dark:text-slate-400'
                            : isHolidayRow
                            ? 'bg-red-100/70 dark:bg-red-950/70 group-hover:bg-red-100 text-red-600 dark:text-red-400 font-bold'
                            : 'bg-white dark:bg-slate-900 group-hover:bg-slate-100 dark:group-hover:bg-slate-800 text-slate-500 dark:text-slate-400'
                        } font-extrabold text-center border-r border-slate-100 dark:border-slate-800 ${
                          isTableScrolledX
                            ? 'p-0.5 text-[12px] min-w-[40px] max-w-[40px]'
                            : 'p-1 text-[15px] min-w-[32px] max-w-[32px]'
                        }`}
                        title={isTableScrolledX ? `Date: ${e.date}` : `S.No: ${idx + 1}`}
                      >
                        {isTableScrolledX ? (e.date ? e.date.split('-')[2] : idx + 1) : (idx + 1)}
                      </td>
                      <td
                        style={{
                          width: isTableScrolledX ? '0px' : '65px',
                          ...(freezeLeft ? { left: isTableScrolledX ? '40px' : '32px' } : {}),
                          display: isTableScrolledX ? 'none' : undefined,
                        }}
                        className={`${isTableScrolledX ? 'hidden' : ''} ${
                          freezeLeft ? 'sticky z-20' : ''
                        } transition-all duration-300 ease-in-out ${
                          isEditingThisRow
                            ? 'bg-amber-200 dark:bg-amber-900'
                            : isCustomSaved
                            ? 'bg-amber-50 dark:bg-amber-950/80 group-hover:bg-amber-100 dark:group-hover:bg-amber-900 text-slate-900 dark:text-white'
                            : isFirstWorkingDay
                            ? 'bg-emerald-50 dark:bg-emerald-950/80 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900 text-slate-900 dark:text-white'
                            : isHolidayRow
                            ? 'bg-red-100/70 dark:bg-red-950/70 group-hover:bg-red-100 text-red-600 dark:text-red-400 font-bold'
                            : 'bg-white dark:bg-slate-900 group-hover:bg-slate-100 dark:group-hover:bg-slate-800 text-slate-900 dark:text-white'
                        } cell-date-value font-size-ignore font-bold whitespace-nowrap border-r border-slate-100 dark:border-slate-800 p-1 text-[12px] min-w-[65px] max-w-[65px]`}
                      >
                        <div className="flex items-center gap-1">
                          <span className="font-mono text-[12px] font-bold tracking-tight cell-date-text">{formatAsDDMMYY(e.date)}</span>
                          {isEditingThisRow ? (
                            <span className="no-print text-[9px] px-1 py-0.2 bg-purple-600 text-white rounded font-black uppercase tracking-wider animate-pulse">
                              Editing
                            </span>
                          ) : isCustomSaved ? (
                            <span className="no-print text-[9px] px-1 py-0.2 bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 rounded font-black uppercase">
                              Edit
                            </span>
                          ) : null}
                        </div>
                      </td>
                      <td
                        style={{
                          width: isTableScrolledX ? '32px' : '32px',
                          ...(freezeLeft ? { left: isTableScrolledX ? '40px' : '97px' } : {}),
                        }}
                        className={`${
                          freezeLeft ? 'sticky z-20 shadow-[2px_0_4px_-1px_rgba(0,0,0,0.12)]' : ''
                        } transition-all duration-300 ease-in-out ${
                          isEditingThisRow
                            ? 'bg-amber-200 dark:bg-amber-900'
                            : isCustomSaved
                            ? 'bg-amber-50 dark:bg-amber-950/80 group-hover:bg-amber-100 dark:group-hover:bg-amber-900'
                            : isHolidayRow
                            ? 'bg-red-100/70 dark:bg-red-950/70 group-hover:bg-red-100 text-red-600 dark:text-red-400 font-bold'
                            : 'bg-white dark:bg-slate-900 group-hover:bg-slate-100 dark:group-hover:bg-slate-800'
                        } cell-day-value font-size-ignore font-bold text-center border-r-2 border-slate-300 dark:border-slate-700 ${
                          isTableScrolledX
                            ? 'p-0.5 min-w-[28px] max-w-[28px]'
                            : 'p-0.5 min-w-[32px] max-w-[32px]'
                        }`}
                      >
                        <span
                          className={`cell-day-badge font-extrabold uppercase tracking-tight leading-none inline-block ${
                            isTableScrolledX ? 'px-0.5 py-0.5 text-[11px] rounded-xs' : 'px-0.5 py-0.5 rounded text-[12px]'
                          } ${
                            isHolidayRow || (dayInfo.isSunday && !dayInfo.isWorkingDayOverride)
                              ? 'bg-red-100 text-red-600 dark:bg-red-950/70 dark:text-red-400 border border-red-300 dark:border-red-800/80 font-bold'
                              : dayInfo.isWorkingDayOverride
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 font-bold'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {isTableScrolledX
                            ? (dayInfo.shortDayName || dayInfo.dayName).substring(0, 2)
                            : (dayInfo.shortDayName || dayInfo.dayName)}
                        </span>
                      </td>

                      {/* Attendance & Meals Served / Holiday Row / Direct In-Cell Editing */}
                      {isEditingThisRow && inlineEditState ? (() => {
                        const curPAtt = inlineEditState.isHoliday ? 0 : inlineEditState.primaryAttendance;
                        const curUpAtt = inlineEditState.isHoliday ? 0 : inlineEditState.upperPrimaryAttendance;
                        const curTotalAtt = curPAtt + curUpAtt;
                        const curMealsServed = inlineEditState.isHoliday ? 0 : inlineEditState.mealsServed;
                        const curCookingCost = inlineEditState.isHoliday
                          ? 0
                          : (curPAtt * mealRates.primaryRatePerMeal) + (curUpAtt * mealRates.upperPrimaryRatePerMeal);

                        const curRiceUsed = inlineEditState.isHoliday
                          ? 0
                          : (curMealsServed > 0 && curTotalAtt > 0
                            ? Number((((curPAtt * 0.1) + (curUpAtt * 0.15)) * (curMealsServed / curTotalAtt)).toFixed(2))
                            : Number(((curPAtt * 0.1) + (curUpAtt * 0.15)).toFixed(2)));
                        const curRiceCB = Number((inlineEditState.rice.ob + inlineEditState.rice.rec - curRiceUsed - inlineEditState.rice.spoiled).toFixed(2));

                        const curEggUsed = inlineEditState.isHoliday
                          ? 0
                          : (dayInfo.dayOfWeek >= 1 && dayInfo.dayOfWeek <= 5 ? curMealsServed : 0);
                        const curEggCB = Number((inlineEditState.egg.ob + inlineEditState.egg.rec - curEggUsed - inlineEditState.egg.spoiled).toFixed(2));

                        const curChikkiUsed = inlineEditState.isHoliday
                          ? 0
                          : (dayInfo.dayOfWeek === 1 || dayInfo.dayOfWeek === 3 || dayInfo.dayOfWeek === 5 ? curMealsServed : 0);
                        const curChikkiCB = Number((inlineEditState.chikki.ob + inlineEditState.chikki.rec - curChikkiUsed - inlineEditState.chikki.spoiled).toFixed(2));

                        const curRagiUsed = inlineEditState.isHoliday
                          ? 0
                          : (dayInfo.dayOfWeek === 2 || dayInfo.dayOfWeek === 4 || dayInfo.dayOfWeek === 6 ? Number((curMealsServed * 0.01).toFixed(2)) : 0);
                        const curRagiCB = Number((inlineEditState.ragi.ob + inlineEditState.ragi.rec - curRagiUsed - inlineEditState.ragi.spoiled).toFixed(2));

                        const curJaggeryUsed = inlineEditState.isHoliday
                          ? 0
                          : (dayInfo.dayOfWeek === 2 || dayInfo.dayOfWeek === 4 || dayInfo.dayOfWeek === 6 ? Number((curMealsServed * 0.01).toFixed(2)) : 0);
                        const curJaggeryCB = Number((inlineEditState.jaggery.ob + inlineEditState.jaggery.rec - curJaggeryUsed - inlineEditState.jaggery.spoiled).toFixed(2));

                        const isFirstDayOfRegister = inlineEditState.date.endsWith('-01') || (monthEntries.length > 0 && inlineEditState.date === monthEntries[0].date);
                        const isFieldActive = (f: string) => inlineActiveField === f || inlineActiveField === f.replace('.', '-');

                        return (
                          <>
                            {/* Roll (Primary) */}
                            {isFieldActive('primaryRoll') ? (
                              <td className="p-0.5 text-center border-r border-slate-200 dark:border-slate-700 bg-amber-50 dark:bg-amber-950/40">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  autoFocus
                                  data-field="primaryRoll"
                                  data-date={inlineEditState.date}
                                  value={inlineEditState.primaryRoll}
                                  onChange={(ev) => {
                                    const val = Math.max(0, parseInt(ev.target.value, 10) || 0);
                                    inlineIsDirtyRef.current = true;
                                    const wasFullPrimary = inlineEditState.primaryAttendance === inlineEditState.primaryRoll || inlineEditState.primaryAttendance === 0;
                                    const newPrimaryAtt = wasFullPrimary ? val : Math.min(val, inlineEditState.primaryAttendance);
                                    const totalAtt = (inlineEditState.isHoliday ? 0 : newPrimaryAtt) + (inlineEditState.isHoliday ? 0 : inlineEditState.upperPrimaryAttendance);
                                    const newMeals = !inlineEditState.isMealsCustomized ? totalAtt : Math.min(totalAtt, inlineEditState.mealsServed);
                                    const newState = {
                                      ...inlineEditState,
                                      primaryRoll: val,
                                      isRollManuallyChanged: true,
                                      primaryAttendance: inlineEditState.isHoliday ? 0 : newPrimaryAtt,
                                      mealsServed: inlineEditState.isHoliday ? 0 : newMeals,
                                    };
                                    inlineEditStateRef.current = newState;
                                    setInlineEditState(newState);
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-center text-[13px] font-black bg-white dark:bg-slate-900 border-2 border-amber-500 rounded text-slate-950 dark:text-white focus:outline-none shadow-xs"
                                  title="Primary Roll (Enrolled) - Editable"
                                />
                              </td>
                            ) : (
                              <td
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  setInlineActiveField('primaryRoll');
                                }}
                                className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40"
                                title="Click to edit Primary Roll"
                              >
                                {inlineEditState.primaryRoll}
                              </td>
                            )}

                            {/* Roll (Upper Primary) */}
                            {isFieldActive('upperPrimaryRoll') ? (
                              <td className="p-0.5 text-center border-r border-slate-200 dark:border-slate-700 bg-amber-50 dark:bg-amber-950/40">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  autoFocus
                                  data-field="upperPrimaryRoll"
                                  data-date={inlineEditState.date}
                                  value={inlineEditState.upperPrimaryRoll}
                                  onChange={(ev) => {
                                    const val = Math.max(0, parseInt(ev.target.value, 10) || 0);
                                    inlineIsDirtyRef.current = true;
                                    const wasFullUpper = inlineEditState.upperPrimaryAttendance === inlineEditState.upperPrimaryRoll || inlineEditState.upperPrimaryAttendance === 0;
                                    const newUpperAtt = wasFullUpper ? val : Math.min(val, inlineEditState.upperPrimaryAttendance);
                                    const totalAtt = (inlineEditState.isHoliday ? 0 : inlineEditState.primaryAttendance) + (inlineEditState.isHoliday ? 0 : newUpperAtt);
                                    const newMeals = !inlineEditState.isMealsCustomized ? totalAtt : Math.min(totalAtt, inlineEditState.mealsServed);
                                    const newState = {
                                      ...inlineEditState,
                                      upperPrimaryRoll: val,
                                      isRollManuallyChanged: true,
                                      upperPrimaryAttendance: inlineEditState.isHoliday ? 0 : newUpperAtt,
                                      mealsServed: inlineEditState.isHoliday ? 0 : newMeals,
                                    };
                                    inlineEditStateRef.current = newState;
                                    setInlineEditState(newState);
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-center text-[13px] font-black bg-white dark:bg-slate-900 border-2 border-amber-500 rounded text-slate-950 dark:text-white focus:outline-none shadow-xs"
                                  title="Upper Primary Roll (Enrolled) - Editable"
                                />
                              </td>
                            ) : (
                              <td
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  setInlineActiveField('upperPrimaryRoll');
                                }}
                                className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40"
                                title="Click to edit Upper Primary Roll"
                              >
                                {inlineEditState.upperPrimaryRoll}
                              </td>
                            )}

                            {/* Total Roll (Calculated) */}
                            <td className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 text-slate-950 dark:text-white text-[14px] bg-slate-50/50 dark:bg-slate-800/30 select-none">
                              {inlineEditState.primaryRoll + inlineEditState.upperPrimaryRoll}
                            </td>

                            {/* Attendance (Primary) */}
                            {isFieldActive('primaryAttendance') ? (
                              <td className="p-0.5 text-center border-r border-slate-200 dark:border-slate-700 bg-amber-50 dark:bg-amber-950/40">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  autoFocus
                                  data-field="primaryAttendance"
                                  data-date={inlineEditState.date}
                                  value={inlineEditState.primaryAttendance}
                                  onChange={(ev) => {
                                    const val = Math.max(0, parseInt(ev.target.value, 10) || 0);
                                    const newTotal = val + inlineEditState.upperPrimaryAttendance;
                                    inlineIsDirtyRef.current = true;
                                    const next = {
                                      ...inlineEditState,
                                      primaryAttendance: val,
                                      mealsServed: inlineEditState.isMealsCustomized ? inlineEditState.mealsServed : newTotal,
                                    };
                                    inlineEditStateRef.current = next;
                                    setInlineEditState(next);
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  disabled={inlineEditState.isHoliday}
                                  className="w-13 px-1 py-0.5 text-center text-[13px] font-black bg-white dark:bg-slate-900 border-2 border-amber-500 rounded text-slate-950 dark:text-white focus:outline-none shadow-xs disabled:opacity-30"
                                  title="Primary Attendance (Editable)"
                                />
                              </td>
                            ) : (
                              <td
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  setInlineActiveField('primaryAttendance');
                                }}
                                className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40"
                                title="Click to edit Primary Attendance"
                              >
                                {curPAtt}
                              </td>
                            )}

                            {/* Attendance (Upper Primary) */}
                            {isFieldActive('upperPrimaryAttendance') ? (
                              <td className="p-0.5 text-center border-r border-slate-200 dark:border-slate-700 bg-amber-50 dark:bg-amber-950/40">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  autoFocus
                                  data-field="upperPrimaryAttendance"
                                  data-date={inlineEditState.date}
                                  value={inlineEditState.upperPrimaryAttendance}
                                  onChange={(ev) => {
                                    const val = Math.max(0, parseInt(ev.target.value, 10) || 0);
                                    const newTotal = inlineEditState.primaryAttendance + val;
                                    inlineIsDirtyRef.current = true;
                                    const next = {
                                      ...inlineEditState,
                                      upperPrimaryAttendance: val,
                                      mealsServed: inlineEditState.isMealsCustomized ? inlineEditState.mealsServed : newTotal,
                                    };
                                    inlineEditStateRef.current = next;
                                    setInlineEditState(next);
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  disabled={inlineEditState.isHoliday}
                                  className="w-13 px-1 py-0.5 text-center text-[13px] font-black bg-white dark:bg-slate-900 border-2 border-amber-500 rounded text-slate-950 dark:text-white focus:outline-none shadow-xs disabled:opacity-30"
                                  title="Upper Primary Attendance (Editable)"
                                />
                              </td>
                            ) : (
                              <td
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  setInlineActiveField('upperPrimaryAttendance');
                                }}
                                className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40"
                                title="Click to edit Upper Primary Attendance"
                              >
                                {curUpAtt}
                              </td>
                            )}

                            {/* Total Attendance (Calculated) */}
                            <td className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 bg-blue-50/40 dark:bg-blue-950/30 text-blue-950 dark:text-blue-200 text-[14px] select-none">
                              {curTotalAtt}
                            </td>

                            {/* Meals Served */}
                            {isFieldActive('mealsServed') ? (
                              <td className="p-0.5 text-center border-r border-slate-200 dark:border-slate-700 bg-emerald-50 dark:bg-emerald-950/40">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  autoFocus
                                  data-field="mealsServed"
                                  data-date={inlineEditState.date}
                                  value={inlineEditState.mealsServed}
                                  onChange={(ev) => {
                                    const val = Math.max(0, parseInt(ev.target.value, 10) || 0);
                                    inlineIsDirtyRef.current = true;
                                    const next = {
                                      ...inlineEditState,
                                      mealsServed: val,
                                      isMealsCustomized: true,
                                    };
                                    inlineEditStateRef.current = next;
                                    setInlineEditState(next);
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  disabled={inlineEditState.isHoliday}
                                  className="w-13 px-1 py-0.5 text-center text-[13px] font-black bg-white dark:bg-slate-900 border-2 border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none shadow-xs disabled:opacity-30"
                                  title="Served Meals (Editable)"
                                />
                              </td>
                            ) : (
                              <td
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  setInlineActiveField('mealsServed');
                                }}
                                className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 text-[14px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40"
                                title="Click to edit Meals Served"
                              >
                                {curMealsServed}
                              </td>
                            )}

                            {/* Cooking Cost (Calculated) */}
                            <td className="p-1 text-right font-black border-r border-slate-100 dark:border-slate-800 bg-violet-50/30 dark:bg-violet-950/20 text-violet-950 dark:text-violet-200 text-[13px] select-none">
                              {curCookingCost > 0 ? `₹${curCookingCost.toFixed(2)}` : '-'}
                            </td>

                            {/* Rice (OB, Rec, Used, Spoiled, CB) */}
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/40 dark:bg-indigo-950/20">
                              {isFieldActive('rice.ob') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="rice-ob"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['rice.ob'] !== undefined ? inlineRawInputs['rice.ob'] : (inlineEditState.rice.ob || '')}
                                  onChange={(ev) => handleCommodityInlineChange('rice.ob', ev.target.value, 'rice', 'ob')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-indigo-500 rounded text-indigo-950 dark:text-indigo-200 focus:outline-none"
                                  title="Rice Opening Balance (Editable, supports decimals e.g. 10.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('rice.ob');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-indigo-700 dark:text-indigo-300 cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 rounded"
                                  title="Click to edit Rice Opening Balance"
                                >
                                  {formatQtyVal(inlineEditState.rice.ob)}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/40 dark:bg-emerald-950/20">
                              {isFieldActive('rice.rec') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="rice-rec"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['rice.rec'] !== undefined ? inlineRawInputs['rice.rec'] : (inlineEditState.rice.rec || '')}
                                  onChange={(ev) => handleCommodityInlineChange('rice.rec', ev.target.value, 'rice', 'rec')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none"
                                  title="Rice Received (+) (Editable, supports decimals e.g. 50.25)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('rice.rec');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-emerald-700 dark:text-emerald-300 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Rice Received"
                                >
                                  {inlineEditState.rice.rec > 0 ? `+${formatQtyVal(inlineEditState.rice.rec)}` : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-1 text-right font-mono font-black text-blue-900 dark:text-blue-300 border-r border-slate-200 dark:border-slate-700 text-[12px] select-none">
                              {curRiceUsed > 0 ? formatQtyVal(curRiceUsed) : '-'}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/40 dark:bg-rose-950/20">
                              {isFieldActive('rice.spoiled') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="rice-spoiled"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['rice.spoiled'] !== undefined ? inlineRawInputs['rice.spoiled'] : (inlineEditState.rice.spoiled || '')}
                                  onChange={(ev) => handleCommodityInlineChange('rice.spoiled', ev.target.value, 'rice', 'spoiled')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-rose-400 rounded text-rose-950 dark:text-rose-200 focus:outline-none"
                                  title="Rice Spoiled (-) (Editable, supports decimals e.g. 1.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('rice.spoiled');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Rice Spoiled"
                                >
                                  {inlineEditState.rice.spoiled > 0 ? formatQtyVal(inlineEditState.rice.spoiled) : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/40 dark:bg-cyan-950/20 select-none">
                              <div
                                className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-cyan-800 dark:text-cyan-300"
                                title="Calculated Rice Closing Balance (= OB + Rec - Used - Spoiled)"
                              >
                                {formatQtyVal(curRiceCB)}
                              </div>
                            </td>

                            {/* Egg (OB, Rec, Used, Spoiled, CB) */}
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/40 dark:bg-indigo-950/20">
                              {isFieldActive('egg.ob') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="egg-ob"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['egg.ob'] !== undefined ? inlineRawInputs['egg.ob'] : (inlineEditState.egg.ob !== undefined && inlineEditState.egg.ob !== null ? String(inlineEditState.egg.ob) : '0')}
                                  onChange={(ev) => handleCommodityInlineChange('egg.ob', ev.target.value, 'egg', 'ob')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-indigo-500 rounded text-indigo-950 dark:text-indigo-200 focus:outline-none"
                                  title="Egg Opening Balance (Editable, supports decimal numbers e.g. 10.5. Formula: OB + Rec - Used - Spoils = Bal)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('egg.ob');
                                  }}
                                  data-field="egg-ob-display"
                                  className={`px-1 py-0.5 text-right text-[12px] font-mono font-bold cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 rounded transition-colors ${
                                    (inlineEditState.egg.ob || 0) < 0 ? 'text-rose-700 dark:text-rose-300 font-black' : 'text-indigo-950 dark:text-indigo-200'
                                  }`}
                                  title="Click to edit Egg Opening Balance (OB + Rec - Used - Spoiled = Balance)"
                                >
                                  {formatQtyVal(inlineEditState.egg.ob ?? 0)}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/40 dark:bg-emerald-950/20">
                              {isFieldActive('egg.rec') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="egg-rec"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['egg.rec'] !== undefined ? inlineRawInputs['egg.rec'] : (inlineEditState.egg.rec || '')}
                                  onChange={(ev) => handleCommodityInlineChange('egg.rec', ev.target.value, 'egg', 'rec')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none"
                                  title="Egg Received (+) (Editable, supports decimal numbers e.g. 50.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('egg.rec');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-emerald-700 dark:text-emerald-300 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Egg Received"
                                >
                                  {inlineEditState.egg.rec > 0 ? `+${formatQtyVal(inlineEditState.egg.rec)}` : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-1 text-right font-mono font-black text-amber-900 dark:text-amber-300 border-r border-slate-200 dark:border-slate-700 text-[12px] select-none">
                              {curEggUsed > 0 ? formatQtyVal(curEggUsed) : '-'}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/40 dark:bg-rose-950/20">
                              {isFieldActive('egg.spoiled') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="egg-spoiled"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['egg.spoiled'] !== undefined ? inlineRawInputs['egg.spoiled'] : (inlineEditState.egg.spoiled || '')}
                                  onChange={(ev) => handleCommodityInlineChange('egg.spoiled', ev.target.value, 'egg', 'spoiled')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-rose-400 rounded text-rose-950 dark:text-rose-200 focus:outline-none"
                                  title="Egg Spoiled (-) (Editable, supports decimal numbers e.g. 2.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('egg.spoiled');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Egg Spoiled"
                                >
                                  {inlineEditState.egg.spoiled > 0 ? formatQtyVal(inlineEditState.egg.spoiled) : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/40 dark:bg-cyan-950/20 select-none">
                              <div
                                className={`px-1 py-0.5 text-right text-[12px] font-mono font-black ${
                                  curEggCB < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'
                                }`}
                                title={`Egg Balance = OB (${inlineEditState.egg.ob}) + Rec (${inlineEditState.egg.rec}) - Used (${curEggUsed}) - Spoils (${inlineEditState.egg.spoiled}) = ${formatQtyVal(curEggCB)}`}
                              >
                                {formatQtyVal(curEggCB)}
                              </div>
                            </td>

                            {/* Chikki (OB, Rec, Used, Spoiled, CB) */}
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/40 dark:bg-indigo-950/20">
                              {isFieldActive('chikki.ob') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="chikki-ob"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['chikki.ob'] !== undefined ? inlineRawInputs['chikki.ob'] : (inlineEditState.chikki.ob !== undefined && inlineEditState.chikki.ob !== null ? String(inlineEditState.chikki.ob) : '0')}
                                  onChange={(ev) => handleCommodityInlineChange('chikki.ob', ev.target.value, 'chikki', 'ob')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-indigo-500 rounded text-indigo-950 dark:text-indigo-200 focus:outline-none"
                                  title="Chikki Opening Balance (Editable, supports decimal numbers e.g. 10.5. Formula: OB + Rec - Used - Spoils = Bal)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('chikki.ob');
                                  }}
                                  data-field="chikki-ob-display"
                                  className={`px-1 py-0.5 text-right text-[12px] font-mono font-bold cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 rounded transition-colors ${
                                    (inlineEditState.chikki.ob || 0) < 0 ? 'text-rose-700 dark:text-rose-300 font-black' : 'text-indigo-950 dark:text-indigo-200'
                                  }`}
                                  title="Click to edit Chikki Opening Balance (OB + Rec - Used - Spoiled = Balance)"
                                >
                                  {formatQtyVal(inlineEditState.chikki.ob ?? 0)}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/40 dark:bg-emerald-950/20">
                              {isFieldActive('chikki.rec') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="chikki-rec"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['chikki.rec'] !== undefined ? inlineRawInputs['chikki.rec'] : (inlineEditState.chikki.rec || '')}
                                  onChange={(ev) => handleCommodityInlineChange('chikki.rec', ev.target.value, 'chikki', 'rec')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none"
                                  title="Chikki Received (+) (Editable, supports decimal numbers e.g. 50.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('chikki.rec');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-emerald-700 dark:text-emerald-300 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Chikki Received"
                                >
                                  {inlineEditState.chikki.rec > 0 ? `+${formatQtyVal(inlineEditState.chikki.rec)}` : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-1 text-right font-mono font-black text-orange-900 dark:text-orange-300 border-r border-slate-200 dark:border-slate-700 text-[12px] select-none">
                              {curChikkiUsed > 0 ? formatQtyVal(curChikkiUsed) : '-'}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/40 dark:bg-rose-950/20">
                              {isFieldActive('chikki.spoiled') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="chikki-spoiled"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['chikki.spoiled'] !== undefined ? inlineRawInputs['chikki.spoiled'] : (inlineEditState.chikki.spoiled || '')}
                                  onChange={(ev) => handleCommodityInlineChange('chikki.spoiled', ev.target.value, 'chikki', 'spoiled')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-rose-400 rounded text-rose-950 dark:text-rose-200 focus:outline-none"
                                  title="Chikki Spoiled (-) (Editable, supports decimal numbers e.g. 2.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('chikki.spoiled');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Chikki Spoiled"
                                >
                                  {inlineEditState.chikki.spoiled > 0 ? formatQtyVal(inlineEditState.chikki.spoiled) : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/40 dark:bg-cyan-950/20 select-none">
                              <div
                                className={`px-1 py-0.5 text-right text-[12px] font-mono font-black ${
                                  curChikkiCB < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'
                                }`}
                                title={`Chikki Balance = OB (${inlineEditState.chikki.ob}) + Rec (${inlineEditState.chikki.rec}) - Used (${curChikkiUsed}) - Spoils (${inlineEditState.chikki.spoiled}) = ${formatQtyVal(curChikkiCB)}`}
                              >
                                {formatQtyVal(curChikkiCB)}
                              </div>
                            </td>

                            {/* Ragi (OB, Rec, Used, Spoiled, CB) */}
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/40 dark:bg-indigo-950/20">
                              {isFieldActive('ragi.ob') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="ragi-ob"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['ragi.ob'] !== undefined ? inlineRawInputs['ragi.ob'] : (inlineEditState.ragi.ob || '')}
                                  onChange={(ev) => handleCommodityInlineChange('ragi.ob', ev.target.value, 'ragi', 'ob')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-indigo-500 rounded text-indigo-950 dark:text-indigo-200 focus:outline-none"
                                  title="Ragi Opening Balance (Editable, supports decimals e.g. 5.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('ragi.ob');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-indigo-700 dark:text-indigo-300 cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 rounded"
                                  title="Click to edit Ragi Opening Balance"
                                >
                                  {formatQtyVal(inlineEditState.ragi.ob)}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/40 dark:bg-emerald-950/20">
                              {isFieldActive('ragi.rec') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="ragi-rec"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['ragi.rec'] !== undefined ? inlineRawInputs['ragi.rec'] : (inlineEditState.ragi.rec || '')}
                                  onChange={(ev) => handleCommodityInlineChange('ragi.rec', ev.target.value, 'ragi', 'rec')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none"
                                  title="Ragi Received (+) (Editable, supports decimals e.g. 20.25)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('ragi.rec');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-emerald-700 dark:text-emerald-300 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Ragi Received"
                                >
                                  {inlineEditState.ragi.rec > 0 ? `+${formatQtyVal(inlineEditState.ragi.rec)}` : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-1 text-right font-mono font-black text-purple-900 dark:text-purple-300 border-r border-slate-200 dark:border-slate-700 text-[12px] select-none">
                              {curRagiUsed > 0 ? formatQtyVal(curRagiUsed) : '-'}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/40 dark:bg-rose-950/20">
                              {isFieldActive('ragi.spoiled') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="ragi-spoiled"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['ragi.spoiled'] !== undefined ? inlineRawInputs['ragi.spoiled'] : (inlineEditState.ragi.spoiled || '')}
                                  onChange={(ev) => handleCommodityInlineChange('ragi.spoiled', ev.target.value, 'ragi', 'spoiled')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-rose-400 rounded text-rose-950 dark:text-rose-200 focus:outline-none"
                                  title="Ragi Spoiled (-) (Editable, supports decimals e.g. 0.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('ragi.spoiled');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Ragi Spoiled"
                                >
                                  {inlineEditState.ragi.spoiled > 0 ? formatQtyVal(inlineEditState.ragi.spoiled) : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/40 dark:bg-cyan-950/20 select-none">
                              <div
                                className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-cyan-800 dark:text-cyan-300"
                                title="Calculated Ragi Closing Balance (= OB + Rec - Used - Spoiled)"
                              >
                                {formatQtyVal(curRagiCB)}
                              </div>
                            </td>

                            {/* Jaggery (OB, Rec, Used, Spoiled, CB) */}
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/40 dark:bg-indigo-950/20">
                              {isFieldActive('jaggery.ob') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="jaggery-ob"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['jaggery.ob'] !== undefined ? inlineRawInputs['jaggery.ob'] : (inlineEditState.jaggery.ob || '')}
                                  onChange={(ev) => handleCommodityInlineChange('jaggery.ob', ev.target.value, 'jaggery', 'ob')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-indigo-500 rounded text-indigo-950 dark:text-indigo-200 focus:outline-none"
                                  title="Jaggery Opening Balance (Editable, supports decimals e.g. 5.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('jaggery.ob');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-indigo-700 dark:text-indigo-300 cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 rounded"
                                  title="Click to edit Jaggery Opening Balance"
                                >
                                  {formatQtyVal(inlineEditState.jaggery.ob)}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/40 dark:bg-emerald-950/20">
                              {isFieldActive('jaggery.rec') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="jaggery-rec"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['jaggery.rec'] !== undefined ? inlineRawInputs['jaggery.rec'] : (inlineEditState.jaggery.rec || '')}
                                  onChange={(ev) => handleCommodityInlineChange('jaggery.rec', ev.target.value, 'jaggery', 'rec')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-14 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-emerald-500 rounded text-emerald-950 dark:text-emerald-200 focus:outline-none"
                                  title="Jaggery Received (+) (Editable, supports decimals e.g. 20.25)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('jaggery.rec');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-emerald-700 dark:text-emerald-300 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Jaggery Received"
                                >
                                  {inlineEditState.jaggery.rec > 0 ? `+${formatQtyVal(inlineEditState.jaggery.rec)}` : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-1 text-right font-mono font-black text-pink-900 dark:text-pink-300 border-r border-slate-200 dark:border-slate-700 text-[12px] select-none">
                              {curJaggeryUsed > 0 ? formatQtyVal(curJaggeryUsed) : '-'}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/40 dark:bg-rose-950/20">
                              {isFieldActive('jaggery.spoiled') ? (
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  step="any"
                                  pattern="[0-9.-]*"
                                  autoFocus
                                  placeholder="0"
                                  data-field="jaggery-spoiled"
                                  data-date={inlineEditState.date}
                                  value={inlineRawInputs['jaggery.spoiled'] !== undefined ? inlineRawInputs['jaggery.spoiled'] : (inlineEditState.jaggery.spoiled || '')}
                                  onChange={(ev) => handleCommodityInlineChange('jaggery.spoiled', ev.target.value, 'jaggery', 'spoiled')}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="w-13 px-1 py-0.5 text-right text-[11.5px] font-bold font-mono bg-white dark:bg-slate-900 border border-rose-400 rounded text-rose-950 dark:text-rose-200 focus:outline-none"
                                  title="Jaggery Spoiled (-) (Editable, supports decimals e.g. 0.5)"
                                />
                              ) : (
                                <div
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    setInlineActiveField('jaggery.spoiled');
                                  }}
                                  className="px-1 py-0.5 text-right text-[12px] font-mono font-bold text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 rounded"
                                  title="Click to edit Jaggery Spoiled"
                                >
                                  {inlineEditState.jaggery.spoiled > 0 ? formatQtyVal(inlineEditState.jaggery.spoiled) : '-'}
                                </div>
                              )}
                            </td>
                            <td className="p-0.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/40 dark:bg-cyan-950/20 select-none">
                              <div
                                className="px-1 py-0.5 text-right text-[12px] font-mono font-black text-cyan-800 dark:text-cyan-300"
                                title="Calculated Jaggery Closing Balance (= OB + Rec - Used - Spoiled)"
                              >
                                {formatQtyVal(curJaggeryCB)}
                              </div>
                            </td>

                            {/* Editable Holiday / Remarks Column */}
                            <td className="p-1 border-r border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50">
                              <div className="flex items-center gap-1.5 min-w-[280px]">
                                <label className="inline-flex items-center gap-1 text-[11.5px] font-black text-orange-700 dark:text-orange-300 cursor-pointer select-none bg-orange-50 dark:bg-orange-950/60 px-2 py-1 rounded border border-orange-300 dark:border-orange-800 shadow-2xs hover:bg-orange-100">
                                  <input
                                    type="checkbox"
                                    checked={inlineEditState.isHoliday}
                                    onChange={(ev) => {
                                      const isH = ev.target.checked;
                                      let next = {
                                        ...inlineEditState,
                                        isHoliday: isH,
                                        holidayName: isH ? (inlineEditState.holidayName || 'School Holiday') : '',
                                      };
                                      if (!isH) {
                                        const pRoll = inlineEditState.primaryRoll ?? primaryEnrolled;
                                        const upRoll = inlineEditState.upperPrimaryRoll ?? upperPrimaryEnrolled;
                                        if (next.primaryAttendance === 0 && next.upperPrimaryAttendance === 0) {
                                          next.primaryAttendance = pRoll;
                                          next.upperPrimaryAttendance = upRoll;
                                          next.mealsServed = pRoll + upRoll;
                                        }
                                        if (!next.remarks || next.remarks.toLowerCase().includes('holiday') || next.remarks.toLowerCase().includes('sunday')) {
                                          next.remarks = 'Working Day';
                                        }
                                      } else {
                                        next.primaryAttendance = 0;
                                        next.upperPrimaryAttendance = 0;
                                        next.mealsServed = 0;
                                      }
                                      setInlineEditState(next);
                                      inlineIsDirtyRef.current = true;
                                      inlineEditStateRef.current = next;
                                      commitInlineEdit(next, false);
                                    }}
                                    className="w-3.5 h-3.5 accent-orange-600 rounded cursor-pointer"
                                  />
                                  <span>Holiday</span>
                                </label>
                                <input
                                  type="text"
                                  autoFocus={isFieldActive('remarks')}
                                  data-field="remarks"
                                  data-date={inlineEditState.date}
                                  placeholder={inlineEditState.isHoliday ? 'Holiday name (e.g. Festival)' : 'Remarks (optional)'}
                                  value={inlineEditState.isHoliday ? inlineEditState.holidayName : inlineEditState.remarks}
                                  onFocus={() => setInlineActiveField('remarks')}
                                  onChange={(ev) => {
                                    const v = ev.target.value;
                                    inlineIsDirtyRef.current = true;
                                    if (inlineEditState.isHoliday) {
                                      setInlineEditState({ ...inlineEditState, holidayName: v });
                                    } else {
                                      setInlineEditState({ ...inlineEditState, remarks: v });
                                    }
                                  }}
                                  onBlur={handleInlineBlur}
                                  onKeyDown={handleInlineKeyDown}
                                  className="flex-1 px-2 py-1 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-2xs"
                                />

                                {/* Auto-save status feedback */}
                                {isAutoSaving ? (
                                  <span className="inline-flex items-center gap-1 px-2 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700 rounded text-[11px] font-bold shrink-0 animate-pulse">
                                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                    <span>Saving...</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 rounded text-[11px] font-bold shrink-0 shadow-2xs" title={inlineAutoSavedTime ? `Auto-saved at ${inlineAutoSavedTime}` : 'All changes are automatically saved'}>
                                    <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                    <span>{inlineAutoSavedTime ? `Saved ${inlineAutoSavedTime}` : 'Auto-saved'}</span>
                                  </span>
                                )}

                                <button
                                  type="button"
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    saveInlineEdit();
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-black shadow-xs transition-all shrink-0 cursor-pointer"
                                  title="Finish editing this day (Enter)"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Done</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    cancelInlineEdit();
                                  }}
                                  className="inline-flex items-center gap-0.5 px-2 py-1 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded text-xs font-bold transition-all shrink-0 cursor-pointer"
                                  title="Close row editor (Esc)"
                                >
                                  <X className="w-3.5 h-3.5" />
                                  <span>Close</span>
                                </button>
                                {isCustomSaved && (
                                  <button
                                    type="button"
                                    onClick={(event) => {
                                      event.stopPropagation();
                                      handleResetDayToAuto(e.date);
                                    }}
                                    className="inline-flex items-center p-1 text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/60 rounded shrink-0 cursor-pointer"
                                    title="Reset to auto calculations"
                                  >
                                    <RotateCcw className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </>
                        );
                      })() : isHolidayRow ? (
                        <>
                          {/* Roll (Always displayed for all dates, never spanned over) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Primary Roll"
                          >
                            {dayPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Upper Primary Roll"
                          >
                            {dayUpperPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 text-slate-950 dark:text-white text-[14px] bg-slate-50/50 dark:bg-slate-800/30 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Roll"
                          >
                            {dayTotalEnrolled}
                          </td>

                          <td
                            colSpan={31}
                            onClick={(ev) => {
                              ev.stopPropagation();
                              setActiveHolidayRowDate((prev) => (prev === e.date ? null : e.date));
                            }}
                            className={`py-1 px-3 text-center font-bold tracking-normal text-red-600 dark:text-red-400 border-r border-red-200 dark:border-red-900/60 select-none group/holiday cursor-pointer transition-all ${
                              isHolidayTouched
                                ? 'bg-red-100 dark:bg-red-950/90'
                                : 'bg-red-100/70 dark:bg-red-950/60 hover:bg-red-100/90 dark:hover:bg-red-950/80'
                            }`}
                            title={isHolidayTouched ? 'Click or touch to hide edit options' : 'Touch row to show edit options'}
                          >
                            <div className={`flex items-center ${isHolidayTouched ? 'justify-between' : 'justify-center sm:justify-between'} gap-2 max-w-4xl mx-auto`}>
                              <div className="flex items-center gap-2">
                                <span className="text-[9.5px] sm:text-[10px] font-black uppercase tracking-wider text-red-700 dark:text-red-300">
                                  {holidayText.toUpperCase()}
                                </span>
                                {e.remarks && e.remarks.trim() && e.remarks.toLowerCase() !== holidayText.toLowerCase() ? (
                                  <span className="normal-case text-[9px] font-medium text-red-600/90 dark:text-red-400">
                                    ({e.remarks})
                                  </span>
                                ) : null}
                                {!isHolidayTouched && (
                                  <span className="no-print text-[8.5px] font-normal text-red-500/70 dark:text-red-400/60 hidden group-hover/holiday:inline">
                                    (Touch to edit)
                                  </span>
                                )}
                              </div>

                              {/* Holiday Action Buttons (hidden by default, shown when row is touched/clicked, or hovered on desktop) */}
                              <div
                                className={`no-print items-center gap-1.5 shrink-0 ${
                                  isHolidayTouched
                                    ? 'flex animate-in fade-in duration-150'
                                    : 'hidden sm:group-hover/holiday:flex opacity-0 sm:group-hover/holiday:opacity-100 transition-opacity'
                                }`}
                              >
                                <button
                                  type="button"
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    handleConvertHolidayToWorkingDay(e.date);
                                    setActiveHolidayRowDate(null);
                                  }}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-bold text-emerald-800 dark:text-emerald-200 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/90 dark:hover:bg-emerald-900 border border-emerald-300 dark:border-emerald-700 rounded shadow-2xs transition-all cursor-pointer active:scale-95"
                                  title="Convert this holiday into an active school working day with attendance and meals"
                                >
                                  <Briefcase className="w-3 h-3 text-emerald-700 dark:text-emerald-300" />
                                  <span>Edit Attendance</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    handleEditHolidayReason(e.date, holidayText);
                                    setActiveHolidayRowDate(null);
                                  }}
                                  className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[10.5px] font-medium text-slate-700 dark:text-slate-300 bg-white/90 dark:bg-slate-800/90 hover:bg-white dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded shadow-2xs transition-all cursor-pointer active:scale-95"
                                  title="Edit the name or reason for this holiday"
                                >
                                  <Edit3 className="w-2.5 h-2.5" />
                                  <span>Edit Reason</span>
                                </button>
                                {isHolidayTouched && (
                                  <button
                                    type="button"
                                    onClick={(ev) => {
                                      ev.stopPropagation();
                                      setActiveHolidayRowDate(null);
                                    }}
                                    className="inline-flex items-center justify-center p-1 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 bg-white/70 dark:bg-slate-800/70 hover:bg-white dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded transition-all cursor-pointer"
                                    title="Hide options"
                                    aria-label="Hide options"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </td>
                        </>
                      ) : (e.date > todayStr && !isCustomSaved) ? (
                        <>
                          {/* Roll (Always displayed for all dates!) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Primary Roll"
                          >
                            {dayPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Upper Primary Roll"
                          >
                            {dayUpperPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-950 dark:text-white text-[14px] bg-slate-50/50 dark:bg-slate-800/30 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Roll"
                          >
                            {dayTotalEnrolled}
                          </td>

                          {/* Attendance (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Primary Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Upper Primary Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to enter Meals Served"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-right font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to enter Cooking Cost"
                          >
                            -
                          </td>

                          {/* Rice (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.ob')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Rice Opening Balance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.rec')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Rice Rec"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-blue-100/60 dark:hover:bg-blue-900/40 transition-colors"
                            title="Click to edit Rice Used"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.spoiled')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Rice Spoiled"
                          >
                            -
                          </td>
                          <td
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Rice Closing Balance"
                          >
                            -
                          </td>

                          {/* Egg (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.ob')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Egg Opening Balance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.rec')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Egg Rec"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Egg Used"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.spoiled')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Egg Spoiled"
                          >
                            -
                          </td>
                          <td
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Egg Closing Balance"
                          >
                            -
                          </td>

                          {/* Chikki (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.ob')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Chikki Opening Balance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.rec')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Chikki Rec"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-orange-100/60 dark:hover:bg-orange-900/40 transition-colors"
                            title="Click to edit Chikki Used"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.spoiled')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Chikki Spoiled"
                          >
                            -
                          </td>
                          <td
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Chikki Closing Balance"
                          >
                            -
                          </td>

                          {/* Ragi (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.ob')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Ragi Opening Balance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.rec')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Ragi Rec"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to edit Ragi Used"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.spoiled')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Ragi Spoiled"
                          >
                            -
                          </td>
                          <td
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Ragi Closing Balance"
                          >
                            -
                          </td>

                          {/* Jaggery (Empty for future dates) */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.ob')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Jaggery Opening Balance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.rec')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Jaggery Rec"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-pink-100/60 dark:hover:bg-pink-900/40 transition-colors"
                            title="Click to edit Jaggery Used"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.spoiled')}
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Jaggery Spoiled"
                          >
                            -
                          </td>
                          <td
                            className="p-1 text-center font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Jaggery Closing Balance"
                          >
                            -
                          </td>

                          <td
                            onClick={() => startSingleCellEdit(e.date, 'remarks')}
                            className="p-1 text-slate-400 max-w-xs truncate text-[12px] font-medium cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/50 transition-colors"
                            title="Click to edit remarks"
                          >
                            -
                          </td>
                        </>
                      ) : isZeroMeals ? (
                        <>
                          {/* Roll */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Primary Roll"
                          >
                            {dayPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Upper Primary Roll"
                          >
                            {dayUpperPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-950 dark:text-white text-[14px] bg-slate-50/50 dark:bg-slate-800/30 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Roll"
                          >
                            {dayTotalEnrolled}
                          </td>

                          {/* Attendance */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Primary Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Upper Primary Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to enter Attendance"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-bold border-r border-slate-100 dark:border-slate-800 text-slate-400 text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to enter Meals Served"
                          >
                            -
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-right font-mono text-slate-400 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to enter Cooking Cost"
                          >
                            -
                          </td>

                          {/* Rice */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.ob')}
                            className="p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Rice Opening Balance"
                          >
                            {formatQtyVal(stock.rice.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Rice Rec"
                          >
                            {stock.rice.rec > 0 ? `+${formatQtyVal(stock.rice.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-blue-700 dark:text-blue-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-blue-100/60 dark:hover:bg-blue-900/40 transition-colors"
                            title="Click to edit Rice Used"
                          >
                            {e.riceUsedKg > 0 ? formatQtyVal(e.riceUsedKg) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Rice Spoiled"
                          >
                            {stock.rice.spoiled > 0 ? formatQtyVal(stock.rice.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Rice Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.rice.cb)}
                          </td>

                          {/* Egg */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.ob')}
                            data-field="egg-ob-cell"
                            data-date={e.date}
                            className={`p-1 text-right font-mono font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${(stock.egg?.ob ?? 0) < 0 ? 'text-rose-600 dark:text-rose-400 font-black' : 'text-indigo-700 dark:text-indigo-300'}`}
                            title="Click to edit Egg Opening Balance (OB + Rec - Used - Spoiled = Balance)"
                          >
                            {formatQtyVal(stock.egg?.ob ?? 0)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Egg Rec"
                          >
                            {stock.egg.rec > 0 ? `+${formatQtyVal(stock.egg.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-amber-700 dark:text-amber-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Egg Used"
                          >
                            {e.eggUsedQty > 0 ? formatQtyVal(e.eggUsedQty) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Egg Spoiled"
                          >
                            {stock.egg.spoiled > 0 ? formatQtyVal(stock.egg.spoiled) : '-'}
                          </td>
                          <td
                            className={`p-1 text-right font-mono font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none ${stock.egg.cb < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}
                            title={`Egg Balance = OB (${stock.egg.ob}) + Rec (${stock.egg.rec}) - Used (${e.eggUsedQty}) - Spoils (${stock.egg.spoiled}) = ${formatQtyVal(stock.egg.cb)}`}
                          >
                            {formatQtyVal(stock.egg.cb)}
                          </td>

                          {/* Chikki */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.ob')}
                            data-field="chikki-ob-cell"
                            data-date={e.date}
                            className={`p-1 text-right font-mono font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${(stock.chikki?.ob ?? 0) < 0 ? 'text-rose-600 dark:text-rose-400 font-black' : 'text-indigo-700 dark:text-indigo-300'}`}
                            title="Click to edit Chikki Opening Balance (OB + Rec - Used - Spoiled = Balance)"
                          >
                            {formatQtyVal(stock.chikki?.ob ?? 0)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Chikki Rec"
                          >
                            {stock.chikki.rec > 0 ? `+${formatQtyVal(stock.chikki.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-orange-700 dark:text-orange-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-orange-100/60 dark:hover:bg-orange-900/40 transition-colors"
                            title="Click to edit Chikki Used"
                          >
                            {e.chikkiUsedQty > 0 ? formatQtyVal(e.chikkiUsedQty) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Chikki Spoiled"
                          >
                            {stock.chikki.spoiled > 0 ? formatQtyVal(stock.chikki.spoiled) : '-'}
                          </td>
                          <td
                            className={`p-1 text-right font-mono font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none ${stock.chikki.cb < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}
                            title={`Chikki Balance = OB (${stock.chikki.ob}) + Rec (${stock.chikki.rec}) - Used (${e.chikkiUsedQty}) - Spoils (${stock.chikki.spoiled}) = ${formatQtyVal(stock.chikki.cb)}`}
                          >
                            {formatQtyVal(stock.chikki.cb)}
                          </td>

                          {/* Ragi */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.ob')}
                            className="p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Ragi Opening Balance"
                          >
                            {formatQtyVal(stock.ragi.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Ragi Rec"
                          >
                            {stock.ragi.rec > 0 ? `+${formatQtyVal(stock.ragi.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-purple-700 dark:text-purple-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to edit Ragi Used"
                          >
                            {e.ragiUsedKg > 0 ? formatQtyVal(e.ragiUsedKg) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Ragi Spoiled"
                          >
                            {stock.ragi.spoiled > 0 ? formatQtyVal(stock.ragi.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Ragi Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.ragi.cb)}
                          </td>

                          {/* Jaggery */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.ob')}
                            className="p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors"
                            title="Click to edit Jaggery Opening Balance"
                          >
                            {formatQtyVal(stock.jaggery.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Jaggery Rec"
                          >
                            {stock.jaggery.rec > 0 ? `+${formatQtyVal(stock.jaggery.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-pink-700 dark:text-pink-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-pink-100/60 dark:hover:bg-pink-900/40 transition-colors"
                            title="Click to edit Jaggery Used"
                          >
                            {stock.jaggery.used > 0 ? formatQtyVal(stock.jaggery.used) : (stock.ragi.used > 0 ? formatQtyVal(stock.ragi.used) : (e.jaggeryUsedKg > 0 ? formatQtyVal(e.jaggeryUsedKg) : (e.ragiUsedKg > 0 ? formatQtyVal(e.ragiUsedKg) : '-')))}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Jaggery Spoiled"
                          >
                            {stock.jaggery.spoiled > 0 ? formatQtyVal(stock.jaggery.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Jaggery Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.jaggery.cb)}
                          </td>

                          <td
                            onClick={() => startSingleCellEdit(e.date, 'remarks')}
                            className="p-1 text-slate-400 max-w-xs truncate text-[12px] cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/50 transition-colors"
                            title="Click to edit remarks"
                          >
                            -
                          </td>
                        </>
                      ) : (
                        <>
                          {/* Roll */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Primary Roll"
                          >
                            {dayPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryRoll')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Upper Primary Roll"
                          >
                            {dayUpperPrimaryEnrolled}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryRoll')}
                            className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 text-slate-950 dark:text-white text-[14px] bg-slate-50/50 dark:bg-slate-800/30 cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Roll"
                          >
                            {dayTotalEnrolled}
                          </td>

                          {/* Attendance */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Primary Attendance"
                          >
                            <div>{dayPrimaryAtt}</div>
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'upperPrimaryAttendance')}
                            className="p-1 text-center border-r border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Upper Primary Attendance"
                          >
                            <div>{dayUpperPrimaryAtt}</div>
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 bg-blue-50/40 dark:bg-blue-950/30 text-blue-950 dark:text-blue-200 text-[14px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Attendance"
                          >
                            <div>{dayTotalAtt}</div>
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-center font-black border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 text-[14px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Served Meals"
                          >
                            {e.mealsServed}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'primaryAttendance')}
                            className="p-1 text-right font-mono font-black text-violet-800 dark:text-violet-200 border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to edit Day Cooking Cost (via Attendance)"
                          >
                            {dayCookingCost > 0 ? (
                              <div className="flex flex-col items-end">
                                <span>₹{dayCookingCost.toFixed(2)}</span>
                                {typeof e.customCookingCost === 'number' ? (
                                  <span className="text-[8.5px] bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200 px-1 py-0 rounded font-black uppercase tracking-tighter">
                                    Fixed
                                  </span>
                                ) : e.primaryRatePerMeal || e.upperPrimaryRatePerMeal ? (
                                  <span className="text-[8.5px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 px-1 py-0 rounded font-bold">
                                    Norms
                                  </span>
                                ) : null}
                              </div>
                            ) : '-'}
                          </td>

                          {/* Rice */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.ob')}
                            className={`p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${
                              isFirstWorkingDay ? 'bg-indigo-50/60 dark:bg-indigo-950/40 font-black' : ''
                            }`}
                            title={
                              isFirstWorkingDay
                                ? `Rice 1st Working Day OB: ${formatQtyVal(stock.rice.ob)} Kg (Click to edit Opening Balance)`
                                : `Rice OB: ${formatQtyVal(stock.rice.ob)} Kg (Click to edit Opening Balance)`
                            }
                          >
                            {formatQtyVal(stock.rice.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Rice Received"
                          >
                            {stock.rice.rec > 0 ? `+${formatQtyVal(stock.rice.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-blue-700 dark:text-blue-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-blue-100/60 dark:hover:bg-blue-900/40 transition-colors"
                            title="Click to edit Rice consumption (via Served Meals)"
                          >
                            {e.riceUsedKg > 0 ? formatQtyVal(e.riceUsedKg) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'rice.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Rice Spoiled"
                          >
                            {stock.rice.spoiled > 0 ? formatQtyVal(stock.rice.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Rice Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.rice.cb)}
                          </td>

                          {/* Egg */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.ob')}
                            className={`p-1 text-right font-mono font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${
                              stock.egg.ob < 0 ? 'text-rose-600 dark:text-rose-400 font-black' : 'text-indigo-700 dark:text-indigo-300'
                            } ${isFirstWorkingDay ? 'bg-indigo-50/60 dark:bg-indigo-950/40 font-black' : ''}`}
                            title={
                              isFirstWorkingDay
                                ? `Egg 1st Working Day OB: ${formatQtyVal(stock.egg.ob)} (Click to edit Opening Balance)`
                                : `Egg OB: ${formatQtyVal(stock.egg.ob)} (Click to edit Opening Balance)`
                            }
                          >
                            {formatQtyVal(stock.egg.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Egg Received"
                          >
                            {stock.egg.rec > 0 ? `+${formatQtyVal(stock.egg.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-amber-700 dark:text-amber-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-amber-100/60 dark:hover:bg-amber-900/40 transition-colors"
                            title="Click to edit Egg consumption (via Served Meals)"
                          >
                            {e.eggUsedQty > 0 ? formatQtyVal(e.eggUsedQty) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'egg.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Egg Spoiled"
                          >
                            {stock.egg.spoiled > 0 ? formatQtyVal(stock.egg.spoiled) : '-'}
                          </td>
                          <td
                            className={`p-1 text-right font-mono font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none ${stock.egg.cb < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}
                            title="Calculated Egg Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.egg.cb)}
                          </td>

                          {/* Chikki */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.ob')}
                            className={`p-1 text-right font-mono font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${
                              stock.chikki.ob < 0 ? 'text-rose-600 dark:text-rose-400 font-black' : 'text-indigo-700 dark:text-indigo-300'
                            } ${isFirstWorkingDay ? 'bg-indigo-50/60 dark:bg-indigo-950/40 font-black' : ''}`}
                            title={
                              isFirstWorkingDay
                                ? `Chikki 1st Working Day OB: ${formatQtyVal(stock.chikki.ob)} (Click to edit Opening Balance)`
                                : `Chikki OB: ${formatQtyVal(stock.chikki.ob)} (Click to edit Opening Balance)`
                            }
                          >
                            {formatQtyVal(stock.chikki.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Chikki Received"
                          >
                            {stock.chikki.rec > 0 ? `+${formatQtyVal(stock.chikki.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-orange-700 dark:text-orange-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-orange-100/60 dark:hover:bg-orange-900/40 transition-colors"
                            title="Click to edit Chikki consumption (via Served Meals)"
                          >
                            {e.chikkiUsedQty > 0 ? formatQtyVal(e.chikkiUsedQty) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'chikki.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Chikki Spoiled"
                          >
                            {stock.chikki.spoiled > 0 ? formatQtyVal(stock.chikki.spoiled) : '-'}
                          </td>
                          <td
                            className={`p-1 text-right font-mono font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none ${stock.chikki.cb < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}
                            title="Calculated Chikki Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.chikki.cb)}
                          </td>

                          {/* Ragi */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.ob')}
                            className={`p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${
                              isFirstWorkingDay ? 'bg-indigo-50/60 dark:bg-indigo-950/40 font-black' : ''
                            }`}
                            title={
                              isFirstWorkingDay
                                ? `Ragi 1st Working Day OB: ${formatQtyVal(stock.ragi.ob)} Kg (Click to edit Opening Balance)`
                                : `Ragi OB: ${formatQtyVal(stock.ragi.ob)} Kg (Click to edit Opening Balance)`
                            }
                          >
                            {formatQtyVal(stock.ragi.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Ragi Received"
                          >
                            {stock.ragi.rec > 0 ? `+${formatQtyVal(stock.ragi.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-purple-700 dark:text-purple-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-purple-100/60 dark:hover:bg-purple-900/40 transition-colors"
                            title="Click to edit Ragi consumption (via Served Meals)"
                          >
                            {e.ragiUsedKg > 0 ? formatQtyVal(e.ragiUsedKg) : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'ragi.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Ragi Spoiled"
                          >
                            {stock.ragi.spoiled > 0 ? formatQtyVal(stock.ragi.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Ragi Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.ragi.cb)}
                          </td>

                          {/* Jaggery */}
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.ob')}
                            className={`p-1 text-right font-mono text-indigo-700 dark:text-indigo-300 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-indigo-100/60 dark:hover:bg-indigo-900/40 transition-colors ${
                              isFirstWorkingDay ? 'bg-indigo-50/60 dark:bg-indigo-950/40 font-black' : ''
                            }`}
                            title={
                              isFirstWorkingDay
                                ? `Jaggery 1st Working Day OB: ${formatQtyVal(stock.jaggery.ob)} Kg (Click to edit Opening Balance)`
                                : `Jaggery OB: ${formatQtyVal(stock.jaggery.ob)} Kg (Click to edit Opening Balance)`
                            }
                          >
                            {formatQtyVal(stock.jaggery.ob)}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.rec')}
                            className="p-1 text-right font-mono border-r border-slate-100 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 font-black text-[13.5px] cursor-pointer hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-colors"
                            title="Click to edit Jaggery Received"
                          >
                            {stock.jaggery.rec > 0 ? `+${formatQtyVal(stock.jaggery.rec)}` : '-'}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'mealsServed')}
                            className="p-1 text-right font-mono text-pink-700 dark:text-pink-300 font-black border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-pink-100/60 dark:hover:bg-pink-900/40 transition-colors"
                            title="Click to edit Jaggery consumption (via Served Meals)"
                          >
                            {stock.jaggery.used > 0 ? formatQtyVal(stock.jaggery.used) : (stock.ragi.used > 0 ? formatQtyVal(stock.ragi.used) : (e.jaggeryUsedKg > 0 ? formatQtyVal(e.jaggeryUsedKg) : (e.ragiUsedKg > 0 ? formatQtyVal(e.ragiUsedKg) : '-')))}
                          </td>
                          <td
                            onClick={() => startSingleCellEdit(e.date, 'jaggery.spoiled')}
                            className="p-1 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-100 dark:border-slate-800 text-[13.5px] cursor-pointer hover:bg-rose-100/60 dark:hover:bg-rose-900/40 transition-colors"
                            title="Click to edit Jaggery Spoiled"
                          >
                            {stock.jaggery.spoiled > 0 ? formatQtyVal(stock.jaggery.spoiled) : '-'}
                          </td>
                          <td
                            className="p-1 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-100 dark:border-slate-800 text-[13.5px] select-none"
                            title="Calculated Jaggery Closing Balance (= OB + Rec - Used - Spoiled)"
                          >
                            {formatQtyVal(stock.jaggery.cb)}
                          </td>

                          <td
                            onClick={() => startSingleCellEdit(e.date, 'remarks')}
                            className="p-1 text-slate-600 dark:text-slate-400 max-w-xs text-[12px] font-medium cursor-pointer hover:bg-slate-200/60 dark:hover:bg-slate-700/50 transition-colors"
                            title="Click to edit remarks"
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className="truncate">{e.remarks || '-'}</span>
                              {dayInfo.isWorkingDayOverride ? (
                                <button
                                  type="button"
                                  onClick={(ev) => {
                                    ev.stopPropagation();
                                    handleRevertWorkingDayToHoliday(e.date);
                                  }}
                                  className="no-print text-[9.5px] font-bold text-amber-800 dark:text-amber-200 bg-amber-100 dark:bg-amber-950/80 hover:bg-amber-200 dark:hover:bg-amber-900 px-1.5 py-0.5 rounded border border-amber-300 dark:border-amber-700 shadow-2xs transition-colors shrink-0 cursor-pointer"
                                  title="Revert back to Holiday"
                                >
                                  Revert to Holiday
                                </button>
                              ) : null}
                            </div>
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
            {displayedEntries.length > 0 && (
              <tfoot className="bg-slate-100 dark:bg-slate-800 font-extrabold border-t-2 border-slate-300 dark:border-slate-700 text-[14px] sm:text-[15px]">
                <tr>
                  {/* S.No, Date, Day */}
                  <td
                    colSpan={isTableScrolledX ? 2 : 3}
                    style={{
                      width: isTableScrolledX ? '72px' : '129px',
                      ...(freezeLeft ? { left: 0 } : {}),
                    }}
                    className={`${
                      freezeLeft ? 'sticky left-0 z-20 shadow-[2px_0_4px_-1px_rgba(0,0,0,0.12)]' : ''
                    } bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-black border-r-2 border-slate-300 dark:border-slate-700 transition-all duration-300 ease-in-out ${
                      isTableScrolledX ? 'p-1 text-[10.5px] text-center' : 'p-2 text-[13.5px]'
                    }`}
                  >
                    {isTableScrolledX ? 'TOTALS' : 'MONTHLY TOTALS'}
                  </td>

                  {/* Roll (Enrolled) Sub-cols: Pri, Up.Pri, Total */}
                  <td className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 text-slate-400 font-bold bg-slate-50/50 dark:bg-slate-800/50">-</td>
                  <td className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 text-slate-400 font-bold bg-slate-50/50 dark:bg-slate-800/50">-</td>
                  <td className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 text-slate-400 font-bold bg-indigo-50/30 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200">-</td>

                  {/* Attendance Sub-cols: Pri, Up.Pri, Total */}
                  <td className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-bold">
                    <div>{totalPrimaryAttendance}</div>
                  </td>
                  <td className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-bold">
                    <div>{totalUpperPrimaryAttendance}</div>
                  </td>
                  <td className="p-1.5 text-center font-black border-r border-slate-200 dark:border-slate-700 bg-blue-50/30 dark:bg-blue-950/30 text-blue-950 dark:text-blue-200">
                    <div>{totalAttendance}</div>
                  </td>

                  {/* Meals Served */}
                  <td className="p-1.5 text-center font-black text-emerald-700 dark:text-emerald-300 border-r border-slate-200 dark:border-slate-700">{totalMealsServed}</td>

                  {/* Expenditure / Day */}
                  <td className="p-1.5 text-right font-mono font-black text-violet-800 dark:text-violet-200 border-r border-slate-200 dark:border-slate-700">₹{totalCookingCost.toFixed(2)}</td>

                  {/* Rice Sub-cols: OB, Rec, Used, Spoils, Bal */}
                  <td
                    className="p-1.5 text-right font-mono font-bold text-indigo-700 dark:text-indigo-300 border-r border-slate-200 dark:border-slate-700 bg-indigo-50/20 dark:bg-indigo-950/20"
                    title={`Present Month Rice Opening Balance: ${formatQtyVal(monthStartRiceOB)} Kg (Auto-carried forward from ${prevMonthLabel} Total Row Closing Balance: ${formatQtyVal(prevRiceCB)} Kg)`}
                  >
                    {formatQtyVal(monthStartRiceOB)}
                  </td>
                  <td className="p-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300 font-black border-r border-slate-200 dark:border-slate-700">{totalRiceRec > 0 ? `+${formatQtyVal(totalRiceRec)}` : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-blue-700 dark:text-blue-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(totalRiceUsed)}</td>
                  <td className="p-1.5 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-200 dark:border-slate-700">{totalRiceSpoils > 0 ? formatQtyVal(totalRiceSpoils) : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(monthEndRiceCB)}</td>

                  {/* Egg Sub-cols: OB, Rec, Used, Spoils, Bal */}
                  <td
                    className="p-1.5 text-right font-mono font-bold text-indigo-700 dark:text-indigo-300 border-r border-slate-200 dark:border-slate-700 bg-indigo-50/20 dark:bg-indigo-950/20"
                    title={`Present Month Eggs Opening Balance: ${formatQtyVal(monthStartEggOB)} (Auto-carried forward from ${prevMonthLabel} Total Row Closing Balance: ${formatQtyVal(prevEggCB)})`}
                  >
                    {formatQtyVal(monthStartEggOB)}
                  </td>
                  <td className="p-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300 font-black border-r border-slate-200 dark:border-slate-700">{totalEggRec > 0 ? `+${formatQtyVal(totalEggRec)}` : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-amber-700 dark:text-amber-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(totalEggUsed)}</td>
                  <td className="p-1.5 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-200 dark:border-slate-700">{totalEggSpoils > 0 ? formatQtyVal(totalEggSpoils) : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(monthEndEggCB)}</td>

                  {/* Chikki Sub-cols: OB, Rec, Used, Spoils, Bal */}
                  <td
                    className="p-1.5 text-right font-mono font-bold text-indigo-700 dark:text-indigo-300 border-r border-slate-200 dark:border-slate-700 bg-indigo-50/20 dark:bg-indigo-950/20"
                    title={`Present Month Chikki Opening Balance: ${formatQtyVal(monthStartChikkiOB)} (Auto-carried forward from ${prevMonthLabel} Total Row Closing Balance: ${formatQtyVal(prevChikkiCB)})`}
                  >
                    {formatQtyVal(monthStartChikkiOB)}
                  </td>
                  <td className="p-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300 font-black border-r border-slate-200 dark:border-slate-700">{totalChikkiRec > 0 ? `+${formatQtyVal(totalChikkiRec)}` : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-orange-700 dark:text-orange-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(totalChikkiUsed)}</td>
                  <td className="p-1.5 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-200 dark:border-slate-700">{totalChikkiSpoils > 0 ? formatQtyVal(totalChikkiSpoils) : '-'}</td>
                  <td className={`p-1.5 text-right font-mono font-black border-r border-slate-200 dark:border-slate-700 ${monthEndChikkiCB < 0 ? 'text-rose-700 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}>{formatQtyVal(monthEndChikkiCB)}</td>

                  {/* Ragi Sub-cols: OB, Rec, Used, Spoils, Bal */}
                  <td
                    className="p-1.5 text-right font-mono font-bold text-indigo-700 dark:text-indigo-300 border-r border-slate-200 dark:border-slate-700 bg-indigo-50/20 dark:bg-indigo-950/20"
                    title={`Present Month Ragi Opening Balance: ${formatQtyVal(monthStartRagiOB)} Kg (Auto-carried forward from ${prevMonthLabel} Total Row Closing Balance: ${formatQtyVal(prevRagiCB)} Kg)`}
                  >
                    {formatQtyVal(monthStartRagiOB)}
                  </td>
                  <td className="p-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300 font-black border-r border-slate-200 dark:border-slate-700">{totalRagiRec > 0 ? `+${formatQtyVal(totalRagiRec)}` : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-purple-700 dark:text-purple-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(totalRagiUsed)}</td>
                  <td className="p-1.5 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-200 dark:border-slate-700">{totalRagiSpoils > 0 ? formatQtyVal(totalRagiSpoils) : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(monthEndRagiCB)}</td>

                  {/* Jaggery Sub-cols: OB, Rec, Used, Spoils, Bal */}
                  <td
                    className="p-1.5 text-right font-mono font-bold text-indigo-700 dark:text-indigo-300 border-r border-slate-200 dark:border-slate-700 bg-indigo-50/20 dark:bg-indigo-950/20"
                    title={`Present Month Jaggery Opening Balance: ${formatQtyVal(monthStartJaggeryOB)} Kg (Auto-carried forward from ${prevMonthLabel} Total Row Closing Balance: ${formatQtyVal(prevJaggeryCB)} Kg)`}
                  >
                    {formatQtyVal(monthStartJaggeryOB)}
                  </td>
                  <td className="p-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300 font-black border-r border-slate-200 dark:border-slate-700">{totalJaggeryRec > 0 ? `+${formatQtyVal(totalJaggeryRec)}` : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-pink-700 dark:text-pink-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(totalJaggeryUsed)}</td>
                  <td className="p-1.5 text-right font-mono text-rose-600 dark:text-rose-400 font-bold border-r border-slate-200 dark:border-slate-700">{totalJaggerySpoils > 0 ? formatQtyVal(totalJaggerySpoils) : '-'}</td>
                  <td className="p-1.5 text-right font-mono font-black text-cyan-800 dark:text-cyan-300 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(monthEndJaggeryCB)}</td>

                  {/* Remarks */}
                  <td className="p-1.5 text-slate-500 text-center font-bold">-</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Official Signature Blocks for Print (Visible on print) */}
        <div className="hidden print:block official-print-signatures p-2 sm:p-4 mt-2 sm:mt-4 border-t-2 border-slate-900 font-sans text-slate-900">
          <div className="flex justify-end text-center text-[9px] font-bold">
            <div className="flex flex-col justify-end items-center h-12 sm:h-16 w-56">
              <div className="w-3/4 border-t border-slate-900 mb-1"></div>
              <div>Headmaster / Principal</div>
              <div className="text-[8px] font-normal text-slate-600">(Signature & School Stamp)</div>
            </div>
          </div>
        </div>

        {/* Reserved Clean Bottom Clearance Space for Ads in Monthly Register */}
        <div
          id="monthly-register-bottom-ad-spacer"
          className="no-print w-full h-14 sm:h-16 md:h-20 lg:h-24 shrink-0 pointer-events-none select-none transition-all duration-300"
          style={{ minHeight: 'calc(3.84rem + env(safe-area-inset-bottom, 0px))' }}
          aria-hidden="true"
        />
      </div>

      {/* Opening Balance Modal */}
      <OpeningBalanceModal
        isOpen={showOpeningModal}
        onClose={() => setShowOpeningModal(false)}
        commodities={commodities}
        baseCommodities={baseCommodities}
        dailyEntries={dailyEntries}
        stockTransactions={stockTransactions}
        selectedMonth={selectedMonth}
        monthlyOverrides={monthlyOverrides}
        onSaveOpeningBalances={onSaveOpeningBalances}
        onSaveMonthlyBalances={onSaveMonthlyBalances}
        onResetMonthlyOverride={onResetMonthlyOverride}
      />

      {/* Expenditure & Cooking Cost Norms Modal */}
      {showMealRatesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in no-print font-sans">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full p-5 sm:p-6 space-y-5 text-slate-900 dark:text-slate-100 relative">
            <button
              onClick={() => setShowMealRatesModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-500/10 dark:bg-purple-500/20 rounded-xl text-purple-600 dark:text-purple-400">
                <IndianRupee className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black uppercase tracking-wide">
                  Expenditure & Cooking Cost Norms (₹)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Configure school-wide cooking cost per student and special item rate norms.
                </p>
              </div>
            </div>

            {/* Quick Actions & Reset Button */}
            <div className="flex items-center justify-between bg-purple-50/60 dark:bg-purple-950/30 p-3 rounded-xl border border-purple-200 dark:border-purple-800/40">
              <span className="text-xs font-bold text-purple-900 dark:text-purple-200">
                Standard AP MDM Government Rates
              </span>
              <button
                type="button"
                onClick={() => {
                  setRawEditingRates({
                    primaryRatePerMeal: '5.45',
                    upperPrimaryRatePerMeal: '8.17',
                    highSchoolRatePerMeal: '8.17',
                    eggRate: '6.00',
                    chikkiRate: '5.00',
                    ragiRatePerKg: '35.00',
                    jaggeryRatePerKg: '60.00',
                  });
                  setEditingMealRates({
                    ...editingMealRates,
                    primaryRatePerMeal: 5.45,
                    upperPrimaryRatePerMeal: 8.17,
                    highSchoolRatePerMeal: 8.17,
                    eggRate: 6.00,
                    chikkiRate: 5.00,
                    ragiRatePerKg: 35.00,
                    jaggeryRatePerKg: 60.00,
                  });
                }}
                className="px-2.5 py-1 text-xs font-bold bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 hover:bg-purple-600 hover:text-white rounded-lg border border-purple-300 dark:border-purple-700 transition-all cursor-pointer flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset to AP Norms</span>
              </button>
            </div>

            {/* Grid Form Fields */}
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              {/* Cooking Cost Per Meal */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide block">
                  1. Per-Student Cooking Cost Norms (₹)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Primary (Class 1-5) Rate:
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.primaryRatePerMeal ?? String(editingMealRates.primaryRatePerMeal ?? 5.45)}
                        onChange={(e) => handleUpdateEditingRate('primaryRatePerMeal', e.target.value)}
                        className="w-full px-2.5 py-1 text-sm font-black bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-indigo-700 dark:text-indigo-300 font-mono"
                      />
                      <span className="text-[11px] text-slate-400">/child</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Upper Primary (Class 6-8) Rate:
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.upperPrimaryRatePerMeal ?? String(editingMealRates.upperPrimaryRatePerMeal ?? 8.17)}
                        onChange={(e) => handleUpdateEditingRate('upperPrimaryRatePerMeal', e.target.value)}
                        className="w-full px-2.5 py-1 text-sm font-black bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-purple-700 dark:text-purple-300 font-mono"
                      />
                      <span className="text-[11px] text-slate-400">/child</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Special Menu Items */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide block">
                  2. Supplementary & Special Menu Rates (₹)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-amber-800 dark:text-amber-300 mb-1">
                      🥚 Egg Rate:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.eggRate ?? String(editingMealRates.eggRate ?? 6.00)}
                        onChange={(e) => handleUpdateEditingRate('eggRate', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded text-amber-900 dark:text-amber-200 font-mono"
                      />
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-orange-800 dark:text-orange-300 mb-1">
                      🥜 Chikki Rate:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.chikkiRate ?? String(editingMealRates.chikkiRate ?? 5.00)}
                        onChange={(e) => handleUpdateEditingRate('chikkiRate', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-orange-300 dark:border-orange-700 rounded text-orange-900 dark:text-orange-200 font-mono"
                      />
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-purple-800 dark:text-purple-300 mb-1">
                      🥣 Ragi / kg:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.ragiRatePerKg ?? String(editingMealRates.ragiRatePerKg ?? 35.00)}
                        onChange={(e) => handleUpdateEditingRate('ragiRatePerKg', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-purple-300 dark:border-purple-700 rounded text-purple-900 dark:text-purple-200 font-mono"
                      />
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-pink-800 dark:text-pink-300 mb-1">
                      🍯 Jaggery / kg:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawEditingRates.jaggeryRatePerKg ?? String(editingMealRates.jaggeryRatePerKg ?? 60.00)}
                        onChange={(e) => handleUpdateEditingRate('jaggeryRatePerKg', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-pink-300 dark:border-pink-700 rounded text-pink-900 dark:text-pink-200 font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowMealRatesModal(false)}
                className="glass-3d-btn px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onUpdateMealRates) {
                    onUpdateMealRates(editingMealRates);
                  }
                  setShowMealRatesModal(false);
                  showToast('Expenditure norms and meal rates updated successfully!');
                }}
                className="btn-3d-glass-purple px-4 py-2 rounded-xl text-xs font-black shadow-md transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Norms</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF & Landscape Print Guidance Modal */}
      {showPdfGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-fade-in no-print">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full p-6 space-y-5 text-slate-900 dark:text-slate-100 relative">
            <button
              onClick={() => setShowPdfGuideModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-purple-500/10 dark:bg-purple-500/20 rounded-xl text-purple-600 dark:text-purple-400">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black uppercase tracking-wide">
                  Print or Save Monthly Register as PDF
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Fits all 37 day-by-day columns cleanly across standard A4 Landscape sheet.
                </p>
              </div>
            </div>

            <div className="space-y-3 bg-purple-50/50 dark:bg-purple-950/20 p-4 rounded-xl border border-purple-200/60 dark:border-purple-800/40 text-xs">
              <div className="flex items-start space-x-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] shrink-0 mt-0.5">1</span>
                <div>
                  <strong className="font-bold text-purple-950 dark:text-purple-200">A4 Landscape Preset Active:</strong>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">The print layout automatically formats all 37 register columns for 297mm A4 Landscape paper width.</p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] shrink-0 mt-0.5">2</span>
                <div>
                  <strong className="font-bold text-purple-950 dark:text-purple-200">Select "Save as PDF" Destination:</strong>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">In your browser's print dialog, change "Destination" to <strong>Save as PDF</strong> (or select your printer).</p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] shrink-0 mt-0.5">3</span>
                <div>
                  <strong className="font-bold text-purple-950 dark:text-purple-200">Verify Layout Settings:</strong>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">Ensure <strong>Layout = Landscape</strong> and <strong>Margins = Default / Minimum</strong> for optimal full-page coverage.</p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] shrink-0 mt-0.5">4</span>
                <div>
                  <strong className="font-bold text-purple-950 dark:text-purple-200">Enable Background Colors:</strong>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">Check <strong>"Background graphics"</strong> to print styled column highlights and totals accurately.</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowPdfGuideModal(false)}
                className="glass-3d-btn px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setShowPdfGuideModal(false);
                  onPrintRegister('landscape');
                }}
                className="btn-glass-pdf"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Open Print / Save PDF Window</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Interactive A4 Sheet Print Preview Modal Overlay */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 text-slate-100 overflow-hidden animate-fade-in no-print font-sans select-none">
          {/* Top Control Header Bar */}
          <div className="bg-slate-900 border-b border-slate-800 px-3 sm:px-6 py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-2.5 shrink-0 shadow-xl relative z-20">
            {/* Title & Info */}
            <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
              <div className="min-w-0">
                <p className="text-xs sm:text-sm font-bold text-white truncate">
                  {monthLabel} — {schoolProfile.schoolName} (UDISE: {schoolProfile.udiseCode})
                </p>
              </div>
            </div>

            {/* Middle Controls: Orientation, Margin Guide & Zoom */}
            <div className="flex items-center flex-wrap gap-1 sm:gap-1.5 md:gap-2 bg-slate-950/60 p-1 sm:p-1.5 rounded-lg sm:rounded-xl border border-slate-800">
              {/* Orientation Selector */}
              <div className="flex items-center bg-slate-800 rounded-xs sm:rounded-md md:rounded-lg p-0.5 border border-slate-700">
                <button
                  type="button"
                  onClick={() => setPreviewOrientation('landscape')}
                  className={`px-1 sm:px-1.5 md:px-2.5 py-0 sm:py-0.5 md:py-1 rounded-xs sm:rounded-md text-[8px] sm:text-[9.5px] md:text-[10.5px] font-bold transition-all cursor-pointer ${
                    previewOrientation === 'landscape'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="ISO 216 Standard A4 Landscape (297 × 210 mm) - Recommended for 37 Columns"
                >
                  A4 Landscape
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewOrientation('portrait')}
                  className={`px-1 sm:px-1.5 md:px-2.5 py-0 sm:py-0.5 md:py-1 rounded-xs sm:rounded-md text-[8px] sm:text-[9.5px] md:text-[10.5px] font-bold transition-all cursor-pointer ${
                    previewOrientation === 'portrait'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="A4 Portrait (210 × 297 mm)"
                >
                  A4 Portrait
                </button>
              </div>

              {/* Margin Guide Toggle */}
              <button
                type="button"
                onClick={() => setShowMarginGuides(!showMarginGuides)}
                className={`px-1 sm:px-1.5 md:px-2.5 py-0 sm:py-0.5 md:py-1 rounded-xs sm:rounded-md md:rounded-lg text-[8px] sm:text-[9.5px] md:text-[10.5px] font-bold border transition-all cursor-pointer flex items-center gap-0.5 sm:gap-1 ${
                  showMarginGuides
                    ? 'bg-emerald-950/60 text-emerald-300 border-emerald-600/50'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                }`}
                title="Toggle 3mm safe printable margin guide boundary"
              >
                <span>3mm Margins:</span>
                <span className="font-mono font-extrabold">{showMarginGuides ? 'ON' : 'OFF'}</span>
              </button>

              {/* Zoom Controls */}
              <div className="flex items-center space-x-0.5 sm:space-x-1 border-l border-slate-800 pl-0.5 sm:pl-1.5">
                <button
                  type="button"
                  onClick={() => setPreviewZoom((z) => Math.max(40, z - 10))}
                  className="p-0.5 sm:p-1 md:p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xs sm:rounded-md transition-all cursor-pointer"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </button>
                <span className="text-[8.5px] sm:text-[10px] md:text-xs font-mono font-bold text-indigo-300 px-0.5 sm:px-1 min-w-[28px] sm:min-w-[34px] md:min-w-[40px] text-center">
                  {previewZoom}%
                </span>
                <button
                  type="button"
                  onClick={() => setPreviewZoom((z) => Math.min(160, z + 10))}
                  className="p-0.5 sm:p-1 md:p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xs sm:rounded-md transition-all cursor-pointer"
                  title="Zoom In"
                >
                  <ZoomIn className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewZoom(100)}
                  className="px-1 sm:px-1.5 md:px-2 py-0 sm:py-0.5 text-[8px] sm:text-[9px] md:text-[10px] font-bold text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xs sm:rounded-md transition-all cursor-pointer"
                  title="Reset Zoom to 100% (1:1 Physical Scale)"
                >
                  100%
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewZoom(80)}
                  className="px-1 sm:px-1.5 md:px-2 py-0 sm:py-0.5 text-[8px] sm:text-[9px] md:text-[10px] font-bold text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xs sm:rounded-md transition-all cursor-pointer"
                  title="Fit to Screen"
                >
                  Fit
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-1 sm:space-x-1.5 md:space-x-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  onPrintRegister(previewOrientation);
                }}
                className="btn-glass-pdf cursor-pointer shadow-lg shadow-emerald-500/20 flex items-center gap-0.5 sm:gap-1.5 px-1.5 sm:px-2.5 md:px-3 py-0 sm:py-0.5 md:py-1 rounded-sm sm:rounded-md md:rounded-lg text-[7.5px] sm:text-[9px] md:text-xs font-bold h-5 sm:h-6 md:h-8"
              >
                <Printer className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                <span>Print / Save PDF (1-Page)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowPrintPreview(false)}
                className="btn-3d-glass-rose cursor-pointer active:scale-95 px-1.5 sm:px-2.5 md:px-3 py-0 sm:py-0.5 md:py-1 rounded-sm sm:rounded-md md:rounded-lg text-[7.5px] sm:text-[9px] md:text-xs font-bold flex items-center gap-0.5 sm:gap-1.5 h-5 sm:h-6 md:h-8"
                title="Exit Print Preview"
                aria-label="Exit Print Preview"
              >
                <LogOut className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-3.5 md:h-3.5" />
                <span>Exit</span>
              </button>
            </div>
          </div>

          {/* Interactive Workspace with Virtual A4 Paper Canvas */}
          <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center items-start bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:20px_20px] bg-slate-950">
            {/* Real Virtual Paper Container */}
            <div
              style={{
                width: previewOrientation === 'landscape' ? '1122.5px' : '793.7px',
                minHeight: previewOrientation === 'landscape' ? '793.7px' : '1122.5px',
                aspectRatio: previewOrientation === 'landscape' ? '297 / 210' : '210 / 297',
                transform: `scale(${previewZoom / 100})`,
                transformOrigin: 'top center',
              }}
              className="bg-white text-slate-900 shadow-[0_25px_60px_rgba(0,0,0,0.8),0_0_0_1px_rgba(0,0,0,0.15)] rounded-xs p-3 sm:p-3.5 border border-slate-300 font-sans transition-all my-2 relative select-text"
            >
              {/* 3mm Safe Printable Margin Guide (Simulated when ON) */}
              {showMarginGuides && (
                <div
                  className="absolute inset-[11px] pointer-events-none border border-dashed border-emerald-500/40 rounded-xs z-30"
                  title="3mm Safe Printable Boundary"
                >
                  <span className="absolute -top-2 left-4 px-1.5 py-0.2 bg-emerald-100 text-emerald-800 text-[8px] font-mono font-bold uppercase rounded-xs border border-emerald-300">
                    3mm Safe Margin Boundary
                  </span>
                </div>
              )}

              {/* Paper Watermark Badge */}
              <div className="absolute top-1.5 right-3 text-[8.5px] font-mono text-slate-400 font-bold uppercase tracking-widest pointer-events-none select-none opacity-70">
                Official A4 {previewOrientation} Sheet (1-Page)
              </div>

              {/* Official Department Header */}
              <div className="border-b-1.5 border-slate-900 pb-1.5 mb-1.5 text-slate-900">
                <div className="flex items-start justify-between">
                  <div>
                    <h1 className="text-[10px] font-black uppercase tracking-wider text-slate-900 leading-tight">
                      SCHOOL EDUCATION DEPARTMENT
                    </h1>
                    <h2 className="text-[13px] font-black text-purple-950 uppercase tracking-tight leading-tight mt-0.5">
                      MID DAY MEAL (MDM) / PM-POSHAN MONTHLY CONSOLIDATED REGISTER
                    </h2>
                    <div className="text-[9.5px] font-bold text-slate-800 mt-0.5 flex flex-wrap gap-x-3 leading-tight">
                      <span>School: <strong className="text-slate-950 font-extrabold">{schoolProfile.schoolName}</strong></span>
                      <span>UDISE: <strong className="text-slate-950 font-extrabold">{schoolProfile.udiseCode}</strong></span>
                      {schoolProfile.mandal && <span>Mandal: <strong className="text-slate-950 font-extrabold">{schoolProfile.mandal}</strong></span>}
                      {schoolProfile.district && <span>District: <strong className="text-slate-950 font-extrabold">{schoolProfile.district}</strong></span>}
                      <span>Month: <strong className="text-purple-900 font-extrabold">{monthLabel}</strong></span>
                    </div>
                  </div>

                  <div className="text-right text-[8.5px] font-bold border-l-1.5 border-slate-900 pl-2 bg-purple-50/80 p-1 rounded-xs leading-tight">
                    <div>Working Days: <strong className="text-purple-950 font-black">{workingDays} Days</strong></div>
                    <div>Attn: <strong className="text-blue-950 font-black">{totalAttendance}</strong> | Served: <strong className="text-emerald-950 font-black">{totalMealsServed}</strong></div>
                    <div>Not Served: <strong className="text-rose-700 font-black">{Math.max(0, totalAttendance - totalMealsServed)}</strong></div>
                    <div>Total Cooking Cost: <strong className="text-purple-950 font-black">{formatCurrency(grandTotalAmount)}</strong></div>
                  </div>
                </div>
              </div>

              {/* Full 37-Column Day-by-Day Table */}
              <div className="w-full border border-slate-300 rounded-none mb-1.5">
                <table className="w-full text-left border-collapse text-[9.2px] leading-tight" style={{ tableLayout: 'fixed' }}>
                  <thead>
                    <tr className="bg-slate-200 text-slate-950 font-extrabold border-b border-slate-300 uppercase text-[9px]">
                      <th rowSpan={2} className="p-0.5 border-r border-slate-300 text-center w-[22px]" style={{ fontSize: '8.5px' }}>S.No</th>
                      <th rowSpan={2} className="p-0.5 border-r border-slate-300 text-center w-[48px]" style={{ fontSize: '12px' }}>Date</th>
                      <th rowSpan={2} className="p-0.5 border-r border-slate-300 text-center w-[22px]" style={{ fontSize: '12px' }}>Day</th>
                      <th colSpan={3} className="p-0.5 border-r border-slate-300 text-center bg-indigo-100 text-indigo-950 font-black">Roll (Enrolled)</th>
                      <th colSpan={3} className="p-0.5 border-r border-slate-300 text-center bg-blue-100 text-blue-950 font-black">Attendance</th>
                      <th rowSpan={2} className="p-0.5 border-r border-slate-300 text-center bg-emerald-100 text-emerald-950 font-black w-[34px]">Meals Served</th>
                      <th rowSpan={2} className="p-0.5 border-r border-slate-300 text-center bg-emerald-200 text-emerald-950 font-black leading-tight w-[50px]">
                        <div>Exp / Day</div>
                        <div className="text-[7.5px] font-bold normal-case text-slate-800">₹ Norm</div>
                      </th>
                      <th colSpan={5} className="p-0.5 border-r border-slate-300 text-center bg-amber-100 text-amber-950 font-black">Rice (Kg)</th>
                      <th colSpan={5} className="p-0.5 border-r border-slate-300 text-center bg-yellow-100 text-yellow-950 font-black">Egg (Pcs)</th>
                      <th colSpan={5} className="p-0.5 border-r border-slate-300 text-center bg-orange-100 text-orange-950 font-black">Chikki (Pcs)</th>
                      <th colSpan={5} className="p-0.5 border-r border-slate-300 text-center bg-purple-100 text-purple-950 font-black">Ragi (Kg)</th>
                      <th colSpan={5} className="p-0.5 border-r border-slate-300 text-center bg-pink-100 text-pink-950 font-black">Jaggery (Kg)</th>
                      <th rowSpan={2} className="p-0.5 text-left w-[44px]">Remarks</th>
                    </tr>
                    <tr className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300 uppercase text-[8px]">
                      <th className="p-0.5 text-center border-r border-slate-300">Pri</th>
                      <th className="p-0.5 text-center border-r border-slate-300">Up</th>
                      <th className="p-0.5 text-center border-r border-slate-300 font-black bg-indigo-50">Tot</th>

                      <th className="p-0.5 text-center border-r border-slate-300">Pri</th>
                      <th className="p-0.5 text-center border-r border-slate-300">Up</th>
                      <th className="p-0.5 text-center border-r border-slate-300 font-black bg-blue-50">Tot</th>

                      {/* Rice */}
                      <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold">Used</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Spl</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold bg-amber-50">Bal</th>

                      {/* Egg */}
                      <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold">Used</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Spl</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold bg-yellow-50">Bal</th>

                      {/* Chikki */}
                      <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold">Used</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Spl</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold bg-orange-50">Bal</th>

                      {/* Ragi */}
                      <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold">Used</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Spl</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold bg-purple-50">Bal</th>

                      {/* Jaggery */}
                      <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold">Used</th>
                      <th className="p-0.5 text-right border-r border-slate-300">Spl</th>
                      <th className="p-0.5 text-right border-r border-slate-300 font-bold bg-pink-50">Bal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-[11px] font-bold">
                    {displayedEntries.map((e, idx) => {
                      const dayInfo = getDayDetails(e.date);
                      const isSunday = !dayInfo.isWorkingDayOverride && dayInfo.isSunday;
                      const isZeroMeals = !e.mealsServed || e.mealsServed === 0;
                      const isHoliday = !dayInfo.isWorkingDayOverride && (
                        dayInfo.isHoliday || isSunday ||
                        Boolean(e.remarks && (e.remarks.toLowerCase().includes('holiday') || e.remarks.toLowerCase().includes('closed') || e.remarks.toLowerCase().includes('sunday')))
                      );

                      const holidayName = dayInfo.holidayName ||
                        (isSunday ? 'Sunday Holiday' : (e.remarks && e.remarks.trim() ? e.remarks : 'School Holiday'));

                      const stock = dailyStockMap[e.date] || {
                        rice: { ob: 0, rec: 0, used: 0, spoiled: 0, cb: 0 },
                        egg: { ob: 0, rec: 0, used: 0, spoiled: 0, cb: 0 },
                        chikki: { ob: 0, rec: 0, used: 0, spoiled: 0, cb: 0 },
                        ragi: { ob: 0, rec: 0, used: 0, spoiled: 0, cb: 0 },
                        jaggery: { ob: 0, rec: 0, used: 0, spoiled: 0, cb: 0 },
                      };

                      // If day 1 and not custom saved override, ensure OB strictly follows previous month total row closing balance
                      const isDayOnePrint = idx === 0 || e.date.endsWith('-01');
                      if (isDayOnePrint && !isOverrideActiveOnSelectedMonth && selectedMonth !== '2026-08' && stock) {
                        if (stock.rice) {
                          stock.rice.ob = prevRiceCB;
                          stock.rice.cb = safeRound3(prevRiceCB + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
                        }
                        if (stock.egg) {
                          stock.egg.ob = prevEggCB;
                          stock.egg.cb = safeRound3(prevEggCB + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
                        }
                        if (stock.chikki) {
                          stock.chikki.ob = prevChikkiCB;
                          stock.chikki.cb = safeRound3(prevChikkiCB + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
                        }
                        if (stock.ragi) {
                          stock.ragi.ob = prevRagiCB;
                          stock.ragi.cb = safeRound3(prevRagiCB + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
                        }
                        if (stock.jaggery && stock.ragi) {
                          stock.jaggery.ob = stock.ragi.ob;
                          stock.jaggery.rec = stock.ragi.rec;
                          stock.jaggery.used = stock.ragi.used;
                          stock.jaggery.spoiled = stock.ragi.spoiled;
                          stock.jaggery.cb = stock.ragi.cb;
                        }
                      }

                      // In month-end row (or 31 row): balance = ob + recieve - used - spoils for columns rice, egg, chikki, ragi, jaggery
                      const isMonthEndRowPrint = idx + 1 === daysInSelMonth || e.date.endsWith('-31') || e.date.endsWith(`-${String(daysInSelMonth).padStart(2, '0')}`);
                      if (isMonthEndRowPrint && stock) {
                        if (stock.rice) stock.rice.cb = safeRound3(stock.rice.ob + (stock.rice.rec || 0) - (e.riceUsedKg || 0) - (stock.rice.spoiled || 0));
                        if (stock.egg) stock.egg.cb = safeRound3(stock.egg.ob + (stock.egg.rec || 0) - (e.eggUsedQty || 0) - (stock.egg.spoiled || 0));
                        if (stock.chikki) stock.chikki.cb = safeRound3(stock.chikki.ob + (stock.chikki.rec || 0) - (e.chikkiUsedQty || 0) - (stock.chikki.spoiled || 0));
                        if (stock.ragi) stock.ragi.cb = safeRound3(stock.ragi.ob + (stock.ragi.rec || 0) - (e.ragiUsedKg || 0) - (stock.ragi.spoiled || 0));
                        if (stock.jaggery && stock.ragi) {
                          stock.jaggery.ob = stock.ragi.ob;
                          stock.jaggery.rec = stock.ragi.rec;
                          stock.jaggery.used = stock.ragi.used;
                          stock.jaggery.spoiled = stock.ragi.spoiled;
                          stock.jaggery.cb = stock.ragi.cb;
                        }
                      }

                      const { dayPrimaryAtt, dayUpperPrimaryAtt, dayTotalAtt } = getDayAttendanceMetrics(e);
                      const dailyCost = calculateDayCookingCost(e);

                      const totalRoll = (e.primaryAttendance || 0) + (e.upperPrimaryAttendance || 0);
                      const totalAtt = dayTotalAtt || (e.primaryAttendance || 0) + (e.upperPrimaryAttendance || 0);
                      const isCustomSavedPrint = monthEntriesMap.has(e.date);

                      const dayStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(e.date) : [];
                      let dayPrimaryEnrolled = 0;
                      let dayUpperPrimaryEnrolled = 0;
                      dayStrengths.forEach((s) => {
                        if (s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i))) {
                          dayPrimaryEnrolled += s.total;
                        } else {
                          dayUpperPrimaryEnrolled += s.total;
                        }
                      });
                      if (dayPrimaryEnrolled === 0 && dayUpperPrimaryEnrolled === 0) {
                        dayPrimaryEnrolled = 170;
                        dayUpperPrimaryEnrolled = 130;
                      }
                      const dayTotalEnrolled = dayPrimaryEnrolled + dayUpperPrimaryEnrolled;

                      return (
                        <tr
                          key={e.id ? `preview-${e.id}-${e.date || idx}` : `preview-${e.date || idx}`}
                          className={isHoliday ? 'bg-red-50 text-red-600 font-bold' : isZeroMeals ? 'bg-white' : 'hover:bg-slate-50'}
                          style={{ height: '17.5px' }}
                        >
                          <td className={`p-0.5 text-center border-r border-slate-200 font-bold ${isHoliday ? 'bg-red-100/70 text-red-600' : ''}`}>{idx + 1}</td>
                          <td className={`p-0.5 border-r border-slate-200 font-semibold text-center whitespace-nowrap ${isHoliday ? 'bg-red-100/70 text-red-600' : ''}`} style={{ fontSize: '12px' }}>{formatAsDDMMYY(e.date)}</td>
                          <td className={`p-0.5 border-r border-slate-200 text-center font-bold ${isSunday || isHoliday ? 'text-red-600 bg-red-100' : 'text-slate-800'}`} style={{ fontSize: '12px' }}>{dayInfo.shortDayName || dayInfo.dayName}</td>

                          {isHoliday ? (
                            <>
                              {/* Roll (Always displayed for all dates, never spanned over) */}
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayUpperPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center font-bold border-r border-slate-200 bg-slate-50">{dayTotalEnrolled}</td>

                              <td
                                colSpan={31}
                                className="p-0.5 text-center border-r border-slate-200 font-bold uppercase tracking-normal bg-red-100/80 text-red-600"
                                style={{ fontSize: '6.2pt' }}
                              >
                                <span className="inline-flex items-center justify-center gap-1.5">
                                  <span>{holidayName.toUpperCase()}</span>
                                  {e.remarks && e.remarks.trim() && e.remarks.toLowerCase() !== holidayName.toLowerCase() ? (
                                    <span className="normal-case text-[5.2pt] font-medium text-red-500">({e.remarks})</span>
                                  ) : null}
                                </span>
                              </td>
                            </>
                          ) : (e.date > todayStr && !isCustomSavedPrint) ? (
                            <>
                              {/* Roll (Always displayed for all dates in print mode) */}
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayUpperPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center font-bold border-r border-slate-200 bg-slate-50">{dayTotalEnrolled}</td>

                              {/* Attendance (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Meals & Cost (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-right border-r border-slate-200">-</td>

                              {/* Rice (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Egg (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Chikki (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Ragi (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Jaggery (Empty for future dates) */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              <td className="p-0.5 border-r border-slate-200 text-[8.2pt] truncate">-</td>
                            </>
                          ) : isZeroMeals ? (
                            <>
                              {/* Roll (Always displayed for all days in print mode) */}
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayUpperPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center font-bold border-r border-slate-200 bg-slate-50">{dayTotalEnrolled}</td>

                              {/* Attendance */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>

                              {/* Meals */}
                              <td className="p-0.5 text-center border-r border-slate-200">-</td>
                              <td className="p-0.5 text-right border-r border-slate-200">-</td>

                              {/* Rice */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.rice.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.rice.rec > 0 ? formatQtyVal(stock.rice.rec) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.rice.used > 0 ? formatQtyVal(stock.rice.used) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.rice.spoiled > 0 ? formatQtyVal(stock.rice.spoiled) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-amber-50/50">{formatQtyVal(stock.rice.cb)}</td>

                              {/* Egg */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.egg.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.egg.rec > 0 ? formatQtyVal(stock.egg.rec) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.egg.used > 0 ? formatQtyVal(stock.egg.used) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.egg.spoiled > 0 ? formatQtyVal(stock.egg.spoiled) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-yellow-50/50">{formatQtyVal(stock.egg.cb)}</td>

                              {/* Chikki */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.chikki.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.chikki.rec > 0 ? formatQtyVal(stock.chikki.rec) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.chikki.used > 0 ? formatQtyVal(stock.chikki.used) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.chikki.spoiled > 0 ? formatQtyVal(stock.chikki.spoiled) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-orange-50/50">{formatQtyVal(stock.chikki.cb)}</td>

                              {/* Ragi */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.ragi.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.ragi.rec > 0 ? formatQtyVal(stock.ragi.rec) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.ragi.used > 0 ? formatQtyVal(stock.ragi.used) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.ragi.spoiled > 0 ? formatQtyVal(stock.ragi.spoiled) : '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-purple-50/50">{formatQtyVal(stock.ragi.cb)}</td>

                              {/* Jaggery */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.jaggery.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.jaggery.rec > 0 ? formatQtyVal(stock.jaggery.rec) : (stock.ragi.rec > 0 ? formatQtyVal(stock.ragi.rec) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.jaggery.used > 0 ? formatQtyVal(stock.jaggery.used) : (stock.ragi.used > 0 ? formatQtyVal(stock.ragi.used) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.jaggery.spoiled > 0 ? formatQtyVal(stock.jaggery.spoiled) : (stock.ragi.spoiled > 0 ? formatQtyVal(stock.ragi.spoiled) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-pink-50/50">{formatQtyVal(stock.jaggery.cb)}</td>

                              <td className="p-0.5 border-r border-slate-200 text-[8.2pt] truncate">
                                {e.remarks || ''}
                              </td>
                            </>
                          ) : (
                            <>
                              {/* Roll */}
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold">{dayUpperPrimaryEnrolled}</td>
                              <td className="p-0.5 text-center font-bold border-r border-slate-200 bg-indigo-50/50">{dayTotalEnrolled}</td>

                              {/* Attendance */}
                              <td className="p-0.5 text-center border-r border-slate-200">{e.primaryAttendance || '-'}</td>
                              <td className="p-0.5 text-center border-r border-slate-200">{e.upperPrimaryAttendance || '-'}</td>
                              <td className="p-0.5 text-center border-r border-slate-200 font-bold bg-blue-50/50">{totalAtt || '-'}</td>

                              {/* Meals */}
                              <td className="p-0.5 text-center border-r border-slate-200 font-black">{e.mealsServed || '-'}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold bg-emerald-50/60">{dailyCost > 0 ? formatCurrency(dailyCost) : '-'}</td>

                              {/* Rice */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.rice.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{formatQtyVal(stock.rice.rec)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{formatQtyVal(stock.rice.used)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{formatQtyVal(stock.rice.spoiled)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-amber-50/50">{formatQtyVal(stock.rice.cb)}</td>

                              {/* Egg */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.egg.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{formatQtyVal(stock.egg.rec)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{formatQtyVal(stock.egg.used)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{formatQtyVal(stock.egg.spoiled)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-yellow-50/50">{formatQtyVal(stock.egg.cb)}</td>

                              {/* Chikki */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.chikki.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{formatQtyVal(stock.chikki.rec)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{formatQtyVal(stock.chikki.used)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{formatQtyVal(stock.chikki.spoiled)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-orange-50/50">{formatQtyVal(stock.chikki.cb)}</td>

                              {/* Ragi */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.ragi.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{formatQtyVal(stock.ragi.rec)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{formatQtyVal(stock.ragi.used)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{formatQtyVal(stock.ragi.spoiled)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-purple-50/50">{formatQtyVal(stock.ragi.cb)}</td>

                              {/* Jaggery */}
                              <td className="p-0.5 text-right border-r border-slate-200">{formatQtyVal(stock.jaggery.ob)}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-emerald-700">{stock.jaggery.rec > 0 ? formatQtyVal(stock.jaggery.rec) : (stock.ragi.rec > 0 ? formatQtyVal(stock.ragi.rec) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-bold">{stock.jaggery.used > 0 ? formatQtyVal(stock.jaggery.used) : (stock.ragi.used > 0 ? formatQtyVal(stock.ragi.used) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 text-rose-600">{stock.jaggery.spoiled > 0 ? formatQtyVal(stock.jaggery.spoiled) : (stock.ragi.spoiled > 0 ? formatQtyVal(stock.ragi.spoiled) : '-')}</td>
                              <td className="p-0.5 text-right border-r border-slate-200 font-extrabold bg-pink-50/50">{formatQtyVal(stock.jaggery.cb)}</td>

                              <td className="p-0.5 border-r border-slate-200 text-[8.2pt] truncate">
                                {e.remarks || ''}
                              </td>
                            </>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                  {/* Total Summary Row */}
                  <tfoot>
                    <tr className="bg-slate-200 text-slate-950 font-extrabold border-t border-slate-300 text-[9.5pt]" style={{ height: '21px' }}>
                      <td colSpan={3} className="p-0.5 border-r border-slate-300 text-center uppercase font-black">TOTAL CONSOLIDATED</td>
                      <td className="p-0.5 border-r border-slate-300 text-center">-</td>
                      <td className="p-0.5 border-r border-slate-300 text-center">-</td>
                      <td className="p-0.5 border-r border-slate-300 text-center font-bold bg-indigo-100">-</td>
                      {/* Attendance Sub-cols: Pri, Up.Pri, Total */}
                      <td className="p-0.5 border-r border-slate-300 text-center">{totalPrimaryAttendance}</td>
                      <td className="p-0.5 border-r border-slate-300 text-center">{totalUpperPrimaryAttendance}</td>
                      <td className="p-0.5 border-r border-slate-300 text-center font-bold bg-blue-100">{totalAttendance}</td>
                      <td className="p-0.5 border-r border-slate-300 text-center font-black bg-emerald-100">{totalMealsServed}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-emerald-200">{formatCurrency(grandTotalAmount)}</td>

                      {/* Rice Totals */}
                      <td className="p-0.5 border-r border-slate-300 text-right font-bold text-indigo-900 bg-indigo-50/50">{formatQtyVal(monthStartRiceOB)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalRiceRec)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black">{formatQtyVal(totalRiceUsed)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalRiceSpoils)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-amber-100">{formatQtyVal(monthEndRiceCB)}</td>

                      {/* Egg Totals */}
                      <td className="p-0.5 border-r border-slate-300 text-right font-bold text-indigo-900 bg-indigo-50/50">{formatQtyVal(monthStartEggOB)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalEggRec)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black">{formatQtyVal(totalEggUsed)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalEggSpoils)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-yellow-100">{formatQtyVal(monthEndEggCB)}</td>

                      {/* Chikki Totals */}
                      <td className="p-0.5 border-r border-slate-300 text-right font-bold text-indigo-900 bg-indigo-50/50">{formatQtyVal(monthStartChikkiOB)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalChikkiRec)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black">{formatQtyVal(totalChikkiUsed)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalChikkiSpoils)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-orange-100">{formatQtyVal(monthEndChikkiCB)}</td>

                      {/* Ragi Totals */}
                      <td className="p-0.5 border-r border-slate-300 text-right font-bold text-indigo-900 bg-indigo-50/50">{formatQtyVal(monthStartRagiOB)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalRagiRec)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black">{formatQtyVal(totalRagiUsed)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalRagiSpoils)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-purple-100">{formatQtyVal(monthEndRagiCB)}</td>

                      {/* Jaggery Totals */}
                      <td className="p-0.5 border-r border-slate-300 text-right font-bold text-indigo-900 bg-indigo-50/50">{formatQtyVal(monthStartJaggeryOB)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalJaggeryRec)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black">{formatQtyVal(totalJaggeryUsed)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right">{formatQtyVal(totalJaggerySpoils)}</td>
                      <td className="p-0.5 border-r border-slate-300 text-right font-black bg-pink-100">{formatQtyVal(monthEndJaggeryCB)}</td>

                      <td className="p-0.5 border-r border-slate-300"></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Official Department Signatures */}
              <div className="pt-2 border-t border-slate-300 text-slate-900 font-bold">
                <div className="flex justify-end text-center text-[8.5px]">
                  <div className="flex flex-col justify-end items-center h-11 border border-dashed border-slate-400 rounded-xs p-1 bg-purple-50/40 w-52">
                    <div className="w-4/5 border-t border-slate-900 mb-0.5"></div>
                    <div className="font-black text-purple-950">Headmaster / Principal</div>
                    <div className="text-[7px] font-medium text-slate-600">(Signature & School Stamp)</div>
                  </div>
                </div>

                {/* Bottom Footer Verification Line */}
                <div className="mt-1.5 pt-1 border-t border-slate-300 flex items-center justify-between text-[7px] text-slate-500 font-mono">
                  <span>Page 1 of 1 (Single Page Official Government Format)</span>
                  <span>PM-POSHAN / MDM AP Continuous Auto-Register</span>
                  <span>Generated: {new Date().toLocaleDateString('en-GB')}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cash Voucher Print Modal Overlay */}
      {showVoucherModal && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 text-slate-100 overflow-hidden animate-fade-in no-print font-sans">
          {/* Modal Body with Embedded CashVoucherView */}
          <div className="flex-1 overflow-y-auto p-2 sm:p-4 md:p-6 bg-slate-900/50">
            <div className="max-w-5xl mx-auto">
              <CashVoucherView
                schoolProfile={schoolProfile}
                dailyEntries={dailyEntries}
                mealRates={mealRates}
                commodities={commodities}
                baseCommodities={baseCommodities}
                stockTransactions={stockTransactions}
                monthlyOverrides={monthlyOverrides}
                studentStrengths={studentStrengths}
                onPrintVoucher={() => window.print()}
                onClose={() => setShowVoucherModal(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* Monthly Report & Stock Report Print Modal Overlay */}
      {activeReportModal && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 text-slate-100 overflow-hidden animate-fade-in no-print font-sans">
          {/* Modal Body with Embedded ReportsView */}
          <div className="flex-1 overflow-y-auto p-2 sm:p-4 md:p-6 bg-slate-900/50">
            <div className="max-w-7xl mx-auto">
              <ReportsView
                schoolProfile={schoolProfile}
                dailyEntries={dailyEntries}
                studentStrengths={studentStrengths}
                commodities={commodities}
                baseCommodities={baseCommodities}
                mealRates={mealRates}
                stockTransactions={stockTransactions}
                monthlyOverrides={monthlyOverrides}
                onPrintReport={() => window.print()}
                initialReportType={activeReportModal}
                initialMonth={selectedMonth}
                onClose={() => setActiveReportModal(null)}
              />
            </div>
          </div>
        </div>
      )}

      {/* School Profile & System Settings Modal Overlay */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 md:p-8 bg-slate-950/95 text-slate-100 animate-fade-in no-print font-sans">
          <SettingsView
            schoolProfile={schoolProfile}
            mealRates={mealRates}
            darkMode={darkMode || false}
            onUpdateSchoolProfile={(profile) => {
              onUpdateSchoolProfile?.(profile);
              setToastMessage('School profile updated successfully!');
            }}
            onUpdateMealRates={(rates) => {
              onUpdateMealRates?.(rates);
              setToastMessage('Cooking expenditure norms updated successfully!');
            }}
            onToggleDarkMode={onToggleDarkMode || (() => {})}
            onResetAllData={onResetAllData}
            onClose={() => setShowSettingsModal(false)}
            initialSection={settingsInitialSection}
            commodities={commodities}
            baseCommodities={baseCommodities}
            dailyEntries={dailyEntries}
            stockTransactions={stockTransactions}
            monthlyOverrides={monthlyOverrides}
            onSaveOpeningBalances={onSaveOpeningBalances}
            onSaveMonthlyBalances={onSaveMonthlyBalances}
            onResetMonthlyOverride={onResetMonthlyOverride}
            onOpenFullModal={() => {
              setShowSettingsModal(false);
              setShowOpeningModal(true);
            }}
          />
        </div>
      )}

      {/* Change School Image Modal Overlay */}
      {showChangeImageModal && (
        <ChangeSchoolImageModal
          schoolProfile={schoolProfile}
          isOpen={showChangeImageModal}
          onClose={() => setShowChangeImageModal(false)}
          onSaveImage={(newPhotoUrl) => {
            const updatedProfile: SchoolProfile = {
              ...schoolProfile,
              schoolPhotoUrl: newPhotoUrl,
            };
            onUpdateSchoolProfile?.(updatedProfile);
            showToast('School photo updated successfully!');
          }}
        />
      )}

      {/* Check Opening Balance & Auto-Update from Last Month Modal Overlay */}
      {showObCheckModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center animate-fade-in no-print font-sans">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-sm sm:max-w-md md:max-w-lg max-h-[92vh] sm:max-h-[85vh] overflow-hidden flex flex-col my-auto">
            {/* Modal Header */}
            <div className="p-3 sm:p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/50 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className={`p-1.5 rounded-lg ${allCommoditiesSynced ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'}`}>
                  {allCommoditiesSynced ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white leading-tight">
                    Opening Balances Auto-Update
                  </h3>
                  <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {prevMonthLabel} Closing &rarr; {currMonthLabel} Opening
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowObCheckModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 sm:space-y-3 flex-1 min-h-0">
              {/* Status Banner */}
              <div className={`p-2.5 rounded-xl border flex items-start space-x-2 text-xs ${
                allCommoditiesSynced
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-200'
              }`}>
                {allCommoditiesSynced ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="space-y-0.5">
                  <div className="font-extrabold text-xs sm:text-sm">
                    {isOverrideActiveOnSelectedMonth
                      ? `✓ Custom Edited OB Saved for ${currMonthLabel}`
                      : allCommoditiesSynced
                      ? `✓ 100% Synchronized from ${prevMonthLabel}!`
                      : `⚠️ Custom Override on ${currMonthLabel}`}
                  </div>
                  <p className="leading-snug text-[11px] text-slate-600 dark:text-slate-400">
                    {isOverrideActiveOnSelectedMonth
                      ? `Opening balances are saved as custom edited. Click 'Auto-Sync All' below anytime to revert to automatic carry forward.`
                      : allCommoditiesSynced
                      ? `All 5 commodities cascade dynamically from ${prevMonthLabel} Total Row Closing Balance to 1st of ${currMonthLabel}.`
                      : `Opening balances are frozen at custom values.`}
                  </p>
                </div>
              </div>

              {/* Holiday Opening Balance Cascade Status Banner */}
              <div className="p-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-900 dark:text-emerald-200 text-[10.5px] sm:text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                <span>Present month Opening Balance automatically carries forward directly from {prevMonthLabel} Total Row Closing Balance across all commodities (Rice, Egg, Chikki, Ragi, Jaggery).</span>
              </div>

              {/* Comparison Table */}
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs">
                <table className="w-full text-left text-[10.5px] border-collapse">
                  <thead>
                    <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-extrabold uppercase border-b border-slate-200 dark:border-slate-700 text-[9.5px]">
                      <th className="p-1.5">Commodity</th>
                      <th className="p-1.5 text-right">
                        <div>{prevMonthLabel} Total Row CB</div>
                      </th>
                      <th className="p-1.5 text-right">
                        <div>{currMonthLabel} 1st of Month OB</div>
                      </th>
                      <th className="p-1.5 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[10px]">
                    {/* Rice */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-1.5 font-sans font-bold flex items-center space-x-1 text-slate-800 dark:text-slate-200">
                        <Wheat className="w-3 h-3 text-amber-600 shrink-0" />
                        <span>Rice</span>
                      </td>
                      <td className="p-1.5 text-right font-black text-cyan-700 dark:text-cyan-300">{formatQtyVal(prevRiceCB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-right font-black text-indigo-700 dark:text-indigo-300">{formatQtyVal(monthStartRiceOB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-center font-sans font-bold">
                        {isRiceSynced ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Auto</span>
                          </span>
                        ) : isOverrideActiveOnSelectedMonth ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Saved</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20 text-[9px]">
                            <span>Diff: {(monthStartRiceOB - prevRiceCB).toFixed(1)}</span>
                          </span>
                        )}
                      </td>
                    </tr>

                    {/* Egg */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-1.5 font-sans font-bold flex items-center space-x-1 text-slate-800 dark:text-slate-200">
                        <Egg className="w-3 h-3 text-yellow-600 shrink-0" />
                        <span>Eggs</span>
                      </td>
                      <td className="p-1.5 text-right font-black text-cyan-700 dark:text-cyan-300">{formatQtyVal(prevEggCB)}</td>
                      <td className="p-1.5 text-right font-black text-indigo-700 dark:text-indigo-300">{formatQtyVal(monthStartEggOB)}</td>
                      <td className="p-1.5 text-center font-sans font-bold">
                        {isEggSynced ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Auto</span>
                          </span>
                        ) : isOverrideActiveOnSelectedMonth ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Saved</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20 text-[9px]">
                            <span>Diff: {(monthStartEggOB - prevEggCB).toFixed(0)}</span>
                          </span>
                        )}
                      </td>
                    </tr>

                    {/* Chikki */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-1.5 font-sans font-bold flex items-center space-x-1 text-slate-800 dark:text-slate-200">
                        <Cookie className="w-3 h-3 text-orange-600 shrink-0" />
                        <span>Chikki</span>
                      </td>
                      <td className="p-1.5 text-right font-black text-cyan-700 dark:text-cyan-300">{formatQtyVal(prevChikkiCB)}</td>
                      <td className="p-1.5 text-right font-black text-indigo-700 dark:text-indigo-300">{formatQtyVal(monthStartChikkiOB)}</td>
                      <td className="p-1.5 text-center font-sans font-bold">
                        {isChikkiSynced ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Auto</span>
                          </span>
                        ) : isOverrideActiveOnSelectedMonth ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Saved</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20 text-[9px]">
                            <span>Diff: {(monthStartChikkiOB - prevChikkiCB).toFixed(0)}</span>
                          </span>
                        )}
                      </td>
                    </tr>

                    {/* Ragi */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-1.5 font-sans font-bold flex items-center space-x-1 text-slate-800 dark:text-slate-200">
                        <Flame className="w-3 h-3 text-purple-600 shrink-0" />
                        <span>Ragi</span>
                      </td>
                      <td className="p-1.5 text-right font-black text-cyan-700 dark:text-cyan-300">{formatQtyVal(prevRagiCB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-right font-black text-indigo-700 dark:text-indigo-300">{formatQtyVal(monthStartRagiOB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-center font-sans font-bold">
                        {isRagiSynced ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Auto</span>
                          </span>
                        ) : isOverrideActiveOnSelectedMonth ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Saved</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20 text-[9px]">
                            <span>Diff: {(monthStartRagiOB - prevRagiCB).toFixed(1)}</span>
                          </span>
                        )}
                      </td>
                    </tr>

                    {/* Jaggery */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-1.5 font-sans font-bold flex items-center space-x-1 text-slate-800 dark:text-slate-200">
                        <Sparkles className="w-3 h-3 text-pink-600 shrink-0" />
                        <span>Jaggery</span>
                      </td>
                      <td className="p-1.5 text-right font-black text-cyan-700 dark:text-cyan-300">{formatQtyVal(prevJaggeryCB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-right font-black text-indigo-700 dark:text-indigo-300">{formatQtyVal(monthStartJaggeryOB)} <span className="text-[9px] font-sans">Kg</span></td>
                      <td className="p-1.5 text-center font-sans font-bold">
                        {isJaggerySynced ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Auto</span>
                          </span>
                        ) : isOverrideActiveOnSelectedMonth ? (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/20 text-[9px]">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Saved</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-0.5 px-1 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20 text-[9px]">
                            <span>Diff: {(monthStartJaggeryOB - prevJaggeryCB).toFixed(1)}</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Explanatory Rule Callout */}
              <div className="p-2 sm:p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed flex items-start space-x-2">
                <Info className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <strong>Official MDM Regulation:</strong> Opening stock must equal previous month's final closing balance.
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-800/90 flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div>
                {!allCommoditiesSynced && (
                  <button
                    type="button"
                    onClick={() => {
                      handleAutoSyncObWithLastMonth();
                    }}
                    className="btn-3d-glass-emerald px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer active:scale-95"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-300" />
                    <span>Auto-Sync All</span>
                  </button>
                )}
              </div>

              <div className="flex items-center space-x-2 ml-auto">
                <button
                  type="button"
                  onClick={() => {
                    setShowObCheckModal(false);
                    setShowOpeningModal(true);
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-200/80 hover:bg-slate-300/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                >
                  Ledger
                </button>
                <button
                  type="button"
                  onClick={() => setShowObCheckModal(false)}
                  className="btn-3d-glass-blue px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
