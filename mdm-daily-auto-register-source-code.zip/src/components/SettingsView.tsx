import React, { useState, useEffect } from 'react';
import { AppSettings, MealRates, SchoolProfile, CommodityItem, DailyEntry, StockTransaction, AutomationSettings } from '../types';
import {
  exportBackupData,
  importRestoreData,
  resetAllApplicationData,
  MonthlyCommodityOverrides,
  getStoredAutomationSettings,
  saveStoredAutomationSettings,
  saveStoredDailyEntries,
  syncWithCloud,
  getStoredCredentials,
  updateLoginCredentials,
  normalizeMobileNumber,
  StoredCredentials,
  getSchoolAccounts,
  getActiveSchoolId,
  setActiveSchoolId,
  SchoolAccount,
} from '../lib/storage';
import { runStockCarryForwardSelfTest, syncDailyEntriesWithMenuIndent } from '../lib/utils';
import { ChangeSchoolImageModal } from './ChangeSchoolImageModal';
import { OpeningBalanceSettings } from './OpeningBalanceSettings';
import { ChangeCredentialsModal } from './ChangeCredentialsModal';
import { RegisterSchoolModal } from './RegisterSchoolModal';
import {
  Boxes,
  Coins,
  IndianRupee,
  School,
  Image as ImageIcon,
  Calculator,
  KeyRound,
  Download,
  Upload,
  Moon,
  Sun,
  Save,
  Check,
  CheckCircle2,
  AlertCircle,
  Shield,
  FileCheck2,
  RotateCcw,
  Trash2,
  X,
  Sliders,
  Settings,
  ArrowLeft,
  LogOut,
  Zap,
  Clock,
  Sparkles,
  PlayCircle,
  RefreshCw,
  SlidersHorizontal,
  CheckCircle,
  Phone,
  Smartphone,
  User as UserIcon,
  Globe,
  Copy,
  Building2,
  PlusCircle,
  Archive,
} from 'lucide-react';

interface SettingsViewProps {
  schoolProfile: SchoolProfile;
  mealRates: MealRates;
  darkMode: boolean;
  onUpdateSchoolProfile: (profile: SchoolProfile) => void;
  onUpdateMealRates: (rates: MealRates) => void;
  onToggleDarkMode: () => void;
  onResetAllData?: () => void;
  onClose?: () => void;
  initialSection?: 'profile' | 'ob' | 'theme' | 'rates' | 'security' | 'backup' | 'reset' | 'automation' | 'all';
  onOpenFlashScreen?: () => void;
  showInstallButton?: boolean;
  onInstallClick?: () => void;
  // Commodity & OB Props
  commodities?: CommodityItem[];
  baseCommodities?: CommodityItem[];
  dailyEntries?: DailyEntry[];
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  onSaveOpeningBalances?: (updatedCommodities: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onOpenFullModal?: () => void;
  automationSettings?: AutomationSettings;
  onUpdateAutomationSettings?: (settings: AutomationSettings) => void;
  onSaveDailyEntry?: (entry: DailyEntry) => void;
  onSwitchSchool?: (schoolId: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  schoolProfile,
  mealRates,
  darkMode,
  onUpdateSchoolProfile,
  onUpdateMealRates,
  onToggleDarkMode,
  onResetAllData,
  onClose,
  initialSection = 'profile',
  onOpenFlashScreen,
  showInstallButton = false,
  onInstallClick,
  commodities = [],
  baseCommodities = [],
  dailyEntries = [],
  stockTransactions = [],
  monthlyOverrides = {},
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  onOpenFullModal,
  automationSettings,
  onUpdateAutomationSettings,
  onSaveDailyEntry,
  onSwitchSchool,
}) => {
  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'profile' | 'ob' | 'theme' | 'rates' | 'security' | 'backup' | 'reset' | 'automation'>(
    initialSection === 'all' ? 'profile' : (initialSection as any)
  );
  const [profileForm, setProfileForm] = useState<SchoolProfile>(schoolProfile);
  const [ratesForm, setRatesForm] = useState<MealRates>(mealRates);

  // Multi-school accounts and isolation state
  const [activeSchoolIdState, setActiveSchoolIdState] = useState<string>(() => getActiveSchoolId());
  const [schoolAccounts, setSchoolAccounts] = useState<SchoolAccount[]>(getSchoolAccounts);
  const [showRegisterSchoolModal, setShowRegisterSchoolModal] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  // Automation Form & Engine State
  const [automationForm, setAutomationForm] = useState<AutomationSettings>(() => {
    return automationSettings || getStoredAutomationSettings();
  });
  const [automationSaveSuccess, setAutomationSaveSuccess] = useState(false);

  // Self-test runner state
  const [selfTestResult, setSelfTestResult] = useState<{
    allPassed: boolean;
    results: Array<{ testName: string; passed: boolean; details: string }>;
  } | null>(null);
  const [isRunningSelfTest, setIsRunningSelfTest] = useState(false);

  // Auto-indent alignment state
  const [isAligningEntries, setIsAligningEntries] = useState(false);
  const [alignMessage, setAlignMessage] = useState<string | null>(null);

  // Cloud sync trigger state
  const [isSyncingCloud, setIsSyncingCloud] = useState(false);
  const [cloudSyncMessage, setCloudSyncMessage] = useState<string | null>(null);

  const handleToggleAutomation = (key: keyof AutomationSettings, val: any) => {
    const updated = { ...automationForm, [key]: val };
    setAutomationForm(updated);
    saveStoredAutomationSettings(updated);
    if (onUpdateAutomationSettings) {
      onUpdateAutomationSettings(updated);
    }
    setAutomationSaveSuccess(true);
    setTimeout(() => setAutomationSaveSuccess(false), 2500);
  };

  const handleRunSelfTest = () => {
    setIsRunningSelfTest(true);
    setTimeout(() => {
      const res = runStockCarryForwardSelfTest();
      setSelfTestResult(res);
      setIsRunningSelfTest(false);
    }, 400);
  };

  const handleRealignAllEntries = () => {
    setIsAligningEntries(true);
    setTimeout(() => {
      const { updatedEntries, changedCount } = syncDailyEntriesWithMenuIndent(dailyEntries, mealRates);
      saveStoredDailyEntries(updatedEntries);
      if (onSaveDailyEntry) {
        updatedEntries.forEach((entry) => onSaveDailyEntry(entry));
      }
      setIsAligningEntries(false);
      setAlignMessage(`✓ Successfully verified & aligned ${updatedEntries.length} entries (${changedCount} adjusted to official AP MDM indent).`);
      setTimeout(() => setAlignMessage(null), 5000);
    }, 400);
  };

  const handleTriggerCloudSync = async () => {
    setIsSyncingCloud(true);
    setCloudSyncMessage(null);
    try {
      const success = await syncWithCloud();
      setIsSyncingCloud(false);
      setCloudSyncMessage(success ? '✓ Cloud sync completed successfully.' : '✓ Cloud check finished.');
      setTimeout(() => setCloudSyncMessage(null), 4000);
    } catch (e) {
      setIsSyncingCloud(false);
      setCloudSyncMessage('⚠️ Cloud sync encountered a network issue; offline data remains intact.');
      setTimeout(() => setCloudSyncMessage(null), 4000);
    }
  };
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const [showImageModal, setShowImageModal] = useState<boolean>(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [confirmYes, setConfirmYes] = useState(false);

  const handleOpenResetModal = () => {
    setResetConfirmPassword('');
    setResetError(null);
    setConfirmYes(false);
    setShowResetConfirmModal(true);
  };

  const handleConfirmReset = () => {
    if (!confirmYes) {
      setResetError('Please check the confirmation box first.');
      return;
    }
    resetAllApplicationData();
    if (onResetAllData) {
      onResetAllData();
    }
    setShowResetConfirmModal(false);
    setConfirmYes(false);
    setResetError(null);
    showMsg('All application data reset successfully! You now have a clean slate for fresh entries.');
  };

  // Success button states
  const [profileSaveSuccess, setProfileSaveSuccess] = useState(false);
  const [ratesSaveSuccess, setRatesSaveSuccess] = useState(false);
  const [passwordSaveSuccess, setPasswordSaveSuccess] = useState(false);

  const [isProfileDirty, setIsProfileDirty] = useState(false);
  const [isRatesDirty, setIsRatesDirty] = useState(false);
  const [isPasswordDirty, setIsPasswordDirty] = useState(false);

  useEffect(() => {
    setProfileForm(schoolProfile);
    setIsProfileDirty(false);
  }, [schoolProfile]);

  const [lastAutoSavedTime, setLastAutoSavedTime] = useState<string | null>(null);

  const [rawRatesInputs, setRawRatesInputs] = useState<Record<string, string>>(() => ({
    primaryRatePerMeal: String(mealRates.primaryRatePerMeal ?? 5.45),
    upperPrimaryRatePerMeal: String(mealRates.upperPrimaryRatePerMeal ?? 8.17),
    highSchoolRatePerMeal: String(mealRates.highSchoolRatePerMeal ?? 8.17),
    riceNormPrimaryGrams: String(mealRates.riceNormPrimaryGrams ?? 100),
    riceNormUpperPrimaryGrams: String(mealRates.riceNormUpperPrimaryGrams ?? 150),
    eggNormQty: String(mealRates.eggNormQty ?? 1),
    chikkiNormQty: String(mealRates.chikkiNormQty ?? 1),
    ragiNormGrams: String(mealRates.ragiNormGrams ?? 10),
    jaggeryNormGrams: String(mealRates.jaggeryNormGrams ?? 10),
  }));

  useEffect(() => {
    setRatesForm(mealRates);
    setRawRatesInputs({
      primaryRatePerMeal: String(mealRates.primaryRatePerMeal ?? 5.45),
      upperPrimaryRatePerMeal: String(mealRates.upperPrimaryRatePerMeal ?? 8.17),
      highSchoolRatePerMeal: String(mealRates.highSchoolRatePerMeal ?? 8.17),
      riceNormPrimaryGrams: String(mealRates.riceNormPrimaryGrams ?? 100),
      riceNormUpperPrimaryGrams: String(mealRates.riceNormUpperPrimaryGrams ?? 150),
      eggNormQty: String(mealRates.eggNormQty ?? 1),
      chikkiNormQty: String(mealRates.chikkiNormQty ?? 1),
      ragiNormGrams: String(mealRates.ragiNormGrams ?? 10),
      jaggeryNormGrams: String(mealRates.jaggeryNormGrams ?? 10),
    });
    setIsRatesDirty(false);
  }, [mealRates]);

  const handleProfileChange = (updated: SchoolProfile) => {
    setProfileForm(updated);
    onUpdateSchoolProfile(updated);
    setIsProfileDirty(true);
    setLastAutoSavedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  };

  const handleRatesChange = (updated: MealRates) => {
    setRatesForm(updated);
    onUpdateMealRates(updated);
    setIsRatesDirty(true);
    setLastAutoSavedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  };

  const handleRateFieldChange = (field: keyof MealRates, valStr: string) => {
    const sanitized = valStr.replace(/[^0-9.]/g, '');
    const parts = sanitized.split('.');
    const cleanStr = parts.length > 2 ? `${parts[0]}.${parts.slice(1).join('')}` : sanitized;

    setRawRatesInputs((prev) => ({ ...prev, [field]: cleanStr }));
    const parsed = parseFloat(cleanStr);
    const updatedRates: MealRates = {
      ...ratesForm,
      [field]: isNaN(parsed) ? 0 : parsed,
    };
    handleRatesChange(updatedRates);
  };

  // Credentials management state - isolated per school
  const [credentials, setCredentials] = useState<StoredCredentials>(() => getStoredCredentials(activeSchoolIdState));
  const [selectedRoleToEdit, setSelectedRoleToEdit] = useState<'HEADMASTER' | 'MDM_INCHARGE'>('HEADMASTER');
  const [credUsername, setCredUsername] = useState(credentials.headmaster.username);
  const [credMobile, setCredMobile] = useState(credentials.headmaster.mobile);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<string | null>(null);
  const [showChangeCredsModal, setShowChangeCredsModal] = useState(false);

  // Sync credentials when active school changes
  useEffect(() => {
    const updated = getStoredCredentials(activeSchoolIdState);
    setCredentials(updated);
    const target = selectedRoleToEdit === 'HEADMASTER' ? updated.headmaster : updated.incharge;
    setCredUsername(target.username);
    setCredMobile(target.mobile);
  }, [activeSchoolIdState, selectedRoleToEdit]);

  const handleRoleSwitch = (role: 'HEADMASTER' | 'MDM_INCHARGE') => {
    setSelectedRoleToEdit(role);
    const target = role === 'HEADMASTER' ? credentials.headmaster : credentials.incharge;
    setCredUsername(target.username);
    setCredMobile(target.mobile);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordMsg(null);
    setIsPasswordDirty(false);
  };

  const handleChangeCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg(null);

    if (newPassword || confirmPassword) {
      if (newPassword !== confirmPassword) {
        setPasswordMsg('New password and confirm password do not match.');
        return;
      }
      if (newPassword.length < 4) {
        setPasswordMsg('New password must be at least 4 characters long.');
        return;
      }
    }

    const roleKey = selectedRoleToEdit === 'HEADMASTER' ? 'headmaster' : 'incharge';
    const targetCred = credentials[roleKey];
    if (currentPassword && targetCred.password && currentPassword !== targetCred.password) {
      setPasswordMsg('Incorrect current password. If you forgot your password, click "Verify via Mobile OTP" below.');
      return;
    }

    const cleanMobile = normalizeMobileNumber(credMobile);
    if (cleanMobile.length !== 10) {
      setPasswordMsg('Please enter a valid 10-digit mobile phone number.');
      return;
    }

    const res = updateLoginCredentials(
      selectedRoleToEdit,
      {
        username: credUsername.trim(),
        mobile: cleanMobile,
        password: newPassword ? newPassword : targetCred.password,
      },
      activeSchoolIdState
    );

    if (res.success) {
      setCredentials(res.updatedCreds);
      setPasswordMsg(res.message);
      setPasswordSaveSuccess(true);
      setIsPasswordDirty(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => {
        setPasswordMsg(null);
        setPasswordSaveSuccess(false);
      }, 4000);
    } else {
      setPasswordMsg(res.message);
    }
  };

  // Backup restore file state
  const [restoreJson, setRestoreJson] = useState('');
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSchoolProfile(profileForm);
    setProfileSaveSuccess(true);
    setIsProfileDirty(false);
    showMsg('School Profile updated successfully!');
    setTimeout(() => setProfileSaveSuccess(false), 3500);
  };

  const handleRatesSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateMealRates(ratesForm);
    setRatesSaveSuccess(true);
    setIsRatesDirty(false);
    showMsg('Meal Rates and Norms updated successfully!');
    setTimeout(() => setRatesSaveSuccess(false), 3500);
  };

  const handleDownloadBackup = () => {
    const json = exportBackupData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MDM_Backup_${profileForm.udiseCode}_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    showMsg('Backup JSON downloaded!');
  };

  const handleRestoreBackup = () => {
    if (!restoreJson.trim()) return;
    const ok = importRestoreData(restoreJson);
    if (ok) {
      setRestoreStatus('Data restored successfully! Refreshing page...');
      setTimeout(() => window.location.reload(), 1500);
    } else {
      setRestoreStatus('Failed to parse backup JSON file. Please verify format.');
    }
  };

  const showMsg = (msg: string) => {
    setSavedMsg(msg);
    setTimeout(() => setSavedMsg(null), 3500);
  };

  return (
    <div className="max-w-full space-y-2 sm:space-y-2.5 pb-2 sm:pb-3">
      {/* Toast */}
      {savedMsg && (
        <div className="fixed bottom-8 sm:bottom-10 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-white" />
          <span>{savedMsg}</span>
        </div>
      )}

      {/* Navigation Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 p-1 sm:p-1.5 bg-slate-100/80 dark:bg-slate-800/80 backdrop-blur-md rounded-xl border border-slate-200 dark:border-slate-700">
        <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
          {[
            { id: 'profile', label: 'School Profile', icon: <School className="w-3.5 h-3.5" /> },
            { id: 'backup', label: 'Backup & Restore', icon: <Download className="w-3.5 h-3.5" /> },
            { id: 'reset', label: 'Reset Data', icon: <RotateCcw className="w-3.5 h-3.5 text-rose-500" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveFilterTab(tab.id as any)}
              className={`px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === tab.id
                  ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 shadow-xs border border-purple-200 dark:border-purple-800'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-white/50 dark:hover:bg-slate-750 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {lastAutoSavedTime && (
          <div className="hidden sm:flex items-center gap-1 text-[9.5px] sm:text-[10px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>Auto-saved at {lastAutoSavedTime}</span>
          </div>
        )}

        <button
          type="button"
          onClick={() => {
            if (onClose) {
              onClose();
            } else if (typeof window !== 'undefined' && window.history.length > 1) {
              window.history.back();
            }
          }}
          className="btn-3d-glass-rose cursor-pointer ml-auto mr-1 !px-2.5 !py-1 !text-xs"
          title="Exit and Return to Dashboard"
        >
          <LogOut className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
          <span>Exit</span>
        </button>
      </div>

      {/* 1. School Information Form */}
      {(activeFilterTab === 'all' || activeFilterTab === 'profile') && (
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3 sm:space-y-3.5">
        <div className="flex items-center justify-between pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            <School className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600" />
            <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">School Profile Information</h3>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* App URL Copy Button */}
            <button
              type="button"
              onClick={() => {
                if (navigator.clipboard?.writeText) {
                  navigator.clipboard.writeText(window.location.href);
                }
                setCopiedUrl(true);
                setTimeout(() => setCopiedUrl(false), 2000);
              }}
              className="px-2 py-1 sm:px-2.5 sm:py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-lg sm:rounded-xl font-bold text-[11px] sm:text-xs flex items-center gap-1 sm:gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Copy Application Web URL"
            >
              <Globe className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-600 dark:text-sky-400" />
              <span>{copiedUrl ? 'Copied!' : 'Copy App URL'}</span>
              {copiedUrl && <Check className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-500" />}
            </button>

            {/* Quick Photo Change Trigger */}
            <button
              type="button"
              onClick={() => setShowImageModal(true)}
              className="px-2.5 py-1 sm:px-3 sm:py-1.5 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-600 dark:text-sky-400 border border-blue-200 dark:border-blue-800 rounded-lg sm:rounded-xl font-extrabold text-[11px] sm:text-xs flex items-center gap-1 sm:gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Change School Icon / Logo"
            >
              <ImageIcon className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>Change School Photo</span>
            </button>
          </div>
        </div>

        {/* Dedicated Multi-School Account & Data Isolation Card */}
        <div className="p-2.5 sm:p-3 bg-gradient-to-r from-blue-50/80 to-indigo-50/80 dark:from-blue-950/40 dark:to-indigo-950/40 border border-blue-200/80 dark:border-blue-800/60 rounded-xl space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Building2 className="w-4 h-4 text-blue-600 dark:text-sky-400 shrink-0" />
              <div>
                <h4 className="font-extrabold text-[11px] sm:text-xs text-blue-950 dark:text-blue-200 flex items-center gap-1.5">
                  <span>Individual School Data Partitioning</span>
                  <span className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9px] px-1.5 py-0.5 rounded-full font-black">
                    ✓ Data Isolated
                  </span>
                </h4>
                <p className="text-[10px] sm:text-[11px] text-blue-800/80 dark:text-blue-300/80">
                  Every school maintains its own individual login credentials, student strength, daily entries, opening stocks, and vouchers.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowRegisterSchoolModal(true)}
              className="px-2.5 py-1 sm:px-3 sm:py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold flex items-center justify-center gap-1 sm:gap-1.5 shadow-xs transition-all cursor-pointer whitespace-nowrap active:scale-95 shrink-0"
            >
              <PlusCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>+ Register Another School</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2 sm:gap-3 pt-1.5 sm:pt-2 border-t border-blue-200/60 dark:border-blue-800/40 text-[11px] sm:text-xs">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-bold text-slate-700 dark:text-slate-300">Active School Database:</span>
              <select
                value={activeSchoolIdState}
                onChange={(e) => {
                  const newId = e.target.value;
                  setActiveSchoolIdState(newId);
                  setActiveSchoolId(newId);
                  if (onSwitchSchool) {
                    onSwitchSchool(newId);
                  }
                  showMsg('Switched active school database partition.');
                }}
                className="font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-900 border border-blue-300 dark:border-blue-700 rounded-md sm:rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 text-[11px] sm:text-xs outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                {schoolAccounts.map((acc) => (
                  <option key={acc.schoolId} value={acc.schoolId}>
                    {acc.schoolName} ({acc.udiseCode})
                  </option>
                ))}
              </select>
            </div>

            <div className="text-[10px] sm:text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <span>Partition Key:</span>
              <code className="bg-white/80 dark:bg-slate-900/80 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-blue-600 dark:text-sky-400 font-bold">
                {activeSchoolIdState}
              </code>
            </div>
          </div>
        </div>

        {/* School Photo Preview Strip */}
        <div className="p-2 sm:p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/80 flex items-center gap-2.5 sm:gap-3">
          <div
            onClick={() => setShowImageModal(true)}
            className="relative group w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-sm overflow-hidden shadow-xs cursor-pointer ring-2 ring-blue-400/40 shrink-0"
            title="Click to change photo"
          >
            {profileForm.schoolPhotoUrl ? (
              <img
                src={profileForm.schoolPhotoUrl}
                alt="School"
                className="w-full h-full object-cover group-hover:opacity-90 transition-opacity"
              />
            ) : (
              <School className="w-6 h-6 text-sky-200" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-[11px] sm:text-xs font-bold text-slate-800 dark:text-white truncate">
              {profileForm.schoolName || 'School Name'}
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 truncate">
              {profileForm.schoolPhotoUrl ? 'Custom photo active' : 'Default emblem active'} | Touch badge or button to change
            </p>
          </div>
        </div>

        <form onSubmit={handleProfileSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-2.5 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">School Name</label>
            <input
              type="text"
              inputMode="text"
              value={profileForm.schoolName}
              onChange={(e) => handleProfileChange({ ...profileForm, schoolName: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">UDISE Code</label>
            <input
              type="text"
              inputMode="numeric"
              value={profileForm.udiseCode}
              onChange={(e) => handleProfileChange({ ...profileForm, udiseCode: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-xs text-slate-900 dark:text-white"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Village</label>
            <input
              type="text"
              value={profileForm.village ?? 'R.B.R.PETA'}
              onChange={(e) => handleProfileChange({ ...profileForm, village: e.target.value })}
              placeholder="e.g. R.B.R.PETA"
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Mandal</label>
            <input
              type="text"
              value={profileForm.mandal ?? 'PALAKONDA'}
              onChange={(e) => handleProfileChange({ ...profileForm, mandal: e.target.value })}
              placeholder="e.g. PALAKONDA"
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">District</label>
            <input
              type="text"
              value={profileForm.district ?? 'PARVATHI PURAM MANYAM'}
              onChange={(e) => handleProfileChange({ ...profileForm, district: e.target.value })}
              placeholder="e.g. PARVATHI PURAM MANYAM"
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">PIN Code</label>
            <input
              type="text"
              value={profileForm.pincode ?? '532462'}
              onChange={(e) => handleProfileChange({ ...profileForm, pincode: e.target.value })}
              placeholder="e.g. 532462"
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">State</label>
            <input
              type="text"
              value={profileForm.state ?? 'ANDHRA PRADESH'}
              onChange={(e) => handleProfileChange({ ...profileForm, state: e.target.value })}
              placeholder="e.g. ANDHRA PRADESH"
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Headmaster Name</label>
            <input
              type="text"
              inputMode="text"
              value={profileForm.headmasterName}
              onChange={(e) => handleProfileChange({ ...profileForm, headmasterName: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
              Implementing Agency
            </label>
            <input
              type="text"
              value={profileForm.implementingAgency}
              onChange={(e) => handleProfileChange({ ...profileForm, implementingAgency: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Bank Name</label>
            <input
              type="text"
              value={profileForm.bankName}
              onChange={(e) => handleProfileChange({ ...profileForm, bankName: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Account Number</label>
            <input
              type="text"
              value={profileForm.accountNumber}
              onChange={(e) => handleProfileChange({ ...profileForm, accountNumber: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">IFSC Code</label>
            <input
              type="text"
              value={profileForm.ifscCode}
              onChange={(e) => handleProfileChange({ ...profileForm, ifscCode: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-xs text-slate-900 dark:text-white"
            />
          </div>


          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">Address</label>
            <input
              type="text"
              value={profileForm.address}
              onChange={(e) => handleProfileChange({ ...profileForm, address: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-3 flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
            <button
              type="button"
              onClick={() => {
                if (onClose) {
                  onClose();
                } else if (typeof window !== 'undefined' && window.history.length > 1) {
                  window.history.back();
                }
              }}
              className="btn-3d-glass-rose cursor-pointer !px-2.5 !py-1 !text-xs"
              title="Exit and Return to Dashboard"
            >
              <LogOut className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>Exit</span>
            </button>
            <button
              type="submit"
              className="btn-3d-glass-emerald cursor-pointer !px-3 !py-1 !text-xs"
              title="Save School Profile changes"
            >
              <Save className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>{profileSaveSuccess ? 'Profile Saved!' : 'Save School Profile'}</span>
            </button>
          </div>
        </form>
      </div>
      )}

      {/* 2. Opening Balance (OB) & Commodity Stock Balances Card */}
      {(activeFilterTab === 'all' || activeFilterTab === 'profile' || activeFilterTab === 'ob') && (
        <OpeningBalanceSettings
          commodities={commodities}
          baseCommodities={baseCommodities.length > 0 ? baseCommodities : commodities}
          dailyEntries={dailyEntries}
          stockTransactions={stockTransactions}
          monthlyOverrides={monthlyOverrides}
          onSaveOpeningBalances={onSaveOpeningBalances}
          onSaveMonthlyBalances={onSaveMonthlyBalances}
          onResetMonthlyOverride={onResetMonthlyOverride}
          onOpenFullModal={onOpenFullModal}
        />
      )}

      {/* Theme & Display Appearance Settings Card */}
      {(activeFilterTab === 'all' || activeFilterTab === 'profile' || activeFilterTab === 'theme') && (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3 sm:space-y-3.5">
          <div className="flex items-center justify-between pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-1.5 sm:space-x-2">
              {darkMode ? <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500" /> : <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-600" />}
              <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">Theme & Display Appearance</h3>
            </div>
            <span className="text-[9px] sm:text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700">
              Current: <strong className="text-indigo-600 dark:text-amber-400">{darkMode ? 'Dark Theme' : 'Light Theme'}</strong>
            </span>
          </div>

          <p className="text-[10.5px] sm:text-xs text-slate-600 dark:text-slate-300">
            Choose your preferred interface theme for comfortable day-to-day operation. Light mode provides high contrast for daytime school offices, while Dark mode reduces eye strain in low-light environments.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 pt-1">
            {/* Light Theme Card */}
            <div
              onClick={() => {
                if (darkMode) onToggleDarkMode();
              }}
              className={`p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                !darkMode
                  ? 'border-indigo-600 bg-white shadow-xs ring-2 ring-indigo-500/20'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 bg-amber-100 text-amber-700 rounded-lg">
                    <Sun className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">Light Theme</h4>
                    <p className="text-[10px] sm:text-[11px] text-slate-500">Crisp high-contrast day mode</p>
                  </div>
                </div>
                {!darkMode && (
                  <span className="p-1 bg-indigo-600 text-white rounded-full">
                    <Check className="w-3 h-3" />
                  </span>
                )}
              </div>
              <div className="p-2 bg-slate-100 rounded-lg text-[9.5px] sm:text-[10px] text-slate-700 font-semibold border border-slate-200">
                ☀️ Clean white & indigo paper register style
              </div>
            </div>

            {/* Dark Theme Card */}
            <div
              onClick={() => {
                if (!darkMode) onToggleDarkMode();
              }}
              className={`p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                darkMode
                  ? 'border-amber-400 bg-slate-900 shadow-xs ring-2 ring-amber-400/20'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 bg-indigo-950 text-indigo-400 rounded-lg border border-indigo-800">
                    <Moon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">Dark Theme</h4>
                    <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400">Deep indigo twilight mode</p>
                  </div>
                </div>
                {darkMode && (
                  <span className="p-1 bg-amber-400 text-slate-950 rounded-full">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </div>
              <div className="p-2 bg-slate-800/80 rounded-lg text-[9.5px] sm:text-[10px] text-slate-300 font-semibold border border-slate-700">
                🌙 Low-light deep mesh 3D glass glow
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Government Cooking Rates & Commodity Quantity Norms */}
      {(activeFilterTab === 'all' || activeFilterTab === 'profile' || activeFilterTab === 'rates') && (
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3 sm:space-y-3.5">
        <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white flex items-center space-x-1.5 sm:space-x-2 pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
          <IndianRupee className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600" />
          <span>Government Approved Cooking Rates & Commodity Quantity Norms</span>
        </h3>

        <form onSubmit={handleRatesSubmit} className="space-y-3 text-xs">
          <div>
            <span className="block font-black text-slate-500 dark:text-slate-400 text-[9.5px] sm:text-[10px] uppercase tracking-wider mb-1.5">
              Meal Cooking Cost Rates (₹ per child / meal)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Primary Rate (₹/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.primaryRatePerMeal ?? ''}
                  onChange={(e) => handleRateFieldChange('primaryRatePerMeal', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Upper Primary Rate (₹/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.upperPrimaryRatePerMeal ?? ''}
                  onChange={(e) => handleRateFieldChange('upperPrimaryRatePerMeal', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  High School Rate (₹/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.highSchoolRatePerMeal ?? ''}
                  onChange={(e) => handleRateFieldChange('highSchoolRatePerMeal', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="block font-black text-slate-500 dark:text-slate-400 text-[9.5px] sm:text-[10px] uppercase tracking-wider mb-1.5">
              Commodity Quantity Norms (per child / meal)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Rice Primary (g/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.riceNormPrimaryGrams ?? ''}
                  onChange={(e) => handleRateFieldChange('riceNormPrimaryGrams', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Rice Upper Pri (g/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.riceNormUpperPrimaryGrams ?? ''}
                  onChange={(e) => handleRateFieldChange('riceNormUpperPrimaryGrams', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Egg Norm (Qty/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.eggNormQty ?? ''}
                  onChange={(e) => handleRateFieldChange('eggNormQty', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Chikki Norm (Qty/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.chikkiNormQty ?? ''}
                  onChange={(e) => handleRateFieldChange('chikkiNormQty', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Ragi Norm (g/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.ragiNormGrams ?? ''}
                  onChange={(e) => handleRateFieldChange('ragiNormGrams', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Jaggery Norm (g/child)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={rawRatesInputs.jaggeryNormGrams ?? ''}
                  onChange={(e) => handleRateFieldChange('jaggeryNormGrams', e.target.value)}
                  autoComplete="off"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg font-bold text-xs text-slate-900 dark:text-white backdrop-blur-xs"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-3.5 sm:px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-lg font-extrabold text-[11px] sm:text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer active:scale-95"
            >
              {ratesSaveSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Rates & Norms Saved!</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Approved Rates & Norms</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
      )}

      {/* 2.5 Automation, Calculation Rules & System Health Suite */}
      {(activeFilterTab === 'all' || activeFilterTab === 'profile' || activeFilterTab === 'automation') && (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3 sm:space-y-3.5">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-amber-500/10 text-amber-500 rounded-lg border border-amber-500/20">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-800 dark:text-white flex items-center gap-1.5 sm:gap-2">
                  <span>Automation, Calculations & Stock Engine Rules</span>
                  {automationSaveSuccess && (
                    <span className="text-[9px] sm:text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800 animate-pulse">
                      Settings Saved
                    </span>
                  )}
                </h3>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400">
                  Manage real-time debounced auto-save, official AP MDM menu indent calculations, morning cutoff rollover, and continuous stock carry-forward.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-extrabold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>All Engines Operational</span>
              </span>
            </div>
          </div>

          {/* Core Automation Toggles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3">
            {/* 1. Auto-Calculate Consumption Norms */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Auto-Calculate Norms</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoCalculateNorms}
                      onChange={(e) => handleToggleAutomation('autoCalculateNorms', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Computes rice, pulses, oil, condiments, eggs, chikki, ragi, and jaggery dynamically using Government student attendance indent norms.
                </p>
              </div>
              <div className="text-[9.5px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                {automationForm.autoCalculateNorms ? '✓ Active: Applied on daily register input' : 'Paused: Manual entry mode enabled'}
              </div>
            </div>

            {/* 2. Real-Time Auto-Save */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <Save className="w-3.5 h-3.5 text-emerald-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Real-Time Auto-Save</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoSave}
                      onChange={(e) => handleToggleAutomation('autoSave', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Debounces and auto-saves daily entries immediately as you enter data. Prevents any accidental browser tab closing loss.
                </p>
              </div>
              <div className="text-[9.5px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                {automationForm.autoSave ? '✓ Active: Debounced persistent cloud & local save' : 'Disabled: Requires manual Save click'}
              </div>
            </div>

            {/* 3. Morning Attendance Rollover & Cutoff */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Morning Roll Rollover</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoMorningAttendanceRoll}
                      onChange={(e) => handleToggleAutomation('autoMorningAttendanceRoll', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-blue-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Periodically monitors class attendance rolls. When the morning cutoff is reached and daily entry is zero, updates automatically.
                </p>
              </div>
              <div className="flex items-center justify-between gap-2 p-1.5 bg-blue-500/10 rounded-md border border-blue-500/20">
                <span className="text-[9.5px] font-bold text-blue-700 dark:text-blue-300">Morning Cutoff Time:</span>
                <input
                  type="time"
                  value={automationForm.morningRollCutoffTime || '07:30'}
                  onChange={(e) => handleToggleAutomation('morningRollCutoffTime', e.target.value)}
                  className="px-1.5 py-0.5 text-[10.5px] font-extrabold rounded bg-white dark:bg-slate-900 border border-blue-300 dark:border-blue-700 text-blue-900 dark:text-blue-200"
                />
              </div>
            </div>

            {/* 4. Continuous Stock Carry-Forward */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <Boxes className="w-3.5 h-3.5 text-purple-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Continuous Stock Carry-Forward</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoCarryForwardStock}
                      onChange={(e) => handleToggleAutomation('autoCarryForwardStock', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-purple-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Cascades previous closing stock as opening stock continuously across all working days, holiday breaks, and monthly roll boundaries.
                </p>
              </div>
              <div className="text-[9.5px] font-bold text-purple-600 dark:text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-md border border-purple-500/20">
                {automationForm.autoCarryForwardStock ? '✓ Active: Continuous mathematical stock chain' : 'Manual stock override mode'}
              </div>
            </div>

            {/* 5. 100% Strength Auto-Fill on New Working Days */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <School className="w-3.5 h-3.5 text-teal-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Auto-Fill Strength on New Day</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoFillFullAttendanceOnNewDay}
                      onChange={(e) => handleToggleAutomation('autoFillFullAttendanceOnNewDay', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-teal-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Pre-fills 100% enrolled student strength when opening an unrecorded working day so teachers only need to adjust absentees.
                </p>
              </div>
              <div className="text-[9.5px] font-bold text-teal-600 dark:text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded-md border border-teal-500/20">
                {automationForm.autoFillFullAttendanceOnNewDay ? '✓ Active: Default 100% attendance roll pre-loaded' : 'Blank attendance default'}
              </div>
            </div>

            {/* 6. Automatic Firebase Cloud Synchronization */}
            <div className="p-2.5 sm:p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 text-indigo-500" />
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">Firestore Cloud Sync</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={automationForm.autoCloudSync}
                      onChange={(e) => handleToggleAutomation('autoCloudSync', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4.5 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-indigo-500" />
                  </label>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Auto-syncs local IndexedDB data with Google Firebase Firestore in the background on data edit and network reconnect.
                </p>
              </div>
              <div className="text-[9.5px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                {automationForm.autoCloudSync ? '✓ Active: Continuous Firebase background sync' : 'Offline local storage only'}
              </div>
            </div>
          </div>

          {/* System Verification & Automation Tools Panel */}
          <div className="p-2.5 sm:p-3 bg-slate-100/60 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-700 dark:text-slate-300" />
                <h4 className="text-[11px] sm:text-xs font-extrabold text-slate-800 dark:text-white uppercase tracking-wider">
                  Automation Health Engines & Verification Tools
                </h4>
              </div>
              <span className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-bold">
                Run diagnostics anytime without affecting saved data
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Tool 1: 7-Point Self-Test */}
              <button
                type="button"
                onClick={handleRunSelfTest}
                disabled={isRunningSelfTest}
                className="p-2.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg flex flex-col items-start gap-1 text-left transition-all cursor-pointer shadow-xs active:scale-[0.98]"
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-extrabold text-[11px] sm:text-xs text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                    <PlayCircle className="w-3.5 h-3.5 text-purple-600" />
                    Run 7-Point Stock Test
                  </span>
                  {selfTestResult && (
                    <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-black ${selfTestResult.allPassed ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400' : 'bg-rose-100 text-rose-700'}`}>
                      {selfTestResult.allPassed ? 'ALL PASSED (7/7)' : 'FAILURES DETECTED'}
                    </span>
                  )}
                </div>
                <p className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400">
                  Tests month boundaries, multi-day skips, double receipts, and continuous carry-forward rules.
                </p>
              </button>

              {/* Tool 2: Align All Entries */}
              <button
                type="button"
                onClick={handleRealignAllEntries}
                disabled={isAligningEntries}
                className="p-2.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg flex flex-col items-start gap-1 text-left transition-all cursor-pointer shadow-xs active:scale-[0.98]"
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-extrabold text-[11px] sm:text-xs text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    Verify AP Menu Indent
                  </span>
                  <span className="text-[8.5px] sm:text-[9px] font-bold text-slate-400">Official Schedule</span>
                </div>
                <p className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400">
                  Verifies historical entries match the AP Government weekly indent (Egg, Chikki, Ragi Malt).
                </p>
              </button>

              {/* Tool 3: Cloud Sync */}
              <button
                type="button"
                onClick={handleTriggerCloudSync}
                disabled={isSyncingCloud}
                className="p-2.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg flex flex-col items-start gap-1 text-left transition-all cursor-pointer shadow-xs active:scale-[0.98]"
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-extrabold text-[11px] sm:text-xs text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5">
                    <RefreshCw className={`w-3.5 h-3.5 text-indigo-600 ${isSyncingCloud ? 'animate-spin' : ''}`} />
                    Sync Cloud Now
                  </span>
                  <span className="text-[8.5px] sm:text-[9px] font-bold text-slate-400">Firebase DB</span>
                </div>
                <p className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400">
                  Forces an immediate bidirectional sync with Google Firebase Firestore database.
                </p>
              </button>
            </div>

            {/* Status Messages */}
            {alignMessage && (
              <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-[11px] rounded-lg font-bold flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>{alignMessage}</span>
              </div>
            )}

            {cloudSyncMessage && (
              <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-300 text-[11px] rounded-lg font-bold flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                <span>{cloudSyncMessage}</span>
              </div>
            )}

            {/* 7-Point Self-Test Results Modal/Inline Panel */}
            {selfTestResult && (
              <div className="p-2.5 sm:p-3 bg-white dark:bg-slate-900 border border-purple-200 dark:border-purple-800/80 rounded-lg sm:rounded-xl space-y-2 shadow-xs">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-1.5">
                  <span className="text-[11px] sm:text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    7-Point MDM Stock Mathematical Test Results
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelfTestResult(null)}
                    className="text-slate-400 hover:text-slate-600 text-[10px] sm:text-[11px] font-bold cursor-pointer"
                  >
                    Close Report
                  </button>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-[10.5px]">
                  {selfTestResult.results.map((r, i) => (
                    <div key={i} className="py-1.5 flex items-start justify-between gap-2.5">
                      <div className="space-y-0.5">
                        <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                          <span className="w-3.5 h-3.5 rounded-full bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 text-[9px] font-extrabold flex items-center justify-center shrink-0">
                            {i + 1}
                          </span>
                          <span>{r.testName}</span>
                        </div>
                        <p className="text-[9.5px] text-slate-500 dark:text-slate-400 pl-4.5">{r.details}</p>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-black shrink-0 ${r.passed ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800' : 'bg-rose-100 text-rose-700'}`}>
                        {r.passed ? 'PASSED' : 'FAILED'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. Password Security & Backup/Restore */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3">
        {/* Change Login Credentials (Mobile, Username, Password) */}
        {(activeFilterTab === 'all' || activeFilterTab === 'profile' || activeFilterTab === 'security') && (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-2.5 sm:space-y-3">
          <div className="flex items-center justify-between pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white flex items-center space-x-1.5 sm:space-x-2">
              <KeyRound className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-600" />
              <span>Login Credentials & Security</span>
            </h3>
            <button
              type="button"
              onClick={() => setShowChangeCredsModal(true)}
              className="px-2 py-0.5 sm:py-1 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 rounded-md sm:rounded-lg text-[10px] sm:text-[11px] font-bold border border-blue-200 dark:border-blue-800 flex items-center gap-1 transition-colors"
            >
              <KeyRound className="w-3 h-3 text-blue-600" />
              <span>Set Password</span>
            </button>
          </div>

          {/* Role selector tabs */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => handleRoleSwitch('HEADMASTER')}
              className={`px-2.5 py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center space-x-1.5 border ${
                selectedRoleToEdit === 'HEADMASTER'
                  ? 'bg-blue-500/10 border-blue-500/40 text-blue-700 dark:text-blue-300 shadow-xs'
                  : 'bg-slate-100/60 dark:bg-slate-800/60 border-transparent text-slate-500'
              }`}
            >
              <span>👨‍💼 Headmaster (HM)</span>
            </button>
            <button
              type="button"
              onClick={() => handleRoleSwitch('MDM_INCHARGE')}
              className={`px-2.5 py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center space-x-1.5 border ${
                selectedRoleToEdit === 'MDM_INCHARGE'
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'bg-slate-100/60 dark:bg-slate-800/60 border-transparent text-slate-500'
              }`}
            >
              <span>🧑‍🍳 MDM Incharge</span>
            </button>
          </div>

          <div className="p-2 bg-slate-100/60 dark:bg-slate-800/60 rounded-lg text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-400 space-y-0.5 border border-slate-200/60 dark:border-slate-700/60">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              Editing: {selectedRoleToEdit === 'HEADMASTER' ? 'Headmaster (Admin)' : 'MDM Incharge (Daily Entry)'}
            </p>
            <p>Users can log in using School Name or UDISE code with password.</p>
          </div>

          {passwordMsg && (
            <div className="p-2 bg-blue-500/10 backdrop-blur-xs border border-blue-500/20 text-blue-800 dark:text-blue-300 text-[11px] rounded-lg font-medium flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-blue-600" />
              <span>{passwordMsg}</span>
            </div>
          )}

          <form onSubmit={handleChangeCredentials} className="space-y-2.5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-2.5">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Login Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                    <UserIcon className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  </div>
                  <input
                    type="text"
                    value={credUsername}
                    onChange={(e) => { setCredUsername(e.target.value); setIsPasswordDirty(true); }}
                    placeholder="Username"
                    className="w-full pl-8 pr-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-slate-900 dark:text-white backdrop-blur-xs font-mono text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Registered Mobile (10 Digits)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                    <Phone className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  </div>
                  <input
                    type="tel"
                    maxLength={10}
                    value={credMobile}
                    onChange={(e) => { setCredMobile(e.target.value); setIsPasswordDirty(true); }}
                    placeholder="10-digit mobile"
                    className="w-full pl-8 pr-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-slate-900 dark:text-white backdrop-blur-xs font-mono text-xs"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                Current Password
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => { setCurrentPassword(e.target.value); setIsPasswordDirty(true); }}
                placeholder="Enter current password to authorize changes"
                className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-slate-900 dark:text-white backdrop-blur-xs text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-2.5">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  New Password <span className="text-slate-400 font-normal">(optional)</span>
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => { setNewPassword(e.target.value); setIsPasswordDirty(true); }}
                  placeholder="Leave empty to keep current"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-slate-900 dark:text-white backdrop-blur-xs text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => { setConfirmPassword(e.target.value); setIsPasswordDirty(true); }}
                  placeholder="Confirm new password"
                  className="w-full px-2.5 py-1.5 bg-slate-100/60 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-slate-900 dark:text-white backdrop-blur-xs text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              className={
                passwordSaveSuccess
                  ? "btn-glass-green w-full py-1.5 sm:py-2 text-[11px] sm:text-xs shadow-md rounded-lg sm:rounded-xl flex items-center justify-center space-x-1.5"
                  : isPasswordDirty
                    ? "btn-glass-orange w-full py-1.5 sm:py-2 text-[11px] sm:text-xs shadow-md rounded-lg sm:rounded-xl flex items-center justify-center space-x-1.5"
                    : "btn-glass-blue w-full py-1.5 sm:py-2 text-[11px] sm:text-xs shadow-md rounded-lg sm:rounded-xl flex items-center justify-center space-x-1.5"
              }
            >
              {passwordSaveSuccess ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-950 animate-bounce" />
                  <span>Credentials Updated Successfully!</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Save Login Credentials</span>
                </>
              )}
            </button>
          </form>
        </div>
        )}

        {/* Data Backup, Source Code (.ZIP) & Restore */}
        {(activeFilterTab === 'all' || activeFilterTab === 'backup') && (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3.5">
          <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white flex items-center justify-between pb-2 sm:pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <span className="flex items-center space-x-1.5 sm:space-x-2">
              <Archive className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Full Source Code (.ZIP) & Data Export</span>
            </span>
            <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
              ZIP Archive
            </span>
          </h3>

          {/* Primary Source Code Download Card */}
          <div className="p-3 sm:p-3.5 bg-gradient-to-br from-emerald-500/10 via-teal-500/10 to-blue-500/10 border-2 border-emerald-500/30 dark:border-emerald-500/40 rounded-xl space-y-2.5 shadow-sm">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                    Complete Application Source Code (.ZIP)
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[8.5px] font-bold bg-emerald-600 text-white">
                    Restored Version
                  </span>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                  Full standalone repository archive (.zip). Contains all frontend React/TypeScript source code, Express backend server, Android TWA config, Firestore security rules, and build scripts.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <a
                href="/api/download-source-zip"
                download="mdm-daily-auto-register-source-code.zip"
                className="py-2.5 px-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white font-black rounded-lg sm:rounded-xl text-[11px] sm:text-xs shadow-md shadow-emerald-600/25 transition-all hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-center space-x-1.5 cursor-pointer text-center"
              >
                <Archive className="w-4 h-4 text-white shrink-0" />
                <span>Download Source Code (.ZIP)</span>
              </a>

              <a
                href="/mdm-daily-auto-register-source-code.zip"
                download="mdm-daily-auto-register-source-code.zip"
                className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 dark:bg-slate-750 dark:hover:bg-slate-700 text-slate-100 font-bold rounded-lg sm:rounded-xl text-[11px] sm:text-xs border border-slate-600/50 shadow-xs transition-all hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-center space-x-1.5 cursor-pointer text-center"
              >
                <Download className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                <span>Mirror Direct File (.zip)</span>
              </a>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-[9.5px] text-slate-500 dark:text-slate-400 pt-1">
              <span className="font-semibold text-emerald-700 dark:text-emerald-300">✓ No JSON data dump</span>
              <span>•</span>
              <span>✓ 100+ Source Files included</span>
              <span>•</span>
              <span>✓ Extract and run: <code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded text-[9px] font-mono">npm install && npm run dev</code></span>
            </div>
          </div>

          <div className="space-y-2 sm:space-y-2.5 text-xs pt-1">
            <div className="flex items-center justify-between text-[10.5px] sm:text-xs text-slate-500">
              <span>School Data Backup (Database records & registers only)</span>
            </div>

            <button
              type="button"
              onClick={handleDownloadBackup}
              className="w-full py-2 sm:py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 font-bold rounded-lg sm:rounded-xl text-[11px] sm:text-xs border border-slate-300 dark:border-slate-700 shadow-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Download Data Records (JSON Backup)</span>
            </button>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10px] sm:text-[11px]">
                Restore Data from Backup File or JSON
              </label>

              <div className="flex items-center gap-1.5">
                <label className="flex-1 py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-dashed border-slate-400 dark:border-slate-600 rounded-lg text-center text-[11px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer flex items-center justify-center gap-1.5 transition-all">
                  <Upload className="w-3.5 h-3.5 text-purple-600" />
                  <span>Choose Backup File (.json)</span>
                  <input
                    type="file"
                    accept=".json,application/json"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          const content = event.target?.result as string;
                          if (content) {
                            setRestoreJson(content);
                            try {
                              const parsed = JSON.parse(content);
                              const details = [
                                parsed.profile?.schoolName ? `School: ${parsed.profile.schoolName}` : null,
                                Array.isArray(parsed.dailyEntries) ? `${parsed.dailyEntries.length} Daily Entries` : null,
                                Array.isArray(parsed.commodities) ? `${parsed.commodities.length} Commodities` : null,
                              ].filter(Boolean).join(', ');
                              setRestoreStatus(`✓ File loaded: ${file.name} (${details || 'Valid format'})`);
                            } catch {
                              setRestoreStatus(`Loaded ${file.name} — ready to restore.`);
                            }
                          }
                        };
                        reader.readAsText(file);
                      }
                    }}
                  />
                </label>
              </div>

              <textarea
                rows={2}
                value={restoreJson}
                onChange={(e) => {
                  setRestoreJson(e.target.value);
                  setRestoreStatus(null);
                }}
                placeholder="Or paste backup JSON text here..."
                className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-[9.5px] sm:text-[10px]"
              />

              {restoreStatus && (
                <div className={`p-1.5 rounded-lg text-[10.5px] font-bold ${
                  restoreStatus.includes('successfully') || restoreStatus.includes('✓')
                    ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                    : 'bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20'
                }`}>
                  {restoreStatus}
                </div>
              )}

              <button
                type="button"
                onClick={handleRestoreBackup}
                disabled={!restoreJson.trim()}
                className="w-full py-2 bg-gradient-to-r from-slate-700 via-slate-800 to-slate-900 hover:from-slate-600 hover:via-slate-700 hover:to-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black rounded-lg sm:rounded-xl text-[11px] sm:text-xs border-2 border-slate-600 dark:border-slate-500 border-b-[3px] sm:border-b-[4px] border-b-slate-950 dark:border-b-slate-950 shadow-md shadow-slate-900/30 transition-all hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Restore Application Data</span>
              </button>
            </div>
          </div>
        </div>
        )}
      </div>

      {/* App Logo & Flash Screen Showcase Card */}
      <div className="bg-gradient-to-r from-sky-950/80 via-slate-900/80 to-blue-950/80 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-sky-400/40 shadow-md text-white space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden shadow-md ring-2 ring-sky-400/50 shrink-0 bg-slate-900">
              <img
                src="/app-logo.png"
                alt="MDM Daily Auto Register App Logo"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-0.5">
                Official Identity
              </div>
              <h3 className="text-sm sm:text-base font-black text-white">
                MDM Daily Auto Register
              </h3>
              <p className="text-[10px] sm:text-[11px] text-sky-200/80">
                Mid-Day Meal Register with Daily Auto Attendance, Cash Voucher & Reports
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {onOpenFlashScreen && (
              <button
                type="button"
                onClick={onOpenFlashScreen}
                className="px-2.5 sm:px-3 py-1.5 bg-gradient-to-r from-amber-400 via-sky-400 to-emerald-400 hover:from-amber-300 hover:to-emerald-300 text-slate-950 font-black rounded-lg sm:rounded-xl text-[11px] sm:text-xs shadow-xs transition-all active:scale-95 flex items-center space-x-1 cursor-pointer"
              >
                <span>⚡ Replay Flash</span>
              </button>
            )}
            <a
              href="/mdm-source-code.zip"
              download="mdm-source-code.zip"
              className="px-2.5 sm:px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg sm:rounded-xl text-[11px] sm:text-xs shadow-xs transition-all flex items-center space-x-1 cursor-pointer ring-1 ring-white/30"
              title="Download Clean Source Code ZIP Archive"
            >
              <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.5]" />
              <span>Source (.ZIP)</span>
            </a>
            <a
              href="/app-logo.png"
              download="mdm-daily-auto-register-logo.png"
              className="px-2.5 sm:px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold rounded-lg sm:rounded-xl text-[11px] sm:text-xs border border-sky-400/30 shadow-xs transition-all flex items-center space-x-1"
            >
              <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>Logo (.PNG)</span>
            </a>
          </div>
        </div>
      </div>

      {/* 4. Reset Data Section (Fresh Start for New User) */}
      {(activeFilterTab === 'all' || activeFilterTab === 'reset') && (
      <div className="bg-rose-50/60 dark:bg-rose-950/20 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-rose-200/80 dark:border-rose-900/50 shadow-xs space-y-2.5 sm:space-y-3">
        <h3 className="text-xs sm:text-sm font-bold text-rose-800 dark:text-rose-300 flex items-center space-x-1.5 sm:space-x-2 pb-2 sm:pb-2.5 border-b border-rose-200/60 dark:border-rose-900/50">
          <RotateCcw className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-600 dark:text-rose-400" />
          <span>Reset Application Data (Fresh Start for New User)</span>
        </h3>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <p className="text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
            If you are a new user or starting a fresh academic term, click below to clear pre-existing sample or past records (daily registers, stock entries, commodity usages, class attendance). Only freshly entered data starting from the dates you select will be displayed. School master information and meal rates will remain intact.
          </p>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-800 dark:text-white font-extrabold rounded-lg sm:rounded-xl text-[11px] sm:text-xs border border-slate-200 dark:border-slate-700 shadow-xs transition-all cursor-pointer uppercase tracking-wider"
              >
                Cancel & Close
              </button>
            )}

            <button
              type="button"
              onClick={handleOpenResetModal}
              className="px-3.5 py-1.5 bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-600 text-white font-black rounded-lg sm:rounded-xl text-[11px] sm:text-xs border-2 border-rose-400 dark:border-rose-500 border-b-[3px] border-b-rose-900 shadow-md shadow-rose-600/30 transition-all hover:-translate-y-0.5 active:translate-y-0.5 flex items-center space-x-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset All Data</span>
            </button>
          </div>
        </div>
      </div>
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-rose-200 dark:border-rose-900 max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3 border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2 text-rose-600 dark:text-rose-400 font-black">
                <AlertCircle className="w-5 h-5 animate-pulse" />
                <span className="text-base">Confirm Database Reset</span>
              </div>
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-rose-50 dark:bg-rose-950/20 p-3 rounded-xl border border-rose-100 dark:border-rose-900/30">
              This action will permanently erase all recorded daily registers, stock entries, commodity receipts, and school attendance records. <strong>Only freshly entered data will be shown from now on.</strong> School profiles and meal rates will remain safe.
            </p>

            {resetError && (
              <div className="p-2.5 bg-red-500/10 border border-red-500/20 text-red-700 dark:text-red-400 text-xs font-bold rounded-xl animate-shake">
                {resetError}
              </div>
            )}

            {/* DOUBLE CONFIRMATION CHECKBOX */}
            <div className="flex items-start space-x-2.5 pt-1.5">
              <input
                id="reset-confirm-yes"
                type="checkbox"
                checked={confirmYes}
                onChange={(e) => {
                  setConfirmYes(e.target.checked);
                  setResetError(null);
                }}
                className="mt-0.5 h-4 w-4 rounded-sm border-slate-300 text-rose-600 focus:ring-rose-500 cursor-pointer"
              />
              <label htmlFor="reset-confirm-yes" className="text-xs font-bold text-slate-700 dark:text-slate-300 select-none cursor-pointer leading-tight">
                Yes, I understand that this action is permanent and I want to proceed.
              </label>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-extrabold rounded-xl text-xs border border-slate-350 dark:border-slate-700 shadow-sm transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReset}
                disabled={!confirmYes}
                className={`px-5 py-2.5 font-black rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow-md cursor-pointer ${
                  confirmYes
                    ? 'bg-rose-600 hover:bg-rose-700 text-white border border-rose-700 active:scale-95'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border border-slate-300 dark:border-slate-700 cursor-not-allowed opacity-60'
                }`}
              >
                <Trash2 className="w-4 h-4" />
                <span>Yes, Reset Everything</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change School Image Modal */}
      {showImageModal && (
        <ChangeSchoolImageModal
          schoolProfile={profileForm}
          isOpen={showImageModal}
          onClose={() => setShowImageModal(false)}
          onSaveImage={(newUrl) => {
            const updated = { ...profileForm, schoolPhotoUrl: newUrl };
            setProfileForm(updated);
            handleProfileChange(updated);
            showMsg('School photo updated!');
          }}
        />
      )}

      {/* Change Credentials & Mobile OTP Reset Modal */}
      <ChangeCredentialsModal
        isOpen={showChangeCredsModal}
        onClose={() => setShowChangeCredsModal(false)}
        defaultRole={selectedRoleToEdit}
        schoolId={activeSchoolIdState}
        onCredentialsUpdated={(updatedCreds, role) => {
          setCredentials(updatedCreds);
          const target = role === 'HEADMASTER' ? updatedCreds.headmaster : updatedCreds.incharge;
          setCredUsername(target.username);
          setCredMobile(target.mobile);
          setPasswordMsg(`Login credentials updated successfully for ${role === 'HEADMASTER' ? 'Headmaster' : 'MDM Incharge'}!`);
          setTimeout(() => setPasswordMsg(null), 4000);
        }}
      />

      {/* Register New School Account Modal */}
      <RegisterSchoolModal
        isOpen={showRegisterSchoolModal}
        onClose={() => setShowRegisterSchoolModal(false)}
        onSchoolRegistered={(user) => {
          setSchoolAccounts(getSchoolAccounts());
          if (user.schoolId) {
            setActiveSchoolIdState(user.schoolId);
            setActiveSchoolId(user.schoolId);
            if (onSwitchSchool) {
              onSwitchSchool(user.schoolId);
            }
          }
          showMsg(`School "${user.schoolName}" registered with isolated data partition!`);
        }}
      />
    </div>
  );
};
