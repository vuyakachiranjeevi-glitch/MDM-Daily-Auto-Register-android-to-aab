import React, { useState } from 'react';
import {
  KeyRound,
  Phone,
  Lock,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  X,
  RefreshCw,
  Building2,
} from 'lucide-react';
import { forgotPasswordReset, forgotPasswordDirectReset } from '../lib/authApi';
import { updateLoginCredentials, getSchoolAccounts, getActiveSchoolId } from '../lib/storage';

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialIdentifier?: string;
}

export const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialIdentifier = '',
}) => {
  const [step, setStep] = useState<'IDENTIFIER' | 'NEW_PASSWORD' | 'SUCCESS'>('IDENTIFIER');
  const [identifier, setIdentifier] = useState(initialIdentifier);
  const [targetAccountName, setTargetAccountName] = useState('');
  const [matchedSchoolId, setMatchedSchoolId] = useState('');
  const [targetRole, setTargetRole] = useState<'HEADMASTER' | 'MDM_INCHARGE'>('HEADMASTER');
  const [resetToken, setResetToken] = useState('');

  // Password state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleResetModal = () => {
    setStep('IDENTIFIER');
    setIdentifier('');
    setTargetAccountName('');
    setMatchedSchoolId('');
    setResetToken('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
    setSuccessMsg(null);
    onClose();
  };

  // STEP 1: Verify Account Directly (No OTP)
  const handleVerifyAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    const cleanInput = identifier.trim();
    const digits = cleanInput.replace(/\D/g, '');
    const lower = cleanInput.toLowerCase();
    if (!cleanInput || digits.length < 6) {
      setError('Please enter your School UDISE code.');
      return;
    }

    setIsLoading(true);

    try {
      const accounts = getSchoolAccounts();
      const matched = accounts.find((a) => {
        return a.udiseCode === digits || a.udiseCode.toLowerCase() === cleanInput.toLowerCase();
      });

      if (matched) {
        // Detect role if specific username matched
        const isInc =
          matched.credentials?.incharge?.username &&
          matched.credentials.incharge.username.toLowerCase() === lower;
        const determinedRole = isInc ? 'MDM_INCHARGE' : 'HEADMASTER';

        setMatchedSchoolId(matched.schoolId);
        setTargetAccountName(matched.schoolName);
        setTargetRole(determinedRole);
        setResetToken(`direct_reset_${Date.now()}`);
        setSuccessMsg(`School account verified: "${matched.schoolName}" (${matched.udiseCode})`);
        setStep('NEW_PASSWORD');
      } else {
        // If not found in local accounts list, fall back to active school
        const activeId = getActiveSchoolId();
        const activeSchool = accounts.find((a) => a.schoolId === activeId);
        if (activeSchool) {
          setMatchedSchoolId(activeSchool.schoolId);
          setTargetAccountName(activeSchool.schoolName);
          setTargetRole('HEADMASTER');
          setResetToken(`direct_reset_${Date.now()}`);
          setSuccessMsg(`School account verified: "${activeSchool.schoolName}"`);
          setStep('NEW_PASSWORD');
        } else {
          setError('No school account found matching this identifier. Please verify your details.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Verification failed. Please check account details.');
    } finally {
      setIsLoading(false);
    }
  };

  // STEP 2: Set New Password
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!newPassword || newPassword.length < 4) {
      setError('New password must be at least 4 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }

    setIsLoading(true);
    try {
      // 1. Sync new password to backend server
      const cleanIdent = identifier.trim() || matchedSchoolId;
      try {
        await forgotPasswordDirectReset(cleanIdent, newPassword, confirmPassword);
      } catch (err) {
        console.warn('Backend direct reset fallback to local storage:', err);
      }

      // 2. Update local storage credentials for school account
      const sId = matchedSchoolId || getActiveSchoolId();
      updateLoginCredentials(targetRole, { password: newPassword }, sId);

      setSuccessMsg('Password has been updated successfully! You can now log in.');
      setStep('SUCCESS');
    } catch (err: any) {
      setError(err?.message || 'Failed to update password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-70 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 pb-8 sm:pb-10 md:pb-12 overflow-y-auto">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto mb-7 sm:mb-8 md:mb-10 max-h-[calc(100dvh-3.5rem)] sm:max-h-[calc(100dvh-4rem)] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-600 to-sky-600 px-4 py-3.5 sm:px-6 sm:py-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5 sm:space-x-3">
            <div className="p-2 sm:p-2.5 bg-white/20 rounded-xl sm:rounded-2xl backdrop-blur-md">
              <KeyRound className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">Reset Password</h3>
              <p className="text-[10px] sm:text-xs text-blue-100 font-medium">Fast & Direct Password Recovery</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleResetModal}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white/90 hover:text-white cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-4">
          {/* Progress Indicator */}
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2.5 text-xs font-bold">
            <span
              className={`flex items-center gap-1 ${
                step === 'IDENTIFIER' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'
              }`}
            >
              1. Verify Account
            </span>
            <span className="text-slate-300 dark:text-slate-700">→</span>
            <span
              className={`flex items-center gap-1 ${
                step === 'NEW_PASSWORD' || step === 'SUCCESS'
                  ? 'text-blue-600 dark:text-blue-400'
                  : 'text-slate-400'
              }`}
            >
              2. Set New Password
            </span>
          </div>

          {/* Feedback Alerts */}
          {error && (
            <div className="p-2.5 sm:p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-700 dark:text-red-300 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-2.5 sm:p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* STEP 1: IDENTIFIER (No OTP) */}
          {step === 'IDENTIFIER' && (
            <form onSubmit={handleVerifyAccount} className="space-y-3.5">
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Enter your School UDISE code to verify your school profile and set your portal password.
              </p>

              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  School UDISE Code
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
                  </div>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value.replace(/\D/g, '').slice(0, 11))}
                    placeholder="e.g. 28261800503"
                    className="w-full pl-9 sm:pl-10 pr-4 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 font-mono"
                    required
                    maxLength={11}
                    autoFocus
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleResetModal}
                  className="px-3.5 sm:px-4 py-2 sm:py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-2 sm:py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5 active:scale-[0.99] cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <span>Verify Account & Continue</span>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: NEW PASSWORD */}
          {step === 'NEW_PASSWORD' && (
            <form onSubmit={handleResetPassword} className="space-y-3.5">
              {targetAccountName && (
                <div className="p-2.5 bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900 rounded-xl flex items-center gap-2 text-xs text-blue-900 dark:text-blue-200">
                  <Building2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="font-semibold truncate">Resetting password for: {targetAccountName}</span>
                </div>
              )}

              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter at least 4 characters"
                    className="w-full pl-9 sm:pl-10 pr-9 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                    required
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Confirm New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full pl-9 sm:pl-10 pr-9 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setStep('IDENTIFIER')}
                  className="px-3.5 sm:px-4 py-2 sm:py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-2 sm:py-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5 active:scale-[0.99] cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <span>Save New Password</span>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 'SUCCESS' && (
            <div className="space-y-4 text-center py-2">
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-950/60 rounded-full flex items-center justify-center mx-auto text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">Password Changed Successfully!</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  You can now log in using your School Name or UDISE code and your new password.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  handleResetModal();
                  onSuccess();
                }}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all active:scale-[0.99] cursor-pointer"
              >
                Proceed to Login
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
