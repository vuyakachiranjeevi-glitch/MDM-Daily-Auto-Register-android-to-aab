import React, { useState } from 'react';
import { CommodityItem, DailyEntry, StockTransaction } from '../types';
import { MonthlyCommodityOverrides } from '../lib/storage';
import { formatDateReadable, formatQtyVal, runStockCarryForwardSelfTest } from '../lib/utils';
import { OpeningBalanceModal } from './OpeningBalanceModal';
import {
  Boxes,
  PlusCircle,
  AlertTriangle,
  History,
  TrendingDown,
  Wheat,
  Egg,
  Cookie,
  Flame,
  Sparkles,
  ArrowUpRight,
  Plus,
  Package,
  Edit3,
  Trash2,
  Calendar,
  Search,
  X,
  CheckCircle2,
  Droplet,
  Soup,
  Save,
  ShieldCheck,
  RefreshCw,
  Sliders,
} from 'lucide-react';

interface CommodityStockViewProps {
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  dailyEntries?: DailyEntry[];
  stockTransactions: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  onAddTransaction: (tx: StockTransaction | StockTransaction[]) => void;
  onUpdateTransaction?: (tx: StockTransaction) => void;
  onDeleteTransaction?: (txId: string) => void;
  onSaveOpeningBalances?: (updated: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  totalStudents: number;
}

export const CommodityStockView: React.FC<CommodityStockViewProps> = ({
  commodities,
  baseCommodities = commodities,
  dailyEntries = [],
  stockTransactions,
  monthlyOverrides = {},
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  totalStudents,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showOpeningModal, setShowOpeningModal] = useState(false);
  const [showSelfTestModal, setShowSelfTestModal] = useState(false);
  const [selfTestResult, setSelfTestResult] = useState<ReturnType<typeof runStockCarryForwardSelfTest> | null>(null);
  const [saveSuccessType, setSaveSuccessType] = useState<'SAVED' | 'UPDATED' | null>(null);

  // Form State for Stock Transaction (Add or Edit)
  const [editingTxId, setEditingTxId] = useState<string | null>(null);
  const [deleteConfirmTx, setDeleteConfirmTx] = useState<StockTransaction | null>(null);
  const [txDate, setTxDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [commodityId, setCommodityId] = useState<string>('rice');
  const [txType, setTxType] = useState<'RECEIVED' | 'SPOILED' | 'ADJUSTMENT'>('RECEIVED');
  const [quantity, setQuantity] = useState<number>(100);
  const [invoiceNo, setInvoiceNo] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // Multi-Commodity Quantities & Remarks
  const [multiQuantities, setMultiQuantities] = useState<Record<string, number | ''>>({});
  const [multiRemarks, setMultiRemarks] = useState<Record<string, string>>({});

  // History Filter
  const [filterQuery, setFilterQuery] = useState<string>('');

  const handleOpenAddModal = (type: 'RECEIVED' | 'SPOILED' | 'ADJUSTMENT' = 'RECEIVED') => {
    setEditingTxId(null);
    setTxDate(new Date().toISOString().split('T')[0]);
    setCommodityId('rice');
    setTxType(type);
    setQuantity(type === 'RECEIVED' ? 100 : 0);
    setInvoiceNo('');
    setRemarks('');
    setMultiQuantities({});
    setMultiRemarks({});
    setShowAddModal(true);
  };

  const handleRunSelfTest = () => {
    const res = runStockCarryForwardSelfTest();
    setSelfTestResult(res);
    setShowSelfTestModal(true);
  };

  const handleOpenEditModal = (tx: StockTransaction) => {
    setEditingTxId(tx.id);
    setTxDate(tx.date || new Date().toISOString().split('T')[0]);
    setCommodityId(tx.commodityId);
    setTxType(tx.type || 'RECEIVED');
    setQuantity(tx.quantity);
    setInvoiceNo(tx.invoiceNo || '');
    setRemarks(tx.remarks || tx.adjustmentReason || '');
    setShowAddModal(true);
  };

  const handleDeleteClick = (tx: StockTransaction) => {
    setDeleteConfirmTx(tx);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingTxId) {
      if (quantity < 0) return;
      const txData: StockTransaction = {
        id: editingTxId,
        date: txDate || new Date().toISOString().split('T')[0],
        commodityId,
        type: txType,
        quantity,
        invoiceNo: invoiceNo.trim() || undefined,
        remarks: remarks.trim() || undefined,
        adjustmentReason: txType === 'ADJUSTMENT' ? (remarks.trim() || 'Manual stock adjustment') : undefined,
      };

      if (onUpdateTransaction) {
        onUpdateTransaction(txData);
      }
    } else {
      // Multi-Commodity Submission
      const validCommodities = commodities.filter((c) => {
        const val = Number(multiQuantities[c.id]);
        return !isNaN(val) && val > 0;
      });

      if (validCommodities.length === 0) {
        alert('Please enter a quantity greater than 0 for at least one commodity.');
        return;
      }

      const newTxs: StockTransaction[] = validCommodities.map((c, index) => ({
        id: `tx-${Date.now()}-${index}`,
        date: txDate || new Date().toISOString().split('T')[0],
        commodityId: c.id as any,
        type: txType,
        quantity: Number(multiQuantities[c.id]),
        invoiceNo: invoiceNo.trim() || undefined,
        remarks: multiRemarks[c.id]?.trim() || remarks.trim() || undefined,
        adjustmentReason: txType === 'ADJUSTMENT' ? (multiRemarks[c.id]?.trim() || remarks.trim() || 'Manual balance adjustment') : undefined,
      }));

      onAddTransaction(newTxs);
    }

    setSaveSuccessType(editingTxId ? 'UPDATED' : 'SAVED');
    setTimeout(() => {
      setSaveSuccessType(null);
      setShowAddModal(false);
      setEditingTxId(null);
      setMultiQuantities({});
      setMultiRemarks({});
      setQuantity(100);
      setInvoiceNo('');
      setRemarks('');
    }, 700);
  };

  const getCommodityIcon = (id: string) => {
    switch (id) {
      case 'rice':
        return <Wheat className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-600 dark:text-amber-400" />;
      case 'oil':
        return <Droplet className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500 dark:text-amber-400" />;
      case 'pulses':
        return <Soup className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-600 dark:text-yellow-400" />;
      case 'egg':
        return <Egg className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-600 dark:text-yellow-400" />;
      case 'chikki':
        return <Cookie className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-700 dark:text-amber-400" />;
      case 'ragi':
        return <Flame className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-800 dark:text-amber-400" />;
      case 'jaggery':
        return <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-700 dark:text-amber-400" />;
      default:
        return <Boxes className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-600 dark:text-amber-400" />;
    }
  };

  return (
    <div className="space-y-2 pb-14 sm:pb-16 md:pb-20 lg:pb-24">
      {/* Header */}
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-2.5 sm:p-3.5 rounded-xl border border-white/80 dark:border-slate-800/80 shadow-2xs flex flex-col space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <Boxes className="w-4 h-4 text-amber-500" />
                Commodity Stock Register & Auto Carry-Forward
              </h2>
              <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5" />
                Auto-Carry Active
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              Closing balances automatically carry forward as next date/month opening balances across all commodities.
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleRunSelfTest}
              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/60 dark:hover:bg-blue-900/80 text-blue-700 dark:text-blue-300 rounded-lg text-[11px] font-bold border border-blue-200 dark:border-blue-800 flex items-center gap-1 cursor-pointer transition-all active:scale-95"
              title="Run 7-Point Automated Verification Suite"
            >
              <ShieldCheck className="w-3 h-3 text-blue-600" />
              <span>Verify Logic (7 Tests)</span>
            </button>
          </div>
        </div>

        {/* Quick Actions & Stock Management Bar */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-1.5 p-1 sm:p-1.5 bg-amber-50/40 dark:bg-amber-950/20 rounded-lg border border-amber-200/60 dark:border-amber-900/40">
          <div className="flex items-center gap-1">
            <Boxes className="w-3 h-3 text-amber-600 dark:text-amber-400" />
            <span className="font-extrabold text-[10px] sm:text-[11px] text-slate-800 dark:text-slate-200 uppercase tracking-wide">
              Commodities Entry & Stock Register Actions
            </span>
          </div>
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-1 w-full lg:w-auto">
            {/* Receive Commodity Button */}
            <button
              type="button"
              onClick={() => handleOpenAddModal('RECEIVED')}
              className="w-full sm:w-auto sm:flex-none relative group px-2 py-1 bg-gradient-to-b from-emerald-500 via-emerald-600 to-emerald-700 dark:from-emerald-600 dark:via-emerald-700 dark:to-emerald-800 text-white font-black text-[9.5px] sm:text-[10.5px] rounded-lg border-t border-x border-emerald-300/60 dark:border-emerald-400/40 border-b-2 border-b-emerald-900 dark:border-b-emerald-950 shadow-2xs hover:shadow-xs transition-all duration-150 active:translate-y-0.5 flex items-center justify-center space-x-1 cursor-pointer text-center whitespace-nowrap overflow-hidden"
            >
              <Plus className="w-3 h-3 text-emerald-100 relative z-10 shrink-0" />
              <span className="relative z-10">RECEIVE COMMODITY</span>
            </button>

            {/* Spoiled / Damaged Button */}
            <button
              type="button"
              onClick={() => handleOpenAddModal('SPOILED')}
              className="w-full sm:w-auto sm:flex-none relative group px-2 py-1 bg-gradient-to-b from-rose-500 via-red-600 to-red-700 dark:from-rose-600 dark:via-red-700 dark:to-red-800 text-white font-black text-[9.5px] sm:text-[10.5px] rounded-lg border-t border-x border-rose-300/60 dark:border-rose-400/40 border-b-2 border-b-red-950 shadow-2xs hover:shadow-xs transition-all duration-150 active:translate-y-0.5 flex items-center justify-center space-x-1 cursor-pointer text-center whitespace-nowrap overflow-hidden"
            >
              <AlertTriangle className="w-3 h-3 text-rose-100 relative z-10 shrink-0" />
              <span className="relative z-10">LOG SPOILS</span>
            </button>

            {/* Stock Adjustment Button */}
            <button
              type="button"
              onClick={() => handleOpenAddModal('ADJUSTMENT')}
              className="w-full sm:w-auto sm:flex-none relative group px-2 py-1 bg-gradient-to-b from-amber-500 via-amber-600 to-amber-700 dark:from-amber-600 dark:via-amber-700 dark:to-amber-800 text-white font-black text-[9.5px] sm:text-[10.5px] rounded-lg border-t border-x border-amber-300/60 dark:border-amber-400/40 border-b-2 border-b-amber-950 shadow-2xs hover:shadow-xs transition-all duration-150 active:translate-y-0.5 flex items-center justify-center space-x-1 cursor-pointer text-center whitespace-nowrap overflow-hidden"
            >
              <Sliders className="w-3 h-3 text-amber-100 relative z-10 shrink-0" />
              <span className="relative z-10">ADJUST STOCK</span>
            </button>

            {/* Closing Balance Button */}
            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('commodity-stock-ledger');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }}
              className="w-full sm:w-auto sm:flex-none relative group px-2 py-1 bg-gradient-to-b from-indigo-500 via-indigo-600 to-indigo-700 dark:from-indigo-600 dark:via-indigo-700 dark:to-indigo-800 text-white font-black text-[9.5px] sm:text-[10.5px] rounded-lg border-t border-x border-indigo-300/60 dark:border-indigo-400/40 border-b-2 border-b-indigo-950 shadow-2xs hover:shadow-xs transition-all duration-150 active:translate-y-0.5 flex items-center justify-center space-x-1 cursor-pointer text-center whitespace-nowrap overflow-hidden"
            >
              <TrendingDown className="w-3 h-3 text-indigo-100 relative z-10 shrink-0" />
              <span className="relative z-10">CLOSING BALANCE</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Stock Table */}
      <div id="commodity-stock-ledger" className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md rounded-xl border border-white/80 dark:border-slate-800/80 shadow-2xs overflow-hidden">
        <div className="p-2.5 sm:p-3 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-1.5">
          <div className="flex items-center space-x-2">
            <h3 className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm">
              Current Stock Balance Ledger
            </h3>
            <button
              onClick={() => setShowOpeningModal(true)}
              className="btn-glass-amber text-[10.5px] px-2 py-0.5"
              title="Edit Opening Balances for starting month"
            >
              <Edit3 className="w-2.5 h-2.5" />
              <span>Starting Balances</span>
            </button>
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-500 flex items-center gap-1.5">
            <span className="font-mono">CB = OB + Received - Used - Spoiled</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px] sm:text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 text-[10.5px]">
                <th className="py-2 px-2.5">Commodity Name</th>
                <th className="py-2 px-2 text-center">Unit</th>
                <th className="py-2 px-2.5 text-right">Opening Balance (Auto)</th>
                <th className="py-2 px-2.5 text-right text-emerald-600 dark:text-emerald-400">Received (+)</th>
                <th className="py-2 px-2.5 text-right text-blue-600 dark:text-blue-400">Issued / Used (-)</th>
                <th className="py-2 px-2.5 text-right text-red-600 dark:text-red-400">Spoiled (-)</th>
                <th className="py-2 px-2.5 text-right">Closing Balance</th>
                <th className="py-2 px-2 text-center">Next Period Carry</th>
                <th className="py-2 px-2 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
              {commodities.map((c) => {
                const isLow = c.closingBalance <= c.minThreshold;

                return (
                  <tr key={c.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-1.5 px-2.5 font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                      <div className="p-1 rounded-md bg-slate-100 dark:bg-slate-800">{getCommodityIcon(c.id)}</div>
                      <span>{c.name}</span>
                    </td>
                    <td className="py-1.5 px-2 text-center font-semibold text-slate-500 text-[10px]">{c.unit}</td>
                    <td className={`py-1.5 px-2.5 text-right font-medium ${c.openingBalance < 0 ? 'text-rose-600 dark:text-rose-400 font-bold' : 'text-indigo-700 dark:text-indigo-300'}`}>
                      {formatQtyVal(c.openingBalance)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-bold text-emerald-600 dark:text-emerald-400">
                      +{formatQtyVal(c.received)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-bold text-blue-600 dark:text-blue-400">
                      -{formatQtyVal(c.used)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-bold text-red-600 dark:text-red-400">
                      {c.spoiled > 0 ? `-${formatQtyVal(c.spoiled)}` : '0'}
                    </td>
                    <td className={`py-1.5 px-2.5 text-right font-black ${c.closingBalance < 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
                      {formatQtyVal(c.closingBalance)} {c.unit}
                    </td>
                    <td className="py-1.5 px-2 text-center">
                      <span className="inline-flex items-center gap-0.5 text-[9.5px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-200 dark:border-emerald-800">
                        <span>↳ {formatQtyVal(c.closingBalance)} {c.unit}</span>
                      </span>
                    </td>
                    <td className="py-1.5 px-2 text-center">
                      {isLow ? (
                        <span className="inline-flex items-center space-x-0.5 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                          <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                          <span>LOW</span>
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          ✓ OK
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock Transaction Log History Table */}
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md rounded-xl border border-white/80 dark:border-slate-800/80 shadow-2xs p-3 space-y-2.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
          <h3 className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm flex items-center space-x-1.5">
            <History className="w-3.5 h-3.5 text-blue-600" />
            <span>Stock Replenishment & Damage History Log</span>
          </h3>

          {/* Quick Search / Date Filter */}
          <div className="relative min-w-[180px]">
            <Search className="w-3 h-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Search date, commodity, invoice..."
              className="w-full pl-7 pr-2.5 py-1 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-1 focus:ring-amber-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-slate-50/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 font-bold border-b border-slate-200/60 dark:border-slate-700/60 text-[10px]">
                <th className="py-1.5 px-2">Date</th>
                <th className="py-1.5 px-2">Commodity</th>
                <th className="py-1.5 px-2">Type</th>
                <th className="py-1.5 px-2 text-right">Quantity</th>
                <th className="py-1.5 px-2">Invoice / Voucher No</th>
                <th className="py-1.5 px-2">Remarks</th>
                <th className="py-1.5 px-2 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {stockTransactions
                .slice()
                .reverse()
                .filter((tx) => {
                  if (!filterQuery.trim()) return true;
                  const q = filterQuery.toLowerCase();
                  const item = commodities.find((c) => c.id === tx.commodityId);
                  return (
                    tx.date.toLowerCase().includes(q) ||
                    (item?.name || tx.commodityId).toLowerCase().includes(q) ||
                    tx.type.toLowerCase().includes(q) ||
                    (tx.invoiceNo || '').toLowerCase().includes(q) ||
                    (tx.remarks || '').toLowerCase().includes(q)
                  );
                })
                .map((tx) => {
                  const item = commodities.find((c) => c.id === tx.commodityId);
                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-1.5 px-2 font-semibold text-slate-800 dark:text-slate-200">
                        {formatDateReadable(tx.date)}
                      </td>
                      <td className="py-1.5 px-2 font-bold text-slate-900 dark:text-white">{item?.name || tx.commodityId}</td>
                      <td className="py-1.5 px-2">
                        <span
                          className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${
                            tx.type === 'RECEIVED'
                              ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-300'
                              : 'bg-red-500/10 border border-red-500/20 text-red-800 dark:text-red-300'
                          }`}
                        >
                          {tx.type}
                        </span>
                      </td>
                      <td
                        className={`py-1.5 px-2 text-right font-black ${
                          tx.type === 'RECEIVED' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600'
                        }`}
                      >
                        {tx.type === 'RECEIVED' ? `+${tx.quantity}` : `-${tx.quantity}`} {item?.unit}
                      </td>
                      <td className="py-1.5 px-2 font-mono text-slate-500 text-[10px]">{tx.invoiceNo || 'N/A'}</td>
                      <td className="py-1.5 px-2 text-slate-500 max-w-xs truncate text-[10.5px]">{tx.remarks || '-'}</td>
                      <td className="py-1.5 px-2 text-center">
                        <div className="flex items-center justify-center space-x-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEditModal(tx)}
                            className="p-1 hover:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded transition-colors cursor-pointer"
                            title="Edit Transaction"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteClick(tx)}
                            className="p-1 hover:bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded transition-colors cursor-pointer"
                            title="Delete Transaction"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>

        {/* Reserved Clean Bottom Clearance Space for Ads in Stock Register */}
        <div
          id="stock-bottom-ad-spacer"
          className="no-print w-full h-14 sm:h-16 md:h-20 lg:h-24 shrink-0 pointer-events-none select-none transition-all duration-300"
          style={{ minHeight: 'calc(3.84rem + env(safe-area-inset-bottom, 0px))' }}
          aria-hidden="true"
        />
      </div>

      {/* Verification Suite Modal */}
      {showSelfTestModal && selfTestResult && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-xl border border-slate-200 dark:border-slate-800 space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className={`w-5 h-5 ${selfTestResult.allPassed ? 'text-emerald-600' : 'text-rose-600'}`} />
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-sm sm:text-base">
                    Automatic Balance Carry-Forward Logic Verification
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    7-Point automated validation suite per MDM specification
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSelfTestModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
              selfTestResult.allPassed
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
            }`}>
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Status: {selfTestResult.allPassed ? 'ALL 7 TESTS PASSED' : 'TESTS FAILED'}</span>
              </div>
              <button
                type="button"
                onClick={handleRunSelfTest}
                className="px-2 py-0.5 bg-white dark:bg-slate-800 rounded-md text-[11px] font-bold shadow-2xs border border-slate-200 dark:border-slate-700 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                <span>Re-Run</span>
              </button>
            </div>

            <div className="space-y-1.5 text-xs">
              {selfTestResult.results.map((r, idx) => (
                <div
                  key={idx}
                  className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-start justify-between gap-2"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1 text-[11px]">
                      <span className={r.passed ? 'text-emerald-600' : 'text-rose-600'}>
                        {r.passed ? '✓' : '✗'}
                      </span>
                      <span>{r.testName}</span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                      {r.details}
                    </div>
                  </div>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-black shrink-0 ${
                    r.passed
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                  }`}>
                    {r.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowSelfTestModal(false)}
                className="px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-lg text-xs cursor-pointer"
              >
                Close Verification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Stock Transaction Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3 overflow-y-auto">
          <div className="w-full max-w-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl p-4 shadow-xl border border-white/80 dark:border-slate-800/80 space-y-3 my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2 shrink-0">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base flex items-center space-x-1.5">
                <Boxes className="w-4 h-4 text-amber-600" />
                <span>
                  {editingTxId
                    ? 'Edit Stock Transaction'
                    : txType === 'RECEIVED'
                    ? 'Record Received Stock'
                    : txType === 'ADJUSTMENT'
                    ? 'Adjust Commodity Stock'
                    : 'Log Damaged / Spoiled Stock'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs overflow-y-auto pr-1 flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* Transaction Date */}
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                    Transaction Date
                  </label>
                  <input
                    type="date"
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-700/70 rounded-lg font-black text-slate-900 dark:text-white text-xs shadow-2xs focus:ring-1 focus:ring-amber-500 cursor-pointer"
                    required
                  />
                </div>

                {/* Transaction Type */}
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                    Transaction Type
                  </label>
                  <div className="grid grid-cols-3 gap-1 p-0.5 bg-slate-100 dark:bg-slate-800/80 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setTxType('RECEIVED')}
                      className={`py-1 px-1 rounded-md font-bold text-[10px] transition-all cursor-pointer ${
                        txType === 'RECEIVED'
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      + Received
                    </button>
                    <button
                      type="button"
                      onClick={() => setTxType('SPOILED')}
                      className={`py-1 px-1 rounded-md font-bold text-[10px] transition-all cursor-pointer ${
                        txType === 'SPOILED'
                          ? 'bg-red-600 text-white shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      - Spoiled
                    </button>
                    <button
                      type="button"
                      onClick={() => setTxType('ADJUSTMENT')}
                      className={`py-1 px-1 rounded-md font-bold text-[10px] transition-all cursor-pointer ${
                        txType === 'ADJUSTMENT'
                          ? 'bg-amber-600 text-white shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      Adjust
                    </button>
                  </div>
                </div>
              </div>

              {/* Invoice / Voucher No */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                  Invoice / Delivery Voucher No. <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  value={invoiceNo}
                  onChange={(e) => setInvoiceNo(e.target.value)}
                  placeholder="e.g. CIV-SUPPLIES/2026/109"
                  className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
                />
              </div>

              {/* General Remarks */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                  General Remarks / Reason <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder={
                    txType === 'RECEIVED'
                      ? 'e.g. Monthly supply from Civil Supplies'
                      : txType === 'ADJUSTMENT'
                      ? 'e.g. Reconciliation adjustment'
                      : 'e.g. Damaged during inspection'
                  }
                  className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
                />
              </div>

              {/* Render Single Commodity selection when Editing an existing record */}
              {editingTxId ? (
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                      Commodity Item
                    </label>
                    <select
                      value={commodityId}
                      onChange={(e) => setCommodityId(e.target.value as any)}
                      className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
                    >
                      {commodities.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.unit})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[10.5px]">
                      Quantity ({commodities.find((c) => c.id === commodityId)?.unit})
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={quantity}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                      className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white"
                      required
                    />
                  </div>
                </div>
              ) : (
                /* Render Multi-Commodity Quantities list for New Record */
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <label className="block font-black text-slate-800 dark:text-slate-200 uppercase text-[10.5px]">
                      Enter Quantities:
                    </label>
                    <span className="text-[9.5px] text-slate-500">
                      Fill in quantity for any commodity
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {commodities.map((c) => {
                      const qtyVal = multiQuantities[c.id] ?? '';
                      const itemRemark = multiRemarks[c.id] ?? '';
                      const hasQty = Number(qtyVal) > 0;

                      return (
                        <div
                          key={c.id}
                          className={`data-entry-card p-2 rounded-xl border transition-all ${
                            hasQty
                              ? 'bg-amber-500/10 border-amber-500/50 dark:border-amber-500/40 shadow-2xs'
                              : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/60'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center space-x-2 min-w-0">
                              <div className="p-1.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200/60 dark:border-slate-700/60 shrink-0">
                                {getCommodityIcon(c.id)}
                              </div>
                              <div>
                                <div className="font-bold text-slate-900 dark:text-white text-[11px] truncate">
                                  {c.name}
                                </div>
                                <div className="text-[9px] text-slate-500 uppercase font-semibold">
                                  Unit: {c.unit}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center space-x-1 shrink-0">
                              <input
                                type="text"
                                inputMode="decimal"
                                placeholder="0"
                                value={qtyVal}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setMultiQuantities((prev) => ({
                                    ...prev,
                                    [c.id]: val === '' ? '' : Number(val),
                                  }));
                                }}
                                className="w-20 p-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-black text-slate-900 dark:text-white text-right focus:ring-1 focus:ring-amber-500 text-xs"
                              />
                              <span className="text-[10px] font-bold text-slate-500 w-7">{c.unit}</span>
                            </div>
                          </div>

                          {/* Optional Item Remark if quantity is entered */}
                          {hasQty && (
                            <div className="mt-1.5 pt-1.5 border-t border-slate-200/50 dark:border-slate-700/50">
                              <input
                                type="text"
                                value={itemRemark}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setMultiRemarks((prev) => ({
                                    ...prev,
                                    [c.id]: val,
                                  }));
                                }}
                                placeholder={`Optional note for ${c.name}...`}
                                className="w-full px-2 py-0.5 bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded text-[10px] text-slate-800 dark:text-slate-200"
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Form Buttons */}
              <div className="flex items-center justify-end space-x-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-lg text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-3 py-1.5 font-black rounded-lg text-xs text-white shadow-sm transition-all cursor-pointer flex items-center space-x-1 active:scale-95 ${
                    txType === 'RECEIVED'
                      ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30'
                      : txType === 'ADJUSTMENT'
                      ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/30'
                      : 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/30'
                  }`}
                >
                  <Save className="w-3 h-3" />
                  <span>{editingTxId ? 'Update Record' : txType === 'RECEIVED' ? 'Save Received' : txType === 'ADJUSTMENT' ? 'Save Adjustment' : 'Log Spoils'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Stock Confirmation Modal */}
      {deleteConfirmTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center space-x-2.5 text-rose-600 dark:text-rose-400">
              <div className="p-2 bg-rose-500/10 rounded-xl">
                <Trash2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">Delete Stock Record</h4>
                <p className="text-[10.5px] text-slate-500 dark:text-slate-400">Subsequent balances will auto-recalculate.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700/50 leading-relaxed">
              Are you sure you want to delete the <strong className="text-slate-900 dark:text-white uppercase">{deleteConfirmTx.type}</strong> record of{' '}
              <strong className="text-slate-900 dark:text-white">{deleteConfirmTx.quantity} {commodities.find((c) => c.id === deleteConfirmTx.commodityId)?.unit || 'units'}</strong> of{' '}
              <strong className="text-slate-900 dark:text-white">
                {commodities.find((c) => c.id === deleteConfirmTx.commodityId)?.name || deleteConfirmTx.commodityId}
              </strong>{' '}
              on <strong className="text-slate-900 dark:text-white">{formatDateReadable(deleteConfirmTx.date)}</strong>?
            </p>

            <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-[10.5px] text-amber-800 dark:text-amber-300">
              ⚡ Recalculates all dependent subsequent balances automatically.
            </div>

            <div className="flex items-center justify-end space-x-1.5 pt-1">
              <button
                type="button"
                onClick={() => setDeleteConfirmTx(null)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-lg text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteTransaction && deleteConfirmTx) {
                    onDeleteTransaction(deleteConfirmTx.id);
                  }
                  setDeleteConfirmTx(null);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs shadow-sm shadow-rose-600/30 transition-all cursor-pointer active:scale-95"
              >
                Delete & Recalculate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Opening Balance Modal */}
      <OpeningBalanceModal
        isOpen={showOpeningModal}
        onClose={() => setShowOpeningModal(false)}
        commodities={commodities}
        baseCommodities={baseCommodities}
        dailyEntries={dailyEntries}
        stockTransactions={stockTransactions}
        monthlyOverrides={monthlyOverrides}
        onSaveOpeningBalances={onSaveOpeningBalances}
        onSaveMonthlyBalances={onSaveMonthlyBalances}
        onResetMonthlyOverride={onResetMonthlyOverride}
      />
    </div>
  );
};
