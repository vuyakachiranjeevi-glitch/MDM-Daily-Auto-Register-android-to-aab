import React, { useState, useEffect } from 'react';
import { CommodityItem, DailyEntry, MealRates, StudentClassStrength, StockTransaction, DailyClassAttendance, NavigationTab, AutomationSettings } from '../types';
import { formatDateReadable, getFormattedDate, getDayDetails, getDailyCommodityBalanceForDate, formatQtyVal, calculateDailyMenuIndent, syncDailyEntriesWithMenuIndent, getAPOfficialHolidaysList, distributeStudentStrengths } from '../lib/utils';
import { getStudentStrengthForMonth, getStudentStrengthForDate, getDailyClassAttendanceForDate, saveDailyClassAttendanceForDate, MonthlyCommodityOverrides, saveStoredCustomHolidays, getStoredCustomHolidays, saveStoredDailyEntries } from '../lib/storage';
import { OpeningBalanceModal } from './OpeningBalanceModal';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Save,
  Trash2,
  Edit3,
  Edit2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Utensils,
  Receipt,
  IndianRupee,
  Wheat,
  Egg,
  Cookie,
  Flame,
  Info,
  Plus,
  PackagePlus,
  PackageX,
  X,
  Boxes,
  Users,
  TrendingUp,
  AlertTriangle,
  History,
  Delete,
  CornerDownLeft,
  Check,
  ChevronDown,
  ChevronUp,
  Percent,
  Droplet,
  Soup,
} from 'lucide-react';

interface DailyEntryViewProps {
  dailyEntries: DailyEntry[];
  studentStrengths: StudentClassStrength[];
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  mealRates: MealRates;
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  onSaveEntry: (entry: DailyEntry) => void;
  onDeleteEntry: (entryId: string) => void;
  onAddTransaction?: (tx: StockTransaction | StockTransaction[]) => void;
  onUpdateTransaction?: (tx: StockTransaction) => void;
  onDeleteTransaction?: (txId: string) => void;
  onSaveOpeningBalances?: (updated: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onNavigate?: (tab: NavigationTab) => void;
  automationSettings?: AutomationSettings;
  onUpdateAutomationSettings?: (settings: AutomationSettings) => void;
}

export const DailyEntryView: React.FC<DailyEntryViewProps> = ({
  dailyEntries,
  studentStrengths,
  commodities,
  baseCommodities = commodities,
  mealRates,
  stockTransactions = [],
  monthlyOverrides = {},
  onSaveEntry,
  onDeleteEntry,
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  onNavigate,
  automationSettings,
  onUpdateAutomationSettings,
}) => {
  const todayStr = getFormattedDate(0);
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [showOpeningModal, setShowOpeningModal] = useState<boolean>(false);

  // Class strengths totals for default attendance caps (retrieves strength effective on selectedDate)
  const activeStudentStrengths = getStudentStrengthForDate(selectedDate);

  const primaryTotalCap = activeStudentStrengths
    .filter((s) => s.category === 'Primary')
    .reduce((sum, s) => sum + s.total, 0);

  const upperPrimaryTotalCap = activeStudentStrengths
    .filter((s) => s.category === 'Upper Primary' || s.category === 'High School')
    .reduce((sum, s) => sum + s.total, 0);

  // Local entry state
  const [primaryAttendance, setPrimaryAttendance] = useState<number>(primaryTotalCap || 170);
  const [upperPrimaryAttendance, setUpperPrimaryAttendance] = useState<number>(upperPrimaryTotalCap || 136);
  const [highSchoolAttendance, setHighSchoolAttendance] = useState<number>(0);
  const [mealsServed, setMealsServed] = useState<number>((primaryTotalCap || 170) + (upperPrimaryTotalCap || 136));
  const [riceUsedKg, setRiceUsedKg] = useState<number>(0);
  const [eggUsedQty, setEggUsedQty] = useState<number>(0);
  const [chikkiUsedQty, setChikkiUsedQty] = useState<number>(0);
  const [ragiUsedKg, setRagiUsedKg] = useState<number>(0);
  const [jaggeryUsedKg, setJaggeryUsedKg] = useState<number>(0);
  const [oilUsedLitres, setOilUsedLitres] = useState<number>(0);
  const [pulsesUsedKg, setPulsesUsedKg] = useState<number>(0);
  const [condimentsUsedKg, setCondimentsUsedKg] = useState<number>(0);
  const [remarks, setRemarks] = useState<string>('');

  const [autoCalculateNorms, setAutoCalculateNorms] = useState<boolean>(() => {
    return automationSettings?.autoCalculateNorms !== undefined ? automationSettings.autoCalculateNorms : true;
  });
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [lastSaved, setLastSaved] = useState<boolean>(false);
  const [saveSuccessType, setSaveSuccessType] = useState<'SAVED' | 'UPDATED' | null>(null);
  const [stockSaveSuccessType, setStockSaveSuccessType] = useState<'SAVED' | 'UPDATED' | null>(null);
  const [isFormDirty, setIsFormDirty] = useState<boolean>(false);
  const [isStockFormDirty, setIsStockFormDirty] = useState<boolean>(false);
  const [attendancePendingConfirm, setAttendancePendingConfirm] = useState<boolean>(false);
  const [lastAttendanceOkTime, setLastAttendanceOkTime] = useState<string | null>(null);

  // Custom on-screen keypad state
  const [activeInputId, setActiveInputId] = useState<string | null>(null);
  const [keypadBuffer, setKeypadBuffer] = useState<string>('0');
  const [isBufferNew, setIsBufferNew] = useState<boolean>(true);

  const [dailyClassAttendance, setDailyClassAttendance] = useState<DailyClassAttendance[]>(() => {
    return getDailyClassAttendanceForDate(selectedDate);
  });

  const [showClassWiseRoll, setShowClassWiseRoll] = useState<boolean>(true);
  const [holidayUpdateTrigger, setHolidayUpdateTrigger] = useState<number>(0);
  const [typedHolidayName, setTypedHolidayName] = useState<string>('');
  const [showHolidaysList, setShowHolidaysList] = useState<boolean>(false);
  const [holidayListTab, setHolidayListTab] = useState<'MONTH' | 'ALL_PUBLIC'>('MONTH');
  const [holidayViewYear, setHolidayViewYear] = useState<number>(() => {
    const y = parseInt(selectedDate.split('-')[0], 10);
    return isNaN(y) ? 2026 : y;
  });

  // Keep holidayViewYear synced when selectedDate's year changes
  useEffect(() => {
    const y = parseInt(selectedDate.split('-')[0], 10);
    if (!isNaN(y)) {
      setHolidayViewYear(y);
    }
  }, [selectedDate]);

  // Compute all holidays for selected month dynamically according to calendar (including Sundays, Second Saturdays, Public & Custom)
  const selectedMonthHolidays = React.useMemo(() => {
    if (!selectedDate) return [];
    const parts = selectedDate.split('-');
    if (parts.length !== 3) return [];
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);

    const daysInMonth = new Date(year, month, 0).getDate();
    const result: Array<{
      date: string;
      dayNum: number;
      dayName: string;
      shortDayName: string;
      holidayName: string;
      isSunday: boolean;
      isSecondSaturday: boolean;
      typeBadge: 'SUNDAY' | 'SATURDAY' | 'PUBLIC' | 'CUSTOM';
    }> = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const dStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const details = getDayDetails(dStr);
      if (details.isHoliday) {
        let typeBadge: 'SUNDAY' | 'SATURDAY' | 'PUBLIC' | 'CUSTOM' = 'PUBLIC';
        if (details.isSunday) {
          typeBadge = 'SUNDAY';
        } else if (details.holidayName === 'Second Saturday') {
          typeBadge = 'SATURDAY';
        } else if (details.holidayName === 'Sunday Holiday') {
          typeBadge = 'SUNDAY';
        } else {
          typeBadge = 'PUBLIC';
        }

        result.push({
          date: dStr,
          dayNum: d,
          dayName: details.dayName,
          shortDayName: details.shortDayName,
          holidayName: details.holidayName || 'School Holiday',
          isSunday: details.isSunday,
          isSecondSaturday: details.holidayName === 'Second Saturday',
          typeBadge,
        });
      }
    }
    return result;
  }, [selectedDate, holidayUpdateTrigger]);

  // Ref to track if entry data is fully initialized for selectedDate
  const isLoadedRef = React.useRef<boolean>(false);

  // Stock Received / Spoiled Modal state
  const [showStockModal, setShowStockModal] = useState<boolean>(false);
  const [editingStockTxId, setEditingStockTxId] = useState<string | null>(null);
  const [deleteConfirmStockTx, setDeleteConfirmStockTx] = useState<StockTransaction | null>(null);
  const [showDeleteEntryConfirm, setShowDeleteEntryConfirm] = useState<boolean>(false);
  const [stockTxDate, setStockTxDate] = useState<string>(selectedDate);
  const [stockCommodityId, setStockCommodityId] = useState<string>('rice');
  const [stockTxType, setStockTxType] = useState<'RECEIVED' | 'SPOILED'>('RECEIVED');
  const [stockQuantity, setStockQuantity] = useState<number>(50);
  const [stockInvoiceNo, setStockInvoiceNo] = useState<string>('');
  const [stockRemarks, setStockRemarks] = useState<string>('');

  // Multi-commodity quantities & remarks in Daily Entry Quick Stock Modal
  const [stockMultiQuantities, setStockMultiQuantities] = useState<Record<string, number | ''>>({});
  const [stockMultiRemarks, setStockMultiRemarks] = useState<Record<string, string>>({});

  // Track if stock form is dirty
  const isStockInitializedRef = React.useRef<boolean>(false);
  useEffect(() => {
    if (!showStockModal) {
      isStockInitializedRef.current = false;
      setIsStockFormDirty(false);
    } else {
      const timer = setTimeout(() => {
        isStockInitializedRef.current = true;
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [showStockModal]);

  useEffect(() => {
    if (showStockModal && isStockInitializedRef.current) {
      setIsStockFormDirty(true);
    }
  }, [stockTxDate, stockTxType, stockInvoiceNo, stockRemarks, stockMultiQuantities, stockMultiRemarks, stockQuantity, stockCommodityId]);

    // Look up existing entry for selectedDate
  const existingEntry = dailyEntries.find((e) => e.date === selectedDate);
  const lastLoadedDateRef = React.useRef<string>('');

  // Load existing entry if available, or auto-calculate for new entry
  useEffect(() => {
    // Prevent re-initializing the form when already loaded for the current selectedDate unless date changes or holiday trigger fired
    if (lastLoadedDateRef.current === selectedDate && isLoadedRef.current) {
      return;
    }

    lastLoadedDateRef.current = selectedDate;
    isLoadedRef.current = false;
    
    const todayDetails = getDayDetails(selectedDate);
    const isTodayHoliday = todayDetails.isHoliday;
    
    let classAtt = getDailyClassAttendanceForDate(selectedDate);
    if (isTodayHoliday) {
      classAtt.forEach((item) => {
        item.boysPresent = 0;
        item.girlsPresent = 0;
        item.totalPresent = 0;
      });
    } else {
      // If NOT a holiday (working day), but classAtt is all 0s (e.g. from previously being marked a holiday), restore roll attendance if enabled
      const isAllZero = classAtt.every((item) => (item.totalPresent || 0) === 0);
      if (isAllZero) {
        const shouldAutoFill = automationSettings?.autoFillFullAttendanceOnNewDay ?? true;
        if (shouldAutoFill) {
          const classStrengths = getStudentStrengthForDate(selectedDate);
          classAtt = classStrengths.map((cs) => ({
            classLevel: cs.classLevel,
            category: cs.category,
            boysPresent: cs.boys,
            girlsPresent: cs.girls,
            totalPresent: cs.total,
          }));
          saveDailyClassAttendanceForDate(selectedDate, classAtt);
        }
      }
    }
    setDailyClassAttendance(classAtt);

    // Enforce matching totals from Class-Wise Daily Attendance Roll Call
    const calculatedPrimary = isTodayHoliday ? 0 : classAtt
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const calculatedUpperPrimary = isTodayHoliday ? 0 : classAtt
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const calculatedHighSchool = isTodayHoliday ? 0 : classAtt
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    if (existingEntry) {
      if (isTodayHoliday) {
        setPrimaryAttendance(0);
        setUpperPrimaryAttendance(0);
        setHighSchoolAttendance(0);
        setRiceUsedKg(0);
        setEggUsedQty(0);
        setChikkiUsedQty(0);
        setRagiUsedKg(0);
        setJaggeryUsedKg(0);
        setOilUsedLitres(0);
        setPulsesUsedKg(0);
        setCondimentsUsedKg(0);
        const reason = existingEntry.remarks && !existingEntry.remarks.toLowerCase().includes('served properly')
          ? existingEntry.remarks
          : (todayDetails.holidayName || (todayDetails.isSunday ? 'Sunday Holiday' : 'School Holiday'));
        setTypedHolidayName(reason);
        setRemarks(reason);
        setMealsServed(0);
      } else {
        const curPri = existingEntry.primaryAttendance !== undefined ? existingEntry.primaryAttendance : calculatedPrimary;
        const curUp = existingEntry.upperPrimaryAttendance !== undefined ? existingEntry.upperPrimaryAttendance : calculatedUpperPrimary;
        const curHs = existingEntry.highSchoolAttendance !== undefined ? existingEntry.highSchoolAttendance : calculatedHighSchool;
        setPrimaryAttendance(curPri);
        setUpperPrimaryAttendance(curUp);
        setHighSchoolAttendance(curHs);

        // Keep daily class attendance aligned with existing entry so it doesn't get reverted
        if (!isTodayHoliday && (curPri !== calculatedPrimary || curUp !== calculatedUpperPrimary)) {
          const classStrengths = getStudentStrengthForDate(selectedDate);
          const syncedClassAtt = distributeStudentStrengths(classStrengths, curPri, curUp).map((cs) => ({
            classLevel: cs.classLevel,
            category: cs.category,
            boysPresent: cs.boys,
            girlsPresent: cs.girls,
            totalPresent: cs.total,
          }));
          classAtt = syncedClassAtt;
          setDailyClassAttendance(syncedClassAtt);
          saveDailyClassAttendanceForDate(selectedDate, syncedClassAtt);
        }

        const indent = calculateDailyMenuIndent(selectedDate, curPri, curUp, curHs, mealRates, false);

        if (autoCalculateNorms) {
          setRiceUsedKg(existingEntry.riceUsedKg !== undefined && existingEntry.riceUsedKg > 0 ? existingEntry.riceUsedKg : indent.riceUsedKg);
          setEggUsedQty(existingEntry.eggUsedQty !== undefined ? existingEntry.eggUsedQty : indent.eggUsedQty);
          setChikkiUsedQty(existingEntry.chikkiUsedQty !== undefined ? existingEntry.chikkiUsedQty : indent.chikkiUsedQty);
          setRagiUsedKg(existingEntry.ragiUsedKg !== undefined ? existingEntry.ragiUsedKg : indent.ragiUsedKg);
          setJaggeryUsedKg(existingEntry.jaggeryUsedKg !== undefined ? existingEntry.jaggeryUsedKg : indent.jaggeryUsedKg);
          setOilUsedLitres(existingEntry.oilUsedLitres !== undefined && existingEntry.oilUsedLitres > 0 ? existingEntry.oilUsedLitres : indent.oilUsedLitres);
          setPulsesUsedKg(existingEntry.pulsesUsedKg !== undefined && existingEntry.pulsesUsedKg > 0 ? existingEntry.pulsesUsedKg : indent.pulsesUsedKg);
          setCondimentsUsedKg(existingEntry.condimentsUsedKg !== undefined && existingEntry.condimentsUsedKg > 0 ? existingEntry.condimentsUsedKg : indent.condimentsUsedKg);
        } else {
          setRiceUsedKg(existingEntry.riceUsedKg ?? 0);
          setEggUsedQty(indent.isEggDay ? (existingEntry.eggUsedQty ?? 0) : 0);
          setChikkiUsedQty(indent.isChikkiDay ? (existingEntry.chikkiUsedQty ?? 0) : 0);
          setRagiUsedKg(indent.isRagiDay ? (existingEntry.ragiUsedKg ?? 0) : 0);
          setJaggeryUsedKg(indent.isJaggeryDay ? (existingEntry.jaggeryUsedKg ?? 0) : 0);
          setOilUsedLitres(existingEntry.oilUsedLitres ?? existingEntry.commodityUsage?.oil ?? 0);
          setPulsesUsedKg(existingEntry.pulsesUsedKg ?? existingEntry.commodityUsage?.pulses ?? 0);
          setCondimentsUsedKg(existingEntry.condimentsUsedKg ?? existingEntry.commodityUsage?.condiments ?? 0);
        }
        setMealsServed(existingEntry.mealsServed ?? (existingEntry.totalAttendance || (curPri + curUp + curHs)));
        setTypedHolidayName('');
        const prevRemarks = existingEntry.remarks || '';
        const isPrevRemarkHoliday = prevRemarks.toLowerCase().includes('holiday') || prevRemarks.toLowerCase().includes('closed') || prevRemarks.toLowerCase().includes('sunday');
        setRemarks(isPrevRemarkHoliday || !prevRemarks ? 'All meals served properly.' : prevRemarks);
      }
      setIsEditing(true);
    } else {
      setIsEditing(false);
      const defaultHolidayReason = todayDetails.holidayName || (todayDetails.isSunday ? 'Sunday Holiday' : 'School Holiday');
      setTypedHolidayName(isTodayHoliday ? defaultHolidayReason : '');
      setRemarks(isTodayHoliday ? defaultHolidayReason : 'All meals served properly.');

      setPrimaryAttendance(calculatedPrimary);
      setUpperPrimaryAttendance(calculatedUpperPrimary);
      setHighSchoolAttendance(calculatedHighSchool);

      if (isTodayHoliday) {
        setRiceUsedKg(0);
        setEggUsedQty(0);
        setChikkiUsedQty(0);
        setRagiUsedKg(0);
        setJaggeryUsedKg(0);
        setOilUsedLitres(0);
        setPulsesUsedKg(0);
        setCondimentsUsedKg(0);
        setMealsServed(0);
      } else {
        // Auto compute norms for fresh working day
        computeNorms(calculatedPrimary, calculatedUpperPrimary, selectedDate);
        setMealsServed(calculatedPrimary + calculatedUpperPrimary + calculatedHighSchool);
      }
    }

    // Enable auto-saving after state initialization
    const timer = setTimeout(() => {
      isLoadedRef.current = true;
      setIsFormDirty(false);
    }, 50);
    return () => clearTimeout(timer);
  }, [selectedDate, holidayUpdateTrigger]);

  // Mark form as dirty when fields are modified by the user
  useEffect(() => {
    if (!isLoadedRef.current) return;
    setIsFormDirty(true);
    setLastSaved(false);
  }, [
    primaryAttendance,
    upperPrimaryAttendance,
    highSchoolAttendance,
    mealsServed,
    riceUsedKg,
    eggUsedQty,
    chikkiUsedQty,
    ragiUsedKg,
    jaggeryUsedKg,
    oilUsedLitres,
    pulsesUsedKg,
    condimentsUsedKg,
    remarks,
  ]);

  const [lastAutoSavedTime, setLastAutoSavedTime] = useState<string | null>(null);

  // Debounced Auto-save Daily Entry (saves automatically in real-time when autoSave is enabled)
  useEffect(() => {
    const isAutoSaveEnabled = automationSettings?.autoSave ?? true;
    if (!isFormDirty || !isLoadedRef.current || !isAutoSaveEnabled) return;

    const timer = setTimeout(() => {
      const totalAttendance = primaryAttendance + upperPrimaryAttendance + highSchoolAttendance;

      const entryToSave: DailyEntry = {
        id: existingEntry ? existingEntry.id : `mdm-entry-${selectedDate}`,
        date: selectedDate,
        primaryAttendance,
        upperPrimaryAttendance,
        highSchoolAttendance,
        totalAttendance,
        mealsServed,
        riceUsedKg,
        eggUsedQty,
        chikkiUsedQty,
        ragiUsedKg,
        jaggeryUsedKg,
        oilUsedLitres,
        pulsesUsedKg,
        condimentsUsedKg,
        commodityUsage: {
          rice: riceUsedKg,
          egg: eggUsedQty,
          chikki: chikkiUsedQty,
          ragi: ragiUsedKg,
          jaggery: jaggeryUsedKg,
          oil: oilUsedLitres,
          pulses: pulsesUsedKg,
          condiments: condimentsUsedKg,
        },
        remarks: remarks || 'All meals served properly.',
        createdAt: existingEntry ? existingEntry.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isManual: true,
      };

      onSaveEntry(entryToSave);
      setIsFormDirty(false);
      setLastSaved(true);
      
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastAutoSavedTime(timeStr);
      
      const saveType = existingEntry ? 'UPDATED' : 'SAVED';
      setSaveSuccessType(saveType);
      
      const feedbackTimer = setTimeout(() => {
        setSaveSuccessType(null);
      }, 1500);

      return () => clearTimeout(feedbackTimer);
    }, 400);

    return () => clearTimeout(timer);
  }, [
    isFormDirty,
    selectedDate,
    primaryAttendance,
    upperPrimaryAttendance,
    highSchoolAttendance,
    mealsServed,
    riceUsedKg,
    eggUsedQty,
    chikkiUsedQty,
    ragiUsedKg,
    jaggeryUsedKg,
    oilUsedLitres,
    pulsesUsedKg,
    condimentsUsedKg,
    remarks,
    onSaveEntry,
    existingEntry,
  ]);

  // Periodic check for morning attendance auto-update rollover
  useEffect(() => {
    const isAutoRollEnabled = automationSettings?.autoMorningAttendanceRoll ?? true;
    if (!isAutoRollEnabled) return;

    const todayStr = getFormattedDate(0);
    if (selectedDate !== todayStr) return;
    
    const details = getDayDetails(selectedDate);
    if (details.isHoliday) return;

    const cutoffTimeStr = automationSettings?.morningRollCutoffTime || '07:30';
    const [cutoffH, cutoffM] = cutoffTimeStr.split(':').map((v) => parseInt(v, 10) || 0);
    const targetMinutes = (cutoffH || 7) * 60 + (cutoffM || 30);

    const intervalId = setInterval(() => {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      // Trigger automatically after morning cutoff time
      if (currentMinutes >= targetMinutes) {
        // If it's after cutoff time, and our current state is all zeros, but getDailyClassAttendanceForDate returns non-zeros now:
        const currentIsAllZero = dailyClassAttendance.every(item => item.boysPresent === 0 && item.girlsPresent === 0);
        if (currentIsAllZero && (!existingEntry || !existingEntry.isManual)) {
          const freshAttendance = getDailyClassAttendanceForDate(selectedDate);
          const freshIsAllZero = freshAttendance.every(item => item.boysPresent === 0 && item.girlsPresent === 0);
          if (!freshIsAllZero) {
            // Roll up and update state
            setDailyClassAttendance(freshAttendance);
            
            const newPrimaryAtt = freshAttendance
              .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
              .reduce((sum, s) => sum + s.totalPresent, 0);
              
            const newUpperPrimaryAtt = freshAttendance
              .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.totalPresent, 0);
              
            const newHighSchoolAtt = freshAttendance
              .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.totalPresent, 0);
              
            handleAttendanceChange(newPrimaryAtt, newUpperPrimaryAtt, newHighSchoolAtt);
            
            showToast(`⏰ Morning cutoff (${cutoffTimeStr}) reached! Daily attendance updated automatically.`);
          }
        }
      }
    }, 5000); // Check every 5 seconds for snappy updates

    return () => clearInterval(intervalId);
  }, [selectedDate, dailyClassAttendance, autoCalculateNorms, automationSettings]);

  const [isUpdatingAll, setIsUpdatingAll] = useState(false);
  const [updateSuccessMsg, setUpdateSuccessMsg] = useState<string | null>(null);

  // Compute commodity usage based on official AP Government MDM Menu Indent
  const computeNorms = (pAtt: number, upAtt: number, dateStr: string, hsAtt?: number) => {
    const cleanPrimary = Math.max(0, pAtt);
    const cleanUpper = Math.max(0, upAtt);
    const cleanHigh = Math.max(0, hsAtt !== undefined ? hsAtt : highSchoolAttendance);
    const totalMeals = cleanPrimary + cleanUpper + cleanHigh;
    setMealsServed(totalMeals);

    const indent = calculateDailyMenuIndent(dateStr, cleanPrimary, cleanUpper, cleanHigh, mealRates);

    setRiceUsedKg(indent.riceUsedKg);
    setOilUsedLitres(indent.oilUsedLitres);
    setPulsesUsedKg(indent.pulsesUsedKg);
    setCondimentsUsedKg(indent.condimentsUsedKg);
    setEggUsedQty(indent.eggUsedQty);
    setChikkiUsedQty(indent.chikkiUsedQty);
    setRagiUsedKg(indent.ragiUsedKg);
    setJaggeryUsedKg(indent.jaggeryUsedKg);
  };

  // Recalculate if attendance changes and auto-calculate enabled
  const handleAttendanceChange = (pAtt: number, upAtt: number, hsAtt: number) => {
    const cleanPrimary = Math.max(0, Math.min(primaryTotalCap || 9999, Math.floor(Number(pAtt) || 0)));
    const cleanUpper = Math.max(0, Math.min(upperPrimaryTotalCap || 9999, Math.floor(Number(upAtt) || 0)));
    const cleanHigh = Math.max(0, Math.floor(Number(hsAtt) || 0));
    setPrimaryAttendance(cleanPrimary);
    setUpperPrimaryAttendance(cleanUpper);
    setHighSchoolAttendance(cleanHigh);
    const total = cleanPrimary + cleanUpper + cleanHigh;
    setMealsServed(total);

    // Keep dailyClassAttendance in sync with edited primary & upper attendance
    try {
      const classStrengthsForDate = getStudentStrengthForDate(selectedDate);
      const syncedClassAtt = distributeStudentStrengths(classStrengthsForDate, cleanPrimary, cleanUpper).map((cs) => ({
        classLevel: cs.classLevel,
        category: cs.category,
        boysPresent: cs.boys,
        girlsPresent: cs.girls,
        totalPresent: cs.total,
      }));
      setDailyClassAttendance(syncedClassAtt);
      saveDailyClassAttendanceForDate(selectedDate, syncedClassAtt);
    } catch (e) {
      console.warn('Failed syncing dailyClassAttendance in handleAttendanceChange', e);
    }

    if (autoCalculateNorms) {
      const indent = calculateDailyMenuIndent(selectedDate, cleanPrimary, cleanUpper, cleanHigh, mealRates);
      setRiceUsedKg(indent.riceUsedKg);
      setOilUsedLitres(indent.oilUsedLitres);
      setPulsesUsedKg(indent.pulsesUsedKg);
      setCondimentsUsedKg(indent.condimentsUsedKg);
      setEggUsedQty(indent.eggUsedQty);
      setChikkiUsedQty(indent.chikkiUsedQty);
      setRagiUsedKg(indent.ragiUsedKg);
      setJaggeryUsedKg(indent.jaggeryUsedKg);
    }
  };

  // Automatically update all saved entries in storage and cloud to follow the official Menu Indent schedule
  const handleAutoUpdateAllEntries = () => {
    setIsUpdatingAll(true);
    const { updatedEntries, changedCount } = syncDailyEntriesWithMenuIndent(dailyEntries, mealRates);

    saveStoredDailyEntries(updatedEntries);
    updatedEntries.forEach((entry) => {
      onSaveEntry(entry);
    });

    // Also recalculate and update today's values
    computeNorms(primaryAttendance, upperPrimaryAttendance, selectedDate);

    setIsUpdatingAll(false);
    const msg = changedCount > 0
      ? `✓ Successfully auto-updated ${changedCount} entry/entries to official MDM Menu Indent!`
      : '✓ All daily entries are already in perfect sync with official MDM Menu Indent!';
    setUpdateSuccessMsg(msg);
    showToast(msg);
    setTimeout(() => {
      setUpdateSuccessMsg(null);
    }, 4500);
  };

  const handleConfirmAttendanceOK = () => {
    saveDailyClassAttendanceForDate(selectedDate, dailyClassAttendance);
    setAttendancePendingConfirm(false);

    const newPrimaryAtt = dailyClassAttendance
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const newUpperPrimaryAtt = dailyClassAttendance
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const newHighSchoolAtt = dailyClassAttendance
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    setPrimaryAttendance(newPrimaryAtt);
    setUpperPrimaryAttendance(newUpperPrimaryAtt);
    setHighSchoolAttendance(newHighSchoolAtt);

    if (autoCalculateNorms) {
      computeNorms(newPrimaryAtt, newUpperPrimaryAtt, selectedDate, newHighSchoolAtt);
    } else {
      setMealsServed(newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt);
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setLastAttendanceOkTime(timeStr);
    const totalPresent = newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt;
    showToast(`✓ Attendance Confirmed (OK) — Total ${totalPresent} Students Present (${timeStr})`);
  };

  const handleClassAttendanceChange = (index: number, field: 'boysPresent' | 'girlsPresent', value: number) => {
    const updated = [...dailyClassAttendance];
    const classLevelStr = updated[index].classLevel;
    const classStrength = activeStudentStrengths.find((s) => s.classLevel === classLevelStr);
    
    // Determine enrollment max capacity for validation (whole integers only, no minus, no decimals)
    const maxVal = classStrength ? (field === 'boysPresent' ? classStrength.boys : classStrength.girls) : 999;
    const validatedValue = Math.max(0, Math.min(maxVal, Math.floor(Number(value) || 0)));
    
    const boysVal = field === 'boysPresent' ? validatedValue : updated[index].boysPresent;
    const girlsVal = field === 'girlsPresent' ? validatedValue : updated[index].girlsPresent;
    
    updated[index] = {
      ...updated[index],
      boysPresent: boysVal,
      girlsPresent: girlsVal,
      totalPresent: boysVal + girlsVal,
    };
    
    setDailyClassAttendance(updated);
    saveDailyClassAttendanceForDate(selectedDate, updated);
    setAttendancePendingConfirm(true);
    
    // Roll up attendance automatically to MDM served data
    const newPrimaryAtt = updated
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    const newUpperPrimaryAtt = updated
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    const newHighSchoolAtt = updated
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    setPrimaryAttendance(newPrimaryAtt);
    setUpperPrimaryAttendance(newUpperPrimaryAtt);
    setHighSchoolAttendance(newHighSchoolAtt);
    
    if (autoCalculateNorms) {
      computeNorms(newPrimaryAtt, newUpperPrimaryAtt, selectedDate, newHighSchoolAtt);
    } else {
      setMealsServed(newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt);
    }
  };

  const applyClassQuickRoll = (index: number, percent: number) => {
    const updated = [...dailyClassAttendance];
    const item = updated[index];
    const classStrength = activeStudentStrengths.find((s) => s.classLevel === item.classLevel);
    if (!classStrength) return;

    const boysPresent = Math.round(classStrength.boys * (percent / 100));
    const girlsPresent = Math.round(classStrength.girls * (percent / 100));
    updated[index] = {
      ...item,
      boysPresent,
      girlsPresent,
      totalPresent: boysPresent + girlsPresent,
    };

    setDailyClassAttendance(updated);
    saveDailyClassAttendanceForDate(selectedDate, updated);
    setAttendancePendingConfirm(true);

    const newPrimaryAtt = updated
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
    const newUpperPrimaryAtt = updated
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
    const newHighSchoolAtt = updated
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    setPrimaryAttendance(newPrimaryAtt);
    setUpperPrimaryAttendance(newUpperPrimaryAtt);
    setHighSchoolAttendance(newHighSchoolAtt);

    if (autoCalculateNorms) {
      computeNorms(newPrimaryAtt, newUpperPrimaryAtt, selectedDate, newHighSchoolAtt);
    } else {
      setMealsServed(newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt);
    }
    showToast(`${item.classLevel}: Set attendance to ${percent}% (${boysPresent + girlsPresent} present)`);
  };

  const applySectionQuickRoll = (section: 'Primary' | 'Upper Primary' | 'High School', percent: number) => {
    const updated = dailyClassAttendance.map((item) => {
      let isMatch = false;
      if (section === 'Primary') {
        isMatch = item.category === 'Primary' || (item.classLevel && !!item.classLevel.match(/class\s*[1-5]/i));
      } else if (section === 'Upper Primary') {
        isMatch = item.category === 'Upper Primary' || (item.classLevel && !!item.classLevel.match(/class\s*[6-8]/i));
      } else if (section === 'High School') {
        isMatch = item.category === 'High School' && (!item.classLevel || !item.classLevel.match(/class\s*[6-8]/i));
      }

      if (!isMatch) return item;

      const classStrength = activeStudentStrengths.find((s) => s.classLevel === item.classLevel);
      if (!classStrength) return item;

      const boysPresent = Math.round(classStrength.boys * (percent / 100));
      const girlsPresent = Math.round(classStrength.girls * (percent / 100));
      return {
        ...item,
        boysPresent,
        girlsPresent,
        totalPresent: boysPresent + girlsPresent,
      };
    });

    setDailyClassAttendance(updated);
    saveDailyClassAttendanceForDate(selectedDate, updated);
    setAttendancePendingConfirm(true);

    const newPrimaryAtt = updated
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const newUpperPrimaryAtt = updated
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    const newHighSchoolAtt = updated
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);

    setPrimaryAttendance(newPrimaryAtt);
    setUpperPrimaryAttendance(newUpperPrimaryAtt);
    setHighSchoolAttendance(newHighSchoolAtt);

    if (autoCalculateNorms) {
      computeNorms(newPrimaryAtt, newUpperPrimaryAtt, selectedDate, newHighSchoolAtt);
    } else {
      setMealsServed(newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt);
    }

    showToast(`${section} Section: Set attendance to ${percent}% present`);
  };

  // Quick helper to fill present attendance (e.g., 100% or 95% roll)
  const applyQuickRollAll = (percent: number) => {
    const updated = dailyClassAttendance.map((item) => {
      const classStrength = activeStudentStrengths.find((s) => s.classLevel === item.classLevel);
      if (!classStrength) return item;
      
      const boysPresent = Math.round(classStrength.boys * (percent / 100));
      const girlsPresent = Math.round(classStrength.girls * (percent / 100));
      return {
        ...item,
        boysPresent,
        girlsPresent,
        totalPresent: boysPresent + girlsPresent,
      };
    });
    
    setDailyClassAttendance(updated);
    saveDailyClassAttendanceForDate(selectedDate, updated);
    setAttendancePendingConfirm(true);
    
    const newPrimaryAtt = updated
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    const newUpperPrimaryAtt = updated
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    const newHighSchoolAtt = updated
      .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.totalPresent, 0);
      
    setPrimaryAttendance(newPrimaryAtt);
    setUpperPrimaryAttendance(newUpperPrimaryAtt);
    setHighSchoolAttendance(newHighSchoolAtt);
    
    if (autoCalculateNorms) {
      computeNorms(newPrimaryAtt, newUpperPrimaryAtt, selectedDate, newHighSchoolAtt);
    } else {
      setMealsServed(newPrimaryAtt + newUpperPrimaryAtt + newHighSchoolAtt);
    }
    
    showToast(`Quick Roll: Set attendance to ${percent}% present for all classes. Click OK to confirm.`);
  };

  // Custom Keypad Helpers
  const getInputValueById = (id: string): string => {
    if (id === 'primaryAttendance') return String(primaryAttendance);
    if (id === 'upperPrimaryAttendance') return String(upperPrimaryAttendance);
    if (id === 'highSchoolAttendance') return String(highSchoolAttendance);
    if (id === 'mealsServed') return String(mealsServed);
    if (id === 'riceUsedKg') return String(riceUsedKg);
    if (id === 'eggUsedQty') return String(eggUsedQty);
    if (id === 'chikkiUsedQty') return String(chikkiUsedQty);
    if (id === 'ragiUsedKg') return String(ragiUsedKg);
    if (id === 'jaggeryUsedKg') return String(jaggeryUsedKg);
    if (id === 'oilUsedLitres') return String(oilUsedLitres);
    if (id === 'pulsesUsedKg') return String(pulsesUsedKg);
    if (id === 'condimentsUsedKg') return String(condimentsUsedKg);
    if (id === 'stockQuantity') return String(stockQuantity);
    if (id.startsWith('classAttendance-boys-')) {
      const idx = parseInt(id.split('-')[2], 10);
      return String(dailyClassAttendance[idx]?.boysPresent ?? 0);
    }
    if (id.startsWith('classAttendance-girls-')) {
      const idx = parseInt(id.split('-')[2], 10);
      return String(dailyClassAttendance[idx]?.girlsPresent ?? 0);
    }
    return '';
  };

  const getInputLabelById = (id: string): string => {
    if (id === 'primaryAttendance') return 'Primary Attendance (Class 1-5)';
    if (id === 'upperPrimaryAttendance') return 'Upper Primary Attendance (Class 6-8)';
    if (id === 'highSchoolAttendance') return 'High School Attendance';
    if (id === 'mealsServed') return 'Meals Served Today';
    if (id === 'riceUsedKg') return 'Rice Used (Kg)';
    if (id === 'oilUsedLitres') return 'Cooking Oil Used (Litres)';
    if (id === 'pulsesUsedKg') return 'Pulses / Dal Used (Kg)';
    if (id === 'condimentsUsedKg') return 'Condiments & Spices Used (Kg)';
    if (id === 'eggUsedQty') return 'Eggs Used (Qty)';
    if (id === 'chikkiUsedQty') return 'Chikki Used (Qty)';
    if (id === 'ragiUsedKg') return 'Ragi Flour Used (Kg)';
    if (id === 'jaggeryUsedKg') return 'Jaggery Used (Kg)';
    if (id === 'stockQuantity') return `Record ${stockTxType === 'RECEIVED' ? 'Received' : 'Spoiled'} ${stockCommodityId.toUpperCase()}`;
    if (id.startsWith('classAttendance-boys-')) {
      const idx = parseInt(id.split('-')[2], 10);
      return `${dailyClassAttendance[idx]?.classLevel} - Boys Present`;
    }
    if (id.startsWith('classAttendance-girls-')) {
      const idx = parseInt(id.split('-')[2], 10);
      return `${dailyClassAttendance[idx]?.classLevel} - Girls Present`;
    }
    return '';
  };

  const getInputMaxById = (id: string): number => {
    if (id === 'primaryAttendance') return primaryTotalCap || 200;
    if (id === 'upperPrimaryAttendance') return upperPrimaryTotalCap || 200;
    if (id === 'highSchoolAttendance') return 200;
    if (id === 'mealsServed') return totalAtt || 999;
    if (id === 'riceUsedKg') return 1000;
    if (id === 'oilUsedLitres') return 500;
    if (id === 'pulsesUsedKg') return 500;
    if (id === 'condimentsUsedKg') return 100;
    if (id === 'eggUsedQty') return 10000;
    if (id === 'chikkiUsedQty') return 10000;
    if (id === 'ragiUsedKg') return 1000;
    if (id === 'jaggeryUsedKg') return 1000;
    if (id === 'stockQuantity') return 100000;
    if (id.startsWith('classAttendance-boys-')) {
      const idx = parseInt(id.split('-')[2], 10);
      const cls = dailyClassAttendance[idx]?.classLevel;
      return activeStudentStrengths.find((s) => s.classLevel === cls)?.boys ?? 999;
    }
    if (id.startsWith('classAttendance-girls-')) {
      const idx = parseInt(id.split('-')[2], 10);
      const cls = dailyClassAttendance[idx]?.classLevel;
      return activeStudentStrengths.find((s) => s.classLevel === cls)?.girls ?? 999;
    }
    return 999999;
  };

  const handleInputFocus = (id: string) => {
    setActiveInputId(id);
    const currentVal = getInputValueById(id);
    setKeypadBuffer(currentVal === '0' ? '0' : currentVal);
    setIsBufferNew(true);
  };

  const isInputActive = (id: string) => activeInputId === id;

  const handleKeypadPress = (key: string) => {
    if (!activeInputId) return;

    const maxVal = getInputMaxById(activeInputId);
    let nextBuffer = keypadBuffer;

    if (key === 'Clear') {
      nextBuffer = '0';
      setIsBufferNew(true);
    } else if (key === 'Backspace') {
      if (nextBuffer.length > 1) {
        nextBuffer = nextBuffer.slice(0, -1);
        if (nextBuffer === '-') nextBuffer = '0';
      } else {
        nextBuffer = '0';
      }
      setIsBufferNew(false);
    } else if (key === 'Max') {
      nextBuffer = String(maxVal);
      setIsBufferNew(true);
    } else if (key === '+/-' || key === '-') {
      if (nextBuffer.startsWith('-')) {
        nextBuffer = nextBuffer.slice(1);
        if (nextBuffer === '') nextBuffer = '0';
      } else {
        if (nextBuffer === '0' || isBufferNew) {
          nextBuffer = '-';
        } else {
          nextBuffer = '-' + nextBuffer;
        }
      }
      setIsBufferNew(false);
    } else if (['+1', '-1', '+5', '-5'].includes(key)) {
      const currentNum = Number(nextBuffer) || 0;
      const offset = parseFloat(key);
      const updatedNum = currentNum + offset;
      nextBuffer = String(Number(updatedNum.toFixed(3)));
      setIsBufferNew(true);
    } else if (key === '.') {
      if (isBufferNew || nextBuffer === '0') {
        nextBuffer = '0.';
        setIsBufferNew(false);
      } else if (nextBuffer === '-') {
        nextBuffer = '-0.';
        setIsBufferNew(false);
      } else if (!nextBuffer.includes('.')) {
        nextBuffer = nextBuffer + '.';
        setIsBufferNew(false);
      }
    } else {
      // It's a digit: '0' to '9'
      if (isBufferNew || nextBuffer === '0') {
        nextBuffer = key;
        setIsBufferNew(false);
      } else if (nextBuffer === '-') {
        nextBuffer = '-' + key;
        setIsBufferNew(false);
      } else {
        nextBuffer = nextBuffer + key;
      }
    }

    setKeypadBuffer(nextBuffer);
    updateValueFromBuffer(activeInputId, nextBuffer);
  };

  const updateValueFromBuffer = (id: string, bufferStr: string) => {
    if (bufferStr === '-' || bufferStr === '-0' || bufferStr === '' || bufferStr === '.') return;
    const numericVal = isNaN(Number(bufferStr)) ? 0 : Number(bufferStr);
    
    if (id === 'riceUsedKg') {
      setRiceUsedKg(Number(numericVal.toFixed(3)));
    } else if (id === 'oilUsedLitres') {
      setOilUsedLitres(Number(numericVal.toFixed(3)));
    } else if (id === 'pulsesUsedKg') {
      setPulsesUsedKg(Number(numericVal.toFixed(3)));
    } else if (id === 'condimentsUsedKg') {
      setCondimentsUsedKg(Number(numericVal.toFixed(3)));
    } else if (id === 'eggUsedQty') {
      setEggUsedQty(Number(numericVal.toFixed(2)));
    } else if (id === 'chikkiUsedQty') {
      setChikkiUsedQty(Number(numericVal.toFixed(2)));
    } else if (id === 'ragiUsedKg') {
      setRagiUsedKg(Number(numericVal.toFixed(3)));
    } else if (id === 'jaggeryUsedKg') {
      setJaggeryUsedKg(Number(numericVal.toFixed(3)));
    } else if (id === 'stockQuantity') {
      setStockQuantity(Number(numericVal.toFixed(3)));
    } else if (id === 'primaryAttendance') {
      handleAttendanceChange(numericVal, upperPrimaryAttendance, highSchoolAttendance);
    } else if (id === 'upperPrimaryAttendance') {
      handleAttendanceChange(primaryAttendance, numericVal, highSchoolAttendance);
    } else if (id === 'highSchoolAttendance') {
      handleAttendanceChange(primaryAttendance, upperPrimaryAttendance, numericVal);
    } else if (id === 'mealsServed') {
      setMealsServed(numericVal);
    } else if (id.startsWith('classAttendance-boys-')) {
      const index = parseInt(id.split('-')[2], 10);
      handleClassAttendanceChange(index, 'boysPresent', numericVal);
    } else if (id.startsWith('classAttendance-girls-')) {
      const index = parseInt(id.split('-')[2], 10);
      handleClassAttendanceChange(index, 'girlsPresent', numericVal);
    }
  };

  const moveToNextInput = () => {
    if (!activeInputId) return;
    const inputOrder = [
      ...dailyClassAttendance.flatMap((_, idx) => [
        `classAttendance-boys-${idx}`,
        `classAttendance-girls-${idx}`
      ]),
      'riceUsedKg',
      'eggUsedQty',
      'chikkiUsedQty',
      'ragiUsedKg',
      'jaggeryUsedKg',
      'stockQuantity'
    ];
    const currentIndex = inputOrder.indexOf(activeInputId);
    if (currentIndex !== -1 && currentIndex < inputOrder.length - 1) {
      handleInputFocus(inputOrder[currentIndex + 1]);
    } else {
      setActiveInputId(null);
    }
  };

  const handleSetCustomHoliday = (holidayName: string | null) => {
    try {
      const customHolidaysMap = getStoredCustomHolidays();
      
      if (holidayName === 'WORKING_DAY' || holidayName === null) {
        if (holidayName === 'WORKING_DAY') {
          customHolidaysMap[selectedDate] = 'WORKING_DAY';
          showToast(`School marked as OPEN (Working Day) on ${formatDateReadable(selectedDate)}.`);
        } else {
          delete customHolidaysMap[selectedDate];
          showToast(`Removed holiday override for ${formatDateReadable(selectedDate)}.`);
        }

        saveStoredCustomHolidays(customHolidaysMap);

        const details = getDayDetails(selectedDate);
        if (!details.isHoliday) {
          setTypedHolidayName('');
          setRemarks('All meals served properly.');
          
          // Re-evaluate attendance with full roll attendance from registered class strengths
          const classStrengths = getStudentStrengthForDate(selectedDate);
          const restoredClassAtt = classStrengths.map((cs) => ({
            classLevel: cs.classLevel,
            category: cs.category,
            boysPresent: cs.boys,
            girlsPresent: cs.girls,
            totalPresent: cs.total,
          }));
          setDailyClassAttendance(restoredClassAtt);
          saveDailyClassAttendanceForDate(selectedDate, restoredClassAtt);

          const calcP = restoredClassAtt
            .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
            .reduce((sum, s) => sum + s.totalPresent, 0);
          const calcUp = restoredClassAtt
            .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
            .reduce((sum, s) => sum + s.totalPresent, 0);
          const calcHs = restoredClassAtt
            .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
            .reduce((sum, s) => sum + s.totalPresent, 0);

          setPrimaryAttendance(calcP);
          setUpperPrimaryAttendance(calcUp);
          setHighSchoolAttendance(calcHs);
          setMealsServed(calcP + calcUp + calcHs);
          computeNorms(calcP, calcUp, selectedDate);
        } else {
          const reason = details.holidayName || (details.isSunday ? 'Sunday Holiday' : 'School Holiday');
          setTypedHolidayName(reason);
          setRemarks(reason);
        }
      } else {
        const cleanReason = holidayName.trim();
        customHolidaysMap[selectedDate] = cleanReason;
        showToast(`School closure reason set to "${cleanReason}" for ${formatDateReadable(selectedDate)}.`);
        
        // Zero all attendance and meals served
        const zeroClassAtt = dailyClassAttendance.map((item) => ({
          ...item,
          boysPresent: 0,
          girlsPresent: 0,
          totalPresent: 0,
        }));
        setDailyClassAttendance(zeroClassAtt);
        saveDailyClassAttendanceForDate(selectedDate, zeroClassAtt);
        
        setPrimaryAttendance(0);
        setUpperPrimaryAttendance(0);
        setHighSchoolAttendance(0);
        setMealsServed(0);
        setRiceUsedKg(0);
        setEggUsedQty(0);
        setChikkiUsedQty(0);
        setRagiUsedKg(0);
        setJaggeryUsedKg(0);
        setOilUsedLitres(0);
        setPulsesUsedKg(0);
        setCondimentsUsedKg(0);
        setTypedHolidayName(cleanReason);
        setRemarks(cleanReason);
      }
      
      saveStoredCustomHolidays(customHolidaysMap);
      setHolidayUpdateTrigger((prev) => prev + 1);
      setIsFormDirty(true);
      setLastSaved(false);
    } catch (e) {
      console.error('Error setting custom holiday:', e);
    }
  };

  const handleUpdateHolidayReason = (reasonText: string) => {
    const cleanReason = reasonText;
    setTypedHolidayName(cleanReason);
    setRemarks(cleanReason);
    try {
      const customHolidaysMap = getStoredCustomHolidays();
      customHolidaysMap[selectedDate] = cleanReason;
      saveStoredCustomHolidays(customHolidaysMap);
      setHolidayUpdateTrigger((prev) => prev + 1);
      setIsFormDirty(true);
      setLastSaved(false);
    } catch (e) {
      console.error('Error updating holiday reason:', e);
    }
  };

  const handleToggleSchoolStatus = (isOpen: boolean) => {
    if (isOpen) {
      handleSetCustomHoliday('WORKING_DAY');
    } else {
      const defaultReason = typedHolidayName.trim() || dayDetails.holidayName || (dayDetails.isSunday ? 'Sunday Holiday' : 'School Holiday');
      handleSetCustomHoliday(defaultReason);
    }
  };

  // Date Navigation (Previous / Next Entry)
  const navigateDate = (daysOffset: number) => {
    const parts = selectedDate.split('-').map(Number);
    if (parts.length === 3) {
      const dateObj = new Date(parts[0], parts[1] - 1, parts[2] + daysOffset);
      const yyyy = dateObj.getFullYear();
      const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
      const dd = String(dateObj.getDate()).padStart(2, '0');
      setSelectedDate(`${yyyy}-${mm}-${dd}`);
    } else {
      const current = new Date(selectedDate);
      current.setDate(current.getDate() + daysOffset);
      setSelectedDate(current.toISOString().split('T')[0]);
    }
  };

  // Save Entry
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const totalAttendance = primaryAttendance + upperPrimaryAttendance + highSchoolAttendance;
    const isExplicitHoliday = dayDetails.isHoliday;

    let finalRemarks = remarks.trim();
    if (isExplicitHoliday) {
      finalRemarks = typedHolidayName.trim() || remarks.trim() || dayDetails.holidayName || (dayDetails.isSunday ? 'Sunday Holiday' : 'School Holiday');
      
      // Save holiday closure reason to storage
      const customMap = getStoredCustomHolidays();
      customMap[selectedDate] = finalRemarks;
      saveStoredCustomHolidays(customMap);
      setHolidayUpdateTrigger((prev) => prev + 1);
    } else if (!finalRemarks) {
      finalRemarks = 'All meals served properly.';
    }

    const entryToSave: DailyEntry = {
      id: existingEntry ? existingEntry.id : `mdm-entry-${selectedDate}`,
      date: selectedDate,
      primaryAttendance,
      upperPrimaryAttendance,
      highSchoolAttendance,
      totalAttendance,
      mealsServed,
      riceUsedKg,
      eggUsedQty,
      chikkiUsedQty,
      ragiUsedKg,
      jaggeryUsedKg,
      oilUsedLitres,
      pulsesUsedKg,
      condimentsUsedKg,
      commodityUsage: {
        rice: riceUsedKg,
        egg: eggUsedQty,
        chikki: chikkiUsedQty,
        ragi: ragiUsedKg,
        jaggery: jaggeryUsedKg,
        oil: oilUsedLitres,
        pulses: pulsesUsedKg,
        condiments: condimentsUsedKg,
      },
      remarks: finalRemarks,
      createdAt: existingEntry ? existingEntry.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isManual: true,
    };

    onSaveEntry(entryToSave);
    const saveType = existingEntry ? 'UPDATED' : 'SAVED';
    setSaveSuccessType(saveType);
    setIsFormDirty(false);
    setLastSaved(true);
    showToast(`Daily entry for ${formatDateReadable(selectedDate)} saved successfully!`);
    setTimeout(() => {
      setSaveSuccessType(null);
    }, 4000);
  };

  // Delete Entry
  const handleDelete = () => {
    if (!existingEntry) return;
    setShowDeleteEntryConfirm(true);
  };

  // Open Quick Stock Modal (New Record)
  const openStockModal = (commodityId?: string, type: 'RECEIVED' | 'SPOILED' = 'RECEIVED') => {
    setEditingStockTxId(null);
    setStockTxDate(selectedDate);
    if (commodityId) setStockCommodityId(commodityId);
    setStockTxType(type);
    setStockQuantity(type === 'RECEIVED' ? 50 : 5);
    setStockInvoiceNo('');
    setStockRemarks('');
    if (commodityId) {
      setStockMultiQuantities({ [commodityId]: type === 'RECEIVED' ? 50 : 5 });
    } else {
      setStockMultiQuantities({});
    }
    setStockMultiRemarks({});
    setIsStockFormDirty(false);
    setShowStockModal(true);
  };

  // Open Edit Stock Modal
  const openEditStockModal = (tx: StockTransaction) => {
    setEditingStockTxId(tx.id);
    setStockTxDate(tx.date || selectedDate);
    setStockCommodityId(tx.commodityId);
    setStockTxType(tx.type === 'SPOILED' ? 'SPOILED' : 'RECEIVED');
    setStockQuantity(tx.quantity);
    setStockInvoiceNo(tx.invoiceNo || '');
    setStockRemarks(tx.remarks || '');
    setIsStockFormDirty(false);
    setShowStockModal(true);
  };

  // Delete Stock Transaction
  const handleDeleteStockTx = (tx: StockTransaction) => {
    setDeleteConfirmStockTx(tx);
  };

  // Submit Received/Spoiled Stock Transaction (Add or Edit)
  const handleStockSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingStockTxId) {
      if (stockQuantity <= 0) {
        alert('Please enter a valid quantity.');
        return;
      }
      const txData: StockTransaction = {
        id: editingStockTxId,
        date: stockTxDate || selectedDate,
        commodityId: stockCommodityId,
        type: stockTxType,
        quantity: stockQuantity,
        invoiceNo: stockInvoiceNo.trim() || undefined,
        remarks: stockRemarks.trim() || undefined,
      };

      if (onUpdateTransaction) {
        onUpdateTransaction(txData);
        showToast('Stock transaction updated successfully.');
      }
    } else {
      const activeComms = commodities.filter((c) => {
        const val = Number(stockMultiQuantities[c.id]);
        return !isNaN(val) && val > 0;
      });

      if (activeComms.length === 0) {
        alert('Please enter a quantity greater than 0 for at least one commodity.');
        return;
      }

      const newTxs: StockTransaction[] = activeComms.map((c, index) => ({
        id: `tx-${Date.now()}-${index}`,
        date: stockTxDate || selectedDate,
        commodityId: c.id as any,
        type: stockTxType,
        quantity: Number(stockMultiQuantities[c.id]),
        invoiceNo: stockInvoiceNo.trim() || undefined,
        remarks: stockMultiRemarks[c.id]?.trim() || stockRemarks.trim() || undefined,
      }));

      if (onAddTransaction) {
        onAddTransaction(newTxs);
        showToast(
          stockTxType === 'RECEIVED'
            ? `Logged Received stock for ${activeComms.length} items.`
            : `Logged Spoiled/Damaged stock for ${activeComms.length} items.`
        );
      }
    }

    setStockSaveSuccessType(editingStockTxId ? 'UPDATED' : 'SAVED');
    setIsStockFormDirty(false);
    setTimeout(() => {
      setStockSaveSuccessType(null);
      setShowStockModal(false);
      setEditingStockTxId(null);
      setStockMultiQuantities({});
      setStockMultiRemarks({});
    }, 700);
  };

  const handleQuickReceiveStock = (commodityId: string, qty: number, unit: string) => {
    if (!onAddTransaction) return;
    const newTx: StockTransaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      date: selectedDate,
      commodityId: commodityId as any,
      type: 'RECEIVED',
      quantity: qty,
      remarks: `Quick Inward Receipt: +${qty} ${unit}`,
    };
    onAddTransaction(newTx);
    showToast(`✅ Received +${qty} ${unit} ${commodityId.toUpperCase()} for ${formatDateReadable(selectedDate)}!`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const totalAtt = primaryAttendance + upperPrimaryAttendance + highSchoolAttendance;
  const primaryAttPercentVal = primaryTotalCap > 0 ? (primaryAttendance / primaryTotalCap) * 100 : 0;
  const primaryAttPercent = primaryTotalCap > 0 ? primaryAttPercentVal.toFixed(1) + '%' : '0.0%';
  
  const upperPrimaryAttPercentVal = upperPrimaryTotalCap > 0 ? (upperPrimaryAttendance / upperPrimaryTotalCap) * 100 : 0;
  const upperPrimaryAttPercent = upperPrimaryTotalCap > 0 ? upperPrimaryAttPercentVal.toFixed(1) + '%' : '0.0%';
  
  const totalCap = primaryTotalCap + upperPrimaryTotalCap;
  const totalAttPercentVal = totalCap > 0 ? (totalAtt / totalCap) * 100 : 0;
  const totalAttPercent = totalCap > 0 ? totalAttPercentVal.toFixed(1) + '%' : '0.0%';

  const getAttendanceColorScale = (percent: number) => {
    if (percent >= 90) return 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200/30';
    if (percent >= 80) return 'text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200/30';
    if (percent >= 70) return 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 border-amber-200/30';
    if (percent > 0) return 'text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 border-rose-200/30';
    return 'text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 border-slate-200/30';
  };

  const mealsServedPercentVal = totalAtt > 0 ? (mealsServed / totalAtt) * 100 : 0;
  const mealsServedPercent = totalAtt > 0 ? mealsServedPercentVal.toFixed(1) + '%' : '0.0%';

  const getMealsServedColorScale = (percent: number) => {
    if (percent >= 100) return 'text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/50 border-emerald-300/30';
    if (percent >= 95) return 'text-teal-700 dark:text-teal-300 bg-teal-100 dark:bg-teal-950/50 border-teal-300/30';
    if (percent >= 90) return 'text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/50 border-amber-300/30';
    if (percent > 0) return 'text-rose-700 dark:text-rose-300 bg-rose-100 dark:bg-rose-950/50 border-rose-300/30';
    return 'text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/50 border-slate-300/30';
  };

  // Filter transactions for currently selected date
  const selectedDateTransactions = stockTransactions.filter((tx) => tx.date === selectedDate);

  // Live calculation of Opening Balance (yesterday's Closing Balance) and today's Closing Balance
  // for all commodities with real-time feedback as the user edits consumption or attendance
  const liveUsageMap: Record<string, number> = {
    rice: riceUsedKg,
    egg: eggUsedQty,
    chikki: chikkiUsedQty,
    ragi: ragiUsedKg,
    jaggery: jaggeryUsedKg,
    oil: oilUsedLitres,
    pulses: pulsesUsedKg,
    condiments: condimentsUsedKg,
  };

  const todayCommodityStockBalances = getDailyCommodityBalanceForDate(
    selectedDate,
    dailyEntries,
    stockTransactions,
    baseCommodities,
    monthlyOverrides,
    liveUsageMap
  );

  // Commodity Icon Helper
  const getCommodityIcon = (id: string) => {
    switch (id) {
      case 'rice':
        return <Wheat className="w-4 h-4 text-amber-600" />;
      case 'oil':
        return <Droplet className="w-4 h-4 text-amber-500" />;
      case 'pulses':
        return <Soup className="w-4 h-4 text-yellow-600" />;
      case 'egg':
        return <Egg className="w-4 h-4 text-yellow-600" />;
      case 'chikki':
        return <Cookie className="w-4 h-4 text-orange-600" />;
      case 'ragi':
        return <Flame className="w-4 h-4 text-purple-600" />;
      case 'jaggery':
        return <Sparkles className="w-4 h-4 text-pink-600" />;
      default:
        return <Boxes className="w-4 h-4 text-blue-600" />;
    }
  };

  const dayDetails = getDayDetails(selectedDate);

  return (
    <div className="max-w-full space-y-2 pb-2 sm:pb-3">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-8 sm:bottom-10 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center space-x-2.5 text-xs font-bold animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header & Date Controller */}
      <div className="glass-3d-tile p-3 sm:p-4 rounded-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-3 w-full">
        <div>
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">Daily Meal Entry</h2>
            {existingEntry ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-blue-500/10 border border-blue-500/20 text-blue-800 dark:text-blue-300 glass-3d-icon">
                Existing Record
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-300 glass-3d-icon">
                New Entry
              </span>
            )}
            {isFormDirty ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-amber-500/15 border border-amber-500/30 text-amber-800 dark:text-amber-300 flex items-center gap-1 animate-pulse">
                <span className="w-2.5 h-2.5 rounded-full border border-amber-600 dark:border-amber-400 border-t-transparent animate-spin shrink-0" />
                Auto-Saving...
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                Auto-Saved
              </span>
            )}
          </div>
          <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Log student attendance, meals served, and record received or spoiled commodities.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full lg:w-auto">
          {/* Date Selector Controls with Day Name & Sunday/Holiday Highlight */}
          <div
            className={`flex items-center justify-between space-x-1.5 glass-3d-tile p-1 sm:p-1.5 rounded-xl border-2 transition-all shadow-xs w-full sm:w-auto ${
              dayDetails.isHoliday
                ? 'border-red-400 bg-red-50/60 dark:bg-red-950/30 shadow-red-500/20'
                : 'border-blue-600 dark:border-blue-400 shadow-blue-500/15'
            }`}
          >

            <div className="flex items-center space-x-1 px-1 flex-1 sm:flex-initial justify-center min-w-0">
              <Calendar className={`w-3.5 h-3.5 shrink-0 ${dayDetails.isHoliday ? 'text-red-600 dark:text-red-400' : 'text-blue-600 dark:text-blue-400'}`} />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className={`bg-transparent font-bold text-[12px] outline-hidden cursor-pointer min-w-0 max-w-[125px] ${
                  dayDetails.isHoliday ? 'text-red-600 dark:text-red-400 font-extrabold' : 'text-slate-900 dark:text-slate-100'
                }`}
              />
              <span className="text-slate-300 dark:text-slate-600 shrink-0">|</span>
              <span
                className={`text-[12px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-md flex items-center justify-center gap-1 shrink-0 ${
                  dayDetails.isHoliday
                    ? 'bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400 border border-red-300 dark:border-red-800 font-bold shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200'
                }`}
              >
                {dayDetails.dayName}
              </span>
            </div>

            <button
              type="button"
              onClick={() => navigateDate(1)}
              className={`p-1.5 h-8 w-8 shrink-0 glass-3d-btn rounded-lg transition-all border flex items-center justify-center active:scale-95 cursor-pointer ${
                dayDetails.isHoliday
                  ? 'text-red-600 dark:text-red-400 hover:text-red-700 border-red-300/80 dark:border-red-500/50'
                  : 'text-blue-700 dark:text-sky-300 hover:text-blue-800 border-sky-300/80 dark:border-sky-500/50'
              }`}
              title="Next Entry Date"
            >
              <ChevronRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

          {/* Opening Balance Settings Button */}
          <button
            type="button"
            onClick={() => setShowOpeningModal(true)}
            className="btn-3d-glass-blue shrink-0 h-9 sm:h-10 px-3 py-1.5 flex items-center justify-center gap-1.5 text-xs font-bold active:scale-95 rounded-xl"
            title="View & Manage Opening Balances and Monthly Overrides"
          >
            <Boxes className="w-3.5 h-3.5 text-blue-700 dark:text-blue-300" />
            <span className="hidden sm:inline">Opening Balance</span>
            <span className="sm:hidden">OB</span>
          </button>

          {/* Cash Voucher Direct Navigation Button */}
          {onNavigate && (
            <button
              type="button"
              onClick={() => onNavigate('cash-voucher')}
              className="btn-3d-glass-emerald shrink-0 h-9 sm:h-10 px-3 py-1.5 flex items-center justify-center gap-1.5 text-xs font-bold active:scale-95 rounded-xl"
              title="Open Official Mid-Day Meal Cash Voucher"
            >
              <IndianRupee className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-200" />
              <span>Cash Voucher</span>
            </button>
          )}
        </div>
      </div>

      {/* School Status & Holiday Closure Reason Panel */}
      <div className={`glass-3d-tile p-4 sm:p-5 rounded-2xl border transition-all shadow-xs ${
        dayDetails.isHoliday
          ? 'bg-red-50/50 dark:bg-red-950/20 border-red-200 dark:border-red-900/60'
          : 'bg-white/80 dark:bg-slate-900/70 border-slate-200/80 dark:border-slate-800'
      }`}>
        {/* Top Bar: Title & Working Status Toggle */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/70 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl text-white ${dayDetails.isHoliday ? 'bg-red-600 shadow-red-500/30' : 'bg-emerald-600 shadow-emerald-500/30'} shadow-sm`}>
              <Calendar className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-black uppercase tracking-wide text-slate-800 dark:text-slate-100">
                  School Working Status & Holiday Reason
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                  dayDetails.isHoliday
                    ? 'bg-red-100 dark:bg-red-950/70 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800'
                    : 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                }`}>
                  {dayDetails.isHoliday ? '🛑 Closed / Holiday' : '🏫 Open / Working'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Set whether school is open for MDM meals or closed due to a holiday, rain, local festival, or election.
              </p>
            </div>
          </div>

          {/* 2-Button Toggle: Open vs Closed */}
          <div className="flex items-center p-1 bg-slate-100/90 dark:bg-slate-800/90 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0 self-stretch sm:self-auto gap-1">
            <button
              type="button"
              onClick={() => handleToggleSchoolStatus(true)}
              className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                !dayDetails.isHoliday
                  ? 'btn-3d-glass-emerald !text-white'
                  : 'glass-3d-btn text-slate-700 dark:text-slate-300'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>School Open</span>
            </button>
            <button
              type="button"
              onClick={() => handleToggleSchoolStatus(false)}
              className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                dayDetails.isHoliday
                  ? 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
                  : 'glass-3d-btn text-slate-700 dark:text-slate-300'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5" />
              <span>School Closed</span>
            </button>
          </div>
        </div>

        {/* Dynamic Status & Reason Body */}
        {dayDetails.isHoliday ? (
          <div className="pt-3 space-y-3 animate-fadeIn">
            {/* Active Closure Reason Banner */}
            <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
                <span className="text-[11px] sm:text-xs text-red-700 dark:text-red-300">
                  School is closed on <strong>{formatDateReadable(selectedDate)} ({dayDetails.dayName})</strong> due to: <strong className="underline underline-offset-2">{typedHolidayName || dayDetails.holidayName || (dayDetails.isSunday ? 'Sunday Holiday' : 'School Holiday')}</strong>
                </span>
              </div>
              <span className="text-[9px] font-bold px-2 py-0.5 bg-red-200/80 dark:bg-red-900/80 text-red-700 dark:text-red-200 rounded-md shrink-0">
                Logged on Register & Reports
              </span>
            </div>

            {/* Closure Reason Input Field & Save Action */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Reason for School Closure / Holiday
              </label>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={typedHolidayName}
                    onChange={(e) => {
                      const val = e.target.value;
                      setTypedHolidayName(val);
                      setRemarks(val);
                    }}
                    placeholder="Enter closure reason (e.g. Heavy Rain School Closure, Local Village Festival, Sunday Holiday)..."
                    className="w-full pl-3 pr-8 py-2 bg-white dark:bg-slate-800 border-2 border-red-300 dark:border-red-800/80 focus:border-red-600 dark:focus:border-red-500 rounded-xl text-xs font-bold text-slate-900 dark:text-white placeholder:text-slate-400 outline-hidden transition-all shadow-2xs"
                  />
                  {typedHolidayName && (
                    <button
                      type="button"
                      onClick={() => {
                        setTypedHolidayName('');
                        setRemarks('');
                      }}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md cursor-pointer"
                      title="Clear reason"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  disabled={!typedHolidayName.trim()}
                  onClick={() => {
                    if (typedHolidayName.trim()) {
                      handleUpdateHolidayReason(typedHolidayName.trim());
                      showToast(`Saved holiday reason: "${typedHolidayName.trim()}"`);
                    }
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-black border transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-xs shrink-0 cursor-pointer ${
                    typedHolidayName.trim()
                      ? 'bg-red-600 hover:bg-red-700 text-white border-red-700'
                      : 'bg-slate-100 text-slate-400 border-slate-200 dark:bg-slate-800 dark:text-slate-600 dark:border-slate-700 opacity-60 cursor-not-allowed'
                  }`}
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Holiday Reason</span>
                </button>
              </div>
            </div>

            {/* Quick 1-Click Reason Presets */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Quick Reason Presets (Click to Select & Save):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Sunday Holiday',
                  'Second Saturday',
                  'Heavy Rain / Weather Closure',
                  'Local / Village Festival',
                  'National / State Holiday',
                  'Declared Holiday / Bandh',
                  'Election Duty / Polling Station',
                  'Staff Training / Meeting',
                  'Vacation / Term Break',
                ].map((reason) => {
                  const isCurrent = typedHolidayName.toLowerCase() === reason.toLowerCase();
                  return (
                    <button
                      key={reason}
                      type="button"
                      onClick={() => handleUpdateHolidayReason(reason)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all border cursor-pointer active:scale-95 flex items-center gap-1 shadow-2xs ${
                        isCurrent
                          ? 'bg-red-600 text-white border-red-700 ring-2 ring-red-400/40'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-red-50 dark:hover:bg-red-950/40 border-slate-200 dark:border-slate-700 hover:border-red-300 hover:text-red-600'
                      }`}
                    >
                      {isCurrent && <Check className="w-3 h-3" />}
                      <span>{reason}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Closure Info Note */}
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span>
                  Attendance (0), meals served (0), and daily commodity consumption are set to 0. Stock balances carry forward seamlessly.
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleToggleSchoolStatus(true)}
                className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline shrink-0 cursor-pointer"
              >
                Reopen as Working Day
              </button>
            </div>
          </div>
        ) : (
          <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300 animate-fadeIn">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
              <span>
                School is <strong>Open & MDM Meals are being served</strong> on {formatDateReadable(selectedDate)}. Roll call and expenditure norms are active.
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleToggleSchoolStatus(false)}
              className="text-[11px] font-bold text-red-600 dark:text-red-400 hover:underline shrink-0 cursor-pointer"
            >
              🛑 Mark School Closed / Holiday
            </button>
          </div>
        )}

        {/* Public Holidays & Sundays Reference List Expandable Accordion */}
        <div className="pt-1.5">
          <button
            type="button"
            onClick={() => setShowHolidaysList(!showHolidaysList)}
            className="w-full flex items-center justify-between px-3 py-2 bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100/60 dark:hover:bg-slate-800/60 rounded-xl text-[11px] font-bold text-slate-600 dark:text-slate-300 transition-all border border-slate-200/60 dark:border-slate-800/60 cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-rose-500" />
              <span>
                View Month Calendar Holidays & Sundays ({selectedMonthHolidays.length} Holidays automatically detected)
              </span>
            </span>
            {showHolidaysList ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
          </button>

          {showHolidaysList && (
            <div className="mt-2 p-3 bg-slate-50/50 dark:bg-slate-900/40 rounded-xl border border-slate-200/60 dark:border-slate-800/60 space-y-2.5 animate-fadeIn">
              {/* Tab Selector */}
              <div className="flex items-center space-x-1 border-b border-slate-200 dark:border-slate-800 pb-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setHolidayListTab('MONTH')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    holidayListTab === 'MONTH'
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  Selected Month Holidays & Sundays ({selectedMonthHolidays.length})
                </button>
                <button
                  type="button"
                  onClick={() => setHolidayListTab('ALL_PUBLIC')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    holidayListTab === 'ALL_PUBLIC'
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  Annual Public Holidays ({getAPOfficialHolidaysList(holidayViewYear).length})
                </button>
              </div>

              {/* Tab Content: Selected Month Holidays & Sundays */}
              {holidayListTab === 'MONTH' && (
                <div>
                  {selectedMonthHolidays.length === 0 ? (
                    <p className="text-xs text-slate-500 p-2 text-center">
                      No holidays or Sundays detected for this month.
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 max-h-[260px] overflow-y-auto pr-1">
                      {selectedMonthHolidays.map((h, i) => {
                        const isSelectedDay = selectedDate === h.date;
                        return (
                          <button
                            key={i}
                            type="button"
                            onClick={() => {
                              setSelectedDate(h.date);
                              showToast(`Navigated to ${h.date} (${h.dayName})!`);
                            }}
                            className={`p-2.5 rounded-xl text-[9px] font-bold text-left transition-all border flex flex-col justify-between h-16 cursor-pointer relative ${
                              isSelectedDay
                                ? 'bg-red-600 text-white border-red-700 shadow-md ring-2 ring-red-500/30'
                                : 'bg-red-50/70 hover:bg-red-100 text-red-600 dark:bg-red-950/40 dark:hover:bg-red-900/50 border-red-200 dark:border-red-800'
                            }`}
                          >
                            <div className="flex items-center justify-between w-full">
                              <span className="font-extrabold opacity-90 text-[8.5px]">
                                {h.shortDayName}, {h.dayNum}
                              </span>
                              <span
                                className={`px-1.5 py-0.2 rounded text-[7.5px] font-black uppercase ${
                                  isSelectedDay
                                    ? 'bg-white/20 text-white'
                                    : h.typeBadge === 'SUNDAY'
                                    ? 'bg-red-100 text-red-600 dark:bg-red-950/80 dark:text-red-400'
                                    : h.typeBadge === 'SATURDAY'
                                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300'
                                    : 'bg-red-100 text-red-600 dark:bg-red-950/80 dark:text-red-400'
                                }`}
                              >
                                {h.typeBadge}
                              </span>
                            </div>
                            <span
                              className="font-black truncate w-full text-[9px] mt-1 text-red-600 dark:text-red-300"
                              title={h.holidayName}
                            >
                              {h.holidayName}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Tab Content: Annual Government Public Holidays */}
              {holidayListTab === 'ALL_PUBLIC' && (
                <div className="space-y-2">
                  {/* Year Switcher and Official AP Govt Citation */}
                  <div className="flex flex-wrap items-center justify-between gap-2 px-1 py-1 text-[10px]">
                    <div className="flex items-center space-x-1">
                      <span className="text-slate-500 font-bold text-[10px] mr-1">Select Year:</span>
                      {[2025, 2026, 2027].map((yr) => (
                        <button
                          key={yr}
                          type="button"
                          onClick={() => setHolidayViewYear(yr)}
                          className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] transition-all cursor-pointer ${
                            holidayViewYear === yr
                              ? 'bg-red-600 text-white shadow-2xs ring-1 ring-red-700'
                              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {yr}
                        </button>
                      ))}
                    </div>
                    <span className="text-[9.5px] font-semibold text-slate-500 dark:text-slate-400 truncate">
                      Official School Academic Calendar Holidays
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 max-h-[260px] overflow-y-auto pr-1">
                    {getAPOfficialHolidaysList(holidayViewYear).map((h, i) => {
                      const isSelectedDayHoliday = selectedDate === h.date;
                      const dateObj = new Date(h.date + 'T00:00:00');
                      const dayName = isNaN(dateObj.getTime())
                        ? ''
                        : dateObj.toLocaleDateString('en-IN', { weekday: 'short' });
                      const formattedDisplay = isNaN(dateObj.getTime())
                        ? h.date
                        : dateObj.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });

                      const categoryBadgeColor =
                        h.category === 'NATIONAL'
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300'
                          : h.category === 'SCHOOL_VACATION'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/60 dark:text-amber-300'
                          : 'bg-rose-100 text-rose-700 dark:bg-rose-900/60 dark:text-rose-300';

                      const categoryLabel =
                        h.category === 'NATIONAL'
                          ? 'NATIONAL'
                          : h.category === 'SCHOOL_VACATION'
                          ? 'VACATION'
                          : 'FESTIVAL';

                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            setSelectedDate(h.date);
                            showToast(`Navigated to ${h.date} (${h.name})!`);
                          }}
                          className={`p-2.5 rounded-xl text-[9px] font-bold text-left transition-all border flex flex-col justify-between h-16 cursor-pointer relative ${
                            isSelectedDayHoliday
                              ? 'bg-red-600 text-white border-red-700 shadow-md ring-2 ring-red-500/30'
                              : 'bg-red-50/50 hover:bg-red-100 text-red-600 dark:bg-red-950/40 dark:hover:bg-red-900/50 border-red-200 dark:border-red-800'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="font-extrabold opacity-90 text-[10px]">
                              {formattedDisplay} {dayName ? `(${dayName})` : ''}
                            </span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[7px] font-black uppercase ${
                                isSelectedDayHoliday ? 'bg-white/25 text-white' : categoryBadgeColor
                              }`}
                            >
                              {categoryLabel}
                            </span>
                          </div>
                          <span
                            className="font-black truncate w-full text-[9px] mt-0.5 text-slate-800 dark:text-slate-100"
                            title={h.name}
                          >
                            {h.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Entry Form */}
      <form onSubmit={handleSave} className="space-y-4">
        {/* Section 1: Student Attendance & Meals Served */}
        <div className="glass-3d-tile p-4 rounded-2xl space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-[13px] font-bold text-slate-800 dark:text-white flex items-center gap-1.5 uppercase">
                <Utensils className="w-3.5 h-3.5 text-blue-600" />
                Student Attendance & Meals Served
              </h3>
              <span className="text-[11px] text-slate-500 font-medium">
                Max School Capacity: <strong className="text-slate-800 dark:text-slate-200">{primaryTotalCap + upperPrimaryTotalCap}</strong>
              </span>
            </div>

            {/* Quick Roll Attendance Presets */}
            <div className="flex flex-wrap items-center gap-1">
              <span className="text-[10px] font-bold text-slate-400 mr-1 flex items-center gap-1">
                <Percent className="w-3 h-3 text-blue-500" /> Quick Roll:
              </span>
              {[100, 95, 90, 85, 80].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() => applyQuickRollAll(pct)}
                  className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/60 dark:hover:bg-blue-900/80 text-blue-700 dark:text-blue-300 rounded-md text-[10px] font-bold border border-blue-200 dark:border-blue-800 transition-all cursor-pointer shadow-2xs active:scale-95"
                >
                  {pct}%
                </button>
              ))}
              <button
                type="button"
                onClick={() => applyQuickRollAll(0)}
                className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 text-rose-700 dark:text-rose-300 rounded-md text-[10px] font-bold border border-rose-200 dark:border-rose-800 transition-all cursor-pointer shadow-2xs active:scale-95"
              >
                0%
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
            {/* Primary Attendance */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('primaryAttendance')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase">
                  Primary (1-5)
                </label>
                <span className={`font-extrabold px-1.5 py-0.2 rounded-md border ${getAttendanceColorScale(primaryAttPercentVal)}`} style={{ fontSize: '65%' }}>
                  {primaryAttPercent}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(Math.max(0, primaryAttendance - 5), upperPrimaryAttendance, highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="-5 students"
                >
                  -5
                </button>
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(Math.max(0, primaryAttendance - 1), upperPrimaryAttendance, highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="-1 student"
                >
                  -
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={primaryAttendance}
                  onChange={(e) => handleAttendanceChange(Number(e.target.value), upperPrimaryAttendance, highSchoolAttendance)}
                  onFocus={() => handleInputFocus('primaryAttendance')}
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(Math.min(primaryTotalCap, primaryAttendance + 1), upperPrimaryAttendance, highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="+1 student"
                >
                  +
                </button>
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(Math.min(primaryTotalCap, primaryAttendance + 5), upperPrimaryAttendance, highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="+5 students"
                >
                  +5
                </button>
              </div>
              <span className="text-[9px] text-slate-400 mt-1 block text-center font-medium">Max Enrolled: {primaryTotalCap}</span>
            </div>

            {/* Upper Primary Attendance */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('upperPrimaryAttendance')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase">
                  Upper Pri (6-8)
                </label>
                <span className={`font-extrabold px-1.5 py-0.2 rounded-md border ${getAttendanceColorScale(upperPrimaryAttPercentVal)}`} style={{ fontSize: '65%' }}>
                  {upperPrimaryAttPercent}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(primaryAttendance, Math.max(0, upperPrimaryAttendance - 5), highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="-5 students"
                >
                  -5
                </button>
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(primaryAttendance, Math.max(0, upperPrimaryAttendance - 1), highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="-1 student"
                >
                  -
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={upperPrimaryAttendance}
                  onChange={(e) => handleAttendanceChange(primaryAttendance, Number(e.target.value), highSchoolAttendance)}
                  onFocus={() => handleInputFocus('upperPrimaryAttendance')}
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(primaryAttendance, Math.min(upperPrimaryTotalCap, upperPrimaryAttendance + 1), highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="+1 student"
                >
                  +
                </button>
                <button
                  type="button"
                  onClick={() => handleAttendanceChange(primaryAttendance, Math.min(upperPrimaryTotalCap, upperPrimaryAttendance + 5), highSchoolAttendance)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                  title="+5 students"
                >
                  +5
                </button>
              </div>
              <span className="text-[9px] text-slate-400 mt-1 block text-center font-medium">Max Enrolled: {upperPrimaryTotalCap}</span>
            </div>

            {/* Total Attendance (Auto Calculated) */}
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase">
                  Total Attn
                </label>
                <span className={`font-extrabold px-1.5 py-0.2 rounded-md border ${getAttendanceColorScale(totalAttPercentVal)}`} style={{ fontSize: '65%' }}>
                  {totalAttPercent}
                </span>
              </div>
              <div className="w-full py-1 text-center text-blue-900 dark:text-blue-200 text-sm font-black">
                {totalAtt}
              </div>
              <span className="text-[9px] text-blue-600 dark:text-blue-400 mt-1 block text-center font-medium">Sum of all classes</span>
            </div>

            {/* Meals Served */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('mealsServed')
                ? 'ring-2 ring-emerald-500 border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10'
                : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase">
                  Meals Served
                </label>
                <span className={`font-extrabold px-1.5 py-0.2 rounded-md border ${getMealsServedColorScale(mealsServedPercentVal)}`} style={{ fontSize: '65%' }}>
                  {mealsServedPercent}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <button
                  type="button"
                  onClick={() => setMealsServed(Math.max(0, mealsServed - 1))}
                  className="w-5 h-6 flex items-center justify-center bg-emerald-200 hover:bg-emerald-300 dark:bg-emerald-800 dark:hover:bg-emerald-700 rounded text-[10px] font-black text-emerald-900 dark:text-emerald-100 cursor-pointer"
                  title="-1 meal"
                >
                  -
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={mealsServed}
                  onChange={(e) => setMealsServed(Number(e.target.value))}
                  onFocus={() => handleInputFocus('mealsServed')}
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-emerald-950 dark:text-emerald-100 text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setMealsServed(Math.min(totalAtt, mealsServed + 1))}
                  className="w-5 h-6 flex items-center justify-center bg-emerald-200 hover:bg-emerald-300 dark:bg-emerald-800 dark:hover:bg-emerald-700 rounded text-[10px] font-black text-emerald-900 dark:text-emerald-100 cursor-pointer"
                  title="+1 meal"
                >
                  +
                </button>
              </div>
              <span className="text-[9px] text-emerald-600 dark:text-emerald-400 mt-1 block text-center font-medium">Driven by roll call</span>
            </div>

            {/* Meals Not Served */}
            <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800">
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase">
                  Meals Not Served
                </label>
                <span className="font-bold text-rose-600 dark:text-rose-400" style={{ fontSize: '65%' }}>
                  ({totalAtt} − {mealsServed})
                </span>
              </div>
              <div className="w-full py-1 text-center text-rose-900 dark:text-rose-200 text-sm font-black">
                {Math.max(0, totalAtt - mealsServed)}
              </div>
              <span className="text-[9px] text-rose-600 dark:text-rose-400 mt-1 block text-center font-medium">
                Total Attendance − Total MDM Meals Served
              </span>
            </div>
          </div>

          {/* Class-wise Roll Call Section Toggle */}
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex flex-col gap-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <h4 className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-wider">
                    Class-wise Daily Attendance Roll Call
                  </h4>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 pt-1 border-t border-slate-100 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowClassWiseRoll(!showClassWiseRoll)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all border border-slate-200 dark:border-slate-700 cursor-pointer"
                  >
                    {showClassWiseRoll ? 'Hide Roll Call ▴' : 'Show Roll Call ▾'}
                  </button>
                </div>
              </div>
            </div>

            {showClassWiseRoll && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 animate-fadeIn">
                {dailyClassAttendance.map((item, index) => {
                  const classStrength = activeStudentStrengths.find((s) => s.classLevel === item.classLevel);
                  const maxBoys = classStrength?.boys || 0;
                  const maxGirls = classStrength?.girls || 0;
                  const maxTotal = classStrength?.total || 0;
                  
                  return (
                    <div key={item.classLevel} className="p-3 bg-slate-50/50 dark:bg-slate-800/20 border border-slate-200/80 dark:border-slate-800 rounded-2xl space-y-2.5 transition-all hover:shadow-xs">
                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60 dark:border-slate-800/60">
                        <span className="text-xs font-black text-slate-800 dark:text-white">
                          {item.classLevel}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded-md">
                          Cap: {maxBoys}B / {maxGirls}G ({maxTotal})
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[9px] font-bold text-slate-500 uppercase mb-1">
                            Boys Present
                          </label>
                          <div className="flex items-center space-x-0.5">
                            <button
                              type="button"
                              onClick={() => handleClassAttendanceChange(index, 'boysPresent', Math.max(0, item.boysPresent - 1))}
                              className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              -
                            </button>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={item.boysPresent}
                              onChange={(e) => handleClassAttendanceChange(index, 'boysPresent', Number(e.target.value))}
                              onFocus={() => handleInputFocus(`classAttendance-boys-${index}`)}
                              className={`w-full px-1 py-1 text-center bg-white dark:bg-slate-900 border rounded-lg text-slate-900 dark:text-white text-xs font-black transition-all ${
                                isInputActive(`classAttendance-boys-${index}`)
                                  ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                                  : 'border-slate-200 dark:border-slate-700'
                              }`}
                            />
                            <button
                              type="button"
                              onClick={() => handleClassAttendanceChange(index, 'boysPresent', Math.min(maxBoys, item.boysPresent + 1))}
                              className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              +
                            </button>
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-[9px] font-bold text-slate-500 uppercase mb-1">
                            Girls Present
                          </label>
                          <div className="flex items-center space-x-0.5">
                            <button
                              type="button"
                              onClick={() => handleClassAttendanceChange(index, 'girlsPresent', Math.max(0, item.girlsPresent - 1))}
                              className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              -
                            </button>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={item.girlsPresent}
                              onChange={(e) => handleClassAttendanceChange(index, 'girlsPresent', Number(e.target.value))}
                              onFocus={() => handleInputFocus(`classAttendance-girls-${index}`)}
                              className={`w-full px-1 py-1 text-center bg-white dark:bg-slate-900 border rounded-lg text-slate-900 dark:text-white text-xs font-black transition-all ${
                                isInputActive(`classAttendance-girls-${index}`)
                                  ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                                  : 'border-slate-200 dark:border-slate-700'
                              }`}
                            />
                            <button
                              type="button"
                              onClick={() => handleClassAttendanceChange(index, 'girlsPresent', Math.min(maxGirls, item.girlsPresent + 1))}
                              className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/40 text-[10px] font-bold">
                        <span className="text-slate-500">Class Attendance:</span>
                        <span className="text-blue-700 dark:text-blue-300 font-black bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-md">
                          {item.totalPresent} / {maxTotal} Present
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Quick Inward Stock Receive Bar (Rice, Cooking Oil, Pulses & Commodities) */}
        <div className="bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 p-3.5 rounded-2xl space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <PackagePlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <div>
                <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                  Quick Stock Inward Receipt ({formatDateReadable(selectedDate)})
                </h4>
                <p className="text-[10px] text-slate-500">Tap to instantly record received commodities for today</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => openStockModal('rice', 'RECEIVED')}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95 self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Custom Inward Receipt</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
            {/* Rice Quick Receive */}
            <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-200/60 dark:border-emerald-900/40 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-black text-slate-800 dark:text-slate-200 flex items-center gap-1">
                  <Wheat className="w-3.5 h-3.5 text-amber-600" /> Rice Inward
                </span>
                <span className="text-[9px] text-slate-400 font-bold">Kg</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {[25, 50, 100, 200].map((qty) => (
                  <button
                    key={qty}
                    type="button"
                    onClick={() => handleQuickReceiveStock('rice', qty, 'Kg')}
                    className="flex-1 min-w-[50px] py-1 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/50 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-200 rounded-lg text-[10px] font-black border border-amber-200 dark:border-amber-800 transition-all cursor-pointer text-center active:scale-95"
                  >
                    +{qty} kg
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Commodity Consumption with AP MDM Auto-Calculator */}
        <div
          className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-4 rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5 uppercase">
                <Wheat className="w-3.5 h-3.5 text-amber-500" />
                Commodities Used Today
              </h3>
              <p className="text-[10px] text-slate-500">Edit usage or use AP MDM Norms auto-calculator</p>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <label className="flex items-center space-x-1.5 text-[10px] font-bold text-blue-600 dark:text-blue-400 cursor-pointer bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded-lg border border-blue-200 dark:border-blue-800">
                <input
                  type="checkbox"
                  checked={autoCalculateNorms}
                  onChange={(e) => {
                    const nextVal = e.target.checked;
                    setAutoCalculateNorms(nextVal);
                    if (onUpdateAutomationSettings && automationSettings) {
                      onUpdateAutomationSettings({
                        ...automationSettings,
                        autoCalculateNorms: nextVal,
                      });
                    }
                    if (nextVal) {
                      computeNorms(primaryAttendance, upperPrimaryAttendance, selectedDate, highSchoolAttendance);
                    }
                  }}
                  className="rounded-xs text-blue-600 w-3 h-3"
                />
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Auto-Calculate Norms</span>
              </label>
            </div>
          </div>

          {/* Daily Menu Indent Calculation Commodities Banner */}
          {(() => {
            const isHolidayDate = getDayDetails(selectedDate).isHoliday;
            const curIndent = calculateDailyMenuIndent(selectedDate, primaryAttendance, upperPrimaryAttendance, highSchoolAttendance, mealRates, isHolidayDate);
            return (
              <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200/80 dark:border-slate-700/80 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 uppercase">
                        <Utensils className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                        Daily Menu Indent Calculation
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-700">
                        {curIndent.dayName}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-600 dark:text-slate-400">
                      Menu: <span className="font-semibold text-slate-800 dark:text-slate-200">{curIndent.menuDescription}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      type="button"
                      onClick={() => computeNorms(primaryAttendance, upperPrimaryAttendance, selectedDate)}
                      title="Recalculate today's commodities based on attendance and AP MDM norms"
                      className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      <span>Recalculate Today</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleAutoUpdateAllEntries}
                      disabled={isUpdatingAll}
                      title="Automatically update all saved daily entries in the database to align with the official Menu Indent schedule"
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <TrendingUp className="w-3 h-3" />
                      <span>{isUpdatingAll ? 'Updating All...' : '⚡ Auto-Update All Data'}</span>
                    </button>
                  </div>
                </div>

                {/* Specific Indent Schedule Cards for Eggs, Chikki, Ragi & Jaggery */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 text-[10px]">
                  {/* Eggs */}
                  <div className={`p-2 rounded-lg border transition-all ${
                    curIndent.isEggDay && !isHolidayDate
                      ? 'bg-yellow-50 dark:bg-yellow-950/30 border-yellow-300 dark:border-yellow-700/60 text-yellow-950 dark:text-yellow-200'
                      : 'bg-slate-100/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-500 dark:text-slate-400 opacity-80'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        <Egg className="w-3.5 h-3.5 text-yellow-600" /> Eggs
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                        curIndent.isEggDay && !isHolidayDate
                          ? 'bg-yellow-200 dark:bg-yellow-800 text-yellow-900 dark:text-yellow-100'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}>
                        {curIndent.isEggDay && !isHolidayDate ? `${eggUsedQty} Eggs` : 'Off Today'}
                      </span>
                    </div>
                    <p className="text-[9px] mt-1 text-slate-600 dark:text-slate-400">
                      Schedule: <strong className="text-slate-800 dark:text-slate-200">Mon, Tue, Wed, Thu, Fri</strong>
                    </p>
                  </div>

                  {/* Chikki */}
                  <div className={`p-2 rounded-lg border transition-all ${
                    curIndent.isChikkiDay && !isHolidayDate
                      ? 'bg-orange-50 dark:bg-orange-950/30 border-orange-300 dark:border-orange-700/60 text-orange-950 dark:text-orange-200'
                      : 'bg-slate-100/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-500 dark:text-slate-400 opacity-80'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        <Cookie className="w-3.5 h-3.5 text-orange-600" /> Chikki
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                        curIndent.isChikkiDay && !isHolidayDate
                          ? 'bg-orange-200 dark:bg-orange-800 text-orange-900 dark:text-orange-100'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}>
                        {curIndent.isChikkiDay && !isHolidayDate ? `${chikkiUsedQty} Pcs` : 'Off Today'}
                      </span>
                    </div>
                    <p className="text-[9px] mt-1 text-slate-600 dark:text-slate-400">
                      Schedule: <strong className="text-slate-800 dark:text-slate-200">Mon, Wed, Fri</strong>
                    </p>
                  </div>

                  {/* Ragi & Jaggery */}
                  <div className={`p-2 rounded-lg border transition-all ${
                    curIndent.isRagiDay && !isHolidayDate
                      ? 'bg-purple-50 dark:bg-purple-950/30 border-purple-300 dark:border-purple-700/60 text-purple-950 dark:text-purple-200'
                      : 'bg-slate-100/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-500 dark:text-slate-400 opacity-80'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 text-purple-600" /> Ragi & Jaggery
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                        curIndent.isRagiDay && !isHolidayDate
                          ? 'bg-purple-200 dark:bg-purple-800 text-purple-900 dark:text-purple-100'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}>
                        {curIndent.isRagiDay && !isHolidayDate ? `${ragiUsedKg}kg / ${jaggeryUsedKg}kg` : 'Off Today'}
                      </span>
                    </div>
                    <p className="text-[9px] mt-1 text-slate-600 dark:text-slate-400">
                      Schedule: <strong className="text-slate-800 dark:text-slate-200">Tue, Thu, Sat</strong>
                    </p>
                  </div>
                </div>

                {updateSuccessMsg && (
                  <div className="p-2 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 font-bold text-center text-[10px] animate-pulse">
                    {updateSuccessMsg}
                  </div>
                )}
              </div>
            );
          })()}

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {/* Rice Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('riceUsedKg')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-amber-50/40 dark:bg-slate-800/80 border-amber-200/60 dark:border-slate-700'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Wheat className="w-3 h-3 text-amber-600" /> Rice (Kg)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setRiceUsedKg(Number((riceUsedKg - 1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -1
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={riceUsedKg}
                  onChange={(e) => setRiceUsedKg(Number(e.target.value))}
                  onFocus={() => handleInputFocus('riceUsedKg')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setRiceUsedKg(Number((riceUsedKg + 1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +1
                </button>
              </div>
            </div>

            {/* Cooking Oil Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('oilUsedLitres')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-yellow-50/40 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Flame className="w-3 h-3 text-yellow-600" /> Oil (Ltr)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setOilUsedLitres(Number((oilUsedLitres - 0.1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -.1
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={oilUsedLitres}
                  onChange={(e) => setOilUsedLitres(Number(e.target.value))}
                  onFocus={() => handleInputFocus('oilUsedLitres')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setOilUsedLitres(Number((oilUsedLitres + 0.1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +.1
                </button>
              </div>
            </div>

            {/* Pulses / Dal Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('pulsesUsedKg')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Boxes className="w-3 h-3 text-amber-600" /> Pulses / Dal (Kg)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setPulsesUsedKg(Number((pulsesUsedKg - 0.25).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -.25
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={pulsesUsedKg}
                  onChange={(e) => setPulsesUsedKg(Number(e.target.value))}
                  onFocus={() => handleInputFocus('pulsesUsedKg')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setPulsesUsedKg(Number((pulsesUsedKg + 0.25).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +.25
                </button>
              </div>
            </div>

            {/* Egg Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('eggUsedQty')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-yellow-50/50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Egg className="w-3 h-3 text-yellow-600" /> Eggs (Qty)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setEggUsedQty(eggUsedQty - 5)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -5
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={eggUsedQty}
                  onChange={(e) => setEggUsedQty(Number(e.target.value))}
                  onFocus={() => handleInputFocus('eggUsedQty')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setEggUsedQty(eggUsedQty + 5)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +5
                </button>
              </div>
            </div>

            {/* Chikki Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('chikkiUsedQty')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-orange-50/50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Cookie className="w-3 h-3 text-orange-600" /> Chikki (Qty)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setChikkiUsedQty(chikkiUsedQty - 5)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -5
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={chikkiUsedQty}
                  onChange={(e) => setChikkiUsedQty(Number(e.target.value))}
                  onFocus={() => handleInputFocus('chikkiUsedQty')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setChikkiUsedQty(chikkiUsedQty + 5)}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +5
                </button>
              </div>
            </div>

            {/* Ragi Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('ragiUsedKg')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-purple-50/50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Flame className="w-3 h-3 text-purple-600" /> Ragi Flour (Kg)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setRagiUsedKg(Number((ragiUsedKg - 0.5).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -.5
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={ragiUsedKg}
                  onChange={(e) => setRagiUsedKg(Number(e.target.value))}
                  onFocus={() => handleInputFocus('ragiUsedKg')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setRagiUsedKg(Number((ragiUsedKg + 0.5).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +.5
                </button>
              </div>
            </div>

            {/* Jaggery Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('jaggeryUsedKg')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-pink-50/50 dark:bg-pink-950/20 border-pink-200 dark:border-pink-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-pink-600" /> Jaggery (Kg)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setJaggeryUsedKg(Number((jaggeryUsedKg - 0.5).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -.5
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={jaggeryUsedKg}
                  onChange={(e) => setJaggeryUsedKg(Number(e.target.value))}
                  onFocus={() => handleInputFocus('jaggeryUsedKg')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setJaggeryUsedKg(Number((jaggeryUsedKg + 0.5).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +.5
                </button>
              </div>
            </div>

            {/* Condiments Used */}
            <div className={`p-2 rounded-xl border transition-all ${
              isInputActive('condimentsUsedKg')
                ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                : 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/50'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Boxes className="w-3 h-3 text-emerald-600" /> Spices / Cond (Kg)
                </label>
              </div>
              <div className="flex items-center space-x-0.5">
                <button
                  type="button"
                  onClick={() => setCondimentsUsedKg(Number((condimentsUsedKg - 0.1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  -.1
                </button>
                <input
                  type="text"
                  inputMode="decimal"
                  value={condimentsUsedKg}
                  onChange={(e) => setCondimentsUsedKg(Number(e.target.value))}
                  onFocus={() => handleInputFocus('condimentsUsedKg')}
                  autoComplete="off"
                  className="w-full text-center px-1 py-0.5 bg-transparent border-0 focus:ring-0 outline-hidden text-slate-900 dark:text-white text-xs font-black"
                />
                <button
                  type="button"
                  onClick={() => setCondimentsUsedKg(Number((condimentsUsedKg + 0.1).toFixed(3)))}
                  className="w-5 h-6 flex items-center justify-center bg-slate-200 dark:bg-slate-700 rounded text-[9px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  +.1
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5">
              Inspection Remarks / Notes
            </label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              inputMode="text"
              placeholder="e.g. Quality of rice inspected by HM, food tasted good, clean kitchen environment."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white text-xs"
            />
          </div>
        </div>

        {/* Section 2.5: Live Daily Commodity Stock & Auto Carry-Forward Ledger */}
        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 rounded-2xl border border-blue-200/70 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5 uppercase tracking-wide">
                  <Boxes className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Daily Commodity Stock & Auto Carry-Forward Ledger
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  Auto-Carry Forward Active
                </span>
              </div>
              <p className="text-[10.5px] text-slate-500 dark:text-slate-400 mt-0.5">
                Yesterday's Closing Balance automatically becomes Today's Opening Balance, updating day-by-day.
              </p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShowOpeningModal(true)}
                className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300 rounded-lg text-[10.5px] font-bold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1 cursor-pointer transition-all active:scale-95"
                title="Adjust Month Starting Balance Overrides"
              >
                <Edit3 className="w-3 h-3" />
                <span>Month Start Balances</span>
              </button>
            </div>
          </div>

          {/* Commodity Stock Grid / Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {[
              { id: 'rice', name: 'Rice', unit: 'Kg', icon: <Wheat className="w-4 h-4 text-amber-600" />, bg: 'bg-amber-50/40 dark:bg-amber-950/20', border: 'border-amber-200/70 dark:border-amber-900/40' },
              { id: 'egg', name: 'Eggs', unit: 'Pcs', icon: <Egg className="w-4 h-4 text-yellow-600" />, bg: 'bg-yellow-50/40 dark:bg-yellow-950/20', border: 'border-yellow-200/70 dark:border-yellow-900/40' },
              { id: 'chikki', name: 'Chikki', unit: 'Pcs', icon: <Cookie className="w-4 h-4 text-orange-600" />, bg: 'bg-orange-50/40 dark:bg-orange-950/20', border: 'border-orange-200/70 dark:border-orange-900/40' },
              { id: 'ragi', name: 'Ragi Flour', unit: 'Kg', icon: <Flame className="w-4 h-4 text-purple-600" />, bg: 'bg-purple-50/40 dark:bg-purple-950/20', border: 'border-purple-200/70 dark:border-purple-900/40' },
              { id: 'jaggery', name: 'Jaggery', unit: 'Kg', icon: <Sparkles className="w-4 h-4 text-pink-600" />, bg: 'bg-pink-50/40 dark:bg-pink-950/20', border: 'border-pink-200/70 dark:border-pink-900/40' },
              { id: 'oil', name: 'Cooking Oil', unit: 'Ltr', icon: <Droplet className="w-4 h-4 text-amber-500" />, bg: 'bg-amber-50/40 dark:bg-amber-950/20', border: 'border-amber-200/70 dark:border-amber-900/40' },
              { id: 'pulses', name: 'Pulses / Dal', unit: 'Kg', icon: <Soup className="w-4 h-4 text-yellow-600" />, bg: 'bg-yellow-50/40 dark:bg-yellow-950/20', border: 'border-yellow-200/70 dark:border-yellow-900/40' },
              { id: 'condiments', name: 'Condiments', unit: 'Kg', icon: <Boxes className="w-4 h-4 text-emerald-600" />, bg: 'bg-emerald-50/40 dark:bg-emerald-950/20', border: 'border-emerald-200/70 dark:border-emerald-900/40' },
            ].map((comm) => {
              const stock = todayCommodityStockBalances[comm.id] || {
                ob: 0,
                rec: 0,
                used: 0,
                spoiled: 0,
                cb: 0,
                prevDate: '',
              };

              return (
                <div
                  key={comm.id}
                  className={`p-3 rounded-xl border ${comm.border} ${comm.bg} flex flex-col justify-between space-y-2 shadow-2xs transition-all hover:shadow-xs`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="p-1 rounded-lg bg-white dark:bg-slate-800 shadow-2xs">
                        {comm.icon}
                      </div>
                      <span className="text-xs font-black text-slate-800 dark:text-slate-100">
                        {comm.name}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 font-mono bg-white/80 dark:bg-slate-800/80 px-1.5 py-0.5 rounded">
                      {comm.unit}
                    </span>
                  </div>

                  {/* Stock Equation Row */}
                  <div className="space-y-1.5 text-[11px] font-mono bg-white/90 dark:bg-slate-900/90 p-2.5 rounded-lg border border-slate-200/60 dark:border-slate-800">
                    {/* Opening Balance (Auto Carried Forward / Read-Only) */}
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600 dark:text-slate-400 font-sans font-semibold flex items-center gap-1">
                          <span>Opening Balance:</span>
                        </span>
                        <div className="flex items-center gap-1">
                          <span className={`font-bold ${stock.ob < 0 ? 'text-rose-600 dark:text-rose-400 font-extrabold' : 'text-indigo-700 dark:text-indigo-300'}`}>
                            {formatQtyVal(stock.ob)} {comm.unit}
                          </span>
                          <span
                            className={`px-1 py-0.2 rounded text-[8.5px] font-black uppercase border ${
                              stock.sourceType === 'MONTHLY_OVERRIDE' || stock.sourceType === 'ADJUSTMENT'
                                ? 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800'
                                : 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                            }`}
                          >
                            {stock.sourceType === 'MONTHLY_OVERRIDE' || stock.sourceType === 'ADJUSTMENT' ? 'OVERRIDE' : 'AUTO'}
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowOpeningModal(true)}
                            className="p-0.5 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200 hover:bg-indigo-100/60 dark:hover:bg-indigo-900/60 rounded cursor-pointer transition-colors"
                            title={`Edit ${comm.name} Month Opening Balance`}
                          >
                            <Edit2 className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </div>
                      <div className="text-[9px] text-slate-500 dark:text-slate-400 font-sans mt-0.5 truncate flex items-center gap-1" title={stock.sourceDescription || 'Auto carried from previous closing'}>
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <span className="truncate">{stock.sourceDescription || `Auto from ${stock.prevDate || 'previous day'}`}</span>
                      </div>
                    </div>

                    {/* Received */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
                      <span className="text-slate-500 dark:text-slate-400 font-sans font-medium flex items-center gap-1">
                        <span>Receipts (+):</span>
                      </span>
                      <div className="flex items-center gap-1">
                        <span className={`font-bold ${stock.rec > 0 ? 'text-emerald-700 dark:text-emerald-300' : 'text-slate-400'}`}>
                          {stock.rec > 0 ? `+${formatQtyVal(stock.rec)}` : '0'} {comm.unit}
                        </span>
                        <button
                          type="button"
                          onClick={() => openStockModal(comm.id, 'RECEIVED')}
                          className="text-[9px] font-sans px-1.5 py-0.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 rounded border border-emerald-200 dark:border-emerald-800 cursor-pointer transition-colors"
                          title={`Record received stock for ${comm.name}`}
                        >
                          +Rec
                        </button>
                      </div>
                    </div>

                    {/* Used */}
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400 font-sans font-medium">
                        Issued / Used (-):
                      </span>
                      <span className={`font-bold ${stock.used > 0 ? 'text-blue-700 dark:text-blue-300' : 'text-slate-400'}`}>
                        {stock.used > 0 ? `-${formatQtyVal(stock.used)}` : '0'} {comm.unit}
                      </span>
                    </div>

                    {/* Spoiled */}
                    {stock.spoiled > 0 && (
                      <div className="flex items-center justify-between">
                        <span className="text-rose-600 dark:text-rose-400 font-sans font-medium">
                          Spoiled / Damaged (-):
                        </span>
                        <span className="font-bold text-rose-600 dark:text-rose-400">
                          -{formatQtyVal(stock.spoiled)} {comm.unit}
                        </span>
                      </div>
                    )}

                    {/* Closing Balance Result */}
                    <div className="pt-1.5 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between font-black text-xs">
                      <span className="text-slate-900 dark:text-white font-sans">
                        Closing Balance:
                      </span>
                      <span className={`font-black ${stock.cb < 0 ? 'text-rose-600 dark:text-rose-400' : 'text-cyan-800 dark:text-cyan-300'}`}>
                        {formatQtyVal(stock.cb)} {comm.unit}
                      </span>
                    </div>
                  </div>

                  <div className="text-[9.5px] text-slate-500 font-medium text-center bg-slate-50 dark:bg-slate-800/50 py-1 rounded-md flex items-center justify-center gap-1">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">✓</span>
                    <span>Carries to next day OB:</span>
                    <strong className="text-slate-800 dark:text-slate-200">{formatQtyVal(stock.cb)} {comm.unit}</strong>
                  </div>
                </div>
              );
            })}
          </div>
        </div>




        {/* Section 3: Stock Transactions Logged for Selected Date */}
        {selectedDateTransactions.length > 0 && (
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 uppercase">
                <History className="w-4 h-4 text-emerald-600" />
                Stock Received / Spoiled Logged on {formatDateReadable(selectedDate)}
              </h3>
              <span className="text-[11px] text-slate-500 font-semibold">
                {selectedDateTransactions.length} Record(s)
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {selectedDateTransactions.map((tx) => {
                const comm = commodities.find((c) => c.id === tx.commodityId);
                const isReceived = tx.type === 'RECEIVED';
                return (
                  <div key={tx.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`p-1.5 rounded-lg ${
                          isReceived
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-300'
                        }`}
                      >
                        {isReceived ? <PackagePlus className="w-4 h-4" /> : <PackageX className="w-4 h-4" />}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span>{comm?.name || tx.commodityId}</span>
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                              isReceived
                                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                            }`}
                          >
                            {isReceived ? 'RECEIVED (+)' : 'SPOILED / DAMAGED (-)'}
                          </span>
                        </div>
                        {tx.remarks && <p className="text-[11px] text-slate-500 mt-0.5">{tx.remarks}</p>}
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <span className={`font-black text-sm ${isReceived ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {isReceived ? '+' : '-'}{tx.quantity} {comm?.unit || 'units'}
                        </span>
                        {tx.invoiceNo && <div className="text-[10px] text-slate-400">Inv: {tx.invoiceNo}</div>}
                      </div>

                      <div className="flex items-center space-x-1 pl-2 border-l border-slate-100 dark:border-slate-800">
                        <button
                          type="button"
                          onClick={() => openEditStockModal(tx)}
                          className="p-1.5 hover:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-lg transition-colors cursor-pointer"
                          title="Edit Stock Record"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteStockTx(tx)}
                          className="p-1.5 hover:bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          title="Delete Stock Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <div>
            {existingEntry && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/40 dark:text-red-400 rounded-xl text-xs font-bold transition-colors flex items-center space-x-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Entry</span>
              </button>
            )}
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => navigateDate(-1)}
              className="px-3 py-2.5 glass-3d-btn text-blue-700 dark:text-sky-300 hover:text-blue-800 dark:hover:text-sky-200 font-extrabold rounded-xl text-xs shadow-md border border-sky-300/80 dark:border-sky-500/50 transition-all flex items-center space-x-1"
              title="Previous Entry Date"
            >
              <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
              <span>Prev Date</span>
            </button>

            <button
              type="button"
              onClick={() => navigateDate(1)}
              className="px-3 py-2.5 glass-3d-btn text-blue-700 dark:text-sky-300 hover:text-blue-800 dark:hover:text-sky-200 font-extrabold rounded-xl text-xs shadow-md border border-sky-300/80 dark:border-sky-500/50 transition-all flex items-center space-x-1"
              title="Next Entry Date"
            >
              <span>Next Date</span>
              <ChevronRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </form>

      {/* Received / Spoiled Commodity Stock Entry Modal */}
      {showStockModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {stockTxType === 'RECEIVED' ? (
                  <PackagePlus className="w-5 h-5 text-emerald-600" />
                ) : (
                  <PackageX className="w-5 h-5 text-rose-600" />
                )}
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {editingStockTxId
                      ? 'Edit Stock Record'
                      : stockTxType === 'RECEIVED'
                      ? 'Record Received Stock'
                      : 'Record Spoiled / Damaged Commodity'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {editingStockTxId ? 'Modify existing stock transaction' : `Date: ${formatDateReadable(stockTxDate)}`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowStockModal(false)}
                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-slate-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleStockSubmit} className="p-5 space-y-4">
              {/* Date Field */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Transaction Date
                </label>
                <input
                  type="date"
                  value={stockTxDate}
                  onChange={(e) => setStockTxDate(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-xl text-slate-900 dark:text-white font-bold text-xs shadow-xs"
                  required
                />
              </div>

              {/* Type selector toggle */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Transaction Type
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setStockTxType('RECEIVED')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
                      stockTxType === 'RECEIVED'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <PackagePlus className="w-4 h-4" />
                    <span>+ Stock Received</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setStockTxType('SPOILED')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
                      stockTxType === 'SPOILED'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <PackageX className="w-4 h-4" />
                    <span>- Spoiled / Damaged</span>
                  </button>
                </div>
              </div>

              {/* Invoice / Delivery Challan No */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Invoice / Delivery Challan No. <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  inputMode="text"
                  value={stockInvoiceNo}
                  onChange={(e) => setStockInvoiceNo(e.target.value)}
                  placeholder="e.g. DC-2026-0811"
                  className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-xs"
                />
              </div>

              {/* Remarks / Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Remarks / Reason <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  inputMode="text"
                  value={stockRemarks}
                  onChange={(e) => setStockRemarks(e.target.value)}
                  placeholder={
                    stockTxType === 'RECEIVED'
                      ? 'e.g. Received from Civil Supplies dept'
                      : 'e.g. Damaged during transit / rat infestation'
                  }
                  className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white text-xs"
                />
              </div>

              {/* Render single item select when editing */}
              {editingStockTxId ? (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                      Select Commodity
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                      {(['rice', 'egg', 'chikki', 'ragi', 'jaggery'] as const).map((cId) => {
                        const cObj = commodities.find((c) => c.id === cId);
                        const isSelected = stockCommodityId === cId;
                        return (
                          <button
                            key={cId}
                            type="button"
                            onClick={() => setStockCommodityId(cId)}
                            className={`p-2 rounded-xl text-center border transition-all flex flex-col items-center justify-center ${
                              isSelected
                                ? 'border-blue-600 bg-blue-50 dark:bg-blue-950 text-blue-900 dark:text-blue-200 font-black shadow-xs'
                                : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            {getCommodityIcon(cId)}
                            <span className="text-[11px] font-bold mt-1 capitalize">{cId}</span>
                            <span className="text-[9px] text-slate-400">({cObj?.unit})</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                      Quantity ({commodities.find((c) => c.id === stockCommodityId)?.unit})
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={stockQuantity}
                        onChange={(e) => setStockQuantity(Number(e.target.value))}
                        onFocus={() => handleInputFocus('stockQuantity')}
                        autoComplete="off"
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-slate-900 dark:text-white font-black text-sm transition-all ${
                          isInputActive('stockQuantity')
                            ? 'ring-2 ring-blue-500 border-blue-500 bg-blue-500/5 dark:bg-blue-500/10'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700'
                        }`}
                        placeholder="Enter quantity"
                        required
                      />
                      <span className="absolute right-3 top-2.5 text-xs font-bold text-slate-400">
                        {commodities.find((c) => c.id === stockCommodityId)?.unit}
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                /* Render Multi-Commodity Quantities for New Stock Record */
                <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <label className="block font-black text-slate-800 dark:text-slate-200 uppercase text-[11px]">
                      Enter Quantities for Commodities:
                    </label>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Specify quantity for received/spoiled items
                    </span>
                  </div>

                  <div className="space-y-2">
                    {commodities.map((c) => {
                      const qtyVal = stockMultiQuantities[c.id] ?? '';
                      const hasQty = Number(qtyVal) > 0;

                      return (
                        <div
                          key={c.id}
                          className={`data-entry-card p-2.5 rounded-xl border transition-all ${
                            hasQty
                              ? 'bg-amber-500/10 border-amber-500/50 dark:border-amber-500/40 shadow-xs'
                              : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/60'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center space-x-2 min-w-0">
                              <div className="p-1.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0">
                                {getCommodityIcon(c.id)}
                              </div>
                              <div className="min-w-0">
                                <div className="font-bold text-slate-900 dark:text-white text-xs truncate">
                                  {c.name}
                                </div>
                                <div className="text-[9px] text-slate-500 uppercase font-semibold">
                                  Unit: {c.unit}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center space-x-1.5 shrink-0">
                              <input
                                type="text"
                                inputMode="decimal"
                                placeholder="0"
                                value={qtyVal}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setStockMultiQuantities((prev) => ({
                                    ...prev,
                                    [c.id]: val === '' ? '' : Number(val),
                                  }));
                                }}
                                className="w-24 p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-black text-slate-900 dark:text-white text-right focus:ring-2 focus:ring-amber-500 text-xs"
                              />
                              <span className="text-[10px] font-bold text-slate-500 w-7">{c.unit}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Form Buttons */}
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowStockModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={
                    stockSaveSuccessType
                      ? "btn-glass-green px-5 py-2 text-xs shadow-lg shadow-emerald-500/40 rounded-xl flex items-center space-x-1.5"
                      : isStockFormDirty
                        ? "btn-glass-orange px-5 py-2 text-xs shadow-lg shadow-amber-500/40 rounded-xl flex items-center space-x-1.5"
                        : "btn-glass-blue px-5 py-2 text-xs shadow-lg shadow-blue-500/30 rounded-xl flex items-center space-x-1.5"
                  }
                >
                  {stockSaveSuccessType ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-950" />
                      <span>{stockSaveSuccessType === 'UPDATED' ? 'Updated Successfully!' : 'Saved Successfully!'}</span>
                    </>
                  ) : editingStockTxId ? (
                    <>
                      <Edit3 className="w-4 h-4" />
                      <span>Update Stock Record</span>
                    </>
                  ) : stockTxType === 'RECEIVED' ? (
                    <>
                      <PackagePlus className="w-4 h-4" />
                      <span>
                        Save Received Stock (
                        {commodities.filter((c) => Number(stockMultiQuantities[c.id]) > 0).length})
                      </span>
                    </>
                  ) : (
                    <>
                      <PackageX className="w-4 h-4" />
                      <span>
                        Log Spoiled Stock (
                        {commodities.filter((c) => Number(stockMultiQuantities[c.id]) > 0).length})
                      </span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom 3D On-Screen Keypad Panel */}
      {activeInputId && (
        <div className="fixed bottom-0 left-0 right-0 z-50 p-3 bg-white/95 dark:bg-slate-950/95 border-t border-slate-200 dark:border-slate-800 shadow-[0_-8px_30px_rgb(0,0,0,0.12)] backdrop-blur-md">
          <div className="max-w-md mx-auto space-y-2.5">
            {/* Header / Info bar */}
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800/60">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wide">
                  Editing Field
                </span>
                <span className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1">
                  {getInputLabelById(activeInputId)}
                  <span className="text-[10px] text-slate-400 font-bold bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                    Max: {getInputMaxById(activeInputId)}
                  </span>
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                {/* Buffer visualizer */}
                <div className="px-3 py-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl font-mono text-sm font-black text-slate-800 dark:text-white min-w-[70px] text-right shadow-inner">
                  {keypadBuffer || '0'}
                </div>
                
                {/* Dismiss Button */}
                <button
                  type="button"
                  onClick={() => setActiveInputId(null)}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Keypad Buttons Grid */}
            <div className="grid grid-cols-4 gap-1.5">
              {/* Row 1: Offsets */}
              <button
                type="button"
                onClick={() => handleKeypadPress('-5')}
                className="py-1.5 bg-rose-50 hover:bg-rose-100 active:bg-rose-200 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 text-rose-700 dark:text-rose-400 font-extrabold text-xs rounded-lg transition-all border border-rose-200/50 dark:border-rose-950/50 cursor-pointer shadow-xs active:scale-95"
              >
                -5
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('-1')}
                className="py-1.5 bg-rose-50 hover:bg-rose-100 active:bg-rose-200 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-extrabold text-xs rounded-lg transition-all border border-rose-100 dark:border-rose-950/30 cursor-pointer shadow-xs active:scale-95"
              >
                -1
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('+1')}
                className="py-1.5 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs rounded-lg transition-all border border-emerald-100 dark:border-emerald-950/30 cursor-pointer shadow-xs active:scale-95"
              >
                +1
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('+5')}
                className="py-1.5 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-extrabold text-xs rounded-lg transition-all border border-emerald-200/50 dark:border-emerald-950/50 cursor-pointer shadow-xs active:scale-95"
              >
                +5
              </button>

              {/* Row 2: 1, 2, 3, Backspace */}
              {['1', '2', '3'].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeypadPress(num)}
                  className="py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:active:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-sm rounded-lg transition-all border border-slate-200/50 dark:border-slate-700/50 cursor-pointer shadow-xs active:scale-95"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleKeypadPress('Backspace')}
                className="py-2 bg-slate-200/80 hover:bg-slate-300 active:bg-slate-400 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-black text-sm rounded-lg transition-all border border-slate-300/50 dark:border-slate-600/50 cursor-pointer shadow-xs flex items-center justify-center active:scale-95"
                title="Backspace"
              >
                <Delete className="w-4 h-4" />
              </button>

              {/* Row 3: 4, 5, 6, Clear */}
              {['4', '5', '6'].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeypadPress(num)}
                  className="py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:active:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-sm rounded-lg transition-all border border-slate-200/50 dark:border-slate-700/50 cursor-pointer shadow-xs active:scale-95"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleKeypadPress('Clear')}
                className="py-2 bg-amber-500/10 hover:bg-amber-500/20 active:bg-amber-500/30 text-amber-600 dark:text-amber-400 font-bold text-xs rounded-lg transition-all border border-amber-500/20 dark:border-amber-500/30 cursor-pointer shadow-xs active:scale-95"
              >
                CLEAR
              </button>

              {/* Row 4: 7, 8, 9, Max */}
              {['7', '8', '9'].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeypadPress(num)}
                  className="py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:active:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-sm rounded-lg transition-all border border-slate-200/50 dark:border-slate-700/50 cursor-pointer shadow-xs active:scale-95"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleKeypadPress('Max')}
                className="py-2 bg-blue-500/10 hover:bg-blue-500/20 active:bg-blue-500/30 text-blue-600 dark:text-blue-400 font-black text-xs rounded-lg transition-all border border-blue-500/20 dark:border-blue-500/30 cursor-pointer shadow-xs active:scale-95"
              >
                MAX
              </button>

              {/* Row 5: ., +/-, 0, Next, Done */}
              <div className="grid grid-cols-2 gap-1 col-span-1">
                <button
                  type="button"
                  onClick={() => handleKeypadPress('.')}
                  className="py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:active:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-sm rounded-lg transition-all border border-slate-200/50 dark:border-slate-700/50 cursor-pointer shadow-xs active:scale-95"
                  title="Decimal point (.)"
                >
                  .
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('+/-')}
                  className="py-2 bg-amber-500/10 hover:bg-amber-500/20 active:bg-amber-500/30 text-amber-700 dark:text-amber-300 font-black text-xs rounded-lg transition-all border border-amber-500/20 cursor-pointer shadow-xs active:scale-95"
                  title="Toggle minus sign (±)"
                >
                  ±
                </button>
              </div>
              
              <button
                type="button"
                onClick={() => handleKeypadPress('0')}
                className="py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700/80 dark:active:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-sm rounded-lg transition-all border border-slate-200/50 dark:border-slate-700/50 cursor-pointer shadow-xs active:scale-95"
              >
                0
              </button>

              <button
                type="button"
                onClick={moveToNextInput}
                className="py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-black text-xs rounded-lg transition-all border border-blue-700 cursor-pointer shadow-xs flex items-center justify-center space-x-1 active:scale-95"
                title="Next Field"
              >
                <span>NEXT</span>
                <CornerDownLeft className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setActiveInputId(null)}
                className="py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-xs rounded-lg transition-all border border-emerald-700 cursor-pointer shadow-xs flex items-center justify-center space-x-1 active:scale-95"
                title="Close Keypad"
              >
                <Check className="w-4 h-4" />
                <span>DONE</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Daily Entry Confirmation Modal */}
      {showDeleteEntryConfirm && existingEntry && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center space-x-3 text-rose-600 dark:text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-2xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-base">Delete Daily Entry</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-700/50 leading-relaxed">
              Are you sure you want to delete the daily MDM entry for <strong className="text-slate-900 dark:text-white">{formatDateReadable(selectedDate)}</strong>?
            </p>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteEntryConfirm(false)}
                className="glass-3d-btn px-4 py-2 rounded-xl text-xs font-black cursor-pointer active:scale-95"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (existingEntry) {
                    onDeleteEntry(existingEntry.id);
                    showToast('Entry deleted successfully.');
                  }
                  setShowDeleteEntryConfirm(false);
                }}
                className="btn-3d-glass-rose px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer active:scale-95"
              >
                Delete Entry
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Stock Record Confirmation Modal */}
      {deleteConfirmStockTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center space-x-3 text-rose-600 dark:text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-2xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-base">Delete Stock Record</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-700/50 leading-relaxed">
              Are you sure you want to delete the <strong className="text-slate-900 dark:text-white uppercase">{deleteConfirmStockTx.type}</strong> record of{' '}
              <strong className="text-slate-900 dark:text-white">{deleteConfirmStockTx.quantity} {commodities.find((c) => c.id === deleteConfirmStockTx.commodityId)?.unit || 'units'}</strong> of{' '}
              <strong className="text-slate-900 dark:text-white">
                {commodities.find((c) => c.id === deleteConfirmStockTx.commodityId)?.name || deleteConfirmStockTx.commodityId}
              </strong>{' '}
              on <strong className="text-slate-900 dark:text-white">{formatDateReadable(deleteConfirmStockTx.date)}</strong>?
            </p>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmStockTx(null)}
                className="glass-3d-btn px-4 py-2 rounded-xl text-xs font-black cursor-pointer active:scale-95"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteTransaction && deleteConfirmStockTx) {
                    onDeleteTransaction(deleteConfirmStockTx.id);
                    showToast('Stock transaction record deleted.');
                  }
                  setDeleteConfirmStockTx(null);
                }}
                className="btn-3d-glass-rose px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer active:scale-95"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Opening Balance Modal */}
      <OpeningBalanceModal
        isOpen={showOpeningModal}
        onClose={() => setShowOpeningModal(false)}
        commodities={commodities}
        baseCommodities={baseCommodities}
        dailyEntries={dailyEntries}
        stockTransactions={stockTransactions}
        selectedMonth={selectedDate ? selectedDate.substring(0, 7) : undefined}
        monthlyOverrides={monthlyOverrides}
        onSaveOpeningBalances={onSaveOpeningBalances}
        onSaveMonthlyBalances={onSaveMonthlyBalances}
        onResetMonthlyOverride={onResetMonthlyOverride}
      />
    </div>
  );
};

