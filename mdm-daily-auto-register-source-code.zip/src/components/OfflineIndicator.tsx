import React, { useState, useEffect } from 'react';
import { WifiOff, Wifi } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });
  const [showReconnected, setShowReconnected] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      const timer = setTimeout(() => {
        setShowReconnected(false);
      }, 3500);
      return () => clearTimeout(timer);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && !showReconnected) return null;

  if (showReconnected) {
    return (
      <div
        id="pwa-reconnected-indicator"
        className="fixed bottom-8 sm:bottom-10 left-4 z-50 flex items-center gap-2 rounded-xl bg-emerald-600/95 border border-emerald-400/50 px-3.5 py-2 text-xs font-bold text-white shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-3"
      >
        <Wifi className="w-3.5 h-3.5 stroke-[2.5]" />
        <span>Back Online • Syncing with Cloud</span>
      </div>
    );
  }

  return (
    <div
      id="pwa-offline-indicator"
      className="fixed bottom-8 sm:bottom-10 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500/95 border border-amber-300/50 px-3.5 py-2 text-xs font-bold text-slate-950 shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-3"
    >
      <span className="relative flex h-2.5 w-2.5">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-slate-900"></span>
      </span>
      <WifiOff className="w-3.5 h-3.5 stroke-[2.5]" />
      <span>Offline Mode • Registers &amp; Stock Active Locally</span>
    </div>
  );
};
