import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone, Sparkles, ShieldCheck } from 'lucide-react';

interface PWAInstallBannerProps {
  onOpenModal: () => void;
  onInstall: () => void;
  hasDeferredPrompt: boolean;
  isStandalone: boolean;
  isInstalled: boolean;
}

export const PWAInstallBanner: React.FC<PWAInstallBannerProps> = ({
  onOpenModal,
  onInstall,
  hasDeferredPrompt,
  isStandalone,
  isInstalled,
}) => {
  const [isDismissed, setIsDismissed] = useState<boolean>(true);

  useEffect(() => {
    // Check if dismissed in this session or installed
    if (isStandalone || isInstalled) {
      setIsDismissed(true);
      return;
    }

    const dismissedUntil = localStorage.getItem('mdm_pwa_banner_dismissed_until');
    if (dismissedUntil && Number(dismissedUntil) > Date.now()) {
      setIsDismissed(true);
      return;
    }

    // Delay 2 seconds so it doesn't interrupt immediate initial paint
    const timer = setTimeout(() => {
      setIsDismissed(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, [isStandalone, isInstalled]);

  if (isDismissed || isStandalone || isInstalled) {
    return null;
  }

  const handleDismiss = () => {
    setIsDismissed(true);
    // Dismiss for 24 hours
    localStorage.setItem(
      'mdm_pwa_banner_dismissed_until',
      String(Date.now() + 24 * 60 * 60 * 1000)
    );
  };

  return (
    <div
      id="pwa-install-floating-banner"
      className="fixed bottom-8 sm:bottom-10 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-40 animate-in slide-in-from-bottom-5 duration-300"
    >
      <div className="glass-3d-tile p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl border border-sky-400/50 shadow-2xl bg-gradient-to-r from-slate-900/95 via-sky-950/90 to-slate-900/95 text-white flex items-center justify-between gap-3 backdrop-blur-xl">
        {/* Left App Icon & Info */}
        <div className="flex items-center space-x-3 min-w-0">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 p-0.5 ring-1 ring-white/30 shrink-0 flex items-center justify-center overflow-hidden shadow-md">
            <img
              src="/pwa-192x192.png"
              alt="Icon"
              className="w-full h-full object-cover rounded-xl"
              onError={(e) => {
                e.currentTarget.src = '/favicon.svg';
              }}
            />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs sm:text-sm text-white truncate">
                Install MDM Daily Auto Register
              </span>
              <span className="hidden xs:inline-flex px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                PWA
              </span>
            </div>
            <p className="text-[10.5px] sm:text-xs text-sky-200/80 truncate">
              Fast 1-touch launch | 100% offline registers
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              if (hasDeferredPrompt) {
                onInstall();
              } else {
                onOpenModal();
              }
            }}
            className="px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white shadow-md shadow-sky-500/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install</span>
          </button>

          <button
            onClick={handleDismiss}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors"
            title="Dismiss for today"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
