import React, { useEffect, useState } from 'react';
import { School, Sparkles, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { SchoolProfile } from '../types';

interface SplashScreenProps {
  schoolProfile?: SchoolProfile;
  onFinish: () => void;
  isManualPreview?: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  schoolProfile,
  onFinish,
  isManualPreview = false,
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [statusText, setStatusText] = useState<string>('Initializing School Ledger...');
  const [isReady, setIsReady] = useState<boolean>(false);
  const [logoSrc, setLogoSrc] = useState<string>('/app-logo.png');

  useEffect(() => {
    const totalDuration = isManualPreview ? 2400 : 2000;
    const intervalTime = 40;
    const step = 100 / (totalDuration / intervalTime);

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + step;
        if (next >= 25 && next < 55) {
          setStatusText('Loading Daily Meal Matrices & Stock Formulas...');
        } else if (next >= 55 && next < 85) {
          setStatusText('Verifying PM-POSHAN Government Rates & Norms...');
        } else if (next >= 85 && next < 100) {
          setStatusText('Ready! Preparing School Register...');
        } else if (next >= 100) {
          clearInterval(timer);
          setIsReady(true);
          setTimeout(() => {
            onFinish();
          }, 350);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isManualPreview, onFinish]);

  const handleLogoError = () => {
    if (logoSrc === '/app-logo.png') {
      setLogoSrc('/app-logo.svg');
    } else if (logoSrc === '/app-logo.svg') {
      setLogoSrc('/pwa-512x512.png');
    }
  };

  return (
    <div
      id="mdm-flash-splash-screen"
      className="fixed inset-0 z-[99999] flex flex-col items-center justify-between bg-gradient-to-b from-slate-950 via-slate-900 to-sky-950 text-white overflow-hidden p-5 sm:p-6 select-none animate-fadeIn"
      style={{
        backgroundImage: `radial-gradient(circle at 50% 25%, rgba(2, 132, 199, 0.4) 0%, rgba(15, 23, 42, 0.96) 70%, #020617 100%)`,
      }}
    >
      {/* Background Decorative Lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-sky-500/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar / Department Branding */}
      <div className="w-full max-w-lg flex items-center justify-between z-10 pt-2">
        <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/15 shadow-sm">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span className="text-[11px] sm:text-xs font-black tracking-wider uppercase text-sky-200">
            PM-POSHAN | Government of India
          </span>
        </div>

        <button
          onClick={onFinish}
          className="text-xs font-bold text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 backdrop-blur-md px-3.5 py-1.5 rounded-full transition-all flex items-center space-x-1 active:scale-95 cursor-pointer shadow-xs"
        >
          <span>Skip</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Center Hero: App Logo Reference Art & Flash Banner */}
      <div className="flex flex-col items-center text-center my-auto z-10 max-w-md w-full py-2">
        {/* Glowing Logo Plaque */}
        <div className="relative group mb-5">
          <div className="absolute -inset-2.5 bg-gradient-to-r from-sky-400 via-amber-400 to-emerald-400 rounded-3xl blur-lg opacity-80 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt pointer-events-none" />
          
          <div className="relative w-44 h-44 sm:w-52 sm:h-52 rounded-3xl overflow-hidden shadow-2xl shadow-sky-500/50 border-2 border-white/40 bg-slate-900 flex items-center justify-center transition-transform hover:scale-105">
            <img
              src={logoSrc}
              alt="MDM Daily Auto Register App Logo"
              className="w-full h-full object-cover object-center"
              onError={handleLogoError}
              loading="eager"
            />
            {/* Shimmer overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/15 to-white/30 pointer-events-none" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-sky-100 to-sky-300 drop-shadow-md mb-1.5">
          MDM Daily Auto Register
        </h1>

        {/* Subtitle */}
        <p className="text-xs sm:text-sm font-semibold text-sky-200/90 mb-4 max-w-sm">
          Mid-Day Meal Attendance, Commodity Stock Ledger, Cash Voucher & Monthly Reports
        </p>

        {/* School Name Tag (if profile exists) */}
        {schoolProfile?.schoolName && (
          <div className="flex items-center space-x-2.5 bg-slate-800/85 border border-sky-400/35 rounded-2xl px-4 py-2 mb-4 backdrop-blur-md shadow-md max-w-xs sm:max-w-sm truncate">
            {schoolProfile.schoolPhotoUrl ? (
              <img
                src={schoolProfile.schoolPhotoUrl}
                alt="School Emblem"
                className="w-6 h-6 rounded-lg object-cover border border-amber-400/40 shrink-0"
              />
            ) : (
              <School className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <div className="text-left min-w-0">
              <div className="text-xs font-extrabold text-white truncate">
                {schoolProfile.schoolName}
              </div>
              <div className="text-[10px] text-slate-300 font-semibold">
                U-DISE: {schoolProfile.udiseCode || 'Registered'}
              </div>
            </div>
          </div>
        )}

        {/* Three Core Feature Badges */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 w-full mb-4 text-center">
          <div className="bg-sky-500/15 border border-sky-400/30 rounded-xl p-2 sm:p-2.5 backdrop-blur-md">
            <div className="text-[11px] sm:text-xs font-black text-sky-300">Daily</div>
            <div className="text-[9px] sm:text-[10px] text-slate-300 font-bold">Auto Register</div>
          </div>

          <div className="bg-amber-500/15 border border-amber-400/30 rounded-xl p-2 sm:p-2.5 backdrop-blur-md">
            <div className="text-[11px] sm:text-xs font-black text-amber-300">Cash</div>
            <div className="text-[9px] sm:text-[10px] text-slate-300 font-bold">Voucher (₹)</div>
          </div>

          <div className="bg-emerald-500/15 border border-emerald-400/30 rounded-xl p-2 sm:p-2.5 backdrop-blur-md">
            <div className="text-[11px] sm:text-xs font-black text-emerald-300">Reports</div>
            <div className="text-[9px] sm:text-[10px] text-slate-300 font-bold">& Analytics</div>
          </div>
        </div>
      </div>

      {/* Bottom Progress Bar & Loading Status */}
      <div className="w-full max-w-md flex flex-col items-center z-10 pb-2">
        <div className="w-full flex items-center justify-between text-xs font-bold text-slate-300 mb-1.5">
          <span className="flex items-center space-x-1.5 truncate">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span className="truncate">{statusText}</span>
          </span>
          <span className="text-sky-300 ml-2 font-extrabold">{Math.round(progress)}%</span>
        </div>

        {/* Progress Track */}
        <div className="w-full h-2.5 bg-slate-800/90 rounded-full overflow-hidden border border-white/10 p-0.5 shadow-inner">
          <div
            className="h-full bg-gradient-to-r from-sky-400 via-blue-500 to-emerald-400 rounded-full transition-all duration-75 shadow-sm shadow-sky-400/50"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Direct Action Button */}
        <button
          id="splash-enter-app-btn"
          onClick={onFinish}
          className="mt-4 w-full py-3 px-5 rounded-xl font-black text-sm text-slate-900 bg-gradient-to-r from-amber-300 via-sky-300 to-emerald-300 hover:from-amber-200 hover:to-emerald-200 shadow-lg shadow-sky-500/30 flex items-center justify-center space-x-2 transition-all active:scale-98 cursor-pointer ring-1 ring-white/60"
        >
          {isReady ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-800 stroke-[2.5]" />
              <span>Launch School Register</span>
            </>
          ) : (
            <>
              <span>Enter Register</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </>
          )}
        </button>

        <div className="text-[10px] text-slate-400 font-semibold mt-2.5 text-center">
          PWA Offline Capable | Auto-Calculated Formulations | PM-POSHAN Compliant
        </div>
      </div>
    </div>
  );
};
