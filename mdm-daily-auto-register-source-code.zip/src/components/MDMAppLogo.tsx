import React from 'react';

interface MDMAppLogoProps {
  size?: number | string;
  className?: string;
  rounded?: string;
  showText?: boolean;
  textClassName?: string;
  subtextClassName?: string;
  onClick?: () => void;
}

export const MDMAppLogo: React.FC<MDMAppLogoProps> = ({
  size = 48,
  className = '',
  rounded = 'rounded-2xl',
  showText = false,
  textClassName = 'text-base font-black text-slate-900 dark:text-white leading-tight',
  subtextClassName = 'text-[10px] font-bold text-sky-600 dark:text-sky-400 uppercase tracking-wider',
  onClick,
}) => {
  const pixelSize = typeof size === 'number' ? `${size}px` : size;

  return (
    <div
      className={`inline-flex items-center gap-3 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      <div
        className={`relative shrink-0 overflow-hidden shadow-lg shadow-sky-500/25 ring-2 ring-sky-400/40 dark:ring-sky-500/30 transition-transform active:scale-95 ${rounded}`}
        style={{ width: pixelSize, height: pixelSize }}
      >
        <img
          src="/app-logo.png"
          alt="MDM Daily Auto Register Logo"
          className="w-full h-full object-cover object-center"
          loading="eager"
        />
        {/* Soft highlight glare */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/25 pointer-events-none" />
      </div>

      {showText && (
        <div className="flex flex-col min-w-0">
          <div className={textClassName}>
            MDM Daily Auto Register
          </div>
          <div className={subtextClassName}>
            PM-POSHAN School Register
          </div>
        </div>
      )}
    </div>
  );
};
