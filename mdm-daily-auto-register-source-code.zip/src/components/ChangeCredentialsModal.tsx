import React, { useState } from 'react';
import {
  KeyRound,
  Phone,
  User as UserIcon,
  Lock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  X,
  RefreshCw,
} from 'lucide-react';
import {
  getStoredCredentials,
  updateLoginCredentials,
  normalizeMobileNumber,
  StoredCredentials,
  RoleCredential,
} from '../lib/storage';
import { changeCredentialsApi } from '../lib/authApi';

interface ChangeCredentialsModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRole?: 'HEADMASTER' | 'MDM_INCHARGE';
  schoolId?: string;
  onCredentialsUpdated?: (updatedCreds: StoredCredentials, targetRole: 'HEADMASTER' | 'MDM_INCHARGE') => void;
}

export const ChangeCredentialsModal: React.FC<ChangeCredentialsModalProps> = ({
  isOpen,
  onClose,
  defaultRole = 'HEADMASTER',
  schoolId,
  onCredentialsUpdated,
}) => {
  const [selectedRole, setSelectedRole] = useState<'HEADMASTER' | 'MDM_INCHARGE'>(defaultRole);

  const currentCreds = getStoredCredentials(schoolId);
  const activeRoleCred: RoleCredential = selectedRole === 'HEADMASTER' ? currentCreds.headmaster : currentCreds.incharge;

  // Form fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newUsername, setNewUsername] = useState(activeRoleCred.username || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  // Handle switching role
  const handleRoleChange = (role: 'HEADMASTER' | 'MDM_INCHARGE') => {
    setSelectedRole(role);
    const cred = role === 'HEADMASTER' ? currentCreds.headmaster : currentCreds.incharge;
    setNewUsername(cred.username);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
    setSuccessMsg(null);
  };

  // Submit Credential Updates
  const handleSaveCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    // 1. Validate Current Password (if already set)
    if (activeRoleCred.password) {
      if (!currentPassword) {
        setError('Please enter your current password to authorize setting a new password.');
        return;
      }
      if (currentPassword !== activeRoleCred.password) {
        setError('Incorrect current password. Please enter the valid existing password.');
        return;
      }
    }

    // 2. Validate New Password
    if (!newPassword || newPassword.length < 4) {
      setError('Please enter a new password (at least 4 characters).');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }

    setIsSubmitting(true);
    const finalPassword = newPassword.trim();
    const finalUsername = (newUsername.trim() || activeRoleCred.username);
    try {
      // Synchronize with backend authentication service
      changeCredentialsApi({
        schoolId,
        role: selectedRole,
        updates: {
          username: finalUsername,
          password: finalPassword,
        },
        currentPassword: currentPassword.trim(),
      }).catch((err) => {
        console.warn('Backend credential sync deferred:', err);
      });

      // Update local storage credentials
      const result = updateLoginCredentials(
        selectedRole,
        {
          username: finalUsername,
          password: finalPassword,
        },
        schoolId
      );

      if (!result.success) {
        setError(result.message);
        setIsSubmitting(false);
        return;
      }

      setSuccessMsg(
        'Password updated successfully! You can now log in using your School UDISE code and your new password.'
      );

      if (onCredentialsUpdated) {
        onCredentialsUpdated(result.updatedCreds, selectedRole);
      }

      setTimeout(() => {
        setIsSubmitting(false);
        onClose();
      }, 1200);
    } catch (err) {
      console.error(err);
      setError('Failed to update credentials. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-70 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 pb-8 sm:pb-10 md:pb-12 overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto mb-7 sm:mb-8 md:mb-10 max-h-[calc(100dvh-3.5rem)] sm:max-h-[calc(100dvh-4rem)] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-600 to-emerald-600 px-4 py-3.5 sm:px-6 sm:py-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5 sm:space-x-3">
            <div className="p-2 sm:p-2.5 bg-white/20 rounded-xl sm:rounded-2xl backdrop-blur-md">
              <KeyRound className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">Set Password</h3>
              <p className="text-[10px] sm:text-xs text-blue-100 font-medium">Set Password of Your Choice for School Profile Login</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white/90 hover:text-white cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-3.5 sm:space-y-4">
          {/* Account Role Selector */}
          <div>
            <label className="block text-[10px] sm:text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              Select Account to Update:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleRoleChange('HEADMASTER')}
                className={`px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  selectedRole === 'HEADMASTER'
                    ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-500 text-blue-700 dark:text-blue-300 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                }`}
              >
                <span>👨‍💼 Headmaster (HM)</span>
                {selectedRole === 'HEADMASTER' && <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-sky-400" />}
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange('MDM_INCHARGE')}
                className={`px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  selectedRole === 'MDM_INCHARGE'
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                }`}
              >
                <span>🧑‍🍳 MDM Incharge</span>
                {selectedRole === 'MDM_INCHARGE' && <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
              </button>
            </div>
          </div>

          {/* Current Info Strip */}
          <div className="px-3 py-2 sm:px-3.5 sm:py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <span className="font-semibold text-[10.5px] sm:text-xs">Account:</span>
              <span className="font-mono font-bold bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[10.5px] sm:text-xs text-blue-600 dark:text-sky-400">
                {selectedRole === 'HEADMASTER' ? 'Headmaster' : 'MDM Incharge'} ({activeRoleCred.username})
              </span>
            </div>
          </div>

          {/* Feedback Messages */}
          {error && (
            <div className="p-2.5 sm:p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-700 dark:text-red-300 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-2.5 sm:p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Clean & Neat Form (No OTP) */}
          <form onSubmit={handleSaveCredentials} className="space-y-3 sm:space-y-3.5">
            {/* Step 1: Current Password Authorization */}
            <div>
              <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Current Password <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
                </div>
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => {
                    setCurrentPassword(e.target.value);
                    setError(null);
                  }}
                  placeholder="Enter current password to authorize changes"
                  className="w-full pl-9 sm:pl-10 pr-9 sm:pr-10 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute inset-y-0 right-0 pr-2.5 sm:pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showCurrentPassword ? <EyeOff className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                </button>
              </div>
            </div>

            {/* New Password & Confirm Password (Only Set Password) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 pt-0.5">
              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Enter new password (your choice)"
                    className="w-full pl-9 sm:pl-10 pr-8 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Confirm New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Confirm new password"
                    className="w-full pl-9 sm:pl-10 pr-3 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2 sm:pt-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 sm:px-4 py-2 sm:py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2 sm:py-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-blue-600/25 active:scale-[0.99] transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                    <span>Saving Changes...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Save & Set Password</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
