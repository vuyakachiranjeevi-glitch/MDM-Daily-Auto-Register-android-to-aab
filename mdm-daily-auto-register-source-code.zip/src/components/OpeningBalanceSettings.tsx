import React, { useState, useMemo } from 'react';
import {
  Boxes,
  Calendar,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Package,
  Layers,
  ArrowRight,
  RefreshCw,
  Info,
} from 'lucide-react';
import { CommodityItem, DailyEntry, StockTransaction } from '../types';
import { MonthlyCommodityOverrides } from '../lib/storage';
import { calculateDailyCommodityStock, safeRound3 } from '../lib/utils';

interface OpeningBalanceSettingsProps {
  commodities: CommodityItem[];
  baseCommodities: CommodityItem[];
  dailyEntries: DailyEntry[];
  stockTransactions: StockTransaction[];
  monthlyOverrides: MonthlyCommodityOverrides;
  onSaveOpeningBalances?: (updatedCommodities: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onOpenFullModal?: () => void;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export const OpeningBalanceSettings: React.FC<OpeningBalanceSettingsProps> = ({
  commodities,
  baseCommodities,
  dailyEntries,
  stockTransactions,
  monthlyOverrides,
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  onOpenFullModal,
}) => {
  // Current selected month for OB configuration (default to current active month: August/September 2026)
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-08');
  const [viewMode, setViewMode] = useState<'month' | 'base'>('month');

  // Input states for month overrides
  const [monthInputValues, setMonthInputValues] = useState<Record<string, string>>({});
  // Input states for base initial stock
  const [baseInputValues, setBaseInputValues] = useState<Record<string, { opening: string; threshold: string }>>({});

  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  // Month list for navigation (covering current academic year)
  const academicMonths = useMemo(() => [
    '2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11', '2026-12',
    '2027-01', '2027-02', '2027-03', '2027-04',
  ], []);

  // Filter out non-ration items (Cooking Oil and Pulses) from Opening Balance Settings
  const displayedCommodities = useMemo(() => {
    return baseCommodities.filter((item) => item.id !== 'oil' && item.id !== 'pulses');
  }, [baseCommodities]);

  // Compute live day-by-day stock map
  const stockMap = useMemo(() => {
    return calculateDailyCommodityStock(
      dailyEntries,
      stockTransactions,
      baseCommodities,
      monthlyOverrides,
      academicMonths
    );
  }, [dailyEntries, stockTransactions, baseCommodities, monthlyOverrides, academicMonths]);

  // Current month stock statistics
  const currentMonthStats = useMemo(() => {
    const firstDay = `${selectedMonth}-01`;
    const daysInMonth = new Date(
      parseInt(selectedMonth.split('-')[0]),
      parseInt(selectedMonth.split('-')[1]),
      0
    ).getDate();
    const lastDay = `${selectedMonth}-${String(daysInMonth).padStart(2, '0')}`;

    const firstDayStock = stockMap[firstDay] || {};
    const lastDayStock = stockMap[lastDay] || {};

    const stats: Record<string, {
      opening: number;
      received: number;
      used: number;
      spoiled: number;
      closing: number;
      isOverridden: boolean;
      sourceDesc: string;
    }> = {};

    baseCommodities.forEach((c) => {
      const cFirst = firstDayStock[c.id];
      const cLast = lastDayStock[c.id];

      // Sum all receipts & usage across the month
      let totalRec = 0;
      let totalUsed = 0;
      let totalSpoiled = 0;

      for (let d = 1; d <= daysInMonth; d++) {
        const dateStr = `${selectedMonth}-${String(d).padStart(2, '0')}`;
        const dayStock = stockMap[dateStr]?.[c.id];
        if (dayStock) {
          totalRec += dayStock.rec || 0;
          totalUsed += dayStock.used || 0;
          totalSpoiled += dayStock.spoiled || 0;
        }
      }

      const isOverridden = Boolean(monthlyOverrides[selectedMonth]?.[c.id] !== undefined);
      const openingVal = cFirst ? cFirst.ob : c.openingBalance;
      const closingVal = cLast ? cLast.cb : openingVal + totalRec - totalUsed - totalSpoiled;

      stats[c.id] = {
        opening: safeRound3(openingVal),
        received: safeRound3(totalRec),
        used: safeRound3(totalUsed),
        spoiled: safeRound3(totalSpoiled),
        closing: safeRound3(closingVal),
        isOverridden,
        sourceDesc: cFirst?.sourceDescription || (isOverridden ? 'Manual Month Override' : 'Auto Carry-Forward'),
      };
    });

    return stats;
  }, [selectedMonth, stockMap, baseCommodities, monthlyOverrides]);

  // Sync input fields when month or commodities change
  React.useEffect(() => {
    const mInputs: Record<string, string> = {};
    baseCommodities.forEach((c) => {
      const currentVal = currentMonthStats[c.id]?.opening ?? c.openingBalance;
      mInputs[c.id] = String(currentVal);
    });
    setMonthInputValues(mInputs);

    const bInputs: Record<string, { opening: string; threshold: string }> = {};
    baseCommodities.forEach((c) => {
      bInputs[c.id] = {
        opening: String(c.openingBalance),
        threshold: String(c.minThreshold),
      };
    });
    setBaseInputValues(bInputs);
  }, [selectedMonth, currentMonthStats, baseCommodities]);

  const showFeedback = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(null), 3500);
  };

  // Month navigation helpers
  const handlePrevMonth = () => {
    const idx = academicMonths.indexOf(selectedMonth);
    if (idx > 0) setSelectedMonth(academicMonths[idx - 1]);
  };

  const handleNextMonth = () => {
    const idx = academicMonths.indexOf(selectedMonth);
    if (idx < academicMonths.length - 1) setSelectedMonth(academicMonths[idx + 1]);
  };

  const getMonthLabel = (monthStr: string) => {
    const [y, m] = monthStr.split('-');
    return `${MONTH_NAMES[parseInt(m, 10) - 1]} ${y}`;
  };

  // Save month override
  const handleSaveMonthBalances = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveMonthlyBalances) return;

    const cleanOverrides: Record<string, number> = {};
    baseCommodities.forEach((c) => {
      const raw = monthInputValues[c.id];
      const parsed = parseFloat(raw);
      cleanOverrides[c.id] = isNaN(parsed) || parsed < 0 ? 0 : safeRound3(parsed);
    });

    onSaveMonthlyBalances(selectedMonth, cleanOverrides);
    if (onSaveOpeningBalances && (selectedMonth === '2026-08' || selectedMonth.startsWith('2026-08'))) {
      const updatedBase = baseCommodities.map((c) => ({
        ...c,
        openingBalance: cleanOverrides[c.id] !== undefined ? cleanOverrides[c.id] : c.openingBalance,
      }));
      onSaveOpeningBalances(updatedBase);
    }
    showFeedback(`Opening balances for ${getMonthLabel(selectedMonth)} saved successfully!`);
  };

  // Reset month override to auto carry-forward
  const handleResetMonth = () => {
    if (!onResetMonthlyOverride) return;
    onResetMonthlyOverride(selectedMonth);
    showFeedback(`Reset ${getMonthLabel(selectedMonth)} to automatic carry-forward from previous month!`);
  };

  // Save base initial stock
  const handleSaveBaseBalances = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveOpeningBalances) return;

    const updatedBase = baseCommodities.map((c) => {
      const inputs = baseInputValues[c.id];
      const parsedOpening = inputs ? parseFloat(inputs.opening) : c.openingBalance;
      const parsedThreshold = inputs ? parseFloat(inputs.threshold) : c.minThreshold;
      return {
        ...c,
        openingBalance: isNaN(parsedOpening) || parsedOpening < 0 ? 0 : safeRound3(parsedOpening),
        minThreshold: isNaN(parsedThreshold) || parsedThreshold < 0 ? 0 : safeRound3(parsedThreshold),
      };
    });

    onSaveOpeningBalances(updatedBase);
    showFeedback('System initial base stock and reserve thresholds updated successfully!');
  };

  const handleRecalculateSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      showFeedback('Full academic year stock balances verified and synchronized.');
    }, 600);
  };

  return (
    <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs space-y-3 sm:space-y-4">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-3 pb-2.5 sm:pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2 sm:space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold shrink-0">
            <Boxes className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 sm:gap-2">
              <span>Opening Balance (OB) & Stock Ledger</span>
              <span className="text-[9px] sm:text-[10px] uppercase tracking-wider px-1.5 sm:px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-extrabold border border-emerald-200 dark:border-emerald-800">
                Verified Active
              </span>
            </h3>
            <p className="text-[10.5px] sm:text-xs text-slate-500 dark:text-slate-400">
              Configure baseline opening balances and inspect automatic month-to-month carry forwards.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="flex p-0.5 sm:p-1 bg-slate-100 dark:bg-slate-800 rounded-lg sm:rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] sm:text-xs font-bold">
            <button
              type="button"
              onClick={() => setViewMode('month')}
              className={`px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-md sm:rounded-lg transition-all cursor-pointer ${
                viewMode === 'month'
                  ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Month-wise OB
            </button>
            <button
              type="button"
              onClick={() => setViewMode('base')}
              className={`px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-md sm:rounded-lg transition-all cursor-pointer ${
                viewMode === 'base'
                  ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Initial Base Stock
            </button>
          </div>

          <button
            type="button"
            onClick={handleRecalculateSync}
            disabled={isSyncing}
            className="p-1.5 sm:p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg sm:rounded-xl transition-all cursor-pointer"
            title="Recalculate & Sync All Balances"
          >
            <RefreshCw className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isSyncing ? 'animate-spin text-amber-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Success Toast / Notification */}
      {saveSuccessMsg && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs rounded-xl font-bold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Mode 1: Month-wise Opening Balances */}
      {viewMode === 'month' && (
        <form onSubmit={handleSaveMonthBalances} className="space-y-3 sm:space-y-4">
          {/* Month Selector Strip */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 p-2 sm:p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg sm:rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto justify-between">
              <button
                type="button"
                onClick={handlePrevMonth}
                disabled={academicMonths.indexOf(selectedMonth) === 0}
                className="p-1 sm:p-1.5 rounded-md sm:rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 disabled:opacity-40 cursor-pointer text-xs"
                title="Previous Month"
              >
                <ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>

              <div className="flex items-center gap-1.5 px-2.5 py-0.5 sm:py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md sm:rounded-lg text-[11px] sm:text-xs font-bold text-slate-900 dark:text-white shadow-xs">
                <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-500" />
                <span>{getMonthLabel(selectedMonth)}</span>
              </div>

              <button
                type="button"
                onClick={handleNextMonth}
                disabled={academicMonths.indexOf(selectedMonth) === academicMonths.length - 1}
                className="p-1 sm:p-1.5 rounded-md sm:rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 disabled:opacity-40 cursor-pointer text-xs"
                title="Next Month"
              >
                <ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>
            </div>

            {/* Quick Month Selector Dropdown */}
            <div className="flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto justify-end">
              <span className="text-[10.5px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">Select Month:</span>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md sm:rounded-lg text-[11px] sm:text-xs font-bold text-slate-800 dark:text-white cursor-pointer"
              >
                {academicMonths.map((m) => (
                  <option key={m} value={m}>
                    {getMonthLabel(m)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Carry-Forward Audit Card */}
          <div className="p-2.5 sm:p-3 bg-amber-50/70 dark:bg-amber-950/20 rounded-lg sm:rounded-xl border border-amber-200/70 dark:border-amber-900/40 flex items-start gap-2 sm:gap-2.5">
            <Info className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-0.5 text-slate-700 dark:text-slate-300">
              <p className="font-bold text-[11px] sm:text-xs text-amber-900 dark:text-amber-300">
                Continuous Carry-Forward Architecture
              </p>
              <p className="text-[10px] sm:text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
                Opening balances automatically inherit from the previous day's closing balance (e.g., closing balance on <strong>August 31st</strong> becomes opening balance on <strong>September 1st</strong>). If an official opening balance audit requires a manual adjustment for this month, specify it below; otherwise, automatic carry-forward remains in effect.
              </p>
            </div>
          </div>

          {/* Commodities Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3">
            {displayedCommodities.map((item) => {
              const stat = currentMonthStats[item.id] || {
                opening: item.openingBalance,
                received: 0,
                used: 0,
                spoiled: 0,
                closing: item.openingBalance,
                isOverridden: false,
                sourceDesc: 'Auto Carry-Forward',
              };

              const isLowStock = stat.closing < item.minThreshold;

              return (
                <div
                  key={item.id}
                  className={`p-2.5 sm:p-3 rounded-lg sm:rounded-xl border transition-all ${
                    stat.isOverridden
                      ? 'bg-purple-50/40 dark:bg-purple-950/20 border-purple-200/80 dark:border-purple-800/60'
                      : 'bg-slate-50/70 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1.5 mb-2">
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <div className="w-6 h-6 rounded-md bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">
                        <Package className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      </div>
                      <div>
                        <h4 className="text-[11px] sm:text-xs font-bold text-slate-900 dark:text-white">
                          {item.name}
                        </h4>
                        <span className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-semibold">
                          Unit: {item.unit} | Safe: {item.minThreshold} {item.unit}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[9px] sm:text-[10px] font-bold px-1.5 sm:px-2 py-0.5 rounded-full border ${
                        stat.isOverridden
                          ? 'bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-700'
                          : 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-700'
                      }`}
                    >
                      {stat.isOverridden ? 'Manual Override' : 'Auto Carry-Forward'}
                    </span>
                  </div>

                  {/* Input row for Month Opening Balance */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] sm:text-[10.5px] font-bold text-slate-700 dark:text-slate-300 uppercase">
                        Month Opening Balance (OB)
                      </label>
                      <span className="text-[9.5px] text-slate-400 dark:text-slate-500 font-medium">
                        Inherited / Verified
                      </span>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={monthInputValues[item.id] ?? ''}
                        onChange={(e) =>
                          setMonthInputValues({
                            ...monthInputValues,
                            [item.id]: e.target.value,
                          })
                        }
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
                        placeholder="0"
                      />
                      <span className="absolute right-2.5 top-1.5 text-xs text-slate-400 font-bold">
                        {item.unit}
                      </span>
                    </div>
                  </div>

                  {/* Month-End Calculation Summary Live Chips */}
                  <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 grid grid-cols-3 gap-1 text-center text-[9px] sm:text-[10px]">
                    <div className="p-1 bg-white/80 dark:bg-slate-900/80 rounded-md border border-slate-200/60 dark:border-slate-800">
                      <span className="block text-slate-400 font-medium">Received</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        +{stat.received}
                      </span>
                    </div>
                    <div className="p-1 bg-white/80 dark:bg-slate-900/80 rounded-md border border-slate-200/60 dark:border-slate-800">
                      <span className="block text-slate-400 font-medium">Consumed</span>
                      <span className="font-bold text-rose-600 dark:text-rose-400">
                        -{stat.used}
                      </span>
                    </div>
                    <div className={`p-1 rounded-md border ${
                      isLowStock
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400'
                        : 'bg-white/80 dark:bg-slate-900/80 border-slate-200/60 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                    }`}>
                      <span className="block text-slate-400 font-medium">Closing (CB)</span>
                      <span className="font-extrabold">{stat.closing}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Footer */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 sm:pt-2">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={handleResetMonth}
                className="px-2.5 sm:px-3 py-1 sm:py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg font-bold text-[11px] sm:text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <RotateCcw className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                <span>Reset Month to Auto Carry-Forward</span>
              </button>

              {onOpenFullModal && (
                <button
                  type="button"
                  onClick={onOpenFullModal}
                  className="px-2.5 sm:px-3 py-1 sm:py-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/50 dark:hover:bg-blue-900/50 text-blue-700 dark:text-blue-300 rounded-lg font-bold text-[11px] sm:text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Layers className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span>Full Ledger & Physical Stock Audit</span>
                </button>
              )}
            </div>

            <button
              type="submit"
              className="px-3.5 sm:px-4 py-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white rounded-lg font-extrabold text-[11px] sm:text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Opening Balances for {getMonthLabel(selectedMonth)}</span>
            </button>
          </div>
        </form>
      )}

      {/* Mode 2: Base Initial Starting Stock */}
      {viewMode === 'base' && (
        <form onSubmit={handleSaveBaseBalances} className="space-y-3 sm:space-y-4">
          <div className="p-2.5 sm:p-3 bg-blue-50/70 dark:bg-blue-950/20 rounded-lg sm:rounded-xl border border-blue-200/70 dark:border-blue-900/40 flex items-start gap-2 sm:gap-2.5">
            <Info className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-0.5 text-slate-700 dark:text-slate-300">
              <p className="font-bold text-[11px] sm:text-xs text-blue-900 dark:text-blue-300">
                Academic Year Initial Starting Stock
              </p>
              <p className="text-[10px] sm:text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
                These represent the school's opening commodities at the commencement of the academic year. These serve as the root starting baseline from which all month-to-month balances cascade forward.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3">
            {displayedCommodities.map((item) => (
              <div
                key={item.id}
                className="p-2.5 sm:p-3 bg-slate-50/70 dark:bg-slate-800/50 rounded-lg sm:rounded-xl border border-slate-200/80 dark:border-slate-700/80 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <div className="w-6 h-6 rounded-md bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold text-xs shrink-0">
                      <Package className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    </div>
                    <div>
                      <h4 className="text-[11px] sm:text-xs font-bold text-slate-900 dark:text-white">
                        {item.name}
                      </h4>
                      <span className="text-[9.5px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-semibold">
                        Unit: {item.unit}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[9.5px] sm:text-[10px]">
                      Initial Starting OB ({item.unit})
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={baseInputValues[item.id]?.opening ?? ''}
                      onChange={(e) =>
                        setBaseInputValues({
                          ...baseInputValues,
                          [item.id]: {
                            ...baseInputValues[item.id],
                            opening: e.target.value,
                          },
                        })
                      }
                      className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md sm:rounded-lg font-bold text-xs text-slate-900 dark:text-white"
                      placeholder="0"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-0.5 text-[9.5px] sm:text-[10px]">
                      Min Reserve ({item.unit})
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={baseInputValues[item.id]?.threshold ?? ''}
                      onChange={(e) =>
                        setBaseInputValues({
                          ...baseInputValues,
                          [item.id]: {
                            ...baseInputValues[item.id],
                            threshold: e.target.value,
                          },
                        })
                      }
                      className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md sm:rounded-lg font-bold text-xs text-slate-900 dark:text-white"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end pt-1.5 sm:pt-2">
            <button
              type="submit"
              className="px-3.5 sm:px-4 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg font-extrabold text-[11px] sm:text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save System Initial Base Stock</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
