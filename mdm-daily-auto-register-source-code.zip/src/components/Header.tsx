import React from 'react';
import { SchoolProfile, User } from '../types';
import {
  Moon,
  Sun,
  School,
  LogOut,
  Calendar,
  Settings,
} from 'lucide-react';

interface HeaderProps {
  schoolProfile: SchoolProfile;
  user: User;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onLogout: () => void;
  onOpenSettings: () => void;
  showInstallButton?: boolean;
  onInstallClick?: () => void;
  onOpenFlashScreen?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  schoolProfile,
  user,
  darkMode,
  onToggleDarkMode,
  onLogout,
  onOpenSettings,
  showInstallButton,
  onInstallClick,
  onOpenFlashScreen,
}) => {
  const todayStr = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  return (
    <header className="glass-3d-tile border-b border-white/80 dark:border-slate-800/80 sticky top-0 z-30 transition-all bg-white/90 dark:bg-slate-900/95 backdrop-blur-md">
      <div
        style={{ height: '106.4375px' }}
        className="max-w-[1700px] mx-auto px-2.5 sm:px-4 lg:px-6 py-2 sm:py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-2 sm:gap-3 min-h-[54px]"
      >
        {/* Left: School Branding & Full School Information */}
        <div className="flex items-center space-x-2 sm:space-x-3 min-w-0 flex-1">
          <div
            style={{
              marginTop: '3px',
              marginLeft: '-5px',
              width: '51.828125px',
              height: '55.828125px',
              fontSize: '19.16px',
            }}
            className="rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold glass-3d-icon ring-1 ring-white/30 shrink-0 cursor-pointer shadow-sm hover:scale-105 transition-transform"
            onClick={onOpenFlashScreen}
            title="View School App Info / Splash"
          >
            {schoolProfile.schoolPhotoUrl ? (
              <img
                src={schoolProfile.schoolPhotoUrl}
                alt="School"
                className="w-full h-full rounded-xl object-cover"
              />
            ) : (
              <School className="w-6 h-6" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            {/* School Name & UDISE horizontal row */}
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5 md:gap-2">
              <button
                type="button"
                onClick={onOpenSettings}
                style={{
                  fontSize: '9.5px',
                  width: 'auto',
                  height: '28px',
                  minHeight: '24px',
                  marginLeft: '0px',
                  marginTop: '-14px',
                  paddingLeft: '6px',
                  paddingRight: '5px',
                  paddingTop: '2px',
                  paddingBottom: '2px',
                }}
                className="font-black text-left leading-tight px-1.5 sm:px-2 md:px-3 py-0.5 rounded-sm sm:rounded-md md:rounded-lg glass-3d-btn border border-sky-300/80 dark:border-sky-500/60 shadow-xs text-red-600 dark:text-red-400 font-serif text-[8.5px] sm:text-[10.5px] md:text-sm hover:scale-[1.01] active:scale-98 transition-all cursor-pointer inline-flex items-center max-w-none shrink-0"
                title={`School: ${schoolProfile.schoolName || 'Mid-Day Meal Register'} (Click to edit School Profile)`}
              >
                <span
                  style={{
                    fontSize: '15.5px',
                    paddingLeft: '-2px',
                    width: '267.765625px',
                    marginTop: '0px',
                    display: 'inline-block',
                  }}
                  className="font-serif font-black whitespace-normal sm:whitespace-nowrap break-words"
                >
                  {schoolProfile.schoolName || 'Mid-Day Meal Register'}
                </span>
              </button>

              <span
                style={{ marginLeft: '11px', fontSize: '10px', paddingTop: '0px', marginTop: '-2px' }}
                className="inline-flex items-center px-1 sm:px-1.5 md:px-2 py-0 sm:py-0.5 rounded-full font-bold bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-500/20 shrink-0 text-[7px] sm:text-[8.5px] md:text-[10.5px] shadow-2xs"
                title={`UDISE Code: ${schoolProfile.udiseCode}`}
              >
                UDISE: {schoolProfile.udiseCode}
              </span>
            </div>

            {/* Implementing Agency & Academic Year horizontal row */}
            <div style={{ fontSize: '7.5px' }} className="text-[7.5px] sm:text-[9px] md:text-xs text-slate-600 dark:text-slate-400 flex flex-wrap items-center gap-1 sm:gap-1.5 md:gap-2 mt-0.5">
              {schoolProfile.implementingAgency &&
               !/Andhra\s*Pradesh\s*Government/i.test(schoolProfile.implementingAgency) &&
               !/Government\s*of\s*Andhra\s*Pradesh/i.test(schoolProfile.implementingAgency) &&
               !/Govt\.?\s*of\s*Andhra\s*Pradesh/i.test(schoolProfile.implementingAgency) && (
                <>
                  <span
                    style={{ fontSize: '9.280001px' }}
                    className="font-semibold text-slate-700 dark:text-slate-300"
                  >
                    {schoolProfile.implementingAgency}
                  </span>
                  <span className="text-slate-300 dark:text-slate-600 hidden xs:inline">•</span>
                </>
              )}
              <span
                style={{ fontSize: '9.280001px' }}
                className="font-bold text-slate-600 dark:text-slate-400"
              >
                AY: {schoolProfile.academicYear || '2025-2026'}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Date, Headmaster Profile (Full Name), Theme Toggle & Actions (50% Decreased on Mobile) */}
        <div className="flex items-center flex-wrap gap-0.5 sm:gap-1 md:gap-2 shrink-0 justify-end">
          {/* Today Date Badge */}
          <div
            style={{ height: '27.078125px', width: '173.75px' }}
            className="hidden md:flex items-center space-x-1.5 px-2 sm:px-2.5 py-0.5 rounded-lg sm:rounded-xl glass-3d-tile text-slate-800 dark:text-slate-200 text-[10.5px] sm:text-xs font-bold border border-slate-200/80 dark:border-slate-700/80 shadow-2xs whitespace-nowrap h-7 sm:h-7.5 md:h-8"
          >
            <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-700 dark:text-blue-400 shrink-0" />
            <span style={{ fontSize: '13.280000999999999px' }}>{todayStr}</span>
          </div>

          {/* Theme Toggle Button */}
          <button
            type="button"
            id="header-theme-toggle-btn"
            onClick={onToggleDarkMode}
            title={darkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
            style={{ height: '28px', marginLeft: '2px', marginTop: '-16px', marginRight: '22px', marginBottom: '-4px', paddingTop: '-11px' }}
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg glass-3d-btn transition-all flex items-center justify-center cursor-pointer text-slate-900 dark:text-slate-100 hover:scale-105 active:scale-95 shrink-0 shadow-md border-t-2 border-l-2 border-white dark:border-sky-300"
          >
            {darkMode ? (
              <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 stroke-[2.2]" />
            ) : (
              <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-700 dark:text-indigo-200 stroke-[2.2]" />
            )}
          </button>


          {/* Full Headmaster Name & Settings Button */}
          <button
            type="button"
            onClick={onOpenSettings}
            title="Open School & Headmaster Settings"
            style={{ height: '24px', lineHeight: '5.5px', minWidth: '140px', width: '151.0625px', marginRight: '6px', marginLeft: '-1px', marginTop: '-13px' }}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-xl glass-3d-btn text-left transition-all shadow-md group cursor-pointer h-7 sm:h-8 active:scale-95 shrink-0"
          >
            <div className="flex flex-col min-w-0 leading-tight">
              <span
                style={{
                  fontSize: '10px',
                  paddingLeft: '1px',
                  marginRight: '0px',
                  width: '117.765625px',
                  maxWidth: '117.765625px',
                }}
                className="font-extrabold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-sky-300 whitespace-nowrap inline-block truncate"
              >
                {schoolProfile.headmasterName || user.name || 'Headmaster'}
              </span>
              <span style={{ fontSize: '9.5px', marginTop: '-3px' }} className="font-semibold text-slate-500 dark:text-slate-400 whitespace-nowrap">
                {user.role === 'MDM_INCHARGE' ? 'MDM Incharge' : 'Headmaster (HM)'}
              </span>
            </div>
            <Settings style={{ marginRight: '-1px' }} className="w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200 transition-colors shrink-0 ml-1" />
          </button>

          {/* Logout Button */}
          <button
            type="button"
            onClick={onLogout}
            title="Logout from Register"
            style={{ marginTop: '-8px', marginRight: '5px', marginBottom: '5px', marginLeft: '5px' }}
            className="btn-3d-glass-rose h-7 sm:h-8 px-2.5 py-1 rounded-xl font-black text-[10px] sm:text-[11px] inline-flex items-center gap-1 cursor-pointer active:scale-95 shrink-0 whitespace-nowrap"
          >
            <LogOut className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};

