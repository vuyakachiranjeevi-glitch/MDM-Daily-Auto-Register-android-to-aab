import React, { useState } from 'react';
import { CommodityItem, DailyEntry, MealRates, SchoolProfile, StockTransaction, StudentClassStrength } from '../types';
import { getStudentStrengthForMonth, getStudentStrengthForDate, getDailyClassAttendanceForDate, MonthlyCommodityOverrides, calculateMonthlyCommodityStock, getStudentStrengthUpdatesList, getStoredManualObMonths } from '../lib/storage';
import {
  formatCurrency,
  formatDateReadable,
  getFormattedDate,
  getDayDetails,
  calculateDailyCommodityStock,
  formatQtyVal,
  safeRound3,
} from '../lib/utils';
import {
  FileText,
  Printer,
  Download,
  Calendar,
  Users,
  Utensils,
  Boxes,
  Receipt,
  IndianRupee,
  Eye,
  ZoomIn,
  ZoomOut,
  X,
  Palette,
  Check,
  LogOut,
  Sun,
  Moon,
} from 'lucide-react';

export interface ReportsViewProps {
  schoolProfile: SchoolProfile;
  dailyEntries: DailyEntry[];
  studentStrengths: StudentClassStrength[];
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  mealRates: MealRates;
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  onPrintReport?: () => void;
  initialReportType?: ReportType;
  initialMonth?: string;
  onClose?: () => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

import { CashVoucherView } from './CashVoucherView';

export type ReportType = 'monthly' | 'stock' | 'cash_voucher';

export const ReportsView: React.FC<ReportsViewProps> = ({
  schoolProfile,
  dailyEntries,
  studentStrengths,
  commodities,
  baseCommodities = commodities,
  mealRates,
  stockTransactions = [],
  monthlyOverrides = {},
  onPrintReport = () => window.print(),
  initialReportType,
  initialMonth,
  onClose,
  darkMode,
  onToggleDarkMode,
}) => {
  const [activeReport, setActiveReport] = useState<ReportType>(initialReportType || 'monthly');
  const [selectedMonth, setSelectedMonth] = useState<string>(initialMonth || getFormattedDate(0).substring(0, 7));
  const [showPrintPreview, setShowPrintPreview] = useState<boolean>(false);
  const [previewZoom, setPreviewZoom] = useState<number>(100);
  const [previewOrientation, setPreviewOrientation] = useState<'landscape' | 'portrait'>('landscape');

  // Background Theme selection states
  const [bgTheme, setBgTheme] = useState<'auto' | 'glass' | 'white-slate' | 'amber' | 'emerald' | 'indigo' | 'amethyst' | 'rose'>(() => {
    const saved = localStorage.getItem('mdm_report_bg_theme');
    return (saved as any) || 'glass';
  });
  const [showThemeMenu, setShowThemeMenu] = useState<boolean>(false);
  const [freezeLeft, setFreezeLeft] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_freeze_left_columns');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const toggleFreezeLeft = () => {
    setFreezeLeft((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('mdm_freeze_left_columns', String(next));
      } catch (err) {
        console.error('Failed to save freeze left preference', err);
      }
      return next;
    });
  };

  const handleSelectTheme = (theme: 'auto' | 'glass' | 'white-slate' | 'amber' | 'emerald' | 'indigo' | 'amethyst' | 'rose') => {
    setBgTheme(theme);
    try {
      localStorage.setItem('mdm_report_bg_theme', theme);
    } catch (e) {
      console.error(e);
    }
    setShowThemeMenu(false);
  };

  const getThemeClasses = () => {
    switch (bgTheme) {
      case 'glass':
      case 'auto':
        return {
          container: "register-glass-canvas register-theme-sapphire p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-slate-950 dark:text-slate-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-sky-200/95 via-indigo-200/90 to-blue-200/95 dark:from-sky-950/90 dark:via-indigo-950/90 dark:to-blue-950/90 text-slate-950 dark:text-white backdrop-blur-md border-b-2 border-sky-400 dark:border-sky-600 font-black",
          stickyCell: "bg-sky-100/90 dark:bg-slate-850/95 backdrop-blur-md text-sky-950 dark:text-sky-100 font-extrabold",
          accentBlue: "bg-sky-100/50 text-sky-950 dark:text-sky-100 border-r border-sky-300/60 dark:border-sky-800/40 font-bold",
          accentPurple: "bg-purple-100/50 text-purple-950 dark:text-purple-100 border-r border-purple-300/60 dark:border-purple-800/40 font-bold",
          accentIndigo: "bg-indigo-100/50 text-indigo-950 dark:text-indigo-100 border-r border-indigo-300/60 dark:border-indigo-800/40 font-bold",
          accentEmerald: "bg-emerald-100/50 text-emerald-950 dark:text-emerald-100 border-r border-emerald-300/60 dark:border-emerald-800/40 font-bold",
          accentAmber: "bg-amber-100/50 text-amber-950 dark:text-amber-100 border-r border-amber-300/60 dark:border-amber-800/40 font-bold",
          accentYellow: "bg-yellow-100/50 text-yellow-950 dark:text-yellow-100 border-r border-yellow-300/60 dark:border-yellow-800/40 font-bold",
          accentOrange: "bg-orange-100/50 text-orange-950 dark:text-orange-100 border-r border-orange-300/60 dark:border-orange-800/40 font-bold",
          accentPink: "bg-red-100/50 text-red-950 dark:text-red-100 border-r border-red-300/60 dark:border-red-800/40 font-bold",
        };
      case 'white-slate':
        return {
          container: "register-glass-canvas register-theme-crystal p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-slate-950 dark:text-slate-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-slate-100 via-slate-200 to-slate-100 dark:from-slate-800 dark:via-slate-750 dark:to-slate-800 text-slate-950 dark:text-slate-50 border-b-2 border-slate-300 dark:border-slate-700 font-black",
          stickyCell: "bg-slate-100 dark:bg-slate-850 text-slate-950 dark:text-slate-50 font-extrabold",
          accentBlue: "bg-blue-50/70 dark:bg-blue-950/40 text-blue-950 dark:text-blue-100",
          accentPurple: "bg-purple-50/70 dark:bg-purple-950/40 text-purple-950 dark:text-purple-100",
          accentIndigo: "bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-100",
          accentEmerald: "bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100",
          accentAmber: "bg-amber-50/70 dark:bg-amber-950/40 text-amber-950 dark:text-amber-100",
          accentYellow: "bg-yellow-50/70 dark:bg-yellow-950/40 text-yellow-950 dark:text-yellow-100",
          accentOrange: "bg-orange-100/50 dark:bg-orange-950/40 text-orange-950 dark:text-orange-100",
          accentPink: "bg-red-50/70 dark:bg-red-950/40 text-red-950 dark:text-red-100",
        };
      case 'amber':
        return {
          container: "register-glass-canvas register-theme-amber p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-amber-950 dark:text-amber-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-amber-200/95 via-yellow-200/90 to-amber-300/95 dark:from-amber-950/90 dark:via-yellow-950/90 dark:to-amber-900/90 text-amber-950 dark:text-amber-50 border-b-2 border-amber-400 dark:border-amber-600 font-black",
          stickyCell: "bg-amber-100/90 dark:bg-amber-900/70 text-amber-950 dark:text-amber-100 font-extrabold",
          accentBlue: "bg-amber-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentPurple: "bg-amber-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentIndigo: "bg-amber-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentEmerald: "bg-emerald-100/50 dark:bg-amber-900/30 text-emerald-950 dark:text-amber-100",
          accentAmber: "bg-amber-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentYellow: "bg-yellow-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentOrange: "bg-orange-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
          accentPink: "bg-red-100/50 dark:bg-amber-900/30 text-amber-950 dark:text-amber-100",
        };
      case 'emerald':
        return {
          container: "register-glass-canvas register-theme-emerald p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-emerald-950 dark:text-emerald-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-emerald-200/95 via-teal-200/90 to-emerald-300/95 dark:from-emerald-950/90 dark:via-teal-950/90 dark:to-emerald-900/90 text-emerald-950 dark:text-emerald-50 border-b-2 border-emerald-400 dark:border-emerald-600 font-black",
          stickyCell: "bg-emerald-100/90 dark:bg-emerald-900/70 text-emerald-950 dark:text-emerald-100 font-extrabold",
          accentBlue: "bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentPurple: "bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentIndigo: "bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentEmerald: "bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentAmber: "bg-emerald-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentYellow: "bg-yellow-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentOrange: "bg-orange-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
          accentPink: "bg-red-100/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100",
        };
      case 'indigo':
        return {
          container: "register-glass-canvas register-theme-cosmic p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-indigo-950 dark:text-indigo-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-indigo-200/95 via-blue-200/90 to-indigo-300/95 dark:from-indigo-950/90 dark:via-blue-950/90 dark:to-indigo-900/90 text-indigo-950 dark:text-indigo-50 border-b-2 border-indigo-400 dark:border-indigo-600 font-black",
          stickyCell: "bg-indigo-100/90 dark:bg-indigo-900/70 text-indigo-950 dark:text-indigo-100 font-extrabold",
          accentBlue: "bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentPurple: "bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentIndigo: "bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentEmerald: "bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentAmber: "bg-indigo-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentYellow: "bg-yellow-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentOrange: "bg-orange-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
          accentPink: "bg-red-100/50 dark:bg-indigo-900/30 text-indigo-950 dark:text-indigo-100",
        };
      case 'amethyst':
        return {
          container: "register-glass-canvas register-theme-amethyst p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-purple-950 dark:text-purple-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-purple-200/95 via-fuchsia-200/90 to-purple-300/95 dark:from-purple-950/90 dark:via-fuchsia-950/90 dark:to-purple-900/90 text-purple-950 dark:text-purple-50 border-b-2 border-purple-400 dark:border-purple-600 font-black",
          stickyCell: "bg-purple-100/90 dark:bg-purple-900/70 text-purple-950 dark:text-purple-100 font-extrabold",
          accentBlue: "bg-purple-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentPurple: "bg-purple-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentIndigo: "bg-purple-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentEmerald: "bg-purple-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentAmber: "bg-purple-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentYellow: "bg-yellow-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentOrange: "bg-orange-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
          accentPink: "bg-red-100/50 dark:bg-purple-900/30 text-purple-950 dark:text-purple-100",
        };
      case 'rose':
        return {
          container: "register-glass-canvas register-theme-rose p-1.5 sm:p-2.5 md:p-3.5 space-y-2.5 sm:space-y-3.5 shadow-2xl relative overflow-hidden text-rose-950 dark:text-rose-50 transition-all duration-300",
          headerRow: "bg-gradient-to-r from-rose-200/95 via-pink-200/90 to-rose-300/95 dark:from-rose-950/90 dark:via-pink-950/90 dark:to-rose-900/90 text-rose-950 dark:text-rose-50 border-b-2 border-rose-400 dark:border-rose-600 font-black",
          stickyCell: "bg-rose-100/90 dark:bg-rose-900/70 text-rose-950 dark:text-rose-100 font-extrabold",
          accentBlue: "bg-rose-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentPurple: "bg-rose-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentIndigo: "bg-rose-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentEmerald: "bg-rose-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentAmber: "bg-rose-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentYellow: "bg-yellow-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentOrange: "bg-orange-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
          accentPink: "bg-red-100/50 dark:bg-rose-900/30 text-rose-950 dark:text-rose-100",
        };
    }
  };

  const themeCls = getThemeClasses();

  // Helper to synthesize exact Official Day-by-Day MDM Register entries for ANY month (YYYY-MM)
  const getSynthesizedEntriesForMonth = (mStr: string): DailyEntry[] => {
    const parts = mStr.split('-');
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const daysInMonth = isNaN(year) || isNaN(month) ? 30 : new Date(year, month, 0).getDate();

    const mEntriesMap = new Map<string, DailyEntry>();
    dailyEntries.forEach((e) => {
      if (e.date && e.date.startsWith(mStr)) {
        mEntriesMap.set(e.date, e);
      }
    });

    const entries: DailyEntry[] = [];
    const today = new Date();
    const curYear = today.getFullYear();
    const curMonth = String(today.getMonth() + 1).padStart(2, '0');
    const curDay = String(today.getDate()).padStart(2, '0');
    const todayStr = `${curYear}-${curMonth}-${curDay}`;

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${mStr}-${String(d).padStart(2, '0')}`;
      if (mEntriesMap.has(dateStr)) {
        entries.push(mEntriesMap.get(dateStr)!);
      } else {
        const dayInfo = getDayDetails(dateStr);
        const isSunday = dayInfo.isSunday;
        const isHoliday = dayInfo.isHoliday;

        let pAtt = 0;
        let upAtt = 0;
        let hsAtt = 0;
        let totalMeals = 0;
        let calculatedRice = 0;
        let eggUsedQty = 0;
        let chikkiUsedQty = 0;
        let ragiUsedKg = 0;
        let jaggeryUsedKg = 0;

        // Active working school days on or before today
        if (!isSunday && !isHoliday && dateStr <= todayStr) {
          const classAtt = getDailyClassAttendanceForDate ? getDailyClassAttendanceForDate(dateStr) : [];
          if (classAtt && classAtt.length > 0) {
            pAtt = classAtt
              .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

            upAtt = classAtt
              .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

            hsAtt = classAtt
              .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);
          } else {
            const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(mStr);
            pAtt = classStrengths
              .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
              .reduce((sum, s) => sum + s.total, 0);

            upAtt = classStrengths
              .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.total, 0);

            hsAtt = classStrengths
              .filter((s) => s.category === 'High School' && (!s.classLevel || !s.classLevel.match(/class\s*[6-8]/i)))
              .reduce((sum, s) => sum + s.total, 0);
          }

          totalMeals = pAtt + upAtt;

          const ricePrimaryNormKg = (mealRates?.riceNormPrimaryGrams ?? 100) / 1000;
          const riceUpperPrimaryNormKg = (mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000;
          calculatedRice = Number(((pAtt * ricePrimaryNormKg) + (upAtt * riceUpperPrimaryNormKg)).toFixed(2));

          const dayOfWeek = dayInfo.dayOfWeek;

          const eggNorm = mealRates?.eggNormQty ?? 1;
          const isEggDay = dayOfWeek >= 1 && dayOfWeek <= 5;
          eggUsedQty = isEggDay ? totalMeals * eggNorm : 0;

          const chikkiNorm = mealRates?.chikkiNormQty ?? 1;
          const isChikkiDay = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5;
          chikkiUsedQty = isChikkiDay ? totalMeals * chikkiNorm : 0;

          const ragiNormKg = (mealRates?.ragiNormGrams ?? 10) / 1000;
          const jaggeryNormKg = (mealRates?.jaggeryNormGrams ?? 10) / 1000;
          const isRagiDay = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6;
          ragiUsedKg = isRagiDay ? Number((totalMeals * ragiNormKg).toFixed(2)) : 0;
          jaggeryUsedKg = isRagiDay ? Number((totalMeals * jaggeryNormKg).toFixed(2)) : 0;
        }

        const synthEntry: DailyEntry = {
          id: `auto_${dateStr}`,
          date: dateStr,
          primaryAttendance: pAtt,
          upperPrimaryAttendance: upAtt,
          highSchoolAttendance: hsAtt,
          totalAttendance: pAtt + upAtt + hsAtt,
          mealsServed: totalMeals,
          riceUsedKg: calculatedRice,
          eggUsedQty,
          chikkiUsedQty,
          ragiUsedKg,
          jaggeryUsedKg,
          remarks: isSunday
            ? 'Sunday Holiday'
            : isHoliday
            ? (dayInfo.holidayName || 'School Holiday')
            : dateStr > todayStr
            ? 'Future Date'
            : 'All meals served properly.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        entries.push(synthEntry);
      }
    }
    return entries;
  };

  // Synthesize Day-by-Day MDM Register entries for the selected month
  const monthEntries: DailyEntry[] = getSynthesizedEntriesForMonth(selectedMonth);

  // Helper to get default academic year months from June to current month
  const getAcademicYearMonthsUpToCurrent = (): string[] => {
    const today = new Date();
    const curYear = today.getFullYear();
    const curMonth = today.getMonth() + 1; // 1 to 12
    const currentMonthStr = `${curYear}-${String(curMonth).padStart(2, '0')}`;

    // Academic year begins in June
    let startYear = curMonth >= 6 ? curYear : curYear - 1;
    if (schoolProfile?.academicYear) {
      const match = schoolProfile.academicYear.match(/^(\d{4})/);
      if (match) {
        const parsed = parseInt(match[1], 10);
        if (!isNaN(parsed) && parsed >= 2000 && parsed <= 2100) {
          startYear = parsed;
        }
      }
    }

    const months: string[] = [];
    let y = startYear;
    let m = 6; // June

    while (true) {
      const mStr = `${y}-${String(m).padStart(2, '0')}`;
      months.push(mStr);
      if (mStr >= currentMonthStr) {
        break;
      }
      m++;
      if (m > 12) {
        m = 1;
        y++;
      }
      if (y > curYear + 1 || months.length > 24) break;
    }
    return months;
  };

  // Monthwise Aggregated Data for Monthly Report
  // Default academic year June to current month in MONTHWISE CONSOLIDATED REPORT
  const academicMonths = getAcademicYearMonthsUpToCurrent();

  const monthSet = new Set<string>();
  academicMonths.forEach((m) => monthSet.add(m));

  dailyEntries.forEach((e) => {
    if (e.date && e.date.length >= 7) {
      monthSet.add(e.date.substring(0, 7));
    }
  });
  if (selectedMonth) {
    monthSet.add(selectedMonth);
  }
  const sortedMonthKeys = Array.from(monthSet).sort();

  // Collect all synthesized daily entries across all months for 100% accurate commodity stock calculation
  const allSynthesizedEntries: DailyEntry[] = [];
  sortedMonthKeys.forEach((mStr) => {
    allSynthesizedEntries.push(...getSynthesizedEntriesForMonth(mStr));
  });

  const manualObMonths = getStoredManualObMonths();

  // Day-by-day commodity stock history for daily view
  const dailyStockMap = calculateDailyCommodityStock(allSynthesizedEntries, stockTransactions, baseCommodities, monthlyOverrides, [], manualObMonths);

  const activeStudentStrengths = getStudentStrengthForMonth(selectedMonth);
  const totalStudents = activeStudentStrengths.reduce((sum, s) => sum + s.total, 0);

  // Monthwise Commodity Stock Breakdown (OB, Received, Total, Utilised, Spoiled, Balance)
  // Strictly guarantees: In MONTHWISE CONSOLIDATED REPORT, last month's closing balance strictly equals next month's opening balance for all commodities across all months.
  const monthCommodityStockMap: Record<
    string,
    Record<
      string,
      { ob: number; rec: number; total: number; used: number; spoiled: number; cb: number }
    >
  > = {};

  sortedMonthKeys.forEach((mStr, monthIdx) => {
    const prevMonthStr = monthIdx > 0 ? sortedMonthKeys[monthIdx - 1] : null;
    const isBaselineMonth = mStr === '2026-08';
    const isManual = Boolean(manualObMonths[mStr] || manualObMonths[`${mStr}-01`]);

    const mEntries = getSynthesizedEntriesForMonth(mStr);
    const stockByComm: Record<
      string,
      { ob: number; rec: number; total: number; used: number; spoiled: number; cb: number }
    > = {};

    baseCommodities.forEach((c) => {
      // 1. Calculate Utilised in month
      let used = 0;
      mEntries.forEach((e) => {
        if (e.commodityUsage && typeof e.commodityUsage[c.id] === 'number') {
          used += e.commodityUsage[c.id];
        } else {
          switch (c.id) {
            case 'rice': used += (e.riceUsedKg || 0); break;
            case 'oil': used += (e.oilUsedLitres || 0); break;
            case 'pulses': used += (e.pulsesUsedKg || 0); break;
            case 'egg': used += (e.eggUsedQty || 0); break;
            case 'chikki': used += (e.chikkiUsedQty || 0); break;
            case 'ragi': used += (e.ragiUsedKg || 0); break;
            case 'jaggery': used += (e.jaggeryUsedKg || 0); break;
            default: break;
          }
        }
      });
      used = safeRound3(used);

      // 2. Calculate Received in month
      let rec = 0;
      (stockTransactions || []).forEach((tx) => {
        if (tx.type === 'RECEIVED' && tx.date && tx.date.startsWith(mStr) && tx.commodityId === c.id) {
          rec += tx.quantity || 0;
        }
      });
      rec = safeRound3(rec);

      // 3. Calculate Spoiled in month
      let spoiled = 0;
      (stockTransactions || []).forEach((tx) => {
        if (tx.type === 'SPOILED' && tx.date && tx.date.startsWith(mStr) && tx.commodityId === c.id) {
          spoiled += tx.quantity || 0;
        }
      });
      spoiled = safeRound3(spoiled);

      // 4. Calculate Opening Balance:
      // - If explicit manual edit saved by user in Opening Balance Modal, respect manual override
      // - If baseline academic month ('2026-08'), start with baseline override or base openingBalance
      // - If previous month exists, OB is STRICTLY EQUAL to previous month's closing balance (CB)
      // - Otherwise initial opening balance or override
      let ob = 0;
      if (isManual && monthlyOverrides?.[mStr]?.[c.id] !== undefined) {
        ob = safeRound3(monthlyOverrides[mStr][c.id]);
      } else if (prevMonthStr && monthCommodityStockMap[prevMonthStr]?.[c.id]) {
        ob = safeRound3(monthCommodityStockMap[prevMonthStr][c.id].cb);
      } else if (isBaselineMonth) {
        const baseAug = monthlyOverrides?.['2026-08']?.[c.id] ?? monthlyOverrides?.['2026-08-01']?.[c.id] ?? c.openingBalance ?? 0;
        ob = safeRound3(baseAug);
      } else if (monthIdx === 0) {
        const initVal = monthlyOverrides?.[mStr]?.[c.id] ?? monthlyOverrides?.[`${mStr}-01`]?.[c.id] ?? c.openingBalance ?? 0;
        ob = safeRound3(initVal);
      } else {
        ob = safeRound3(c.openingBalance ?? 0);
      }

      const total = safeRound3(ob + rec);
      const cb = safeRound3(total - used - spoiled);

      stockByComm[c.id] = { ob, rec, total, used, spoiled, cb };
    });

    if (stockByComm['ragi'] && stockByComm['jaggery']) {
      stockByComm['jaggery'] = { ...stockByComm['ragi'] };
    }

    monthCommodityStockMap[mStr] = stockByComm;
  });

  // Filter out Cooking Oil and Pulses Dal from Monthwise Consolidated Report as requested
  const monthwiseCommodities = baseCommodities.filter(
    (c) =>
      c.id !== 'oil' &&
      c.id !== 'pulses' &&
      !c.name.toLowerCase().includes('oil') &&
      !c.name.toLowerCase().includes('pulse') &&
      !c.name.toLowerCase().includes('dal')
  );

  // Show data default academic year June to current month in MONTHWISE CONSOLIDATED REPORT (excluding March)
  const todayDateObj = new Date();
  const currentMonthStr = `${todayDateObj.getFullYear()}-${String(todayDateObj.getMonth() + 1).padStart(2, '0')}`;
  const academicStartMonth = academicMonths[0] || `${todayDateObj.getFullYear()}-06`;

  const reportMonthKeys = sortedMonthKeys.filter((mStr) => {
    const monthNum = mStr.split('-')[1];
    if (monthNum === '03') return false;
    return mStr >= academicStartMonth && mStr <= currentMonthStr;
  });

  // Commodity Summary Totals across all active report months (excluding March)
  const commodityTotals: Record<
    string,
    { firstOB: number; totalRec: number; grandTotal: number; totalUsed: number; totalSpoiled: number; finalCB: number }
  > = {};

  baseCommodities.forEach((c) => {
    let firstOB = 0;
    let totalRec = 0;
    let totalUsed = 0;
    let totalSpoiled = 0;
    let finalCB = 0;

    if (reportMonthKeys.length > 0) {
      const firstMonthKey = reportMonthKeys[0];
      const lastMonthKey = reportMonthKeys[reportMonthKeys.length - 1];

      firstOB = monthCommodityStockMap[firstMonthKey]?.[c.id]?.ob || 0;
      finalCB = monthCommodityStockMap[lastMonthKey]?.[c.id]?.cb || 0;

      reportMonthKeys.forEach((mStr) => {
        const st = monthCommodityStockMap[mStr]?.[c.id];
        if (st) {
          totalRec += st.rec;
          totalUsed += st.used;
          totalSpoiled += st.spoiled;
        }
      });
    }

    totalRec = Number(totalRec.toFixed(2));
    totalUsed = Number(totalUsed.toFixed(2));
    totalSpoiled = Number(totalSpoiled.toFixed(2));
    const grandTotal = Number((firstOB + totalRec).toFixed(2));

    commodityTotals[c.id] = {
      firstOB,
      totalRec,
      grandTotal,
      totalUsed,
      totalSpoiled,
      finalCB,
    };
  });

  // Exactly calculate monthwise consolidated summary following the Official Day-by-Day MDM Register (excluding March)
  const monthwiseData = reportMonthKeys.map((mStr) => {
    const mEntries = getSynthesizedEntriesForMonth(mStr);

    let workingDays = 0;
    let mealsServed = 0;
    let primaryAtt = 0;
    let upperPrimaryAtt = 0;
    let expenditure = 0;
    let riceUsed = 0;
    let eggUsed = 0;
    let chikkiUsed = 0;
    let ragiUsed = 0;
    let jaggeryUsed = 0;

    mEntries.forEach((e) => {
      if (e.mealsServed && e.mealsServed > 0) {
        workingDays++;
        mealsServed += e.mealsServed;
        const pAtt = e.primaryAttendance || 0;
        const upAtt = (e.upperPrimaryAttendance || 0) + (e.highSchoolAttendance || 0);
        primaryAtt += pAtt;
        upperPrimaryAtt += upAtt;

        const totalAtt = pAtt + upAtt;
        if (totalAtt > 0) {
          const scale = e.mealsServed / totalAtt;
          expenditure += ((pAtt * scale) * mealRates.primaryRatePerMeal) + ((upAtt * scale) * mealRates.upperPrimaryRatePerMeal);
        } else {
          expenditure += e.mealsServed * mealRates.primaryRatePerMeal;
        }
      }
      riceUsed += e.riceUsedKg || 0;
      eggUsed += e.eggUsedQty || 0;
      chikkiUsed += e.chikkiUsedQty || 0;
      ragiUsed += e.ragiUsedKg || 0;
      jaggeryUsed += e.jaggeryUsedKg || 0;
    });

    const monthLabel = new Date(`${mStr}-01`).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });

    return {
      monthKey: mStr,
      monthLabel,
      workingDays,
      primaryAtt,
      upperPrimaryAtt,
      totalAtt: primaryAtt + upperPrimaryAtt,
      mealsServed,
      expenditure: Number(expenditure.toFixed(2)),
      riceUsed: Number(riceUsed.toFixed(2)),
      eggUsed,
      chikkiUsed,
      ragiUsed: Number(ragiUsed.toFixed(2)),
      jaggeryUsed: Number((ragiUsed || jaggeryUsed).toFixed(2)),
      mEntries,
    };
  });

  const monthwiseTotals = monthwiseData.reduce(
    (acc, item) => ({
      workingDays: acc.workingDays + item.workingDays,
      primaryAtt: acc.primaryAtt + item.primaryAtt,
      upperPrimaryAtt: acc.upperPrimaryAtt + item.upperPrimaryAtt,
      totalAtt: acc.totalAtt + item.totalAtt,
      mealsServed: acc.mealsServed + item.mealsServed,
      expenditure: Number((acc.expenditure + item.expenditure).toFixed(2)),
      riceUsed: Number((acc.riceUsed + item.riceUsed).toFixed(2)),
      eggUsed: acc.eggUsed + item.eggUsed,
      chikkiUsed: acc.chikkiUsed + item.chikkiUsed,
      ragiUsed: Number((acc.ragiUsed + item.ragiUsed).toFixed(2)),
      jaggeryUsed: Number((acc.jaggeryUsed + item.jaggeryUsed).toFixed(2)),
    }),
    {
      workingDays: 0,
      primaryAtt: 0,
      upperPrimaryAtt: 0,
      totalAtt: 0,
      mealsServed: 0,
      expenditure: 0,
      riceUsed: 0,
      eggUsed: 0,
      chikkiUsed: 0,
      ragiUsed: 0,
      jaggeryUsed: 0,
    }
  );

  // Export CSV helper
  const exportToCSV = (filename: string, rows: (string | number)[][]) => {
    const csvContent = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
  };

  const handleExportCSV = () => {
    if (activeReport === 'monthly') {
      const rows = [
        [
          'Month',
          'Working Days',
          'Primary Attn',
          'Upper Primary Attn',
          'Total Attn',
          'Meals Served',
          'Cooking Expenditure (₹)',
          ...monthwiseCommodities.flatMap((c) => [
            `${c.name} OB (${c.unit})`,
            `${c.name} Received (${c.unit})`,
            `${c.name} Total (${c.unit})`,
            `${c.name} Utilised (${c.unit})`,
            `${c.name} Spoiled (${c.unit})`,
            `${c.name} Balance (${c.unit})`,
          ]),
        ],
        ...monthwiseData.map((m) => {
          const mStock = monthCommodityStockMap[m.monthKey] || {};
          return [
            m.monthLabel,
            m.workingDays,
            m.primaryAtt,
            m.upperPrimaryAtt,
            m.totalAtt,
            m.mealsServed,
            m.expenditure,
            ...monthwiseCommodities.flatMap((c) => {
              const st = mStock[c.id] || { ob: 0, rec: 0, total: 0, used: 0, spoiled: 0, cb: 0 };
              return [st.ob, st.rec, st.total, st.used, st.spoiled, st.cb];
            }),
          ];
        }),
        [
          'TOTAL',
          monthwiseTotals.workingDays,
          monthwiseTotals.primaryAtt,
          monthwiseTotals.upperPrimaryAtt,
          monthwiseTotals.totalAtt,
          monthwiseTotals.mealsServed,
          monthwiseTotals.expenditure,
          ...monthwiseCommodities.flatMap((c) => {
            const ct = commodityTotals[c.id] || { firstOB: 0, totalRec: 0, grandTotal: 0, totalUsed: 0, totalSpoiled: 0, finalCB: 0 };
            return [ct.firstOB, ct.totalRec, ct.grandTotal, ct.totalUsed, ct.totalSpoiled, ct.finalCB];
          }),
        ],
      ];
      exportToCSV(`MDM_Monthly_Report_Monthwise.csv`, rows);
    } else if (activeReport === 'stock') {
      const rows = [
        ['Commodity Name', 'Unit', 'Opening Balance', 'Received', 'Grand Total (OB+Rec)', 'Used', 'Spoiled', 'Closing Balance'],
        ...baseCommodities
          .filter((c) => c.id !== 'oil' && c.id !== 'pulses')
          .map((c) => {
            const st = monthCommodityStockMap[selectedMonth]?.[c.id] || {
              ob: c.openingBalance || 0,
              rec: 0,
              total: c.openingBalance || 0,
              used: 0,
              spoiled: 0,
              cb: c.openingBalance || 0,
            };
            const obPlusRec = Number((st.ob + st.rec).toFixed(2));
            return [
              c.name,
              c.unit,
              st.ob,
              st.rec,
              obPlusRec,
              st.used,
              st.spoiled,
              st.cb,
            ];
          }),
      ];
      exportToCSV(`MDM_Stock_Report_${selectedMonth}.csv`, rows);
    }
  };

  // Selected month stats for preview header
  let totalWorkingDays = 0;
  let totalMealsServed = 0;
  let totalExpenditure = 0;

  monthEntries.forEach((e) => {
    if (e.mealsServed > 0) {
      totalWorkingDays++;
      totalMealsServed += e.mealsServed;
      const dayPrimaryAtt = e.primaryAttendance || 0;
      const dayUpperPrimaryAtt = (e.upperPrimaryAttendance || 0) + (e.highSchoolAttendance || 0);
      const dayTotalAtt = dayPrimaryAtt + dayUpperPrimaryAtt;
      if (dayTotalAtt > 0) {
        const scale = e.mealsServed / dayTotalAtt;
        totalExpenditure += ((dayPrimaryAtt * scale) * mealRates.primaryRatePerMeal) + ((dayUpperPrimaryAtt * scale) * mealRates.upperPrimaryRatePerMeal);
      } else {
        totalExpenditure += e.mealsServed * mealRates.primaryRatePerMeal;
      }
    }
  });

  return (
    <div className="space-y-2 sm:space-y-2.5 pb-14 sm:pb-16 md:pb-20 lg:pb-24">
      {/* Tab Selectors & Action Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 sm:gap-3 border-b border-slate-200/60 dark:border-slate-800/60 pb-3">
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 select-none">
          {/* Month Picker Button (First) */}
          {activeReport !== 'cash_voucher' && (
            <div className="flex items-center space-x-1.5 btn-glass-month-input shrink-0 mr-1 px-2.5 py-1 rounded-lg">
              <Calendar className="w-3.5 h-3.5 text-blue-900 dark:text-blue-100 shrink-0" />
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent text-blue-950 dark:text-blue-50 font-extrabold text-[10px] sm:text-xs outline-hidden cursor-pointer"
                title="Select Report Month"
              />
            </div>
          )}

          {[
            { id: 'monthly', label: 'Monthly Report', icon: <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> },
            { id: 'stock', label: 'Stock Report', icon: <Boxes className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveReport(tab.id as ReportType)}
              className={activeReport === tab.id ? 'btn-3d-glass-tab-active' : 'btn-3d-glass-tab-inactive'}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5 md:gap-2 flex-wrap">
          {/* Action Buttons for Monthly / Stock reports */}
          {activeReport !== 'cash_voucher' && (
            <>
              {/* Freeze Left Toggle Button */}
              <button
                type="button"
                onClick={toggleFreezeLeft}
                className={`cursor-pointer active:scale-95 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center transition-all shadow-md h-8 sm:h-9 ${
                  freezeLeft
                    ? 'btn-3d-glass-amber !text-amber-950 dark:!text-amber-50'
                    : 'glass-3d-btn text-slate-700 dark:text-slate-200'
                }`}
                title={freezeLeft ? 'Freeze is ON (Click to turn OFF)' : 'Freeze is OFF (Click to turn ON)'}
              >
                <span>Freeze: <strong className="uppercase">{freezeLeft ? 'ON' : 'OFF'}</strong></span>
              </button>

              <button
                type="button"
                onClick={handleExportCSV}
                className="btn-glass-csv cursor-pointer active:scale-95 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center gap-1.5 h-8 sm:h-9"
                title="Export report as CSV spreadsheet"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>Export CSV</span>
              </button>

              <button
                type="button"
                onClick={onPrintReport || (() => window.print())}
                className="btn-glass-print cursor-pointer active:scale-95 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center gap-1.5 h-8 sm:h-9"
                title="Print Report"
              >
                <Printer className="w-3.5 h-3.5 shrink-0" />
                <span>Print</span>
              </button>
            </>
          )}

          {/* Exit Button in Top-Right Corner */}
          <button
            type="button"
            onClick={() => {
              if (onClose) {
                onClose();
              } else if (typeof window !== 'undefined' && window.history.length > 1) {
                window.history.back();
              }
            }}
            className="btn-3d-glass-rose cursor-pointer active:scale-95 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center gap-1.5 h-8 sm:h-9"
            title="Exit Reports & Return to Dashboard"
            aria-label="Exit Reports"
          >
            <LogOut className="w-3.5 h-3.5 shrink-0" />
            <span>Exit</span>
          </button>
        </div>
      </div>

      {/* Report Content Container */}
      {activeReport === 'cash_voucher' ? (
        <CashVoucherView
          schoolProfile={schoolProfile}
          dailyEntries={dailyEntries}
          mealRates={mealRates}
          commodities={commodities}
          baseCommodities={baseCommodities}
          stockTransactions={stockTransactions}
          monthlyOverrides={monthlyOverrides}
          studentStrengths={studentStrengths}
          onPrintVoucher={onPrintReport || (() => {})}
          onClose={onClose}
          darkMode={darkMode}
          onToggleDarkMode={onToggleDarkMode}
        />
      ) : (
        <div id="printable-report" className={`${themeCls.container}`}>
        {/* Report Title Banner */}
        <div style={{ height: '54.78125px' }} className="border-b border-slate-200 dark:border-slate-800 pb-4 text-center sm:text-left flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h3 style={{ textAlign: 'left', fontSize: '12.920002px' }} className="text-lg font-black text-slate-950 dark:text-white uppercase tracking-tight">
              {schoolProfile.schoolName} — {activeReport === 'monthly' ? 'MONTHWISE CONSOLIDATED REPORT' : `${activeReport.toUpperCase()} REPORT`}
            </h3>
            <p style={{ fontSize: '12.280001px' }} className="text-xs text-slate-700 dark:text-slate-300 font-bold mt-1">
              UDISE Code: {schoolProfile.udiseCode} | Headmaster: {schoolProfile.headmasterName} {activeReport !== 'monthly' ? `| Month: ${selectedMonth}` : '| Monthwise Data'}
            </p>
          </div>
        </div>

        {/* Mobile Swipe Hint */}
        <div className="sm:hidden flex items-center justify-between px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200/80 dark:border-sky-800/50 text-sky-900 dark:text-sky-200 text-[11px] font-bold shadow-2xs">
          <span className="flex items-center gap-1.5">
            <span>↔</span> Swipe horizontally to inspect all columns
          </span>
          <span className="text-[10px] bg-sky-200/60 dark:bg-sky-800/60 text-sky-950 dark:text-sky-100 px-2 py-0.5 rounded-full font-mono font-black">
            Responsive
          </span>
        </div>

        {/* Dynamic Report View */}
        {activeReport === 'monthly' ? (
          /* MONTHWISE REPORT TABLE */
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 touch-pan-x overscroll-x-contain">
            <table className="w-full text-left border-collapse text-[13px]">
              <thead>
                <tr className="bg-slate-100/90 dark:bg-slate-800 text-slate-950 dark:text-slate-50 font-black border-b border-slate-300 dark:border-slate-700 text-[12.5px] uppercase tracking-wider">
                  <th rowSpan={2} style={{ height: '72.78125px' }} className={`${freezeLeft ? 'sticky left-0 z-30 shadow-[2px_0_6px_-2px_rgba(0,0,0,0.08)]' : ''} bg-slate-100 dark:bg-slate-800 p-2 border-r border-slate-300 dark:border-slate-700 min-w-[105px]`}>Month</th>
                  <th rowSpan={2} className="p-2 text-center border-r border-slate-300 dark:border-slate-700">Working Days</th>
                  <th colSpan={3} className="p-2 text-center border-r border-slate-300 dark:border-slate-700 bg-sky-100/70 dark:bg-sky-950/60 text-sky-950 dark:text-sky-100 font-black">Attendance</th>
                  <th rowSpan={2} className="p-2 text-center border-r border-slate-300 dark:border-slate-700 bg-emerald-100/70 dark:bg-emerald-950/60 text-emerald-950 dark:text-emerald-200 font-black">Meals Served</th>
                  <th rowSpan={2} className="p-2 text-right border-r border-slate-300 dark:border-slate-700 bg-indigo-100/70 dark:bg-indigo-950/60 text-indigo-950 dark:text-indigo-200 font-black min-w-[105px]">Cooking Cost (₹)</th>
                  {monthwiseCommodities.map((c) => (
                    <th key={c.id} colSpan={6} className="p-2 text-center border-r border-slate-300 dark:border-slate-700 font-black uppercase bg-slate-200/80 dark:bg-slate-700 text-slate-900 dark:text-slate-100">
                      {c.name} ({c.unit})
                    </th>
                  ))}
                </tr>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-950 dark:text-slate-50 font-black border-b border-slate-300 dark:border-slate-700 text-[11.5px] uppercase">
                  <th className="p-1.5 text-center border-r border-slate-300 dark:border-slate-700 bg-sky-50 dark:bg-sky-950/40">Pri</th>
                  <th className="p-1.5 text-center border-r border-slate-300 dark:border-slate-700 bg-sky-50 dark:bg-sky-950/40">Up.Pri</th>
                  <th className="p-1.5 text-center border-r border-slate-300 dark:border-slate-700 bg-sky-50 dark:bg-sky-950/40 font-black text-slate-950 dark:text-white">Total</th>
                  {monthwiseCommodities.map((c) => (
                    <React.Fragment key={`sub_${c.id}`}>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200 font-black">OB</th>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-emerald-50/50 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-200 font-black">Received</th>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-amber-50/50 dark:bg-amber-950/30 text-amber-950 dark:text-amber-200 font-black">Total</th>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-blue-50/50 dark:bg-blue-950/30 text-blue-950 dark:text-blue-100 font-black">Utilised</th>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-rose-50/50 dark:bg-rose-950/30 text-red-950 dark:text-red-200 font-black">Spoiled</th>
                      <th className="p-1.5 text-right border-r border-slate-200 dark:border-slate-700 bg-cyan-50/50 dark:bg-cyan-950/30 text-cyan-950 dark:text-cyan-200 font-black">Balance</th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {monthwiseData.map((m) => {
                  const mStock = monthCommodityStockMap[m.monthKey] || {};
                  return (
                    <tr key={m.monthKey} className="odd:bg-white even:bg-slate-50/60 dark:odd:bg-slate-900 dark:even:bg-slate-850 hover:bg-sky-50/70 dark:hover:bg-slate-800/80 transition-colors text-slate-950 dark:text-slate-50 font-black text-[12.5px]">
                      <td className={`${freezeLeft ? 'sticky left-0 z-20 shadow-[2px_0_6px_-2px_rgba(0,0,0,0.06)]' : ''} bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs p-2 font-black text-slate-950 dark:text-white border-r border-slate-200 dark:border-slate-800 whitespace-nowrap`}>
                        <span>{m.monthLabel}</span>
                      </td>
                      <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-slate-950 dark:text-white">{m.workingDays} Days</td>
                      <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800">{m.primaryAtt}</td>
                      <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800">{m.upperPrimaryAtt}</td>
                      <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-slate-950 dark:text-white">{m.totalAtt}</td>
                      <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-emerald-800 dark:text-emerald-300">{m.mealsServed}</td>
                      <td className="p-2 text-right font-mono font-black text-indigo-950 dark:text-indigo-200 border-r border-slate-100 dark:border-slate-800 whitespace-nowrap">₹{m.expenditure.toFixed(2)}</td>
                      {monthwiseCommodities.map((c) => {
                        const st = mStock[c.id] || { ob: 0, rec: 0, total: 0, used: 0, spoiled: 0, cb: 0 };
                        return (
                          <React.Fragment key={`val_${m.monthKey}_${c.id}`}>
                            <td className="p-2 text-right font-mono text-indigo-950 dark:text-indigo-200 font-black border-r border-slate-100 dark:border-slate-800">{formatQtyVal(st.ob)}</td>
                            <td className="p-2 text-right font-mono text-emerald-950 dark:text-emerald-200 font-black border-r border-slate-100 dark:border-slate-800">{st.rec > 0 ? `+${formatQtyVal(st.rec)}` : '-'}</td>
                            <td className="p-2 text-right font-mono text-amber-950 dark:text-amber-200 font-black border-r border-slate-100 dark:border-slate-800">{formatQtyVal(st.total)}</td>
                            <td className="p-2 text-right font-mono text-blue-950 dark:text-blue-100 font-black border-r border-slate-100 dark:border-slate-800">{st.used > 0 ? formatQtyVal(st.used) : '-'}</td>
                            <td className="p-2 text-right font-mono text-red-950 dark:text-red-200 font-black border-r border-slate-100 dark:border-slate-800">{st.spoiled > 0 ? formatQtyVal(st.spoiled) : '-'}</td>
                            <td className="p-2 text-right font-mono font-black text-cyan-950 dark:text-cyan-200 border-r border-slate-100 dark:border-slate-800">{formatQtyVal(st.cb)}</td>
                          </React.Fragment>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100/90 dark:bg-slate-800 font-black text-slate-900 dark:text-white border-t-2 border-slate-300 dark:border-slate-700 text-[11px]">
                  <td className={`${freezeLeft ? 'sticky left-0 z-20 shadow-[2px_0_6px_-2px_rgba(0,0,0,0.06)]' : ''} bg-slate-100/95 dark:bg-slate-800/95 p-2 uppercase border-r border-slate-200 dark:border-slate-700 whitespace-nowrap`}>Total / Summary</td>
                  <td className="p-2 text-center border-r border-slate-200 dark:border-slate-700">{monthwiseTotals.workingDays} Days</td>
                  <td className="p-2 text-center border-r border-slate-200 dark:border-slate-700">{monthwiseTotals.primaryAtt}</td>
                  <td className="p-2 text-center border-r border-slate-200 dark:border-slate-700">{monthwiseTotals.upperPrimaryAtt}</td>
                  <td className="p-2 text-center border-r border-slate-200 dark:border-slate-700">{monthwiseTotals.totalAtt}</td>
                  <td className="p-2 text-center border-r border-slate-200 dark:border-slate-700 text-emerald-600 dark:text-emerald-400">{monthwiseTotals.mealsServed}</td>
                  <td className="p-2 text-right font-mono text-indigo-600 dark:text-indigo-400 border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">₹{monthwiseTotals.expenditure.toFixed(2)}</td>
                  {monthwiseCommodities.map((c) => {
                    const ct = commodityTotals[c.id] || { firstOB: 0, totalRec: 0, grandTotal: 0, totalUsed: 0, totalSpoiled: 0, finalCB: 0 };
                    return (
                      <React.Fragment key={`tot_${c.id}`}>
                        <td className="p-2 text-right font-mono text-indigo-600 dark:text-indigo-400 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(ct.firstOB)}</td>
                        <td className="p-2 text-right font-mono text-emerald-600 border-r border-slate-200 dark:border-slate-700">{ct.totalRec > 0 ? `+${formatQtyVal(ct.totalRec)}` : '-'}</td>
                        <td className="p-2 text-right font-mono text-amber-600 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(ct.grandTotal)}</td>
                        <td className="p-2 text-right font-mono text-blue-600 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(ct.totalUsed)}</td>
                        <td className="p-2 text-right font-mono text-rose-500 border-r border-slate-200 dark:border-slate-700">{ct.totalSpoiled > 0 ? formatQtyVal(ct.totalSpoiled) : '-'}</td>
                        <td className="p-2 text-right font-mono text-cyan-700 dark:text-cyan-400 border-r border-slate-200 dark:border-slate-700">{formatQtyVal(ct.finalCB)}</td>
                      </React.Fragment>
                    );
                  })}
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          /* STOCK REPORT TABLE */
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 touch-pan-x overscroll-x-contain">
            <table className="w-full text-left border-collapse text-[13.5px]">
              <thead>
                <tr className="bg-slate-100/90 dark:bg-slate-800 text-slate-950 dark:text-slate-50 font-black border-b border-slate-300 dark:border-slate-700 uppercase tracking-wider text-[12.5px]">
                  <th className={`${freezeLeft ? 'sticky left-0 z-30 shadow-[2px_0_6px_-2px_rgba(0,0,0,0.08)]' : ''} bg-slate-100 dark:bg-slate-800 p-3 min-w-[130px] border-r border-slate-300 dark:border-slate-700`}>Commodity</th>
                  <th className="p-3 text-center">Unit</th>
                  <th className="p-3 text-right bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200">Opening Balance</th>
                  <th className="p-3 text-right bg-emerald-50/50 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-200">Total Received</th>
                  <th className="p-3 text-right bg-amber-50/50 dark:bg-amber-950/30 text-amber-950 dark:text-amber-200 font-black">Grand Total (OB+Rec)</th>
                  <th className="p-3 text-right bg-blue-50/50 dark:bg-blue-950/30 text-blue-950 dark:text-blue-100">Total Used</th>
                  <th className="p-3 text-right bg-rose-50/50 dark:bg-rose-950/30 text-red-950 dark:text-red-200">Total Spoiled</th>
                  <th className="p-3 text-right bg-cyan-50/50 dark:bg-cyan-950/30 font-black text-cyan-950 dark:text-cyan-200">Closing Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {baseCommodities
                  .filter((c) => c.id !== 'oil' && c.id !== 'pulses')
                  .map((c) => {
                    const st = monthCommodityStockMap[selectedMonth]?.[c.id] || {
                      ob: c.openingBalance || 0,
                      rec: 0,
                      total: c.openingBalance || 0,
                      used: 0,
                      spoiled: 0,
                      cb: c.openingBalance || 0,
                    };
                    const obPlusRec = Number((st.ob + st.rec).toFixed(2));
                    return (
                      <tr key={c.id} className="odd:bg-white even:bg-slate-50/60 dark:odd:bg-slate-900 dark:even:bg-slate-850 text-slate-950 dark:text-slate-50 font-black hover:bg-sky-50/70 dark:hover:bg-slate-800/60 text-[13.5px] transition-colors">
                        <td className={`${freezeLeft ? 'sticky left-0 z-20 shadow-[2px_0_6px_-2px_rgba(0,0,0,0.06)]' : ''} bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs p-3 font-black text-slate-950 dark:text-white border-r border-slate-200 dark:border-slate-800`}>{c.name}</td>
                        <td className="p-3 text-center">{c.unit}</td>
                        <td className="p-3 text-right">{formatQtyVal(st.ob)}</td>
                        <td className="p-3 text-right text-emerald-950 dark:text-emerald-200">+{formatQtyVal(st.rec)}</td>
                        <td className="p-3 text-right text-amber-950 dark:text-amber-200 font-black">{formatQtyVal(obPlusRec)}</td>
                        <td className="p-3 text-right text-blue-950 dark:text-blue-100">-{formatQtyVal(st.used)}</td>
                        <td className="p-3 text-right text-red-950 dark:text-red-200">-{formatQtyVal(st.spoiled)}</td>
                        <td className="p-3 text-right font-black text-[14.5px] text-cyan-950 dark:text-cyan-200">{formatQtyVal(st.cb)}</td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        )}

        {/* Reserved Clean Bottom Clearance Space for Ads in Monthly & Stock Reports */}
        <div
          id="report-bottom-ad-clearance-spacer"
          className="no-print w-full h-14 sm:h-16 md:h-20 lg:h-24 shrink-0 pointer-events-none select-none transition-all duration-300"
          style={{ minHeight: 'calc(3.84rem + env(safe-area-inset-bottom, 0px))' }}
          aria-hidden="true"
        />
      </div>
      )}

      {/* Interactive Report Print Preview Modal */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 text-slate-100 overflow-hidden animate-fade-in no-print font-sans">
          {/* Top Control Bar */}
          <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0 shadow-xl relative z-20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl text-white shadow-md">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="text-sm font-black uppercase tracking-wider text-white">
                    Official Report Print Preview
                  </h3>
                  <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                    {activeReport.toUpperCase()} REPORT ({previewOrientation.toUpperCase()})
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-medium">
                  {schoolProfile.schoolName} (UDISE: {schoolProfile.udiseCode}) {activeReport !== 'monthly' ? `— Month: ${selectedMonth}` : '— Monthwise Summary'}
                </p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center flex-wrap gap-2 sm:gap-3 bg-slate-950/60 p-1.5 rounded-xl border border-slate-800">
              <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
                <button
                  onClick={() => setPreviewOrientation('landscape')}
                  className={previewOrientation === 'landscape' ? 'btn-3d-glass-pill-active' : 'btn-3d-glass-pill-inactive'}
                >
                  A4 Landscape
                </button>
                <button
                  onClick={() => setPreviewOrientation('portrait')}
                  className={previewOrientation === 'portrait' ? 'btn-3d-glass-pill-active' : 'btn-3d-glass-pill-inactive'}
                >
                  A4 Portrait
                </button>
              </div>

              <div className="flex items-center space-x-1 border-l border-slate-800 pl-2">
                <button
                  onClick={() => setPreviewZoom((z) => Math.max(50, z - 10))}
                  className="btn-3d-glass-zoom p-1.5"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="text-xs font-mono font-bold text-sky-400 px-1.5 min-w-[42px] text-center">
                  {previewZoom}%
                </span>
                <button
                  onClick={() => setPreviewZoom((z) => Math.min(150, z + 10))}
                  className="btn-3d-glass-zoom p-1.5"
                  title="Zoom In"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setPreviewZoom(100)}
                  className={previewZoom === 100 ? 'btn-3d-glass-zoom-active text-[10px]' : 'btn-3d-glass-zoom text-[10px]'}
                >
                  100%
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  onPrintReport();
                }}
                className="btn-3d-glass-purple"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / Save PDF Now</span>
              </button>

              <button
                onClick={() => setShowPrintPreview(false)}
                className="btn-3d-glass-rose p-1.5"
                title="Close Preview"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Paper Canvas */}
          <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center items-start bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] bg-slate-950/80">
            <div
              style={{
                width: previewOrientation === 'landscape' ? '1122.5px' : '793.7px',
                minHeight: previewOrientation === 'landscape' ? '793.7px' : '1122.5px',
                aspectRatio: previewOrientation === 'landscape' ? '297 / 210' : '210 / 297',
                transform: `scale(${previewZoom / 100})`,
                transformOrigin: 'top center',
              }}
              className="bg-white text-slate-900 shadow-[0_20px_60px_rgba(0,0,0,0.7)] rounded-xs p-6 sm:p-8 border border-slate-300 font-sans transition-all my-2 relative"
            >
              <div className="border-b-2 border-slate-900 pb-3 mb-4 flex justify-between items-start">
                <div>
                  <h1 className="text-xs font-black uppercase tracking-wider text-slate-800">
                    SCHOOL EDUCATION DEPARTMENT
                  </h1>
                  <h2 className="text-base font-black text-blue-950 uppercase mt-0.5 tracking-tight">
                    {activeReport === 'monthly' ? 'MONTHWISE CONSOLIDATED MDM REPORT' : `${activeReport.toUpperCase()} REPORT — ${selectedMonth}`}
                  </h2>
                  <p className="text-xs font-bold text-slate-700 mt-1">
                    School: {schoolProfile.schoolName} | UDISE Code: {schoolProfile.udiseCode}
                  </p>
                </div>
                <div className="text-right text-[10px] font-bold border-l-2 border-blue-900 pl-3">
                  <div>Date Generated: {new Date().toLocaleDateString()}</div>
                  <div>Report Type: {activeReport.toUpperCase()}</div>
                </div>
              </div>

              {/* Summary Stats Cards */}
              <div className="grid grid-cols-3 gap-3 mb-4 text-[11px] font-bold">
                <div className="bg-slate-100 p-2.5 rounded border border-slate-300">
                  <span className="text-slate-500 block text-[9px] uppercase">Working Days</span>
                  <span className="text-sm font-black text-slate-900">
                    {activeReport === 'monthly' ? `${monthwiseTotals.workingDays} Days` : `${totalWorkingDays} Days`}
                  </span>
                </div>
                <div className="bg-slate-100 p-2.5 rounded border border-slate-300">
                  <span className="text-slate-500 block text-[9px] uppercase">Meals Served</span>
                  <span className="text-sm font-black text-emerald-700">
                    {activeReport === 'monthly' ? `${monthwiseTotals.mealsServed} Meals` : `${totalMealsServed} Meals`}
                  </span>
                </div>
                <div className="bg-slate-100 p-2.5 rounded border border-slate-300">
                  <span className="text-slate-500 block text-[9px] uppercase">Total Cost</span>
                  <span className="text-sm font-black text-purple-900">
                    {activeReport === 'monthly' ? formatCurrency(monthwiseTotals.expenditure) : formatCurrency(totalExpenditure)}
                  </span>
                </div>
              </div>

              {activeReport === 'monthly' ? (
                /* Monthwise Preview Table */
                <table className="w-full text-left border-collapse text-[9px] mb-4">
                  <thead>
                    <tr className="bg-slate-200 text-slate-900 font-extrabold border-b border-slate-400">
                      <th rowSpan={2} className="p-1 border-r border-slate-300">Month</th>
                      <th rowSpan={2} className="p-1 text-center border-r border-slate-300">Working Days</th>
                      <th rowSpan={2} className="p-1 text-center border-r border-slate-300">Total Attn</th>
                      <th rowSpan={2} className="p-1 text-center border-r border-slate-300">Meals Served</th>
                      <th rowSpan={2} className="p-1 text-right border-r border-slate-300">Cooking Cost (₹)</th>
                      {monthwiseCommodities.map((c) => (
                        <th key={`prn_${c.id}`} colSpan={6} className="p-1 text-center border-r border-slate-300 uppercase font-black bg-slate-300/50">
                          {c.name} ({c.unit})
                        </th>
                      ))}
                    </tr>
                    <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300 text-[8.5px] uppercase">
                      {monthwiseCommodities.map((c) => (
                        <React.Fragment key={`prn_sub_${c.id}`}>
                          <th className="p-0.5 text-right border-r border-slate-300">OB</th>
                          <th className="p-0.5 text-right border-r border-slate-300">Rec</th>
                          <th className="p-0.5 text-right border-r border-slate-300">Tot</th>
                          <th className="p-0.5 text-right border-r border-slate-300">Used</th>
                          <th className="p-0.5 text-right border-r border-slate-300">Spoil</th>
                          <th className="p-0.5 text-right border-r border-slate-300">Bal</th>
                        </React.Fragment>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {monthwiseData.map((m) => {
                      const mStock = monthCommodityStockMap[m.monthKey] || {};
                      return (
                        <tr key={`prn_row_${m.monthKey}`}>
                          <td className="p-1 font-bold border-r border-slate-200 whitespace-nowrap">{m.monthLabel}</td>
                          <td className="p-1 text-center border-r border-slate-200">{m.workingDays}</td>
                          <td className="p-1 text-center border-r border-slate-200">{m.totalAtt}</td>
                          <td className="p-1 text-center font-bold border-r border-slate-200">{m.mealsServed}</td>
                          <td className="p-1 text-right font-mono font-bold border-r border-slate-200">₹{m.expenditure.toFixed(2)}</td>
                          {monthwiseCommodities.map((c) => {
                            const st = mStock[c.id] || { ob: 0, rec: 0, total: 0, used: 0, spoiled: 0, cb: 0 };
                            return (
                              <React.Fragment key={`prn_val_${m.monthKey}_${c.id}`}>
                                <td className="p-0.5 text-right font-mono border-r border-slate-200">{formatQtyVal(st.ob)}</td>
                                <td className="p-0.5 text-right font-mono border-r border-slate-200">{st.rec > 0 ? `+${formatQtyVal(st.rec)}` : '-'}</td>
                                <td className="p-0.5 text-right font-mono border-r border-slate-200">{formatQtyVal(st.total)}</td>
                                <td className="p-0.5 text-right font-mono border-r border-slate-200">{st.used > 0 ? formatQtyVal(st.used) : '-'}</td>
                                <td className="p-0.5 text-right font-mono border-r border-slate-200">{st.spoiled > 0 ? formatQtyVal(st.spoiled) : '-'}</td>
                                <td className="p-0.5 text-right font-mono font-bold border-r border-slate-200">{formatQtyVal(st.cb)}</td>
                              </React.Fragment>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-200 font-black border-t-2 border-slate-400 text-[9px]">
                      <td className="p-1 uppercase">TOTAL</td>
                      <td className="p-1 text-center">{monthwiseTotals.workingDays}</td>
                      <td className="p-1 text-center">{monthwiseTotals.totalAtt}</td>
                      <td className="p-1 text-center">{monthwiseTotals.mealsServed}</td>
                      <td className="p-1 text-right font-mono">₹{monthwiseTotals.expenditure.toFixed(2)}</td>
                      {monthwiseCommodities.map((c) => {
                        const ct = commodityTotals[c.id] || { firstOB: 0, totalRec: 0, grandTotal: 0, totalUsed: 0, totalSpoiled: 0, finalCB: 0 };
                        return (
                          <React.Fragment key={`prn_tot_${c.id}`}>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{formatQtyVal(ct.firstOB)}</td>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{ct.totalRec > 0 ? `+${formatQtyVal(ct.totalRec)}` : '-'}</td>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{formatQtyVal(ct.grandTotal)}</td>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{formatQtyVal(ct.totalUsed)}</td>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{ct.totalSpoiled > 0 ? formatQtyVal(ct.totalSpoiled) : '-'}</td>
                            <td className="p-0.5 text-right font-mono border-r border-slate-300">{formatQtyVal(ct.finalCB)}</td>
                          </React.Fragment>
                        );
                      })}
                    </tr>
                  </tfoot>
                </table>
              ) : (
                /* Notice for other views */
                <p className="text-[10px] italic text-slate-600 mb-3">
                  Note: This is an official preview of the consolidated {activeReport} data for {schoolProfile.schoolName}.
                </p>
              )}

              {/* Signatures */}
              <div className="pt-8 mt-8 border-t-2 border-slate-900 font-bold text-[10px]">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="border-t border-slate-900 w-3/4 mx-auto mb-1"></div>
                    <div>MDM Teacher Incharge</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-900 w-3/4 mx-auto mb-1"></div>
                    <div>Headmaster / Principal</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-900 w-3/4 mx-auto mb-1"></div>
                    <div>MEO / Inspecting Officer</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
