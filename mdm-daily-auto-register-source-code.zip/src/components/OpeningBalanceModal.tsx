import React, { useState, useEffect } from 'react';
import { CommodityItem, DailyEntry, StockTransaction } from '../types';
import {
  calculateMonthlyCommodityStock,
  MonthlyCommodityOverrides,
  saveStoredCommodities,
  saveStoredMonthlyCommodityBalances,
  saveStoredManualObMonth,
} from '../lib/storage';
import { safeRound3 } from '../lib/utils';
import {
  Package,
  Save,
  X,
  RotateCcw,
  CheckCircle2,
  Wheat,
  Egg,
  Cookie,
  Flame,
  Sparkles,
  Calendar,
  Info,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  RefreshCw,
  Droplet,
  Soup,
  Boxes,
} from 'lucide-react';

interface OpeningBalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  commodities: CommodityItem[];
  baseCommodities: CommodityItem[];
  dailyEntries?: DailyEntry[];
  stockTransactions?: StockTransaction[];
  selectedMonth?: string; // e.g. "2026-08"
  monthlyOverrides?: MonthlyCommodityOverrides;
  onSaveOpeningBalances?: (updatedCommodities: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
}

export const OpeningBalanceModal: React.FC<OpeningBalanceModalProps> = ({
  isOpen,
  onClose,
  commodities,
  baseCommodities,
  dailyEntries = [],
  stockTransactions = [],
  selectedMonth,
  monthlyOverrides = {},
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
}) => {
  // Currently active month in the modal selector
  const [modalMonth, setModalMonth] = useState<string>(
    selectedMonth || new Date().toISOString().substring(0, 7)
  );
  const [isSavedSuccess, setIsSavedSuccess] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  // Track raw input values as strings to allow typing minus signs and decimals comfortably
  const [rawInputs, setRawInputs] = useState<Record<string, { opening: string; closing: string }>>({});

  // Form state: commId -> { opening: number, closing: number, rec: number, used: number, spoiled: number, threshold: number }
  const [formState, setFormState] = useState<
    Record<
      string,
      {
        opening: number;
        closing: number;
        rec: number;
        used: number;
        spoiled: number;
        threshold: number;
      }
    >
  >({});

  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Sync state whenever modal opens or month changes
  useEffect(() => {
    if (isOpen) {
      const activeMonth = selectedMonth || new Date().toISOString().substring(0, 7);
      setModalMonth(activeMonth);
      loadMonthStats(activeMonth);
      setSuccessMsg(null);
    }
  }, [isOpen, selectedMonth]);

  const loadMonthStats = (monthStr: string) => {
    const monthCommodities = calculateMonthlyCommodityStock(
      monthStr,
      baseCommodities,
      dailyEntries,
      stockTransactions,
      monthlyOverrides
    );

    const initial: Record<
      string,
      {
        opening: number;
        closing: number;
        rec: number;
        used: number;
        spoiled: number;
        threshold: number;
      }
    > = {};

    const initialRaw: Record<string, { opening: string; closing: string }> = {};
    monthCommodities.forEach((c) => {
      initial[c.id] = {
        opening: c.openingBalance,
        closing: c.closingBalance,
        rec: c.received || 0,
        used: c.used || 0,
        spoiled: c.spoiled || 0,
        threshold: c.minThreshold,
      };
      initialRaw[c.id] = {
        opening: String(c.openingBalance),
        closing: String(c.closingBalance),
      };
    });

    setFormState(initial);
    setRawInputs(initialRaw);
    setIsDirty(false);
  };

  if (!isOpen) return null;

  const handleMonthChange = (newMonth: string) => {
    setModalMonth(newMonth);
    loadMonthStats(newMonth);
    setSuccessMsg(null);
    setIsDirty(false);
  };

  const getCommodityIcon = (id: string) => {
    switch (id) {
      case 'rice':
        return <Wheat className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
      case 'oil':
        return <Droplet className="w-5 h-5 text-amber-500 dark:text-amber-400" />;
      case 'pulses':
        return <Soup className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />;
      case 'egg':
        return <Egg className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />;
      case 'chikki':
        return <Cookie className="w-5 h-5 text-orange-600 dark:text-orange-400" />;
      case 'ragi':
        return <Flame className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      case 'jaggery':
        return <Sparkles className="w-5 h-5 text-pink-600 dark:text-pink-400" />;
      default:
        return <Package className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
    }
  };

  // Handle changes to Opening Balance or Closing Balance
  const handleBalanceChange = (id: string, field: 'opening' | 'closing' | 'threshold', valStr: string) => {
    // 1. Set the raw input value directly so they can type "-", ".", decimals, etc. freely
    setRawInputs((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: valStr,
      },
    }));

    const num = isNaN(parseFloat(valStr)) ? 0 : parseFloat(valStr);
    setIsDirty(true);

    setFormState((prev) => {
      const current = prev[id] || { opening: 0, closing: 0, rec: 0, used: 0, spoiled: 0, threshold: 10 };
      let newOpening = current.opening;
      let newClosing = current.closing;
      let newThreshold = current.threshold;

      if (field === 'opening') {
        newOpening = num;
        // Closing = Opening + Received - Used - Spoiled
        newClosing = safeRound3(newOpening + current.rec - current.used - current.spoiled);
      } else if (field === 'closing') {
        newClosing = num;
        // Opening = Closing - Received + Used + Spoiled
        newOpening = safeRound3(newClosing - current.rec + current.used + current.spoiled);
      } else if (field === 'threshold') {
        newThreshold = num;
      }

      // Sync the calculated counterpart in rawInputs as well
      setRawInputs((rawPrev) => {
        const existing = rawPrev[id] || { opening: '', closing: '' };
        return {
          ...rawPrev,
          [id]: {
            ...existing,
            opening: field === 'opening' ? valStr : String(newOpening),
            closing: field === 'closing' ? valStr : String(newClosing),
          },
        };
      });

      const nextFormState = {
        ...prev,
        [id]: {
          ...current,
          opening: newOpening,
          closing: newClosing,
          threshold: newThreshold,
        },
      };

      if (id === 'ragi' && nextFormState['jaggery']) {
        nextFormState['jaggery'] = {
          ...nextFormState['jaggery'],
          opening: newOpening,
          closing: newClosing,
          threshold: newThreshold,
        };
        setTimeout(() => {
          setRawInputs((rawPrev) => ({
            ...rawPrev,
            jaggery: {
              ...rawPrev.jaggery,
              opening: field === 'opening' ? valStr : String(newOpening),
              closing: field === 'closing' ? valStr : String(newClosing),
            },
          }));
        }, 0);
      }

      // Auto-save changes immediately into persistent storage
      if (onSaveMonthlyBalances) {
        const openingBalancesForMonth: Record<string, number> = {};
        baseCommodities.forEach((item) => {
          const val = nextFormState[item.id];
          openingBalancesForMonth[item.id] = val ? val.opening : item.openingBalance;
        });
        onSaveMonthlyBalances(modalMonth, openingBalancesForMonth);
      }

      return nextFormState;
    });
  };

  const handleResetCurrentMonth = () => {
    if (onResetMonthlyOverride) {
      onResetMonthlyOverride(modalMonth);
    }
    saveStoredManualObMonth(modalMonth, false);
    // Reload standard carry forward values
    const updatedOverrides = { ...monthlyOverrides };
    delete updatedOverrides[modalMonth];

    const monthCommodities = calculateMonthlyCommodityStock(
      modalMonth,
      baseCommodities,
      dailyEntries,
      stockTransactions,
      updatedOverrides
    );

    const initial: Record<
      string,
      { opening: number; closing: number; rec: number; used: number; spoiled: number; threshold: number }
    > = {};

    const initialRaw: Record<string, { opening: string; closing: string }> = {};
    monthCommodities.forEach((c) => {
      initial[c.id] = {
        opening: c.openingBalance,
        closing: c.closingBalance,
        rec: c.received || 0,
        used: c.used || 0,
        spoiled: c.spoiled || 0,
        threshold: c.minThreshold,
      };
      initialRaw[c.id] = {
        opening: String(c.openingBalance),
        closing: String(c.closingBalance),
      };
    });

    setFormState(initial);
    setRawInputs(initialRaw);
    setSuccessMsg(`Reset month ${modalMonth} to automatic carry forward!`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const openingBalancesForMonth: Record<string, number> = {};
    baseCommodities.forEach((item) => {
      const val = formState[item.id];
      const cleanOpening = safeRound3(val ? val.opening : item.openingBalance);
      openingBalancesForMonth[item.id] = cleanOpening;
    });

    const targetMonthKey = modalMonth.length === 10 ? modalMonth.substring(0, 7) : modalMonth;
    const targetDateKey = modalMonth.length === 10 ? modalMonth : `${modalMonth}-01`;

    // 1. Save monthly override if callback exists
    if (onSaveMonthlyBalances) {
      onSaveMonthlyBalances(targetMonthKey, openingBalancesForMonth);
      onSaveMonthlyBalances(targetDateKey, openingBalancesForMonth);
    }
    saveStoredMonthlyCommodityBalances({
      ...monthlyOverrides,
      [targetMonthKey]: openingBalancesForMonth,
      [targetDateKey]: openingBalancesForMonth,
    });
    saveStoredManualObMonth(targetMonthKey, true);

    // 2. Only save base commodities opening balances if saving initial month or explicit initial baseline
    if (targetMonthKey === '2026-08' || targetDateKey.startsWith('2026-08')) {
      const updatedBase = baseCommodities.map((item) => {
        const val = formState[item.id];
        return {
          ...item,
          openingBalance: safeRound3(val ? val.opening : item.openingBalance),
          minThreshold: val ? Math.max(0, val.threshold) : item.minThreshold,
        };
      });
      if (onSaveOpeningBalances) {
        onSaveOpeningBalances(updatedBase);
      }
      saveStoredCommodities(updatedBase);
    }

    setIsSavedSuccess(true);
    setIsDirty(false);
    setSuccessMsg(`Commodities monthly stock balances for ${modalMonth} saved successfully!`);
    setTimeout(() => {
      setSuccessMsg(null);
      setIsSavedSuccess(false);
      onClose();
    }, 1200);
  };

  // Helper date labels
  const monthDate = new Date(`${modalMonth}-01T00:00:00`);
  const monthLabel = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  // Previous and next month strings
  const prevDate = new Date(monthDate);
  prevDate.setMonth(prevDate.getMonth() - 1);
  const prevMonthStr = prevDate.toISOString().substring(0, 7);
  const prevMonthLabel = prevDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

  const nextDate = new Date(monthDate);
  nextDate.setMonth(nextDate.getMonth() + 1);
  const nextMonthStr = nextDate.toISOString().substring(0, 7);
  const nextMonthLabel = nextDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

  const isOverrideActive = !!monthlyOverrides[modalMonth];

  // Calculate previous month's final closing stocks to check dynamic auto-update
  const prevMonthCommodities = calculateMonthlyCommodityStock(
    prevMonthStr,
    baseCommodities,
    dailyEntries,
    stockTransactions,
    monthlyOverrides
  );
  const prevMonthCBMap: Record<string, number> = {};
  prevMonthCommodities.forEach((c) => {
    prevMonthCBMap[c.id] = c.closingBalance;
  });

  // Filter out Pulses / Dal and Cooking Oil from the display list as requested
  const displayCommodities = baseCommodities.filter(
    (item) =>
      item.id !== 'pulses' &&
      !item.name.toLowerCase().includes('pulse') &&
      !item.name.toLowerCase().includes('dal') &&
      item.id !== 'oil' &&
      !item.name.toLowerCase().includes('oil')
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-1.5 sm:p-3 overflow-y-auto">
      <div className="w-full max-w-lg md:max-w-xl lg:max-w-2xl max-h-[96vh] sm:max-h-[90vh] flex flex-col bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl p-2.5 sm:p-3.5 shadow-2xl border border-white/80 dark:border-slate-800/80 my-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2 shrink-0">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 shrink-0">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 dark:text-white text-xs sm:text-sm md:text-base leading-tight">
                Monthly Commodity Stock Manager
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-tight">
                Edit Opening & Closing Balances month-by-month with automatic carry-forward
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Month Selector Bar */}
        <div className="shrink-0 my-1.5 p-1.5 sm:p-2 rounded-xl bg-slate-100/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-1.5 sm:gap-2">
          <div className="flex items-center space-x-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300 shrink-0" />
            <span className="text-[10.5px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase">Select Month:</span>
            <input
              type="month"
              value={modalMonth}
              onChange={(e) => handleMonthChange(e.target.value)}
              className="btn-glass-month-input text-xs px-2 py-0.5"
            />
          </div>

          {isOverrideActive ? (
            <button
              type="button"
              onClick={handleResetCurrentMonth}
              className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-200 border border-amber-500/30 text-[10.5px] font-bold flex items-center space-x-1 transition-all cursor-pointer shadow-xs"
              title={`Remove manual override and dynamically auto-sync opening balances with ${prevMonthLabel} closing balances`}
            >
              <RefreshCw className="w-3 h-3 text-amber-600 dark:text-amber-400" />
              <span>Auto-Sync from {prevMonthLabel} Closing</span>
            </button>
          ) : (
            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[10.5px] font-bold">
              <CheckCircle2 className="w-3 h-3" />
              <span>Auto-Carried Forward from {prevMonthLabel}</span>
            </span>
          )}
        </div>

        {/* Override / Carry Forward Status Badge */}
        <div className="shrink-0 flex items-center justify-between text-xs px-1 mb-1">
          <div className="flex items-center space-x-1.5">
            <span className="font-extrabold text-slate-800 dark:text-slate-200 text-xs">
              {monthLabel} Stock Ledger
            </span>
            {isOverrideActive ? (
              <span className="px-1.5 py-0.5 rounded-md bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/20 text-[9.5px] font-bold">
                ✏️ Custom Override Active
              </span>
            ) : (
              <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-[9.5px] font-bold">
                ✨ Auto Carried Forward from {prevMonthLabel}
              </span>
            )}
          </div>
        </div>

        {/* Info Callout */}
        <div className="shrink-0 p-1.5 sm:p-2 rounded-lg bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/60 dark:border-blue-800/60 flex items-start space-x-2 text-[10.5px] text-blue-900 dark:text-blue-200 mb-1.5">
          <Info className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <div className="text-[10px] sm:text-[11px] leading-snug">
            <span className="font-bold">Month-Wise Balance Rules:</span> Edit <strong>Opening Balance</strong> or <strong>Closing Balance</strong> for <strong>{monthLabel}</strong>. Changing one automatically recalculates the other.
            <span className="font-semibold block text-blue-950 dark:text-blue-100">
              Closing Balance of {monthLabel} &rarr; carries forward as Opening Balance of {nextMonthLabel}.
            </span>
          </div>
        </div>

        {/* Success Alert */}
        {successMsg && (
          <div className="shrink-0 p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold flex items-center space-x-1.5 mb-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 min-h-0 flex flex-col justify-between">
          <div className="flex-1 min-h-0 overflow-y-auto space-y-1.5 sm:space-y-2 pr-1">
            {displayCommodities.map((item) => {
              const val = formState[item.id] || {
                opening: item.openingBalance,
                closing: item.closingBalance,
                rec: 0,
                used: 0,
                spoiled: 0,
                threshold: item.minThreshold,
              };

              return (
                <div
                  key={item.id}
                  className="data-entry-card p-2 sm:p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 transition-all space-y-1.5"
                >
                  <div className="flex flex-row items-center justify-between gap-2">
                    {/* Item Name & Icon */}
                    <div className="flex items-center space-x-2 min-w-[110px]">
                      <div className="p-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-2xs shrink-0">
                        {getCommodityIcon(item.id)}
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 dark:text-white text-xs leading-tight">{item.name}</h4>
                        <span className="text-[9.5px] font-bold text-slate-500 uppercase">Unit: {item.unit}</span>
                      </div>
                    </div>

                    {/* Usage Stats Pills */}
                    <div className="flex flex-wrap items-center gap-1 text-[9px] sm:text-[9.5px] font-bold text-slate-600 dark:text-slate-300">
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20">
                        Rec: +{val.rec}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20">
                        Used: -{val.used}
                      </span>
                      {val.spoiled > 0 && (
                        <span className="px-1.5 py-0.2 rounded bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20">
                          Spoiled: -{val.spoiled}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Dual Input Grid: Opening Balance & Closing Balance */}
                  <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-200/50 dark:border-slate-700/50">
                    {/* Opening Balance Input */}
                    <div className="w-full">
                      <div className="flex items-center justify-between mb-0.5">
                        <label className="block text-[9.5px] sm:text-[10px] font-extrabold text-slate-700 dark:text-slate-300 uppercase">
                          Opening ({item.unit})
                        </label>
                        {(item.id === 'egg' || item.id === 'chikki') && (
                          <div className="flex items-center gap-0.5">
                            <button
                              type="button"
                              onClick={() => {
                                const current = val.opening;
                                const toggled = -current;
                                handleBalanceChange(item.id, 'opening', String(toggled));
                              }}
                              className="px-1 py-0.2 text-[8.5px] font-black rounded bg-indigo-100 hover:bg-indigo-200 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-200 border border-indigo-300 dark:border-indigo-700 cursor-pointer"
                              title="Toggle negative/positive sign"
                            >
                              ± Sign
                            </button>
                          </div>
                        )}
                      </div>
                      <input
                        type="text"
                        inputMode="decimal"
                        pattern="[0-9.-]*"
                        value={rawInputs[item.id]?.opening ?? String(val.opening)}
                        onChange={(e) => handleBalanceChange(item.id, 'opening', e.target.value)}
                        className={`w-full px-2 py-1 bg-white dark:bg-slate-900 border rounded-lg font-black text-xs sm:text-sm focus:ring-1 focus:ring-amber-500 shadow-2xs ${
                          val.opening < 0
                            ? 'border-rose-400 dark:border-rose-600 text-rose-700 dark:text-rose-300 font-black'
                            : 'border-amber-300 dark:border-amber-700/70 text-slate-900 dark:text-white'
                        }`}
                      />
                      <div className="flex items-center justify-between text-[8.5px] sm:text-[9px] mt-0.5 text-slate-500 dark:text-slate-400">
                        <span>
                          {prevMonthLabel} CB: <strong className="text-slate-700 dark:text-slate-200 font-mono font-bold">{prevMonthCBMap[item.id] ?? 0}</strong>
                        </span>
                        {Math.abs(val.opening - (prevMonthCBMap[item.id] ?? 0)) > 0.001 ? (
                          <button
                            type="button"
                            onClick={() => handleBalanceChange(item.id, 'opening', String(prevMonthCBMap[item.id] ?? 0))}
                            className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                          >
                            Adopt {prevMonthCBMap[item.id] ?? 0}
                          </button>
                        ) : (
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5">
                            <CheckCircle2 className="w-2 h-2" /> Synced
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Closing Balance Input */}
                    <div className="w-full">
                      <label className="block text-[9.5px] sm:text-[10px] font-extrabold text-slate-700 dark:text-slate-300 uppercase mb-0.5 flex items-center justify-between">
                        <span>Closing ({item.unit})</span>
                        <span className="text-[8.5px] text-amber-600 dark:text-amber-400">
                          &rarr; {nextMonthLabel}
                        </span>
                      </label>
                      <input
                        type="text"
                        inputMode="decimal"
                        pattern="[0-9.-]*"
                        value={rawInputs[item.id]?.closing ?? String(val.closing)}
                        onChange={(e) => handleBalanceChange(item.id, 'closing', e.target.value)}
                        className="w-full px-2 py-1 bg-white dark:bg-slate-900 border border-emerald-400 dark:border-emerald-700/70 rounded-lg font-black text-emerald-900 dark:text-emerald-100 text-xs sm:text-sm focus:ring-1 focus:ring-emerald-500 shadow-2xs"
                      />
                      <span className="text-[8.5px] text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5 block">
                        Auto-calculated or custom CB
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Buttons */}
          <div className="shrink-0 flex items-center justify-between gap-2 pt-2 mt-1.5 border-t border-slate-100 dark:border-slate-800">
            {isOverrideActive ? (
              <button
                type="button"
                onClick={handleResetCurrentMonth}
                className="btn-3d-glass-purple px-2.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center justify-center space-x-1 cursor-pointer active:scale-95"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset {monthLabel}</span>
              </button>
            ) : (
              <span className="text-[10.5px] text-slate-400 font-medium">
                Auto carry active
              </span>
            )}

            <div className="flex items-center space-x-1.5 justify-end">
              <button
                type="button"
                onClick={onClose}
                className="glass-3d-btn px-3 py-1.5 text-xs rounded-lg font-black transition-all cursor-pointer active:scale-95 text-center"
              >
                Cancel
              </button>

              <button
                type="submit"
                className={
                  (isSavedSuccess
                    ? "btn-3d-glass-emerald px-3 py-1.5 text-xs rounded-lg flex items-center justify-center space-x-1.5 font-black cursor-pointer active:scale-95 !text-white"
                    : isDirty
                      ? "btn-3d-glass-amber px-3 py-1.5 text-xs rounded-lg flex items-center justify-center space-x-1.5 font-black cursor-pointer active:scale-95"
                      : "btn-3d-glass-blue px-3 py-1.5 text-xs rounded-lg flex items-center justify-center space-x-1.5 font-black cursor-pointer active:scale-95")
                }
              >
                {isSavedSuccess ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-white animate-bounce" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save {monthLabel}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
