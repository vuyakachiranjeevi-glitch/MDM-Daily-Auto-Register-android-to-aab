import React, { useState, useEffect } from 'react';
import { StudentClassStrength, StudentStrengthUpdateRecord } from '../types';
import {
  Users,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Download,
  Printer,
  Calendar,
  Layers,
  Edit3,
  Trash2,
  FileText,
  Filter,
  Search,
  PlusCircle,
  TrendingUp,
  Info,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  getStudentStrengthForDate,
  saveStudentStrengthForDate,
  getStudentStrengthRemarkForDate,
  saveStudentStrengthRemarkForDate,
  getStudentStrengthUpdatesList,
  deleteStudentStrengthForDate,
} from '../lib/storage';
import { getDayDetails, formatDateReadable } from '../lib/utils';

interface StudentStrengthViewProps {
  studentStrengths: StudentClassStrength[];
  onSaveStrengths: (strengths: StudentClassStrength[], monthStr?: string) => void;
}

export const StudentStrengthView: React.FC<StudentStrengthViewProps> = ({
  studentStrengths,
  onSaveStrengths,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    return new Date().toISOString().substring(0, 7); // Default to current month, e.g. "2026-08"
  });

  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().substring(0, 10); // Default to today's date, e.g. "2026-08-10"
  });

  const [remarkInput, setRemarkInput] = useState<string>('');
  const [strengths, setStrengths] = useState<StudentClassStrength[]>(() => {
    return getStudentStrengthForDate(selectedDate);
  });
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Filter and search state for Monthly Register list
  const [registerMonthFilter, setRegisterMonthFilter] = useState<string>(() => {
    return new Date().toISOString().substring(0, 7);
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);

  // Updates list
  const [updateRecords, setUpdateRecords] = useState<StudentStrengthUpdateRecord[]>([]);

  const refreshUpdateRecords = () => {
    const list = getStudentStrengthUpdatesList(registerMonthFilter);
    setUpdateRecords(list);
  };

  useEffect(() => {
    const dayData = getStudentStrengthForDate(selectedDate);
    setStrengths(dayData);
    setRemarkInput(getStudentStrengthRemarkForDate(selectedDate));
  }, [selectedDate, studentStrengths]);

  useEffect(() => {
    refreshUpdateRecords();
  }, [registerMonthFilter, selectedDate]);

  const handleDateChange = (newDateStr: string) => {
    setSelectedDate(newDateStr);
    const newMonth = newDateStr.substring(0, 7);
    if (newMonth !== selectedMonth) {
      setSelectedMonth(newMonth);
    }
  };

  const navigateDate = (offset: number) => {
    const parts = selectedDate.split('-');
    let dateObj: Date;
    if (parts.length === 3) {
      dateObj = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    } else {
      dateObj = new Date(selectedDate);
    }
    dateObj.setDate(dateObj.getDate() + offset);

    const y = dateObj.getFullYear();
    const m = String(dateObj.getMonth() + 1).padStart(2, '0');
    const d = String(dateObj.getDate()).padStart(2, '0');
    handleDateChange(`${y}-${m}-${d}`);
  };

  const dayDetails = getDayDetails(selectedDate);

  const handleClassChange = (index: number, field: 'boys' | 'girls', value: number) => {
    const wholeVal = Math.max(0, Math.floor(Number(value) || 0));
    const updated = [...strengths];
    const boysVal = field === 'boys' ? wholeVal : updated[index].boys;
    const girlsVal = field === 'girls' ? wholeVal : updated[index].girls;

    updated[index] = {
      ...updated[index],
      boys: boysVal,
      girls: girlsVal,
      total: boysVal + girlsVal,
    };

    setStrengths(updated);

    // Save day-wise update to storage with remark
    saveStudentStrengthForDate(selectedDate, updated, remarkInput);
    onSaveStrengths(updated, selectedDate);
    refreshUpdateRecords();
  };

  const handleRemarkChange = (text: string) => {
    setRemarkInput(text);
    saveStudentStrengthRemarkForDate(selectedDate, text);
    saveStudentStrengthForDate(selectedDate, strengths, text);
    refreshUpdateRecords();
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveStudentStrengthForDate(selectedDate, strengths, remarkInput);
    onSaveStrengths(strengths, selectedDate);
    setSavedSuccess(true);
    refreshUpdateRecords();
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleDeleteRecord = (dateToDelete: string) => {
    if (window.confirm(`Are you sure you want to delete the strength update recorded on ${formatDateReadable(dateToDelete)}?`)) {
      deleteStudentStrengthForDate(dateToDelete);
      refreshUpdateRecords();
      if (selectedDate === dateToDelete) {
        setStrengths(getStudentStrengthForDate(selectedDate));
      }
    }
  };

  const handleEditRecordOnDate = (recordDate: string) => {
    setSelectedDate(recordDate);
    const m = recordDate.substring(0, 7);
    setSelectedMonth(m);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Category Totals for current selected date
  const primaryStrengths = strengths.filter((s) => s.category === 'Primary' || Boolean(s.classLevel && s.classLevel.match(/class\s*[1-5]/i)));
  const upperPrimaryStrengths = strengths.filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || Boolean(s.classLevel && s.classLevel.match(/class\s*[6-8]/i)));

  const totalPrimaryBoys = primaryStrengths.reduce((sum, s) => sum + s.boys, 0);
  const totalPrimaryGirls = primaryStrengths.reduce((sum, s) => sum + s.girls, 0);
  const totalPrimaryGrand = totalPrimaryBoys + totalPrimaryGirls;

  const totalUpperBoys = upperPrimaryStrengths.reduce((sum, s) => sum + s.boys, 0);
  const totalUpperGirls = upperPrimaryStrengths.reduce((sum, s) => sum + s.girls, 0);
  const totalUpperGrand = totalUpperBoys + totalUpperGirls;

  const schoolTotalBoys = strengths.reduce((sum, s) => sum + s.boys, 0);
  const schoolTotalGirls = strengths.reduce((sum, s) => sum + s.girls, 0);
  const schoolGrandTotal = schoolTotalBoys + schoolTotalGirls;

  // Filtered update records for list display
  const filteredRecords = updateRecords.filter((rec) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const matchDate = rec.date.includes(q) || formatDateReadable(rec.date).toLowerCase().includes(q);
    const matchRemark = (rec.remarks || '').toLowerCase().includes(q);
    const matchSummary = (rec.changesSummary || '').toLowerCase().includes(q);
    return matchDate || matchRemark || matchSummary;
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Date',
      'Primary Boys',
      'Primary Girls',
      'Primary Total',
      'Upper Primary Boys',
      'Upper Primary Girls',
      'Upper Primary Total',
      'Grand Total Boys',
      'Grand Total Girls',
      'Grand Total Students',
      'Changes Summary',
      'Remarks',
    ];

    const rows = updateRecords.map((r) => [
      r.date,
      r.primaryBoys,
      r.primaryGirls,
      r.primaryTotal,
      r.upperBoys,
      r.upperGirls,
      r.upperTotal,
      r.totalBoys,
      r.totalGirls,
      r.grandTotal,
      r.changesSummary || 'No change',
      r.remarks || '',
    ]);

    const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Monthly_Student_Strength_Register_${registerMonthFilter}.csv`;
    link.click();
  };

  const handlePrintRegister = () => {
    window.print();
  };

  return (
    <div className="max-w-full space-y-2 sm:space-y-2.5 pb-2 sm:pb-3">
      {/* Header */}
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-2 sm:p-3 rounded-xl sm:rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-2 sm:gap-3">
        <div>
          <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex flex-wrap items-center gap-1.5 sm:gap-2">
            <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-600 shrink-0" />
            <span className="font-extrabold tracking-tight text-xs sm:text-sm">Student Strength Update Register</span>
            <span className="px-1.5 py-0.2 rounded-full text-[8.5px] sm:text-[9px] font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
              <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-emerald-600 dark:text-emerald-400" />
              Auto-Saved Datewise
            </span>
          </h2>
          <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            Update class-wise and sex-wise enrolled strength by date. Strength updates automatically log into the Monthly Register list.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between md:justify-end gap-2 sm:gap-3 w-full md:w-auto self-stretch md:self-auto">
          <div className="flex flex-col gap-0.5 w-full sm:w-auto sm:min-w-[260px] md:min-w-[300px] grow sm:grow-0">
            {/* Date Selection Bar */}
            <div className="flex flex-col w-full">
              <span className="text-[8.5px] sm:text-[9.5px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5">Select Date of Strength Update</span>
              <div
                className={`flex items-center justify-between gap-1 sm:gap-1.5 p-0.5 sm:p-1 rounded-xl border bg-white dark:bg-slate-950 transition-all shadow-xs w-full ${
                  dayDetails.isHoliday
                    ? 'border-red-300 bg-red-50/70 dark:bg-red-950/20 shadow-red-500/5'
                    : 'border-slate-200 dark:border-slate-800 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500'
                }`}
              >
                <button
                  type="button"
                  onClick={() => navigateDate(-1)}
                  className={`px-1.5 py-1 sm:px-2 sm:py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-0.5 sm:gap-1 text-[8.5px] sm:text-[9.5px] font-extrabold active:scale-95 cursor-pointer shrink-0 ${
                    dayDetails.isHoliday ? 'text-red-600 dark:text-red-400' : 'text-slate-700 dark:text-slate-300'
                  }`}
                  title="Previous Date"
                >
                  <ChevronLeft className="w-3 h-3 stroke-[2.5]" />
                  <span>BACK</span>
                </button>

                <div style={{ height: '22px' }} className="flex items-center justify-center space-x-1 sm:space-x-1.5 px-1.5 sm:px-2 py-0 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-100 dark:border-slate-800/80 grow min-w-0">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => handleDateChange(e.target.value)}
                    className={`bg-transparent font-black text-[11px] sm:text-xs outline-hidden cursor-pointer w-[95px] sm:w-[110px] md:w-[120px] shrink-0 text-center ${
                      dayDetails.isHoliday ? 'text-red-600 dark:text-red-400 font-extrabold' : 'text-slate-900 dark:text-slate-100'
                    }`}
                  />
                  <span className="text-slate-300 dark:text-slate-700 text-xs hidden sm:inline">|</span>
                  <span
                    className={`text-[7.5px] sm:text-[8.5px] font-bold uppercase tracking-wide px-1.5 sm:px-2 py-0.5 rounded-md whitespace-nowrap shrink-0 ${
                      dayDetails.isHoliday
                        ? 'bg-red-100 dark:bg-red-950/70 text-red-600 dark:text-red-400 font-bold border border-red-300 dark:border-red-800'
                        : 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 font-extrabold'
                    }`}
                  >
                    {dayDetails.dayName}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => navigateDate(1)}
                  className={`px-1.5 py-1 sm:px-2 sm:py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-0.5 sm:gap-1 text-[8.5px] sm:text-[9.5px] font-extrabold active:scale-95 cursor-pointer shrink-0 ${
                    dayDetails.isHoliday ? 'text-red-600 dark:text-red-400' : 'text-slate-700 dark:text-slate-300'
                  }`}
                  title="Next Date"
                >
                  <span>NEXT</span>
                  <ChevronRight className="w-3 h-3 stroke-[2.5]" />
                </button>
              </div>
            </div>
          </div>
          <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center p-1.5 sm:p-0 bg-indigo-50/50 dark:bg-slate-800/40 sm:bg-transparent sm:dark:bg-transparent rounded-xl border border-indigo-100/50 sm:border-0 dark:border-slate-800/50 shrink-0">
            <span className="text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400 uppercase font-black block">Grand Total Enrolled</span>
            <span className="text-base sm:text-lg font-black text-indigo-600 dark:text-indigo-400">{schoolGrandTotal}</span>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-500/10 backdrop-blur-xs border border-emerald-500/20 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Student strength updated and recorded in register successfully!</span>
        </div>
      )}

      {/* Editor Section */}
      <form onSubmit={handleSave} className="space-y-4">
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md rounded-2xl border border-white/80 dark:border-slate-800/80 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50/80 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <PlusCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h3 className="font-extrabold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                Class-wise & Sex-wise Strength Entry ({formatDateReadable(selectedDate)})
              </h3>
            </div>
            <div className="flex items-center space-x-2 w-full sm:w-auto">
              <span className="text-[10px] font-bold text-slate-500 uppercase whitespace-nowrap">Remarks:</span>
              <input
                type="text"
                value={remarkInput}
                onChange={(e) => handleRemarkChange(e.target.value)}
                placeholder="e.g. 2 New Admissions in Class 3"
                className="px-2.5 py-1 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg w-full sm:w-64 font-medium"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/70 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                  <th className="p-3">Class / Grade</th>
                  <th className="p-3">Category</th>
                  <th className="p-3 text-center">Boys</th>
                  <th className="p-3 text-center">Girls</th>
                  <th className="p-3 text-right">Class Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                {strengths.map((item, idx) => (
                  <tr key={item.classLevel} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{item.classLevel}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          item.category === 'Primary' || Boolean(item.classLevel && item.classLevel.match(/class\s*[1-5]/i))
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                        }`}
                      >
                        {item.category}
                      </span>
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={item.boys === 0 ? '' : String(item.boys)}
                        onKeyDown={(e) => {
                          if (['-', '+', 'e', 'E', '.', ','].includes(e.key)) e.preventDefault();
                        }}
                        onChange={(e) => {
                          const clean = e.target.value.replace(/[^0-9]/g, '');
                          handleClassChange(idx, 'boys', clean ? parseInt(clean, 10) : 0);
                        }}
                        placeholder="0"
                        autoComplete="off"
                        className="w-20 text-center px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={item.girls === 0 ? '' : String(item.girls)}
                        onKeyDown={(e) => {
                          if (['-', '+', 'e', 'E', '.', ','].includes(e.key)) e.preventDefault();
                        }}
                        onChange={(e) => {
                          const clean = e.target.value.replace(/[^0-9]/g, '');
                          handleClassChange(idx, 'girls', clean ? parseInt(clean, 10) : 0);
                        }}
                        placeholder="0"
                        autoComplete="off"
                        className="w-20 text-center px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="p-3 text-right font-black text-indigo-600 dark:text-indigo-400 text-sm">
                      {item.total}
                    </td>
                  </tr>
                ))}
              </tbody>
              {/* Category Subtotals & Grand Total */}
              <tfoot className="bg-slate-50 dark:bg-slate-800/90 font-bold border-t-2 border-slate-300 dark:border-slate-700">
                <tr className="text-blue-900 dark:text-blue-200">
                  <td className="p-2.5" colSpan={2}>
                    Primary Subtotal (Class 1-5)
                  </td>
                  <td className="p-2.5 text-center">{totalPrimaryBoys} Boys</td>
                  <td className="p-2.5 text-center">{totalPrimaryGirls} Girls</td>
                  <td className="p-2.5 text-right font-black">{totalPrimaryGrand}</td>
                </tr>
                <tr className="text-purple-900 dark:text-purple-200">
                  <td className="p-2.5" colSpan={2}>
                    Upper Primary Subtotal (Class 6-8)
                  </td>
                  <td className="p-2.5 text-center">{totalUpperBoys} Boys</td>
                  <td className="p-2.5 text-center">{totalUpperGirls} Girls</td>
                  <td className="p-2.5 text-right font-black">{totalUpperGrand}</td>
                </tr>
                <tr className="bg-gradient-to-r from-stone-100/95 via-white/95 to-slate-100/95 dark:from-slate-900/95 dark:via-slate-850/95 dark:to-slate-900/95 text-slate-900 dark:text-white text-sm backdrop-blur-md ring-1 ring-slate-300 dark:ring-slate-700">
                  <td className="p-3 font-black uppercase tracking-wider text-slate-900 dark:text-white" colSpan={2}>
                    GRAND TOTAL SCHOOL STRENGTH
                  </td>
                  <td className="p-3 text-center font-bold text-slate-900 dark:text-slate-100">{schoolTotalBoys} Boys</td>
                  <td className="p-3 text-center font-bold text-slate-900 dark:text-slate-100">{schoolTotalGirls} Girls</td>
                  <td className="p-3 text-right font-black text-base text-indigo-700 dark:text-sky-300">{schoolGrandTotal} Students</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </form>

      {/* MONTHLY STUDENT STRENGTH REGISTER — ONLY UPDATED LIST ROWS */}
      <div className="bg-white/75 dark:bg-slate-900/75 backdrop-blur-lg rounded-2xl border border-white/85 dark:border-slate-800/85 shadow-xs overflow-hidden space-y-4 p-5">
        {/* Register Title & Controls Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>Student Strength Update Register</span>
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-extrabold bg-indigo-500/15 border border-indigo-500/30 text-indigo-800 dark:text-indigo-300">
                Only Updated List Rows
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Data list created by date whenever student strength changes class-wise and sex-wise. No rows for dates without changes.
            </p>
          </div>

          <div className="flex items-center space-x-2 shrink-0 flex-wrap gap-1">
            <div className="flex items-center space-x-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <Filter className="w-3.5 h-3.5 text-slate-500 ml-1" />
              <select
                value={registerMonthFilter}
                onChange={(e) => setRegisterMonthFilter(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 outline-none cursor-pointer pr-1"
              >
                <option value="ALL">All Months History</option>
                <option value={new Date().toISOString().substring(0, 7)}>
                  This Month ({new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })})
                </option>
                {/* Dynamically include months present in updateRecords */}
                {Array.from(new Set(updateRecords.map((r) => r.date.substring(0, 7))))
                  .sort()
                  .reverse()
                  .map((m) => (
                    <option key={m} value={m}>
                      {new Date(`${m}-01`).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                    </option>
                  ))}
              </select>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search date / remarks..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none w-36 sm:w-48 font-medium"
              />
            </div>

            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold transition-all flex items-center space-x-1.5 shadow-xs cursor-pointer active:scale-95"
              title="Export Register to CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={handlePrintRegister}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold transition-all flex items-center space-x-1.5 shadow-xs cursor-pointer active:scale-95"
              title="Print Official Student Strength Register"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Register</span>
            </button>
          </div>
        </div>

        {/* Info banner confirming 'Only Updated List' behavior */}
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 rounded-xl text-indigo-900 dark:text-indigo-200 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span>
              <strong>Rule:</strong> Rows are created in this register <strong>only when strength changes on a date</strong>. Unchanged dates produce no list rows.
            </span>
          </div>
          <span className="text-[10px] font-black uppercase px-2 py-0.5 bg-indigo-600 text-white rounded">
            {filteredRecords.length} Update {filteredRecords.length === 1 ? 'Row' : 'Rows'}
          </span>
        </div>

        {/* Printable Official Header (Hidden until print) */}
        <div className="hidden print:block p-4 border-b-2 border-slate-900 font-sans text-slate-900 mb-4">
          <h1 className="text-xs font-black uppercase tracking-wider">
            SCHOOL EDUCATION DEPARTMENT
          </h1>
          <h2 className="text-sm font-black uppercase mt-0.5 text-indigo-950">
            STUDENT STRENGTH UPDATE REGISTER (CLASS-WISE & SEX-WISE UPDATES)
          </h2>
          <p className="text-[10px] font-bold text-slate-700 mt-1">
            Total Update Entries Recorded: {filteredRecords.length} Rows
          </p>
        </div>

        {/* Register Data Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/90 dark:bg-slate-800/90 text-slate-800 dark:text-slate-200 font-extrabold border-b border-slate-200 dark:border-slate-700 text-[10.5px] uppercase tracking-wider">
                <th rowSpan={2} className="p-2.5 border-r border-slate-200 dark:border-slate-700 whitespace-nowrap">Date of Update</th>
                <th colSpan={3} className="p-2 text-center border-r border-slate-200 dark:border-slate-700 bg-blue-50/70 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300">
                  Primary Enrolled (Class 1-5)
                </th>
                <th colSpan={3} className="p-2 text-center border-r border-slate-200 dark:border-slate-700 bg-purple-50/70 dark:bg-purple-950/40 text-purple-800 dark:text-purple-300">
                  Upper Primary Enrolled (Class 6-8)
                </th>
                <th colSpan={3} className="p-2 text-center border-r border-slate-200 dark:border-slate-700 bg-indigo-50/80 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-200 font-black">
                  School Grand Total Strength
                </th>
                <th rowSpan={2} className="p-2.5 border-r border-slate-200 dark:border-slate-700 text-left min-w-[150px]">Changes Summary</th>
                <th rowSpan={2} className="p-2.5 border-r border-slate-200 dark:border-slate-700 text-left">Remarks / Reason</th>
                <th rowSpan={2} className="p-2.5 text-center no-print whitespace-nowrap">Actions</th>
              </tr>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 text-[9.5px] uppercase">
                {/* Primary */}
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700">Boys</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700">Girls</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-black text-blue-700 dark:text-blue-300">Total</th>

                {/* Upper Primary */}
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700">Boys</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700">Girls</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-black text-purple-700 dark:text-purple-300">Total</th>

                {/* Grand Total */}
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-extrabold text-slate-900 dark:text-white">Boys</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-extrabold text-slate-900 dark:text-white">Girls</th>
                <th className="p-1.5 text-center border-r border-slate-200 dark:border-slate-700 font-black text-indigo-600 dark:text-sky-300 text-xs">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium text-slate-800 dark:text-slate-200">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={13} className="p-8 text-center text-slate-400 dark:text-slate-500">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <Layers className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                      <p className="font-extrabold text-sm text-slate-600 dark:text-slate-400">
                        No strength update rows recorded for this period.
                      </p>
                      <p className="text-xs text-slate-400 max-w-md">
                        There is no list row when strength is not changed. Rows are created automatically whenever student strength is modified on a date.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => {
                  const isExpanded = expandedRowId === rec.id;
                  const dateInfo = getDayDetails(rec.date);

                  return (
                    <React.Fragment key={rec.id}>
                      <tr className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="p-2.5 border-r border-slate-100 dark:border-slate-800 whitespace-nowrap">
                          <div className="font-extrabold text-slate-900 dark:text-white text-xs">
                            {formatDateReadable(rec.date)}
                          </div>
                          <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">
                            {dateInfo.dayName}
                          </div>
                        </td>

                        {/* Primary */}
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-semibold">{rec.primaryBoys}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-semibold">{rec.primaryGirls}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/20">{rec.primaryTotal}</td>

                        {/* Upper Primary */}
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-semibold">{rec.upperBoys}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-semibold">{rec.upperGirls}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-purple-700 dark:text-purple-300 bg-purple-50/30 dark:bg-purple-950/20">{rec.upperTotal}</td>

                        {/* Grand Total */}
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-bold">{rec.totalBoys}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-bold">{rec.totalGirls}</td>
                        <td className="p-2 text-center border-r border-slate-100 dark:border-slate-800 font-black text-indigo-700 dark:text-sky-300 text-sm bg-indigo-50/40 dark:bg-sky-950/30">{rec.grandTotal}</td>

                        {/* Changes Summary */}
                        <td className="p-2.5 border-r border-slate-100 dark:border-slate-800">
                          <span className="px-2 py-0.5 rounded text-[10.5px] font-extrabold bg-amber-500/10 text-amber-800 dark:text-amber-300 border border-amber-500/20 inline-block">
                            {rec.changesSummary}
                          </span>
                        </td>

                        {/* Remarks */}
                        <td className="p-2.5 border-r border-slate-100 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300">
                          {rec.remarks || 'Enrolment record'}
                        </td>

                        {/* Actions */}
                        <td className="p-2 text-center no-print whitespace-nowrap">
                          <div className="flex items-center justify-center space-x-1">
                            <button
                              onClick={() => setExpandedRowId(isExpanded ? null : rec.id)}
                              className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 font-bold text-[10px] flex items-center gap-1 cursor-pointer"
                              title="Toggle Class-by-Class Matrix"
                            >
                              <span>Classes</span>
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>

                            <button
                              onClick={() => handleEditRecordOnDate(rec.date)}
                              className="p-1.5 hover:bg-indigo-100 dark:hover:bg-indigo-950/60 rounded-lg text-indigo-600 dark:text-indigo-400 transition-colors cursor-pointer"
                              title="Edit Strength for this Date"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => handleDeleteRecord(rec.date)}
                              className="p-1.5 hover:bg-red-100 dark:hover:bg-red-950/60 rounded-lg text-red-600 dark:text-red-400 transition-colors cursor-pointer"
                              title="Delete Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>

                      {/* Expandable Class Matrix Row */}
                      {isExpanded && (
                        <tr className="bg-slate-50/90 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-700">
                          <td colSpan={13} className="p-4">
                            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                              <div className="flex items-center justify-between border-b pb-2 dark:border-slate-800">
                                <span className="font-extrabold text-xs text-indigo-950 dark:text-indigo-300 uppercase tracking-wider">
                                  Class-by-Class Enrolled Breakdown on {formatDateReadable(rec.date)}
                                </span>
                                <span className="text-[10px] text-slate-400 font-bold">
                                  {rec.strengths.length} Classes Recorded
                                </span>
                              </div>

                              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 text-center text-xs">
                                {rec.strengths.map((cs) => (
                                  <div
                                    key={cs.classLevel}
                                    className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700"
                                  >
                                    <div className="font-black text-slate-900 dark:text-white text-[11px]">
                                      {cs.classLevel}
                                    </div>
                                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                                      {cs.boys}B + {cs.girls}G
                                    </div>
                                    <div className="font-extrabold text-indigo-600 dark:text-indigo-400 text-xs mt-0.5">
                                      {cs.total} Total
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
