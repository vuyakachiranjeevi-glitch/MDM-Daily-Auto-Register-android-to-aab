import React from 'react';
import { RefreshCw, Sparkles, X } from 'lucide-react';

interface PWAUpdateBannerProps {
  show: boolean;
  onUpdate: () => void;
}

export const PWAUpdateBanner: React.FC<PWAUpdateBannerProps> = ({ show, onUpdate }) => {
  const [dismissed, setDismissed] = React.useState<boolean>(false);

  if (!show || dismissed) return null;

  return (
    <div
      id="pwa-update-banner"
      className="fixed top-16 right-3 sm:right-6 z-50 max-w-sm w-full animate-in slide-in-from-top-4 duration-300"
    >
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-900/95 via-teal-900/95 to-slate-900/95 border border-emerald-400/50 shadow-2xl text-white backdrop-blur-xl flex items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-black text-emerald-300 truncate">
              App Update Available
            </h4>
            <p className="text-[10px] text-slate-300 truncate">
              Fresh features &amp; speed enhancements ready.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onUpdate}
            className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1 shadow-md transition-all active:scale-95"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Update</span>
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-slate-400 hover:text-white rounded"
            title="Dismiss"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
