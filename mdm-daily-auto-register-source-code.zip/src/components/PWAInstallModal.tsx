import React from 'react';
import {
  Download,
  Share,
  PlusSquare,
  CheckCircle2,
  X,
  Smartphone,
  Monitor,
  WifiOff,
  Zap,
  ShieldCheck,
  Printer,
  ChevronRight
} from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInstall: () => void;
  isIOS: boolean;
  hasDeferredPrompt: boolean;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  onInstall,
  isIOS,
  hasDeferredPrompt,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="pwa-install-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="pwa-install-modal-container"
        className="relative w-full max-w-lg bg-slate-900 border border-sky-500/30 rounded-3xl shadow-2xl overflow-hidden text-slate-100 p-5 sm:p-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon & Close Button */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-sky-500"></span>
            </span>
            <span className="text-xs font-extrabold uppercase tracking-widest text-sky-400">
              Install Native Web App
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* App Emblem & Branding */}
        <div className="flex items-center space-x-4 my-4">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-sky-600 via-blue-600 to-indigo-700 p-0.5 ring-2 ring-sky-400/40 shadow-lg shadow-sky-500/20 shrink-0 flex items-center justify-center overflow-hidden">
            <img
              src="/pwa-192x192.png"
              alt="MDM App Icon"
              className="w-full h-full object-cover rounded-2xl"
              onError={(e) => {
                // Fallback to SVG if PNG loading has delay
                e.currentTarget.src = '/favicon.svg';
              }}
            />
          </div>
          <div className="min-w-0">
            <h3 className="text-lg sm:text-xl font-black text-white tracking-tight leading-tight">
              MDM Daily Auto Register
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              PM-POSHAN Mid-Day Meal Management
            </p>
            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                ⚡ Fast Standalone Mode
              </span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                📶 Offline Ready
              </span>
            </div>
          </div>
        </div>

        {/* Feature Matrix / Highlights */}
        <div className="grid grid-cols-2 gap-2 sm:gap-2.5 my-4">
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start space-x-2.5">
            <Zap className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-slate-200">1-Touch Home Launch</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                Full-screen view without browser address bars or tabs.
              </p>
            </div>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start space-x-2.5">
            <WifiOff className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-slate-200">Works Without Internet</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                Log daily meals &amp; calculate stocks even in remote areas.
              </p>
            </div>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start space-x-2.5">
            <Printer className="w-4 h-4 text-sky-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-slate-200">Official A4 Reports</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                Print cash vouchers &amp; monthly registers instantly.
              </p>
            </div>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start space-x-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-slate-200">Auto Cloud Backup</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                Encrypted sync to school database when online.
              </p>
            </div>
          </div>
        </div>

        {/* Installation Instructions for iOS / Desktop / Direct */}
        {isIOS ? (
          <div className="p-3.5 rounded-2xl bg-sky-950/40 border border-sky-500/30 text-xs my-3 space-y-2">
            <div className="font-bold text-sky-300 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4" />
              How to Install on iPhone / iPad (Safari):
            </div>
            <ol className="list-decimal list-inside text-slate-300 space-y-1.5 pl-1">
              <li className="flex items-center gap-2">
                <span>1. Tap Safari's</span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-sky-300 font-bold">
                  <Share className="w-3.5 h-3.5" /> Share
                </span>
                <span>button at bottom.</span>
              </li>
              <li className="flex items-center gap-2">
                <span>2. Scroll down &amp; choose</span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-emerald-300 font-bold">
                  <PlusSquare className="w-3.5 h-3.5" /> Add to Home Screen
                </span>
              </li>
              <li className="flex items-center gap-2">
                <span>3. Tap</span>
                <span className="font-bold text-white bg-blue-600 px-2 py-0.5 rounded">Add</span>
                <span>in the top right corner.</span>
              </li>
            </ol>
          </div>
        ) : !hasDeferredPrompt ? (
          <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700 text-xs my-3 space-y-1.5">
            <div className="font-bold text-sky-300 flex items-center gap-1.5">
              <Monitor className="w-4 h-4" />
              Install via Browser Menu:
            </div>
            <p className="text-slate-300">
              Click the <strong className="text-white">Install</strong> icon (⊕ or 💻) in your Chrome/Edge address bar, or open your browser menu (⋮) and select <strong className="text-white">"Install MDM Register"</strong> or <strong className="text-white">"Add to Home screen"</strong>.
            </p>
          </div>
        ) : null}

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 mt-4 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
          >
            Maybe Later
          </button>

          {hasDeferredPrompt && (
            <button
              onClick={onInstall}
              className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white shadow-lg shadow-sky-600/30 flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Install App Now</span>
            </button>
          )}

          {isIOS && (
            <button
              onClick={onClose}
              className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Got It</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
