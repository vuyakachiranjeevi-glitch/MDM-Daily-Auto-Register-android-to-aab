import React, { useState, useEffect } from 'react';
import { CommodityItem, DailyEntry, StockTransaction } from '../types';
import { safeRound3, formatQtyVal, formatDateReadable } from '../lib/utils';
import { MonthlyCommodityOverrides, calculateMonthlyCommodityStock, saveStoredManualObMonth } from '../lib/storage';
import {
  Egg,
  Cookie,
  Save,
  X,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Info,
} from 'lucide-react';

interface EggsChikkiObModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMonth: string; // e.g. "2026-08"
  baseCommodities: CommodityItem[];
  dailyEntries?: DailyEntry[];
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onSaveOpeningBalances?: (updatedCommodities: CommodityItem[]) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  firstWorkingDayDateStr?: string;
  onShowToast?: (msg: string) => void;
}

export const EggsChikkiObModal: React.FC<EggsChikkiObModalProps> = ({
  isOpen,
  onClose,
  selectedMonth,
  baseCommodities,
  dailyEntries = [],
  stockTransactions = [],
  monthlyOverrides = {},
  onSaveMonthlyBalances,
  onSaveOpeningBalances,
  onResetMonthlyOverride,
  firstWorkingDayDateStr,
  onShowToast,
}) => {
  const [modalMonth, setModalMonth] = useState<string>(selectedMonth);
  const [eggObInput, setEggObInput] = useState<string>('0');
  const [chikkiObInput, setChikkiObInput] = useState<string>('0');
  const [targetType, setTargetType] = useState<'month_start' | 'first_working_day'>('month_start');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Month date info
  const monthDate = new Date(`${modalMonth}-01T00:00:00`);
  const monthLabel = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const prevDate = new Date(monthDate);
  prevDate.setMonth(prevDate.getMonth() - 1);
  const prevMonthStr = prevDate.toISOString().substring(0, 7);
  const prevMonthLabel = prevDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

  // Calculate previous month's closing stock
  const prevMonthStock = calculateMonthlyCommodityStock(
    prevMonthStr,
    baseCommodities,
    dailyEntries,
    stockTransactions,
    monthlyOverrides
  );
  const prevEggCB = prevMonthStock.find((c) => c.id === 'egg')?.closingBalance ?? 0;
  const prevChikkiCB = prevMonthStock.find((c) => c.id === 'chikki')?.closingBalance ?? 0;

  // Calculate current month's stock under current settings
  const currentMonthStock = calculateMonthlyCommodityStock(
    modalMonth,
    baseCommodities,
    dailyEntries,
    stockTransactions,
    monthlyOverrides
  );
  const currentEgg = currentMonthStock.find((c) => c.id === 'egg') || {
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
  };
  const currentChikki = currentMonthStock.find((c) => c.id === 'chikki') || {
    openingBalance: 0,
    received: 0,
    used: 0,
    spoiled: 0,
    closingBalance: 0,
  };

  // Sync inputs whenever modal opens or month changes
  useEffect(() => {
    if (isOpen) {
      setModalMonth(selectedMonth);
      setSaveSuccess(false);

      // Check current override or carry-forward
      const monthOverride = monthlyOverrides[selectedMonth] || monthlyOverrides[`${selectedMonth}-01`];
      const eggVal = typeof monthOverride?.egg === 'number'
        ? monthOverride.egg
        : (currentEgg.openingBalance !== undefined ? currentEgg.openingBalance : prevEggCB);
      const chikkiVal = typeof monthOverride?.chikki === 'number'
        ? monthOverride.chikki
        : (currentChikki.openingBalance !== undefined ? currentChikki.openingBalance : prevChikkiCB);

      setEggObInput(String(eggVal));
      setChikkiObInput(String(chikkiVal));
    }
  }, [isOpen, selectedMonth, monthlyOverrides]);

  if (!isOpen) return null;

  const parsedEgg = isNaN(parseFloat(eggObInput)) ? 0 : parseFloat(eggObInput);
  const parsedChikki = isNaN(parseFloat(chikkiObInput)) ? 0 : parseFloat(chikkiObInput);

  // Projected closing balances
  const projectedEggCB = safeRound3(parsedEgg + (currentEgg.received || 0) - (currentEgg.used || 0) - (currentEgg.spoiled || 0));
  const projectedChikkiCB = safeRound3(parsedChikki + (currentChikki.received || 0) - (currentChikki.used || 0) - (currentChikki.spoiled || 0));

  const handleApplyPreset = (comm: 'egg' | 'chikki', delta: number) => {
    if (comm === 'egg') {
      const next = safeRound3(parsedEgg + delta);
      setEggObInput(String(next));
    } else {
      const next = safeRound3(parsedChikki + delta);
      setChikkiObInput(String(next));
    }
  };

  const handleSetExact = (comm: 'egg' | 'chikki', val: number) => {
    if (comm === 'egg') {
      setEggObInput(String(val));
    } else {
      setChikkiObInput(String(val));
    }
  };

  const handleResetToPrevCB = () => {
    setEggObInput(String(prevEggCB));
    setChikkiObInput(String(prevChikkiCB));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanEgg = safeRound3(parsedEgg);
    const cleanChikki = safeRound3(parsedChikki);

    const existingOverrides = monthlyOverrides[modalMonth] || {};
    const newOverrides = {
      ...existingOverrides,
      egg: cleanEgg,
      chikki: cleanChikki,
    };

    // Save to month string and date string
    if (onSaveMonthlyBalances) {
      onSaveMonthlyBalances(modalMonth, newOverrides);
      onSaveMonthlyBalances(`${modalMonth}-01`, newOverrides);

      if (firstWorkingDayDateStr && targetType === 'first_working_day') {
        onSaveMonthlyBalances(firstWorkingDayDateStr, {
          ...(monthlyOverrides[firstWorkingDayDateStr] || {}),
          egg: cleanEgg,
          chikki: cleanChikki,
        });
      }
    }
    saveStoredManualObMonth(modalMonth, true);

    // If initial base month (August 2026), also update base commodities
    if (onSaveOpeningBalances && modalMonth === '2026-08') {
      const updatedBase = baseCommodities.map((item) => {
        if (item.id === 'egg') {
          return { ...item, openingBalance: cleanEgg };
        }
        if (item.id === 'chikki') {
          return { ...item, openingBalance: cleanChikki };
        }
        return item;
      });
      onSaveOpeningBalances(updatedBase);
    }

    setSaveSuccess(true);
    if (onShowToast) {
      onShowToast(`Saved Opening Balances for ${monthLabel}: Eggs = ${cleanEgg} Qty, Chikki = ${cleanChikki} Qty`);
    }

    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 900);
  };

  const isOverrideActive = Boolean(monthlyOverrides[modalMonth]?.egg !== undefined || monthlyOverrides[modalMonth]?.chikki !== undefined);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="eggs-chikki-ob-title"
        className="w-full max-w-xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-800/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-3.5 py-2.5 sm:px-5 sm:py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white flex items-center justify-between shadow-sm">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-xl bg-white/20 backdrop-blur-xs text-white">
              <Egg className="w-5 h-5" />
            </div>
            <div>
              <h3 id="eggs-chikki-ob-title" className="font-black text-sm sm:text-base leading-tight">
                Eggs & Chikki Opening Balance (OB)
              </h3>
              <p className="text-[10.5px] sm:text-xs text-amber-100 font-medium">
                Enter, Edit, and Save Opening Stock for {monthLabel}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSave} className="p-3 sm:p-4 space-y-3">
          {/* Top Month & Quick Carry Bar */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center space-x-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-700 dark:text-amber-300" />
              <span className="text-[11px] font-bold text-amber-900 dark:text-amber-200 uppercase">Month:</span>
              <span className="text-xs font-black text-slate-900 dark:text-white px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700">
                {monthLabel}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleResetToPrevCB}
                className="px-2 py-1 rounded-lg text-[10.5px] font-bold bg-white dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                title={`Sync with ${prevMonthLabel} Closing Balance`}
              >
                <RotateCcw className="w-3 h-3 text-amber-600" />
                <span>Adopt {prevMonthLabel} Closing</span>
              </button>

              {isOverrideActive && onResetMonthlyOverride && (
                <button
                  type="button"
                  onClick={() => {
                    onResetMonthlyOverride(modalMonth);
                    handleResetToPrevCB();
                    if (onShowToast) onShowToast(`Reset ${monthLabel} Eggs & Chikki OB to dynamic carry-forward`);
                  }}
                  className="px-2 py-1 rounded-lg text-[10.5px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 cursor-pointer hover:bg-rose-100"
                >
                  Clear Override
                </button>
              )}
            </div>
          </div>

          {/* Cards Grid: Egg OB & Chikki OB */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Egg OB Card */}
            <div className="p-3 rounded-xl bg-gradient-to-b from-amber-50/80 to-white dark:from-amber-950/20 dark:to-slate-900 border-2 border-amber-400 dark:border-amber-700/80 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="p-1 rounded-lg bg-amber-500 text-white shadow-xs">
                    <Egg className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white text-xs sm:text-sm">Eggs Opening Balance</h4>
                    <span className="text-[9.5px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wide">Unit: Qty (Pieces)</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-800">
                  {prevMonthLabel} CB: {formatQtyVal(prevEggCB)}
                </span>
              </div>

              {/* Egg Input */}
              <div>
                <label className="block text-[10px] font-extrabold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Enter Egg Opening Stock (OB):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="decimal"
                    pattern="[0-9.-]*"
                    autoFocus
                    value={eggObInput}
                    onChange={(e) => setEggObInput(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-950 border-2 border-amber-500 rounded-lg text-base font-black font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:outline-none shadow-inner text-right pr-12"
                    placeholder="0"
                  />
                  <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-700 dark:text-amber-400 select-none">
                    Eggs
                  </span>
                </div>
              </div>

              {/* Quick Stepper Presets for Eggs */}
              <div className="flex flex-wrap items-center gap-1 pt-0.5">
                <span className="text-[9px] font-bold text-slate-500 mr-0.5">Quick Add:</span>
                {[+10, +25, +50, +100, +200].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => handleApplyPreset('egg', d)}
                    className="px-1.5 py-0.5 rounded bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/50 dark:hover:bg-amber-800 text-amber-900 dark:text-amber-200 text-[10px] font-bold font-mono transition-transform active:scale-95 cursor-pointer"
                  >
                    +{d}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleSetExact('egg', 0)}
                  className="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold font-mono cursor-pointer ml-auto"
                >
                  0
                </button>
              </div>

              {/* Live Month Stats Preview for Eggs */}
              <div className="p-2 rounded-lg bg-slate-100/80 dark:bg-slate-800/60 text-[10px] font-mono grid grid-cols-3 gap-1 text-center">
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Rec (+)</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">+{currentEgg.received || 0}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Used (-)</span>
                  <span className="font-bold text-amber-700 dark:text-amber-300">-{currentEgg.used || 0}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Closing</span>
                  <span className={`font-black ${projectedEggCB < 0 ? 'text-rose-600' : 'text-cyan-700 dark:text-cyan-300'}`}>
                    {projectedEggCB}
                  </span>
                </div>
              </div>
            </div>

            {/* Chikki OB Card */}
            <div className="p-3 rounded-xl bg-gradient-to-b from-orange-50/80 to-white dark:from-orange-950/20 dark:to-slate-900 border-2 border-orange-400 dark:border-orange-700/80 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="p-1 rounded-lg bg-orange-500 text-white shadow-xs">
                    <Cookie className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white text-xs sm:text-sm">Chikki Opening Balance</h4>
                    <span className="text-[9.5px] font-bold text-orange-700 dark:text-orange-400 uppercase tracking-wide">Unit: Qty (Packets)</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-orange-100 dark:bg-orange-900/60 text-orange-900 dark:text-orange-200 border border-orange-300 dark:border-orange-800">
                  {prevMonthLabel} CB: {formatQtyVal(prevChikkiCB)}
                </span>
              </div>

              {/* Chikki Input */}
              <div>
                <label className="block text-[10px] font-extrabold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Enter Chikki Opening Stock (OB):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="decimal"
                    pattern="[0-9.-]*"
                    value={chikkiObInput}
                    onChange={(e) => setChikkiObInput(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-950 border-2 border-orange-500 rounded-lg text-base font-black font-mono text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:outline-none shadow-inner text-right pr-14"
                    placeholder="0"
                  />
                  <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-orange-700 dark:text-orange-400 select-none">
                    Chikki
                  </span>
                </div>
              </div>

              {/* Quick Stepper Presets for Chikki */}
              <div className="flex flex-wrap items-center gap-1 pt-0.5">
                <span className="text-[9px] font-bold text-slate-500 mr-0.5">Quick Add:</span>
                {[+10, +25, +50, +100, +200].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => handleApplyPreset('chikki', d)}
                    className="px-1.5 py-0.5 rounded bg-orange-100 hover:bg-orange-200 dark:bg-orange-900/50 dark:hover:bg-orange-800 text-orange-900 dark:text-orange-200 text-[10px] font-bold font-mono transition-transform active:scale-95 cursor-pointer"
                  >
                    +{d}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleSetExact('chikki', 0)}
                  className="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold font-mono cursor-pointer ml-auto"
                >
                  0
                </button>
              </div>

              {/* Live Month Stats Preview for Chikki */}
              <div className="p-2 rounded-lg bg-slate-100/80 dark:bg-slate-800/60 text-[10px] font-mono grid grid-cols-3 gap-1 text-center">
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Rec (+)</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">+{currentChikki.received || 0}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Used (-)</span>
                  <span className="font-bold text-orange-700 dark:text-orange-300">-{currentChikki.used || 0}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-500 uppercase block font-sans">Closing</span>
                  <span className={`font-black ${projectedChikkiCB < 0 ? 'text-rose-600' : 'text-cyan-700 dark:text-cyan-300'}`}>
                    {projectedChikkiCB}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Info rule footnote */}
          <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex items-start space-x-2 text-[10.5px] text-blue-900 dark:text-blue-200">
            <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
            <span>
              Saving these Opening Balances immediately recalculates the entire register, daily consumption, and closing balances for <strong>{monthLabel}</strong> forward.
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black flex items-center space-x-1.5 shadow-md transition-all cursor-pointer ${
                saveSuccess
                  ? 'bg-emerald-600 text-white animate-bounce'
                  : 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white active:scale-95'
              }`}
            >
              {saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>Saved Successfully!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 text-white" />
                  <span>Save Eggs & Chikki OB</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
