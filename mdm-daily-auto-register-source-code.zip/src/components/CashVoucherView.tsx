import React, { useState, useEffect, useRef } from 'react';
import { CommodityItem, DailyEntry, MealRates, SchoolProfile, StockTransaction, StudentClassStrength } from '../types';
import { formatCurrency, getDayDetails, numToWords, calculateDailyCommodityStock, generateContinuousMonthRange } from '../lib/utils';
import { getStudentStrengthForMonth, getStudentStrengthForDate, getDailyClassAttendanceForDate, MonthlyCommodityOverrides } from '../lib/storage';
import { Receipt, IndianRupee, Printer, Building2, Calendar, FileText, RotateCcw, X, Filter, ChevronDown, Check, Copy, FileDown, HelpCircle, Sparkles, Eye, ZoomIn, ZoomOut, LogOut, Sun, Moon } from 'lucide-react';
import { OpeningBalanceModal } from './OpeningBalanceModal';

interface CashVoucherViewProps {
  schoolProfile: SchoolProfile;
  dailyEntries: DailyEntry[];
  mealRates: MealRates;
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  studentStrengths?: StudentClassStrength[];
  onSaveOpeningBalances?: (updatedCommodities: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onPrintVoucher: () => void;
  onClose?: () => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const CashVoucherView: React.FC<CashVoucherViewProps> = ({
  schoolProfile,
  dailyEntries,
  mealRates,
  commodities,
  baseCommodities = [],
  stockTransactions = [],
  monthlyOverrides = {},
  studentStrengths = [],
  onSaveOpeningBalances,
  onSaveMonthlyBalances,
  onResetMonthlyOverride,
  onPrintVoucher,
  onClose,
  darkMode,
  onToggleDarkMode,
}) => {
  const [showOpeningModal, setShowOpeningModal] = useState<boolean>(false);
  const today = new Date();
  const currentMonthStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const todayYr = today.getFullYear();
  const todayMo = String(today.getMonth() + 1).padStart(2, '0');
  const todayDy = String(today.getDate()).padStart(2, '0');
  const todayDateStr = `${todayYr}-${todayMo}-${todayDy}`;
  
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_month');
      if (saved) return saved;
    } catch (e) {}
    return currentMonthStr;
  });
  const [fromDate, setFromDate] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_from_date');
      if (saved) return saved;
    } catch (e) {}
    return '';
  });
  const [toDate, setToDate] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_to_date');
      if (saved) return saved;
    } catch (e) {}
    return '';
  });
  const [classCategory, setClassCategory] = useState<'I - V' | 'VI - VIII' | 'I - VIII'>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_category');
      if (saved === 'I - V' || saved === 'VI - VIII' || saved === 'I - VIII') {
        return saved;
      }
    } catch (e) {}
    return 'I - V';
  });
  const [cooksCount, setCooksCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_cooks');
      if (saved) return parseInt(saved, 10);
    } catch (e) {}
    return 2;
  });
  const [includeHolidays, setIncludeHolidays] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_include_holidays');
      if (saved) return saved === 'true';
    } catch (e) {}
    return true;
  });
  const [showPdfOptions, setShowPdfOptions] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [checklist, setChecklist] = useState(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_checklist');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      paperA4: true,
      marginsNone: true,
      bgGraphics: true,
      portrait: true,
    };
  });

  // Advanced Print Settings State
  const [printConfig, setPrintConfig] = useState(() => {
    try {
      const saved = localStorage.getItem('mdm_voucher_print_config');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      paperSize: 'A4',
      orientation: 'portrait',
      marginSize: '4mm',
      densityPreset: 'auto',
      fitSinglePage: true,
      bgGraphics: true,
    };
  });

  // Responsive Canvas Preview State for Mobile/Tablet/Desktop aspect ratio auto-fitting
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState<number>(0);
  const [zoomMode, setZoomMode] = useState<'auto' | '100'>('auto');
  const [customZoom, setCustomZoom] = useState<number | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect) {
          setContainerWidth(entry.contentRect.width);
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Parse Year and Month
  const [yearNum, monthNum] = selectedMonth.split('-').map(Number);
  const daysInMonth = new Date(yearNum, monthNum, 0).getDate();

  const fullMonthStart = `${selectedMonth}-01`;
  const fullMonthEnd = `${selectedMonth}-${String(daysInMonth).padStart(2, '0')}`;
  const defaultToDate = selectedMonth === currentMonthStr ? todayDateStr : (selectedMonth > currentMonthStr ? todayDateStr : fullMonthEnd);

  const activeFromDate = fromDate || fullMonthStart;
  const activeToDate = toDate || defaultToDate;
  const effectiveToDate = selectedMonth >= currentMonthStr
    ? (activeToDate > todayDateStr ? todayDateStr : activeToDate)
    : activeToDate;

  const isCustomRangeActive = activeFromDate !== fullMonthStart || activeToDate !== defaultToDate;

  // Track mount status to avoid overwriting initial dates with full month dates
  const isMounted = React.useRef(false);

  // Sync date range whenever selectedMonth changes (defaulting to full month start and up to today for current month)
  useEffect(() => {
    if (isMounted.current) {
      setFromDate(fullMonthStart);
      setToDate(defaultToDate);
    } else {
      isMounted.current = true;
    }
  }, [selectedMonth]);

  // Persist states to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_month', selectedMonth);
    } catch (e) {}
  }, [selectedMonth]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_from_date', fromDate);
    } catch (e) {}
  }, [fromDate]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_to_date', toDate);
    } catch (e) {}
  }, [toDate]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_include_holidays', String(includeHolidays));
    } catch (e) {}
  }, [includeHolidays]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_category', classCategory);
    } catch (e) {}
  }, [classCategory]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_cooks', String(cooksCount));
    } catch (e) {}
  }, [cooksCount]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_checklist', JSON.stringify(checklist));
    } catch (e) {}
  }, [checklist]);

  useEffect(() => {
    try {
      localStorage.setItem('mdm_voucher_print_config', JSON.stringify(printConfig));
    } catch (e) {}
  }, [printConfig]);

  // Month Name for display
  const monthName = new Date(yearNum, monthNum - 1, 1).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  // Calculate enrolled students for the selected class category
  const activeStudentStrengths = getStudentStrengthForMonth(selectedMonth);
  let primaryEnrolled = 0;
  let upperPrimaryEnrolled = 0;

  activeStudentStrengths.forEach((s) => {
    if (s.category === 'Primary' || (s.classLevel && s.classLevel.match(/class\s*[1-5]/i))) {
      primaryEnrolled += s.total;
    } else {
      upperPrimaryEnrolled += s.total;
    }
  });

  // Fallback defaults if strength data is completely missing
  if (primaryEnrolled === 0 && upperPrimaryEnrolled === 0) {
    primaryEnrolled = 170;
    upperPrimaryEnrolled = 136;
  }

  const totalEnrolled = classCategory === 'I - V' 
    ? primaryEnrolled 
    : classCategory === 'VI - VIII' 
      ? upperPrimaryEnrolled 
      : primaryEnrolled + upperPrimaryEnrolled;

  // Rate per child for category
  const ratePerChild = classCategory === 'VI - VIII' 
    ? mealRates.upperPrimaryRatePerMeal 
    : mealRates.primaryRatePerMeal;

  // Construct day-wise table data for all days in the month
  let totalPrimaryAttendanceCount = 0;
  let totalUpperPrimaryAttendanceCount = 0;
  let totalPresentCount = 0;
  let totalMealsServedCount = 0;
  let totalMealsNotTakenCount = 0;
  let totalRiceUsed = 0;
  let totalEggsUsed = 0;
  let totalChikkiUsed = 0;
  let totalRagiUsed = 0;
  let totalJaggeryUsed = 0;
  let grandTotalAmount = 0;
  let workingDaysCount = 0;

  const monthEntriesMap = new Map<string, DailyEntry>();
  dailyEntries.forEach((e) => {
    if (e.date.startsWith(selectedMonth)) {
      monthEntriesMap.set(e.date, e);
    }
  });

  const allMonthRows = Array.from({ length: daysInMonth }, (_, index) => {
    const dayNum = index + 1;
    const dateStr = `${selectedMonth}-${String(dayNum).padStart(2, '0')}`;
    const dayDetails = getDayDetails(dateStr);
    let entry = monthEntriesMap.get(dateStr);

    const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(selectedMonth);
    const dayPriRoll = classStrengths
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + s.total, 0) || primaryEnrolled;
    const dayUpPriRoll = classStrengths
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + s.total, 0) || upperPrimaryEnrolled;
    const dayTotalRoll = dayPriRoll + dayUpPriRoll;

    // Follow Daily Auto Attendance Register (class-wise roll call attendance)
    const classAtt = getDailyClassAttendanceForDate ? getDailyClassAttendanceForDate(dateStr) : [];
    const autoPriAtt = classAtt
      .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
      .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);
    const autoUpPriAtt = classAtt
      .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
      .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

    // If no explicit entry saved and it's a working day in this month, follow the daily auto attendance register up to today
    if (!entry && !dayDetails.isSunday && !dayDetails.isHoliday && dateStr <= todayDateStr) {
      const pAtt = autoPriAtt || dayPriRoll;
      const upAtt = autoUpPriAtt || dayUpPriRoll;
      const hsAtt = 0;
      const totalMeals = pAtt + upAtt;

      const ricePrimaryNormKg = (mealRates?.riceNormPrimaryGrams ?? 100) / 1000;
      const riceUpperPrimaryNormKg = (mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000;
      const calculatedRice = Number(((pAtt * ricePrimaryNormKg) + (upAtt * riceUpperPrimaryNormKg)).toFixed(2));

      const dayOfWeek = dayDetails.dayOfWeek;

      const eggNorm = mealRates?.eggNormQty ?? 1;
      const isEggDay = dayOfWeek >= 1 && dayOfWeek <= 5;
      const eggUsedQty = isEggDay ? totalMeals * eggNorm : 0;

      const chikkiNorm = mealRates?.chikkiNormQty ?? 1;
      const isChikkiDay = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5;
      const chikkiUsedQty = isChikkiDay ? totalMeals * chikkiNorm : 0;

      const ragiNormKg = (mealRates?.ragiNormGrams ?? 10) / 1000;
      const jaggeryNormKg = (mealRates?.jaggeryNormGrams ?? 10) / 1000;
      const isRagiDay = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6;
      const ragiUsedKg = isRagiDay ? Number((totalMeals * ragiNormKg).toFixed(2)) : 0;
      const jaggeryUsedKg = isRagiDay ? Number((totalMeals * jaggeryNormKg).toFixed(2)) : 0;

      entry = {
        id: `auto_${dateStr}`,
        date: dateStr,
        primaryAttendance: pAtt,
        upperPrimaryAttendance: upAtt,
        highSchoolAttendance: hsAtt,
        totalAttendance: pAtt + upAtt + hsAtt,
        mealsServed: totalMeals,
        riceUsedKg: calculatedRice,
        eggUsedQty,
        chikkiUsedQty,
        ragiUsedKg,
        jaggeryUsedKg,
        remarks: 'MDM Served',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }

    let rollPri = dayPriRoll;
    let rollUpPri = dayUpPriRoll;
    let roll = dayTotalRoll;
    let attPri = 0;
    let attUpPri = 0;
    let present = 0;
    let mealsTaken = 0;
    let mealsNotTaken = 0;
    let riceUsed = 0;
    let eggUsed = 0;
    let chikkiUsed = 0;
    let ragiUsed = 0;
    let jaggeryUsed = 0;
    let amountPerChild = ratePerChild;
    let amountPerDay = 0;
    let isWorkingDay = false;
    let label = '';

    const isCalendarHoliday = !dayDetails.isWorkingDayOverride && (dayDetails.isSunday || dayDetails.isHoliday);

    if (isCalendarHoliday) {
      isWorkingDay = false;
      label = dayDetails.isSunday ? 'Sunday' : (dayDetails.holidayName || 'Holiday');
      mealsTaken = 0;
      present = 0;
      attPri = 0;
      attUpPri = 0;
      mealsNotTaken = 0;
      riceUsed = 0;
      eggUsed = 0;
      chikkiUsed = 0;
      ragiUsed = 0;
      jaggeryUsed = 0;
      amountPerDay = 0;
    } else if (entry) {
      attPri = entry.primaryAttendance !== undefined && entry.primaryAttendance !== null 
        ? entry.primaryAttendance 
        : (autoPriAtt || dayPriRoll);
      attUpPri = (entry.upperPrimaryAttendance !== undefined && entry.upperPrimaryAttendance !== null 
        ? entry.upperPrimaryAttendance 
        : (autoUpPriAtt || dayUpPriRoll)) + (entry.highSchoolAttendance ?? 0);
      let totalAtt = entry.totalAttendance ?? (attPri + attUpPri);
      const mealsServed = entry.mealsServed ?? (attPri + attUpPri);

      // If meals served is recorded but attendance fields were empty, align with strengths roll
      if (mealsServed > 0 && totalAtt === 0) {
        attPri = autoPriAtt || dayPriRoll;
        attUpPri = autoUpPriAtt || dayUpPriRoll;
        totalAtt = attPri + attUpPri;
      }

      const dayOfWeek = dayDetails.dayOfWeek;
      const isEggDay = dayOfWeek >= 1 && dayOfWeek <= 5;
      const isChikkiDay = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5;
      const isRagiDay = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6;

      const priRate = entry.primaryRatePerMeal ?? mealRates.primaryRatePerMeal ?? 5.45;
      const upRate = entry.upperPrimaryRatePerMeal ?? mealRates.upperPrimaryRatePerMeal ?? 8.17;
      const cch = entry.cchCost || 0;
      const other = entry.otherCost || 0;

      const isHolidayEntry = (mealsServed === 0 && Boolean(entry.remarks && (entry.remarks.toLowerCase().includes('holiday') || entry.remarks.toLowerCase().includes('closed'))));

      if (classCategory === 'I - V') {
        roll = dayPriRoll;
        present = attPri;
        if (mealsServed === 0) {
          mealsTaken = 0;
        } else {
          mealsTaken = attPri;
        }
        mealsNotTaken = Math.max(0, present - mealsTaken);
        amountPerChild = priRate;

        if (typeof entry.customCookingCost === 'number') {
          amountPerDay = totalAtt > 0 ? Number((entry.customCookingCost * (attPri / totalAtt)).toFixed(2)) : entry.customCookingCost;
        } else {
          amountPerDay = Number((mealsTaken * priRate).toFixed(2));
        }

        riceUsed = Number((attPri * ((mealRates?.riceNormPrimaryGrams ?? 100) / 1000)).toFixed(2));
        eggUsed = isEggDay ? mealsTaken * (mealRates?.eggNormQty ?? 1) : 0;
        chikkiUsed = isChikkiDay ? mealsTaken * (mealRates?.chikkiNormQty ?? 1) : 0;
        ragiUsed = isRagiDay ? Number((mealsTaken * ((mealRates?.ragiNormGrams ?? 10) / 1000)).toFixed(2)) : 0;
        jaggeryUsed = isRagiDay ? Number((mealsTaken * ((mealRates?.jaggeryNormGrams ?? 10) / 1000)).toFixed(2)) : 0;

        isWorkingDay = !isHolidayEntry && present > 0;
        if (!isWorkingDay) {
          if (dayDetails.isSunday) {
            label = 'Sunday';
          } else if (dayDetails.isHoliday) {
            label = dayDetails.holidayName || 'Holiday';
          } else if (entry.remarks && entry.remarks !== 'Auto' && entry.remarks !== 'MDM Served' && entry.remarks !== 'All meals served properly.') {
            label = entry.remarks;
          } else {
            label = present === 0 ? 'No Attendance' : 'No Meals Served';
          }
        }
      } else if (classCategory === 'VI - VIII') {
        roll = dayUpPriRoll;
        present = attUpPri;
        if (mealsServed === 0) {
          mealsTaken = 0;
        } else {
          mealsTaken = attUpPri;
        }
        mealsNotTaken = Math.max(0, present - mealsTaken);
        amountPerChild = upRate;

        if (typeof entry.customCookingCost === 'number') {
          amountPerDay = totalAtt > 0 ? Number((entry.customCookingCost * (attUpPri / totalAtt)).toFixed(2)) : entry.customCookingCost;
        } else {
          amountPerDay = Number((mealsTaken * upRate).toFixed(2));
        }

        riceUsed = Number((attUpPri * ((mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000)).toFixed(2));
        eggUsed = isEggDay ? mealsTaken * (mealRates?.eggNormQty ?? 1) : 0;
        chikkiUsed = isChikkiDay ? mealsTaken * (mealRates?.chikkiNormQty ?? 1) : 0;
        ragiUsed = isRagiDay ? Number((mealsTaken * ((mealRates?.ragiNormGrams ?? 10) / 1000)).toFixed(2)) : 0;
        jaggeryUsed = isRagiDay ? Number((mealsTaken * ((mealRates?.jaggeryNormGrams ?? 10) / 1000)).toFixed(2)) : 0;

        isWorkingDay = !isHolidayEntry && present > 0;
        if (!isWorkingDay) {
          if (dayDetails.isSunday) {
            label = 'Sunday';
          } else if (dayDetails.isHoliday) {
            label = dayDetails.holidayName || 'Holiday';
          } else if (entry.remarks && entry.remarks !== 'Auto' && entry.remarks !== 'MDM Served' && entry.remarks !== 'All meals served properly.') {
            label = entry.remarks;
          } else {
            label = present === 0 ? 'No Attendance' : 'No Meals Served';
          }
        }
      } else {
        roll = dayTotalRoll;
        present = totalAtt > 0 ? totalAtt : (attPri + attUpPri);
        mealsTaken = mealsServed === 0 ? 0 : (attPri + attUpPri);
        mealsNotTaken = Math.max(0, present - mealsTaken);
        riceUsed = entry.riceUsedKg || Number(((attPri * ((mealRates?.riceNormPrimaryGrams ?? 100) / 1000)) + (attUpPri * ((mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000))).toFixed(2));
        eggUsed = entry.eggUsedQty || (isEggDay ? mealsTaken * (mealRates?.eggNormQty ?? 1) : 0);
        chikkiUsed = entry.chikkiUsedQty || (isChikkiDay ? mealsTaken * (mealRates?.chikkiNormQty ?? 1) : 0);
        ragiUsed = entry.ragiUsedKg || (isRagiDay ? Number((mealsTaken * ((mealRates?.ragiNormGrams ?? 10) / 1000)).toFixed(2)) : 0);
        jaggeryUsed = entry.jaggeryUsedKg || (isRagiDay ? Number((mealsTaken * ((mealRates?.jaggeryNormGrams ?? 10) / 1000)).toFixed(2)) : 0);
        amountPerChild = priRate;

        if (typeof entry.customCookingCost === 'number') {
          amountPerDay = entry.customCookingCost;
        } else {
          amountPerDay = Number((((attPri) * priRate) + ((attUpPri) * upRate) + cch + other).toFixed(2));
        }

        isWorkingDay = !isHolidayEntry && present > 0;
        if (!isWorkingDay) {
          if (dayDetails.isSunday) {
            label = 'Sunday';
          } else if (dayDetails.isHoliday) {
            label = dayDetails.holidayName || 'Holiday';
          } else if (entry.remarks && entry.remarks !== 'Auto' && entry.remarks !== 'MDM Served' && entry.remarks !== 'All meals served properly.') {
            label = entry.remarks;
          } else {
            label = present === 0 ? 'No Attendance' : 'No Meals Served';
          }
        }
      }
    } else if (dayDetails.isSunday) {
      label = 'Sunday';
    } else if (dayDetails.isHoliday) {
      label = dayDetails.holidayName || 'Holiday';
    } else {
      label = '-';
    }

    return {
      sNo: dayNum,
      dateStr,
      formattedDate: `${String(dayNum).padStart(2, '0')}.${String(monthNum).padStart(2, '0')}.${String(yearNum).slice(-2)}`,
      shortDay: dayDetails.shortDayName,
      isSunday: dayDetails.isSunday,
      isHoliday: dayDetails.isHoliday,
      isWorkingDay,
      label,
      rollPri,
      rollUpPri,
      roll,
      attPri,
      attUpPri,
      present,
      mealsTaken,
      mealsNotTaken,
      riceUsed,
      eggUsed,
      chikkiUsed,
      ragiUsed,
      jaggeryUsed,
      amountPerChild,
      amountPerDay,
    };
  });

  // Filter day rows according to activeFromDate, effectiveToDate, holiday preference, and strictly up to today
  const dayRows = allMonthRows
    .filter((row) => {
      // Cash voucher print strictly follows only up to today
      if (row.dateStr > todayDateStr) {
        return false;
      }
      const withinDate = row.dateStr >= activeFromDate && row.dateStr <= effectiveToDate;
      if (!withinDate) return false;
      if (!includeHolidays) {
        return row.isWorkingDay;
      }
      return true;
    })
    .map((row, idx) => ({
      ...row,
      sNo: idx + 1,
    }));

  // Compute grand totals for active filtered days
  dayRows.forEach((row) => {
    if (row.isWorkingDay) {
      workingDaysCount++;
      totalPrimaryAttendanceCount += row.attPri;
      totalUpperPrimaryAttendanceCount += row.attUpPri;
      totalPresentCount += row.present;
      totalMealsServedCount += row.mealsTaken;
      totalMealsNotTakenCount += row.mealsNotTaken;
      totalRiceUsed += row.riceUsed;
      totalEggsUsed += row.eggUsed;
      totalChikkiUsed += row.chikkiUsed;
      totalRagiUsed += row.ragiUsed;
      totalJaggeryUsed += row.jaggeryUsed;
      grandTotalAmount += row.amountPerDay;
    }
  });

  const avgMealsTaken = workingDaysCount > 0 ? Math.round(totalMealsServedCount / workingDaysCount) : 0;
  const avgMealsPercentage = totalEnrolled > 0 ? ((avgMealsTaken / totalEnrolled) * 100).toFixed(1) : '0';
  const roundedGrandTotal = Math.round(grandTotalAmount);

  // Continuous commodity stock computation across academic months
  const effectiveBaseCommodities = baseCommodities && baseCommodities.length > 0 ? baseCommodities : commodities;
  const continuousMonths = generateContinuousMonthRange(['2026-08', selectedMonth]);

  // Synthesize daily entries across continuous months for unbroken commodity stock cascade
  const allSynthesizedEntries: DailyEntry[] = [];
  const entriesMap = new Map<string, DailyEntry>();
  dailyEntries.forEach((e) => {
    if (e.date) entriesMap.set(e.date, e);
  });

  continuousMonths.forEach((mStr) => {
    const mParts = mStr.split('-');
    const mY = parseInt(mParts[0], 10);
    const mMo = parseInt(mParts[1], 10);
    const daysInM = isNaN(mY) || isNaN(mMo) ? 30 : new Date(mY, mMo, 0).getDate();

    for (let d = 1; d <= daysInM; d++) {
      const dateStr = `${mStr}-${String(d).padStart(2, '0')}`;
      if (entriesMap.has(dateStr)) {
        allSynthesizedEntries.push(entriesMap.get(dateStr)!);
      } else {
        const dayInfo = getDayDetails(dateStr);
        if (!dayInfo.isSunday && !dayInfo.isHoliday && dateStr <= todayDateStr) {
          const classStrengths = getStudentStrengthForDate ? getStudentStrengthForDate(dateStr) : getStudentStrengthForMonth(mStr);
          const dayPriRoll = classStrengths
            .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
            .reduce((sum, s) => sum + s.total, 0) || primaryEnrolled;
          const dayUpPriRoll = classStrengths
            .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
            .reduce((sum, s) => sum + s.total, 0) || upperPrimaryEnrolled;

          const classAtt = getDailyClassAttendanceForDate ? getDailyClassAttendanceForDate(dateStr) : [];
          const autoPriAtt = classAtt
            .filter((s) => s.category === 'Primary' || (s.classLevel && !!s.classLevel.match(/class\s*[1-5]/i)))
            .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);
          const autoUpPriAtt = classAtt
            .filter((s) => s.category === 'Upper Primary' || s.category === 'High School' || (s.classLevel && !!s.classLevel.match(/class\s*[6-8]/i)))
            .reduce((sum, s) => sum + (s.totalPresent ?? 0), 0);

          const pAtt = autoPriAtt || dayPriRoll;
          const upAtt = autoUpPriAtt || dayUpPriRoll;
          const totalMeals = pAtt + upAtt;
          const dayOfWeek = dayInfo.dayOfWeek;

          const calculatedRice = Number(((pAtt * ((mealRates?.riceNormPrimaryGrams ?? 100) / 1000)) + (upAtt * ((mealRates?.riceNormUpperPrimaryGrams ?? 150) / 1000))).toFixed(2));
          const eggUsedQty = (dayOfWeek >= 1 && dayOfWeek <= 5) ? totalMeals * (mealRates?.eggNormQty ?? 1) : 0;
          const chikkiUsedQty = (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5) ? totalMeals * (mealRates?.chikkiNormQty ?? 1) : 0;
          const ragiUsedKg = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((totalMeals * ((mealRates?.ragiNormGrams ?? 10) / 1000)).toFixed(2)) : 0;
          const jaggeryUsedKg = (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) ? Number((totalMeals * ((mealRates?.jaggeryNormGrams ?? 10) / 1000)).toFixed(2)) : 0;

          allSynthesizedEntries.push({
            id: `synth_${dateStr}`,
            date: dateStr,
            primaryAttendance: pAtt,
            upperPrimaryAttendance: upAtt,
            highSchoolAttendance: 0,
            totalAttendance: totalMeals,
            mealsServed: totalMeals,
            riceUsedKg: calculatedRice,
            eggUsedQty,
            chikkiUsedQty,
            ragiUsedKg,
            jaggeryUsedKg,
            remarks: 'MDM Served',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }
    }
  });

  const dailyStockMap = calculateDailyCommodityStock(
    allSynthesizedEntries,
    stockTransactions,
    effectiveBaseCommodities,
    monthlyOverrides,
    continuousMonths
  );

  // Calculate Commodity Monthly Summary
  const calculateCommodityMonthSummary = (commId: 'rice' | 'egg' | 'chikki' | 'ragi' | 'jaggery') => {
    const baseObj = effectiveBaseCommodities.find((c) => c.id === commId) || commodities.find((c) => c.id === commId);
    let ob = baseObj ? baseObj.openingBalance : 0;

    // Use monthly override if explicitly defined for this month or starting date
    if (monthlyOverrides[selectedMonth]?.[commId] !== undefined && !isCustomRangeActive) {
      ob = monthlyOverrides[selectedMonth][commId];
    } else if (monthlyOverrides[`${selectedMonth}-01`]?.[commId] !== undefined && !isCustomRangeActive) {
      ob = monthlyOverrides[`${selectedMonth}-01`][commId];
    } else if (dailyStockMap[activeFromDate] && dailyStockMap[activeFromDate][commId]) {
      ob = dailyStockMap[activeFromDate][commId].ob;
    } else if (dailyStockMap[fullMonthStart] && dailyStockMap[fullMonthStart][commId]) {
      ob = dailyStockMap[fullMonthStart][commId].ob;
    } else if (monthlyOverrides[selectedMonth]?.[commId] !== undefined) {
      ob = monthlyOverrides[selectedMonth][commId];
    }

    // Received during active date range
    let receivedInMonth = 0;
    const hasExplicitJaggery = stockTransactions.some((tx) => tx.commodityId === 'jaggery');
    stockTransactions.forEach((tx) => {
      const isMatch = tx.commodityId?.toLowerCase() === commId.toLowerCase() || (!hasExplicitJaggery && commId === 'jaggery' && tx.commodityId?.toLowerCase() === 'ragi');
      if (
        isMatch &&
        tx.type === 'RECEIVED' &&
        tx.date >= activeFromDate &&
        tx.date <= effectiveToDate
      ) {
        receivedInMonth += tx.quantity;
      }
    });

    const totalObRec = ob + receivedInMonth;

    // Utilised in active date range
    let utilisedInMonth = 0;
    if (commId === 'rice') utilisedInMonth = totalRiceUsed;
    if (commId === 'egg') utilisedInMonth = totalEggsUsed;
    if (commId === 'chikki') utilisedInMonth = totalChikkiUsed;
    if (commId === 'ragi') utilisedInMonth = totalRagiUsed;
    if (commId === 'jaggery') utilisedInMonth = totalJaggeryUsed;

    // Damaged in active date range
    let damagedInMonth = 0;
    stockTransactions.forEach((tx) => {
      const isMatch = tx.commodityId?.toLowerCase() === commId.toLowerCase() || (!hasExplicitJaggery && commId === 'jaggery' && tx.commodityId?.toLowerCase() === 'ragi');
      if (
        isMatch &&
        tx.type === 'SPOILED' &&
        tx.date >= activeFromDate &&
        tx.date <= effectiveToDate
      ) {
        damagedInMonth += tx.quantity;
      }
    });

    // Invariant: Eggs & Chikki can legitimately have negative opening & closing balance (PERMANENT_APPLICATION_CONTRACT section 4.2)
    const isEggOrChikki = commId === 'egg' || commId === 'chikki';
    const rawClosing = totalObRec - utilisedInMonth - damagedInMonth;
    const closing = isEggOrChikki ? Number(rawClosing.toFixed(1)) : Math.max(0, Number(rawClosing.toFixed(1)));
    const requiredNext = Number(Math.max(0, utilisedInMonth * 1.1).toFixed(1));

    return {
      ob: Number(ob.toFixed(1)),
      rec: Number(receivedInMonth.toFixed(1)),
      totalObRec: Number(totalObRec.toFixed(1)),
      used: Number(utilisedInMonth.toFixed(1)),
      damaged: Number(damagedInMonth.toFixed(1)),
      closing: Number(closing.toFixed(1)),
      requiredNext: Number(requiredNext.toFixed(1)),
    };
  };

  const riceSummary = calculateCommodityMonthSummary('rice');
  const eggSummary = calculateCommodityMonthSummary('egg');
  const chikkiSummary = calculateCommodityMonthSummary('chikki');
  const ragiSummary = calculateCommodityMonthSummary('ragi');
  const jaggerySummary = calculateCommodityMonthSummary('jaggery');

  // Class 1 to 8 strength matrix
  const getClassStrength = (classNum: number) => {
    const listToSearch = activeStudentStrengths.length > 0 ? activeStudentStrengths : studentStrengths;
    const target = listToSearch.find((s) => s.classLevel && s.classLevel.toLowerCase().includes(`class ${classNum}`));
    if (target) {
      return { boys: target.boys, girls: target.girls, total: target.total };
    }
    // Default estimated values if strength not found
    const defaults = [
      { boys: 14, girls: 16, total: 30 },
      { boys: 18, girls: 15, total: 33 },
      { boys: 16, girls: 19, total: 35 },
      { boys: 20, girls: 17, total: 37 },
      { boys: 15, girls: 20, total: 35 },
      { boys: 25, girls: 20, total: 45 },
      { boys: 22, girls: 23, total: 45 },
      { boys: 23, girls: 23, total: 46 },
    ];
    return defaults[classNum - 1] || { boys: 0, girls: 0, total: 0 };
  };

  const c1 = getClassStrength(1);
  const c2 = getClassStrength(2);
  const c3 = getClassStrength(3);
  const c4 = getClassStrength(4);
  const c5 = getClassStrength(5);

  const totalBoysI_V = c1.boys + c2.boys + c3.boys + c4.boys + c5.boys;
  const totalGirlsI_V = c1.girls + c2.girls + c3.girls + c4.girls + c5.girls;
  const grandTotalI_V = c1.total + c2.total + c3.total + c4.total + c5.total;

  // Calculate dynamic typography and cell padding based on row count and print config presets
  const visibleRowCount = dayRows.length;
  let dynamicFontSize = '12.0pt';
  let dynamicPadding = '0.75mm 1.05mm';
  let dynamicHeaderFontSize = '10.8pt';
  let dynamicMetaFontSize = '13.2pt';

  if (printConfig.densityPreset === 'compact') {
    dynamicFontSize = '10.8pt';
    dynamicPadding = '0.55mm 0.8mm';
    dynamicHeaderFontSize = '9.8pt';
    dynamicMetaFontSize = '12.2pt';
  } else if (printConfig.densityPreset === 'standard') {
    dynamicFontSize = '12.2pt';
    dynamicPadding = '0.8mm 1.15mm';
    dynamicHeaderFontSize = '11.0pt';
    dynamicMetaFontSize = '13.5pt';
  } else if (printConfig.densityPreset === 'spacious' || printConfig.densityPreset === 'large') {
    dynamicFontSize = '13.2pt';
    dynamicPadding = '1.05mm 1.45mm';
    dynamicHeaderFontSize = '12.0pt';
    dynamicMetaFontSize = '14.5pt';
  } else if (printConfig.densityPreset === 'xlarge') {
    dynamicFontSize = '14.2pt';
    dynamicPadding = '1.2mm 1.85mm';
    dynamicHeaderFontSize = '13.0pt';
    dynamicMetaFontSize = '15.5pt';
  } else {
    // Auto density preset based on visible row count
    if (visibleRowCount <= 10) {
      dynamicFontSize = '13.8pt';
      dynamicPadding = '1.3mm 2.0mm';
      dynamicHeaderFontSize = '12.8pt';
      dynamicMetaFontSize = '15.5pt';
    } else if (visibleRowCount <= 20) {
      dynamicFontSize = '12.5pt';
      dynamicPadding = '1.0mm 1.35mm';
      dynamicHeaderFontSize = '11.2pt';
      dynamicMetaFontSize = '14.0pt';
    } else if (visibleRowCount <= 26) {
      dynamicFontSize = '11.8pt';
      dynamicPadding = '0.75mm 1.05mm';
      dynamicHeaderFontSize = '10.2pt';
      dynamicMetaFontSize = '13.2pt';
    } else {
      dynamicFontSize = '10.8pt';
      dynamicPadding = '0.55mm 0.85mm';
      dynamicHeaderFontSize = '9.5pt';
      dynamicMetaFontSize = '12.2pt';
    }
  }

  const effectivePaperSize = printConfig.paperSize || (checklist.paperA4 ? 'A4' : 'auto');
  const effectiveOrientation = printConfig.orientation || (checklist.portrait ? 'portrait' : 'landscape');
  const effectiveMargin = printConfig.marginSize || (checklist.marginsNone ? '4mm' : 'auto');
  const effectiveBgGraphics = printConfig.bgGraphics ?? checklist.bgGraphics;

  // Base A4 dimensions in CSS pixels (202mm x 286mm at 96 DPI: 1mm = 3.779527559px)
  const baseA4WidthPx = 763.46; // 202mm
  const baseA4HeightPx = 1080.94; // 286mm

  // Calculate auto-fit scale based on available container width
  const paddingOffset = 12;
  const rawAvailableWidth = containerWidth > 0 ? containerWidth : (typeof window !== 'undefined' ? window.innerWidth - 32 : baseA4WidthPx);
  const availableWidth = Math.max(280, rawAvailableWidth - paddingOffset);
  const autoFitScale = Math.min(1, availableWidth / baseA4WidthPx);

  let effectiveScale = autoFitScale;
  if (customZoom !== null) {
    effectiveScale = customZoom;
  } else if (zoomMode === '100') {
    effectiveScale = 1;
  } else {
    effectiveScale = autoFitScale;
  }

  return (
    <div className="max-w-full space-y-2 sm:space-y-2.5 pb-16 sm:pb-20 md:pb-24">
      {/* Dynamic Print Settings Override based on Calibration Checklist */}
      <style>{`
        /* Dynamic calibration based on visible row count (${visibleRowCount} days) */
        #printable-cash-voucher th:not([style*="font-size"]),
        #printable-cash-voucher td:not([style*="font-size"]) {
          font-size: ${dynamicFontSize};
        }
        #printable-cash-voucher th:not([style*="padding"]),
        #printable-cash-voucher td:not([style*="padding"]) {
          padding: ${dynamicPadding};
        }
        #printable-cash-voucher .col-span-7 th:not([style*="font-size"]),
        #printable-cash-voucher .col-span-7 td:not([style*="font-size"]) {
          font-size: ${dynamicHeaderFontSize};
        }
        #printable-cash-voucher .col-span-5:not([style*="font-size"]) {
          font-size: ${dynamicMetaFontSize};
        }

        @media print {
          @page {
            size: ${effectivePaperSize} ${effectiveOrientation} !important;
            margin: ${effectiveMargin} !important;
          }
          #printable-cash-voucher {
            ${printConfig.fitSinglePage ? 'height: 286mm !important; overflow: hidden !important;' : 'height: auto !important; overflow: visible !important;'}
            -webkit-print-color-adjust: ${effectiveBgGraphics ? 'exact' : 'unset'} !important;
            print-color-adjust: ${effectiveBgGraphics ? 'exact' : 'unset'} !important;
          }
        }
      `}</style>

      {/* Top Controls Bar (Hidden during printing) */}
      <div
        style={{ height: '229.90625px', minHeight: '229.90625px', marginBottom: '9.04px', marginTop: '-5px' }}
        className="no-print glass-3d-tile p-2.5 sm:p-3 md:p-3.5 rounded-xl sm:rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-2 sm:space-y-2.5"
      >
        {/* Title & Quick Summary Bar */}
        <div
          style={{ height: '54.575px', marginTop: '-5px' }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-2 pb-1.5 sm:pb-2 border-b border-slate-100 dark:border-slate-800/80"
        >
          <h2
            style={{ marginTop: '-10px' }}
            className="text-xs sm:text-sm md:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5"
          >
            <IndianRupee className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span
              style={{ fontSize: '12.28px', marginTop: '6px', display: 'inline-block' }}
              className="font-extrabold tracking-tight text-xs sm:text-sm md:text-[14.5px]"
            >
              Mid-Day Meal Official Cash Contingency Voucher
            </span>
          </h2>
          
          <div
            style={{ marginTop: '-6px' }}
            className="flex items-center space-x-1.5 sm:space-x-2 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-slate-300"
          >
            <span
              style={{ height: '20.35px', display: 'inline-flex', alignItems: 'center' }}
              className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-md text-[10px] sm:text-[10.5px] font-extrabold"
            >
              {dayRows.length} Days Filtered
            </span>
            <span
              style={{ height: '20.35px', display: 'inline-flex', alignItems: 'center' }}
              className="bg-blue-500/10 text-blue-700 dark:text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-md text-[10px] sm:text-[10.5px] font-extrabold font-mono"
            >
              Total: ₹{grandTotalAmount.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Action Controls & Filters Bar */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-2">
          {/* Left: Filters & Parameters Group */}
          <div
            style={{ minHeight: '93.25px', lineHeight: '22.56px', marginTop: '-10px' }}
            className="flex flex-wrap items-center gap-1.5 sm:gap-2 flex-1"
          >
            {/* Month Picker */}
            <div
              style={{ height: '19px' }}
              className="flex items-center space-x-1 sm:space-x-1.5 btn-glass-month-input shrink-0 px-2 py-0.5 rounded-md text-[11px] sm:text-xs"
            >
              <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-600 dark:text-slate-300 shrink-0" />
              <input
                type="month"
                style={{ height: '13px', fontSize: '12.28px' }}
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent text-slate-900 dark:text-white font-extrabold outline-hidden cursor-pointer"
                title="Select Voucher Month"
              />
            </div>

            {/* Class Category Selector */}
            <div className="flex items-center space-x-0.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-md border border-slate-200 dark:border-slate-700 text-[10.5px] sm:text-xs font-bold shrink-0">
              <button
                type="button"
                onClick={() => setClassCategory('I - V')}
                className={classCategory === 'I - V' ? 'btn-3d-glass-pill-active py-0.5 px-2 text-[10px] sm:text-[11px]' : 'btn-3d-glass-pill-inactive py-0.5 px-2 text-[10px] sm:text-[11px]'}
                title="Filter Primary Classes I - V"
              >
                I - V
              </button>
              <button
                type="button"
                onClick={() => setClassCategory('VI - VIII')}
                className={classCategory === 'VI - VIII' ? 'btn-3d-glass-pill-active py-0.5 px-2 text-[10px] sm:text-[11px]' : 'btn-3d-glass-pill-inactive py-0.5 px-2 text-[10px] sm:text-[11px]'}
                title="Filter Upper Primary Classes VI - VIII"
              >
                VI - VIII
              </button>
              <button
                type="button"
                onClick={() => setClassCategory('I - VIII')}
                className={classCategory === 'I - VIII' ? 'btn-3d-glass-pill-active py-0.5 px-2 text-[10px] sm:text-[11px]' : 'btn-3d-glass-pill-inactive py-0.5 px-2 text-[10px] sm:text-[11px]'}
                title="All Classes I - VIII"
              >
                I - VIII
              </button>
            </div>

            {/* Date Range Picker (From - To) */}
            <div
              style={{ height: '24.3125px', width: '250.671875px', marginTop: '-5px' }}
              className="flex flex-wrap items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 text-[10.5px] sm:text-xs font-bold shrink-0"
            >
              <span className="text-slate-500 text-[10px] sm:text-[11px] font-semibold">From:</span>
              <input
                type="date"
                style={{ fontSize: '11.28px' }}
                value={activeFromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="bg-transparent text-slate-900 dark:text-white font-bold outline-hidden cursor-pointer max-w-[115px] sm:max-w-[125px]"
                title="Filter Start Date"
              />
              <span className="text-slate-500 text-[10px] sm:text-[11px] font-semibold">To:</span>
              <input
                type="date"
                style={{ fontSize: '11.28px' }}
                value={effectiveToDate}
                max={selectedMonth >= currentMonthStr ? todayDateStr : fullMonthEnd}
                onChange={(e) => setToDate(e.target.value)}
                className="bg-transparent text-slate-900 dark:text-white font-bold outline-hidden cursor-pointer max-w-[115px] sm:max-w-[125px]"
                title="Filter End Date"
              />
              {isCustomRangeActive && (
                <button
                  type="button"
                  onClick={() => {
                    setFromDate(fullMonthStart);
                    setToDate(defaultToDate);
                  }}
                  title="Reset date range filter"
                  className="btn-3d-glass-rose ml-0.5 text-[10px] py-0.5 px-1.5 rounded-md"
                >
                  <X className="w-2.5 h-2.5" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {/* Cooks Count Input */}
            <div
              style={{ height: '28.3125px', width: '96.53125px' }}
              className="flex items-center space-x-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 text-[10.5px] sm:text-xs font-bold shrink-0"
            >
              <span
                style={{ height: '19.5625px', display: 'inline-flex', alignItems: 'center' }}
                className="text-slate-500 font-semibold text-[10px] sm:text-[11px]"
              >
                Cooks:
              </span>
              <input
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                style={{ height: '19.85px', width: '38.078125px' }}
                value={cooksCount}
                onChange={(e) => setCooksCount(parseInt(e.target.value, 10) || 1)}
                className="w-8 sm:w-9 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded text-center font-bold text-slate-900 dark:text-white text-[11px] py-0.5"
                title="Number of Cooks for Honorarium Split"
              />
            </div>

            {/* Include Holidays Filter Toggle */}
            <div
              style={{ height: '28.35px' }}
              className="flex items-center space-x-0.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-md border border-slate-200 dark:border-slate-700 text-[10.5px] sm:text-xs font-bold shrink-0"
            >
              <button
                type="button"
                onClick={() => setIncludeHolidays(true)}
                className={includeHolidays ? 'btn-3d-glass-pill-active py-0.5 px-2 text-[10px] sm:text-[10.5px]' : 'btn-3d-glass-pill-inactive py-0.5 px-2 text-[10px] sm:text-[10.5px]'}
                title="Show all days including holidays"
              >
                <span>With Holidays</span>
              </button>
              <button
                type="button"
                onClick={() => setIncludeHolidays(false)}
                className={!includeHolidays ? 'btn-3d-glass-pill-active py-0.5 px-2 text-[10px] sm:text-[10.5px]' : 'btn-3d-glass-pill-inactive py-0.5 px-2 text-[10px] sm:text-[10.5px]'}
                title="Hide holidays and show working days only"
              >
                <span>Without Holidays</span>
              </button>
            </div>

            {/* Action Buttons Group (Print, Save PDF, Exit) - Brought after Without Holidays button */}
            <div
              style={{ lineHeight: '31.56px' }}
              className="flex flex-wrap items-center gap-1.5 shrink-0"
            >
              <button
                type="button"
                style={{ height: '21px' }}
                onClick={onPrintVoucher}
                className="btn-3d-glass-sky cursor-pointer active:scale-95 px-2.5 sm:px-3 py-0 rounded-lg text-[10px] sm:text-[11px] font-bold inline-flex items-center gap-1 sm:gap-1.5"
                title="Print Cash Voucher"
              >
                <Printer className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
                <span>Print</span>
              </button>

              <button
                type="button"
                style={{ height: '19px' }}
                onClick={() => setShowPdfOptions(!showPdfOptions)}
                className="btn-3d-glass-purple cursor-pointer active:scale-95 px-2.5 sm:px-3 py-0 rounded-lg text-[10px] sm:text-[11px] font-bold inline-flex items-center gap-1 sm:gap-1.5"
                title="Configure A4 PDF Settings"
              >
                <FileDown className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
                <span>Save PDF</span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${showPdfOptions ? 'rotate-180' : ''}`} />
              </button>

              <button
                type="button"
                id="cash-voucher-exit-btn"
                style={{ height: '21px' }}
                onClick={() => {
                  if (onClose) {
                    onClose();
                  } else if (typeof window !== 'undefined' && window.history.length > 1) {
                    window.history.back();
                  }
                }}
                className="btn-3d-glass-rose cursor-pointer active:scale-95 px-2.5 sm:px-3 py-0 rounded-lg text-[10px] sm:text-[11px] font-bold inline-flex items-center gap-1 sm:gap-1.5"
                title="Exit Cash Voucher & return to Dashboard"
                aria-label="Exit Cash Voucher"
              >
                <LogOut className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
                <span>Exit</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Save as A4 PDF Calibration Assistant & Interactive Print Settings Panel */}
      {showPdfOptions && (
        <div style={{ height: '454.71875px' }} className="no-print bg-white dark:bg-slate-900/95 border border-indigo-500/20 rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-xl relative z-20 text-slate-800 dark:text-slate-100 font-sans backdrop-blur-md animate-in fade-in slide-in-from-top-3 duration-200 overflow-y-auto">
          <div style={{ height: '58.515625px', marginTop: '-11px' }} className="flex items-start justify-between mb-2.5 sm:mb-3 pb-2 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-indigo-50 dark:bg-indigo-950/40 rounded-lg border border-indigo-500/15 text-indigo-600 dark:text-indigo-400">
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span style={{ fontSize: '9.28px' }}>Print & A4 PDF Settings Manager</span>
                  <span
                    style={{ fontSize: '7.5px', lineHeight: '9.3333px' }}
                    className="px-1.5 py-0.2 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 rounded font-bold"
                  >
                    Auto-Saved
                  </span>
                </h4>
                <p style={{ lineHeight: '13px' }} className="text-[10px] sm:text-[10.5px] text-slate-500 dark:text-slate-400 font-medium">Customize paper size, font density, margins, and page orientation for perfect printing</p>
              </div>
            </div>
            <button 
              onClick={() => setShowPdfOptions(false)} 
              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4">
            {/* Interactive Print Settings Controls */}
            <div className="md:col-span-7 space-y-3">
              {/* Preset Selectors */}
              <div
                style={{ marginTop: '-11px', height: '213.828125px', lineHeight: '-3.4399990000000003px' }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-50 dark:bg-slate-800/40 p-2.5 sm:p-3 rounded-lg sm:rounded-xl border border-slate-200/60 dark:border-slate-800/80"
              >
                {/* Paper Size */}
                <div>
                  <label
                    style={{ marginTop: '-14px' }}
                    className="block text-[9.5px] sm:text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Paper Size
                  </label>
                  <div className="flex gap-1 bg-slate-200/70 dark:bg-slate-700/60 p-0.5 rounded-md text-[10.5px] font-bold">
                    {(['A4', 'Letter', 'Legal'] as const).map((size) => (
                      <button
                        key={size}
                        onClick={() => {
                          setPrintConfig({ ...printConfig, paperSize: size });
                          setChecklist({ ...checklist, paperA4: size === 'A4' });
                        }}
                        className={printConfig.paperSize === size ? 'btn-3d-glass-pill-active flex-1 text-[10px] sm:text-[10.5px] py-0.5' : 'btn-3d-glass-pill-inactive flex-1 text-[10px] sm:text-[10.5px] py-0.5'}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Orientation */}
                <div>
                  <label
                    style={{ marginTop: '-11px' }}
                    className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1.5"
                  >
                    Orientation
                  </label>
                  <div
                    style={{ marginTop: '-9px', height: '30.5px', paddingTop: '0.7599999999999998px' }}
                    className="flex gap-1 bg-slate-200/70 dark:bg-slate-700/60 p-1 rounded-lg text-xs font-bold"
                  >
                    {(['portrait', 'landscape'] as const).map((orient) => (
                      <button
                        key={orient}
                        onClick={() => {
                          setPrintConfig({ ...printConfig, orientation: orient });
                          setChecklist({ ...checklist, portrait: orient === 'portrait' });
                        }}
                        className={printConfig.orientation === orient ? 'btn-3d-glass-pill-active flex-1 capitalize text-[11px]' : 'btn-3d-glass-pill-inactive flex-1 capitalize text-[11px]'}
                      >
                        {orient}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Margins */}
                <div>
                  <label
                    style={{ marginTop: '-14px' }}
                    className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1.5"
                  >
                    Page Margins
                  </label>
                  <div
                    style={{ height: '26.5px', paddingTop: '-0.2400000000000002px', marginTop: '-7px' }}
                    className="flex gap-1 bg-slate-200/70 dark:bg-slate-700/60 p-1 rounded-lg text-xs font-bold"
                  >
                    {[
                      { label: 'None (4mm)', value: '4mm' },
                      { label: 'Narrow (8mm)', value: '8mm' },
                      { label: 'Normal (12mm)', value: '12mm' },
                    ].map((margin) => (
                      <button
                        key={margin.value}
                        onClick={() => {
                          setPrintConfig({ ...printConfig, marginSize: margin.value });
                          setChecklist({ ...checklist, marginsNone: margin.value === '4mm' });
                        }}
                        className={printConfig.marginSize === margin.value ? 'btn-3d-glass-pill-active flex-1 text-[10px]' : 'btn-3d-glass-pill-inactive flex-1 text-[10px]'}
                      >
                        {margin.label.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Text Font Scale */}
                <div>
                  <label
                    style={{ marginTop: '-9px' }}
                    className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1.5"
                  >
                    Text Font Size Scale
                  </label>
                  <div
                    style={{ height: '29.5px', paddingTop: '1.7599999999999998px', marginTop: '-5px' }}
                    className="flex gap-1 bg-slate-200/70 dark:bg-slate-700/60 p-1 rounded-lg text-xs font-bold flex-wrap sm:flex-nowrap"
                  >
                    {[
                      { label: 'Auto Fit', value: 'auto' },
                      { label: 'Compact', value: 'compact' },
                      { label: 'Standard', value: 'standard' },
                      { label: 'Large', value: 'large' },
                      { label: 'X-Large', value: 'xlarge' },
                    ].map((density) => (
                      <button
                        key={density.value}
                        onClick={() => setPrintConfig({ ...printConfig, densityPreset: density.value })}
                        className={printConfig.densityPreset === density.value ? 'btn-3d-glass-pill-active flex-1 text-[10px]' : 'btn-3d-glass-pill-inactive flex-1 text-[10px]'}
                      >
                        {density.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Toggles & Checkbox Checklist */}
              <div
                style={{ height: '141.125px', marginTop: '-18px', lineHeight: '-2.44px' }}
                className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-800/80"
              >
                <h5 className="text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span style={{ fontSize: '9px', marginTop: '-10px' }} className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-indigo-500" />
                    Print Quality & Layout Toggles
                  </span>
                  <button
                    onClick={() => {
                      setPrintConfig({
                        paperSize: 'A4',
                        orientation: 'portrait',
                        marginSize: '4mm',
                        densityPreset: 'auto',
                        fitSinglePage: true,
                        bgGraphics: true,
                      });
                      setChecklist({
                        paperA4: true,
                        marginsNone: true,
                        bgGraphics: true,
                        portrait: true,
                      });
                    }}
                    className="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline font-bold cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                </h5>

                <div className="space-y-2.5">
                  <label className="flex items-start gap-2.5 cursor-pointer group text-[11px]">
                    <input
                      type="checkbox"
                      checked={printConfig.bgGraphics}
                      onChange={(e) => {
                        setPrintConfig({ ...printConfig, bgGraphics: e.target.checked });
                        setChecklist({ ...checklist, bgGraphics: e.target.checked });
                      }}
                      className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500/30 h-3.5 w-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span
                        style={{ fontSize: '9px' }}
                        className="font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors"
                      >
                        Background Colors & Graphics: Enabled
                      </span>
                      <p className="text-[9.5px] text-slate-500 dark:text-slate-400 mt-0.5">Prints table headers, Sunday red stripes, borders, and signature highlights cleanly.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer group text-[11px]">
                    <input
                      type="checkbox"
                      checked={printConfig.fitSinglePage}
                      onChange={(e) => setPrintConfig({ ...printConfig, fitSinglePage: e.target.checked })}
                      className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500/30 h-3.5 w-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span
                        style={{ fontSize: '9px' }}
                        className="font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors"
                      >
                        Strict 1-Page Height Boundary Lock
                      </span>
                      <p className="text-[9.5px] text-slate-500 dark:text-slate-400 mt-0.5">Locks voucher height to 286mm to prevent trailing page spills when downloading as PDF.</p>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Quick Export Actions */}
            <div
              style={{ height: '237.796875px', lineHeight: '-6.4399999999999995px' }}
              className="md:col-span-5 flex flex-col justify-between space-y-4 bg-indigo-50/20 dark:bg-slate-800/20 p-4 rounded-2xl border border-indigo-500/10"
            >
              <div style={{ marginTop: '-31px', lineHeight: '-4.439999px', fontSize: '20.040001px' }} className="space-y-3">
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-300 border border-emerald-500/25">
                  Export Actions
                </span>
                <h5 style={{ marginTop: '-8px' }} className="text-[12px] font-extrabold text-slate-900 dark:text-white">Print or Download PDF Now</h5>
                <p style={{ marginTop: '-11px' }} className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal font-medium">
                  Your current print settings ({printConfig.paperSize} {printConfig.orientation}, Margins: {printConfig.marginSize}, Density: {printConfig.densityPreset}) will be applied automatically to your print preview and PDF export.
                </p>
              </div>

              <div style={{ marginTop: '-20px', paddingTop: '-3.4800000000000004px' }} className="space-y-2.5 pt-2">
                <button
                  style={{ height: '21px', marginTop: '-16px' }}
                  onClick={onPrintVoucher}
                  className="w-full btn-glass-pdf justify-center"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print / Save as PDF ({printConfig.paperSize})</span>
                </button>

                <button
                  style={{ height: '28.0625px', fontSize: '11.28px' }}
                  onClick={() => {
                    const shareUrl = window.location.href;
                    navigator.clipboard.writeText(shareUrl).then(() => {
                      setCopySuccess(true);
                      setTimeout(() => setCopySuccess(false), 2500);
                    }).catch(err => {
                      console.error('Could not copy link', err);
                    });
                  }}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:active:bg-slate-600 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl font-bold transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {copySuccess ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-500" />
                      <span style={{ fontSize: '12.28px' }} className="text-emerald-600 dark:text-emerald-400 font-extrabold">Copied Report Share Link!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-slate-500" />
                      <span style={{ fontSize: '12.28px' }}>Copy Report Share Link</span>
                    </>
                  )}
                </button>

                {navigator.share && (
                  <button
                    style={{ height: '27.0625px' }}
                    onClick={() => {
                      navigator.share({
                        title: `Mid-Day Meal Cash Voucher - ${monthName}`,
                        text: `Verify the official MDM Cash Voucher for ${monthName}.`,
                        url: window.location.href
                      }).catch(err => console.log('Share aborted', err));
                    }}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all flex items-center justify-center space-x-2 shadow-lg shadow-indigo-600/10 cursor-pointer active:scale-[0.98]"
                  >
                    <FileDown className="w-4 h-4" />
                    <span style={{ fontSize: '11.28px', paddingTop: '0px', marginTop: '-6px' }}>Share Report Digitally</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1:1 A4 Paper Canvas Screen Preview Wrapper (Auto-responsive for Mobile, Tablet & Desktop) */}
      <div
        ref={containerRef}
        style={{ marginTop: '6.52px' }}
        className="no-print-canvas w-full p-1 sm:p-2 md:p-2.5 bg-slate-50/90 dark:bg-slate-950/80 rounded-xl sm:rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col items-center overflow-x-auto print:p-0 print:m-0 print:bg-white print:border-none print:shadow-none print:overflow-visible"
      >
        <div
          style={{ minHeight: '81.5px', marginTop: '-6px' }}
          className="no-print w-full flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-2 mb-2 px-1 text-[10px] sm:text-[10.5px] font-bold text-slate-600 dark:text-slate-300"
        >
          <div
            style={{ height: '41.734375px', marginTop: '2px', display: 'flex', alignItems: 'center' }}
            className="flex flex-wrap items-center gap-1.5"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
            <span className="truncate">
              1:1 Exact A4 Paper Sheet Preview ({printConfig.paperSize} {printConfig.orientation})
            </span>
            <span className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.2 rounded-full text-[9px] sm:text-[9.5px] font-mono whitespace-nowrap">
              {Math.round(effectiveScale * 100)}% {zoomMode === 'auto' && customZoom === null ? 'Responsive Fit' : 'Zoom'}
            </span>
          </div>

          {/* Interactive Responsive Zoom Toolbar */}
          <div className="flex flex-wrap items-center gap-1 bg-white/95 dark:bg-slate-900/90 p-1 rounded-lg border border-slate-200/90 dark:border-slate-800 shadow-2xs max-w-full overflow-x-auto">
            <button
              type="button"
              onClick={() => { setZoomMode('auto'); setCustomZoom(null); }}
              className={zoomMode === 'auto' && customZoom === null ? 'btn-3d-glass-zoom-active text-[9.5px] px-2 py-0.5' : 'btn-3d-glass-zoom text-[9.5px] px-2 py-0.5'}
              title="Automatically adjust voucher size to fit current mobile/device screen width"
            >
              Auto Fit
            </button>
            <button
              type="button"
              onClick={() => { setZoomMode('100'); setCustomZoom(null); }}
              className={zoomMode === '100' && customZoom === null ? 'btn-3d-glass-zoom-active text-[9.5px] px-2 py-0.5' : 'btn-3d-glass-zoom text-[9.5px] px-2 py-0.5'}
            >
              100%
            </button>

            <div className="h-3 w-px bg-slate-200 dark:bg-slate-700 mx-0.5 shrink-0"></div>

            <button
              type="button"
              onClick={() => setCustomZoom(Math.max(0.25, Math.round((effectiveScale - 0.05) * 100) / 100))}
              className="btn-3d-glass-zoom p-1 text-[11px]"
              title="Zoom Out"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setCustomZoom(Math.min(1.5, Math.round((effectiveScale + 0.05) * 100) / 100))}
              className="btn-3d-glass-zoom p-1 text-[11px]"
              title="Zoom In"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Scaled Voucher Canvas Container for Mobile, Tablet & Desktop Aspect Ratio Responsiveness */}
        <div
          className="voucher-preview-scale-wrapper transition-all duration-200 ease-out flex justify-center"
          style={{
            width: `${baseA4WidthPx * effectiveScale}px`,
            height: `${baseA4HeightPx * effectiveScale}px`,
            maxWidth: '100%',
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <div
            className="voucher-preview-scale-inner"
            style={{
              width: '202mm',
              height: '286mm',
              transform: `scale(${effectiveScale})`,
              transformOrigin: 'top left',
              position: 'absolute',
              top: 0,
              left: 0
            }}
          >
            {/* Official Cash Voucher Document Canvas */}
            <div
              id="printable-cash-voucher"
              className="bg-white text-slate-900 p-0 rounded-none shadow-2xl space-y-0 font-sans text-xs relative overflow-hidden shrink-0 print:shadow-none print:border-none"
              style={{ borderWidth: '2px', backgroundColor: '#ffffff', borderColor: '#000304', borderStyle: 'solid' }}
            >
        {/* TOP HEADER SECTION */}
        <div className="border-slate-900" style={{ height: '255.46875px', marginTop: '-1px', backgroundColor: '#ffffff', borderWidth: '0px' }}>
          <div className="grid grid-cols-12 border-b-2 border-slate-900 text-center items-center font-bold" style={{ height: '42.625px' }}>
            {/* Class Box Top Left */}
            <div
              className="col-span-2 border-r-2 border-slate-900 p-1.5 bg-slate-100 text-[16px] print:text-[16px] font-black text-slate-900"
              style={{
                width: '104.234375px',
                height: '33.25px',
                marginTop: '-6px',
                marginLeft: '1px',
                borderColor: '#ffffff',
                fontSize: '20px',
                textAlign: 'center'
              }}
            >
              {classCategory}
            </div>
            {/* Center Voucher Title */}
            <div className="col-span-10 py-0.5 px-1 uppercase tracking-wide leading-tight" style={{ height: '38.625px' }}>
              <h1 className="font-black text-slate-900 leading-none" style={{ fontSize: '21px', paddingRight: '41px', marginRight: '29px', paddingLeft: '-4px', marginLeft: '-10px', marginTop: '0px', marginBottom: '0px' }}>CASH VOUCHER</h1>
              <p className="text-[12px] print:text-[12px] font-bold text-slate-800 leading-none mt-0.5" style={{ marginTop: '1.875px', fontSize: '13px' }}>
                DAY WISE CASH VOUCHER FOR SERVING OF MID DAY MEALS
              </p>
            </div>
          </div>

          {/* School Header Line */}
          <div className="py-0.5 border-b-2 border-slate-900 bg-slate-50 font-bold flex flex-wrap items-center justify-between gap-1 tracking-normal" style={{ height: '54.59375px', width: '759.65625px', marginBottom: '-2px', marginTop: '2px', paddingLeft: '15px', paddingRight: '5px', paddingBottom: '7.88px', paddingTop: '0.88px', lineHeight: '0px', fontSize: '18.280001px' }}>
            <div className="text-[14px] print:text-[14px]">
              <span className="text-slate-600 text-[14px]">School Name :</span>{' '}
              <span className="text-slate-900 font-extrabold text-[13px] print:text-[13px]" style={{ paddingTop: '-1px', paddingBottom: '0px', paddingRight: '10px', paddingLeft: '6px', textAlign: 'center', marginLeft: '3px', marginRight: '-2px', marginTop: '2px', marginBottom: '0px', fontSize: '16px', width: '0px', height: '-2px' }}>
                {schoolProfile.schoolName ? schoolProfile.schoolName.replace(/R\.\s*B\.\s*R\.\s*PETA/gi, 'R.B.R.PETA') : ''}
              </span>
            </div>
            <div className="text-left flex items-center justify-start gap-1 text-[14px] print:text-[14px]" style={{ height: '21px', width: '241.609375px', fontSize: '14px', marginTop: '0px', marginLeft: '0px', marginRight: '100px', marginBottom: '0px', paddingBottom: '-10px', paddingTop: '4px', paddingLeft: '35px', textAlign: 'left' }}>
              <span className="text-slate-600 text-left inline-block text-[14px]" style={{ paddingBottom: '0px', paddingLeft: '-2px', paddingRight: '26px', paddingTop: '4px', width: '61.828125px', marginRight: '7px', height: '14px', marginLeft: '-135px', marginTop: '5px', fontSize: '16px' }}>Village :</span>{' '}
              <span className="text-slate-900 font-extrabold text-[14px] print:text-[14px]" style={{ paddingRight: '1px', paddingBottom: '7px', paddingTop: '8px', paddingLeft: '-4px', marginRight: '37px', fontSize: '17px', marginLeft: '-10px', width: '192.640625px', marginBottom: '-6px', marginTop: '-2px', height: '17px' }}>
                {(schoolProfile.village || (schoolProfile.address ? schoolProfile.address.split(',')[0]?.trim() : 'R.B.R.PETA')).replace(/R\.\s*B\.\s*R\.\s*PETA/gi, 'R.B.R.PETA')}
              </span>
            </div>
            <div className="text-[13px] print:text-[13px]" style={{ marginRight: '-16px', paddingBottom: '0px', paddingTop: '-4px', marginLeft: '-39px', width: '249.875px', fontSize: '11px', height: '15px' }}>
              <span className="text-slate-600 text-[14px] pl-[42px] pr-[64px] pb-[1px] pt-0 w-auto h-auto inline-block" style={{ height: '11px', marginTop: '2px', marginRight: '-3px', marginBottom: '3px', marginLeft: '1px', paddingTop: '0px', paddingBottom: '0px', paddingRight: '22px', paddingLeft: '42px' }}>Mandal :</span>{' '}
              <span className="text-slate-900 font-extrabold text-[12px] leading-[12px] pl-[17px] pr-[10px] pb-[2px] text-left inline-block" style={{ fontSize: '15px', width: '97px', marginTop: '0px', marginLeft: '-20px' }}>{schoolProfile.mandal || 'PALAKONDA'}</span>
            </div>
            <div className="text-[13px] print:text-[13px]" style={{ marginTop: '4px', marginBottom: '1px', marginLeft: '0px', paddingBottom: '3px', paddingTop: '4px', marginRight: '246px', width: '291.625px', paddingRight: '-1px', height: '14px' }}>
              <span className="text-slate-600 text-[14px] print:text-[14px] w-auto" style={{ marginRight: '20px', paddingBottom: '0px', width: 'auto', paddingLeft: '13px', marginLeft: '-13px' }}>District :</span>{' '}
              <span className="text-slate-900 font-extrabold text-[12px] print:text-[12px]" style={{ marginRight: '25px', paddingBottom: '0px', paddingTop: '0px', paddingRight: '-1px', paddingLeft: '12px', fontSize: '13px', width: 'auto', marginLeft: '-16px' }}>{schoolProfile.district || 'PARVATHI PURAM MANYAM'}</span>
            </div>
            <div className="text-[13px] print:text-[13px]" style={{ paddingTop: '7px', marginTop: '-27px', width: '217.65625px', marginLeft: '522px', height: '19px', marginRight: '1px', marginBottom: '2px', paddingBottom: '6px', paddingRight: '-1px', paddingLeft: '-6px', fontSize: '19px' }}>
              <span className="text-slate-600 text-[14px] print:text-[14px] pl-[5px] pr-[27px]" style={{ paddingBottom: '-1px', paddingTop: '-2px', paddingRight: '31px', marginTop: '6px', marginLeft: '-39px', width: 'auto', marginRight: '-28px' }}>Period :</span>{' '}
              <span className="text-slate-900 font-extrabold text-[13px] print:text-[13px]" style={{ paddingRight: '29px', paddingBottom: '-3px', paddingTop: '0px', marginRight: '-48px', marginBottom: '2px', marginTop: '2px', marginLeft: '7px', fontSize: '21px' }}>
                {monthName}
              </span>
            </div>
          </div>

          {/* Two-Column Details & Commodity Summary Matrix */}
          <div className="grid grid-cols-12 text-xs print:text-[9.5px] divide-x-2 divide-slate-900" style={{ height: '164px', marginTop: '0px', marginLeft: '-5px' }}>
            {/* Left Meta Info */}
            <div className="col-span-5 p-1 space-y-0 font-bold text-slate-800 leading-[1.15] [word-spacing:1px]" style={{ paddingLeft: '9px', paddingRight: '5px', marginLeft: '3px', marginRight: '2px', marginTop: '5px', marginBottom: '-15px', width: '275.09375px', height: '130.296875px', fontWeight: 'bold', lineHeight: '16.326666px', fontSize: '15.066667px', borderColor: '#ffffff' }}>
              <div className="flex justify-between border-b border-slate-300 pb-[1px]" style={{ width: '284.5px', paddingTop: '-4px', height: '15px', marginTop: '-2px' }}>
                <span className="text-slate-600" style={{ fontSize: '13.666666px' }}>UDISE CODE :</span>
                <span className="font-mono text-slate-900" style={{ fontSize: '16.666666px', width: '180.140625px', height: '17px', paddingLeft: '11px' }}>{schoolProfile.udiseCode}</span>
              </div>
              <div className="flex justify-between border-b border-slate-300 pb-[1px] pt-[1px]" style={{ height: '35px' }}>
                <span className="text-slate-600" style={{ width: '82.328125px', height: '23px', fontSize: '14.666666px', lineHeight: '10.326666px', marginTop: '0px', paddingLeft: '4px' }}>Implement Agency :</span>
                <span className="text-slate-900 truncate max-w-full" style={{ height: '30px', marginLeft: '-2px', paddingBottom: '-2px', paddingRight: '-1px', marginRight: '-7px', width: '166.03125px', fontSize: '14.666666px' }}>{schoolProfile.implementingAgency}</span>
              </div>
              <div className="flex justify-between border-b border-slate-300 pb-[1px] pt-[1px]" style={{ height: '28px' }}>
                <span className="text-slate-600" style={{ height: '24px', width: '121.515625px', lineHeight: '10.326666px', paddingTop: '0px', paddingBottom: '2px', paddingLeft: '0px', paddingRight: '1px', marginLeft: '4px', marginTop: '8px' }}>Bank name :</span>
                <span className="text-slate-900" style={{ paddingLeft: '0px', paddingRight: '2px', paddingTop: '6px', height: '30px', fontSize: '14.066668px', width: '272.4375px', lineHeight: '14.326666px', textAlign: 'center', marginTop: '-2px' }}>{schoolProfile.bankName}</span>
              </div>
              <div className="flex justify-between border-b border-slate-300 pb-[1px] pt-[1px]" style={{ marginTop: '2px', paddingTop: '-1px', height: '17px' }}>
                <span className="text-slate-600" style={{ fontSize: '12.066667px', width: '125.96875px' }}>Bank account :</span>
                <span className="font-mono text-slate-900" style={{ width: '174.140625px', height: '18px', fontSize: '14.666666px', paddingLeft: '24px' }}>{schoolProfile.accountNumber}</span>
              </div>
              <div className="flex justify-between border-b border-slate-300 pb-[1px] pt-[1px]" style={{ marginTop: '0px', height: '17px' }}>
                <span className="text-slate-600">Working Days :</span>
                <span className="text-slate-900" style={{ width: '69.21875px' }}>{workingDaysCount}</span>
              </div>
              <div className="flex justify-between border-b border-slate-300 pb-[1px] pt-[1px]" style={{ marginTop: '4px', marginLeft: '0px', height: '17px' }}>
                <span className="text-slate-600" style={{ marginTop: '-4px', lineHeight: '10.326666px', fontSize: '13.066667px', width: '198.3125px' }}>Average meals taken :</span>
                <span className="text-slate-900" style={{ fontSize: '12.666666px', width: '105.6875px', paddingTop: '0px', marginLeft: '-26px' }}>{avgMealsTaken} ({avgMealsPercentage}%)</span>
              </div>
              <div className="flex justify-between pt-[1px]" style={{ paddingTop: '5px', marginTop: '-4px', marginLeft: '-2px', height: '17px' }}>
                <span className="text-slate-600">No of cook & helpers :</span>
                <span className="text-slate-900" style={{ width: '75.046875px', height: '18px' }}>{cooksCount}</span>
              </div>
            </div>

            {/* Right Commodity Summary Table */}
            <div className="col-span-7 p-0" style={{ fontSize: dynamicFontSize, height: '164px', marginTop: '-1px', width: '482.75px', marginLeft: '-36px' }}>
              <table className="w-full text-center border-collapse" style={{ height: '156px', marginLeft: '-2px', marginTop: '3px' }}>
                <thead>
                  <tr className="bg-slate-100 font-bold border-b border-slate-900 text-slate-900" style={{ fontSize: '11.5px' }}>
                    <th className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ width: '127.921875px', height: '19.625px', fontSize: '10px', marginLeft: '-2px' }}>
                      <div className="flex items-center justify-between pr-1" style={{ width: '154.515625px' }}>
                        <span style={{ fontSize: '10px', width: '104.125px' }}>MID-DAY MEALS PROGRAM</span>
                      </div>
                    </th>
                    <th className="p-0.5 border-r border-slate-900 w-9" style={{ width: '68.859375px' }}>Rice</th>
                    <th className="p-0.5 border-r border-slate-900 w-9" style={{ width: '60.28125px' }}>Eggs</th>
                    <th className="p-0.5 border-r border-slate-900 w-9" style={{ width: '59.1875px' }}>Chikki</th>
                    <th className="p-0.5 border-r border-slate-900 w-9" style={{ width: '61.90625px' }}>Raagi</th>
                    <th className="p-0.5 w-9" style={{ width: '61.9375px' }}>Jaggery</th>
                  </tr>
                </thead>
                <tbody 
                  onClick={() => setShowOpeningModal(true)}
                  className="divide-y divide-slate-800 text-slate-900 font-semibold cursor-pointer hover:bg-amber-50/30 transition-colors"
                  title="Click to update commodities and balances for this month"
                >
                  <tr style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '20.625px', fontSize: '11px', width: '154.65px' }}>Opening Balance</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.ob}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.ob}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.ob}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.ob}</td>
                    <td className="p-0.5">{jaggerySummary.ob}</td>
                  </tr>
                  <tr style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '18.625px', width: '152.921875px' }}>Received all phases</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.rec}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.rec}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.rec}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.rec}</td>
                    <td className="p-0.5">{jaggerySummary.rec}</td>
                  </tr>
                  <tr className="bg-slate-50 font-bold" style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '21.625px' }}>Total OB + Received</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.totalObRec}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.totalObRec}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.totalObRec}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.totalObRec}</td>
                    <td className="p-0.5">{jaggerySummary.totalObRec}</td>
                  </tr>
                  <tr style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '20.625px' }}>Utilised or Supplied</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.used}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.used}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.used}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.used}</td>
                    <td className="p-0.5">{jaggerySummary.used}</td>
                  </tr>
                  <tr style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '19.625px' }}>Damaged or Expired</td>
                    <td className="p-0.5 border-r border-slate-900" style={{ height: '18.625px' }}>{riceSummary.damaged}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.damaged}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.damaged}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.damaged}</td>
                    <td className="p-0.5">{jaggerySummary.damaged}</td>
                  </tr>
                  <tr className="bg-slate-100 font-bold" style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '20.625px', fontSize: '11px' }}>Closing balance</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.closing}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.closing}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.closing}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.closing}</td>
                    <td className="p-0.5">{jaggerySummary.closing}</td>
                  </tr>
                  <tr style={{ height: '15px' }}>
                    <td className="p-0.5 border-r border-slate-900 text-left pl-1.5" style={{ height: '18.625px', fontSize: '10.5px' }}>Required for next month</td>
                    <td className="p-0.5 border-r border-slate-900">{riceSummary.requiredNext}</td>
                    <td className="p-0.5 border-r border-slate-900">{eggSummary.requiredNext}</td>
                    <td className="p-0.5 border-r border-slate-900">{chikkiSummary.requiredNext}</td>
                    <td className="p-0.5 border-r border-slate-900">{ragiSummary.requiredNext}</td>
                    <td className="p-0.5">{jaggerySummary.requiredNext}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* MAIN DAY WISE CASH VOUCHER TABLE */}
        <div className="overflow-x-auto" style={{ height: '709.046875px', marginTop: '11.765625px', borderColor: '#000208' }}>
          <table className="w-full text-center border-collapse border-2 border-slate-900" style={{ fontSize: dynamicFontSize, lineHeight: '14px', marginLeft: '0px', marginRight: '0px', marginTop: '1px', height: '682.046875px', marginBottom: '0px' }}>
            <thead>
              <tr className="bg-slate-200 font-bold text-slate-900 border-b-2 border-slate-900 leading-tight whitespace-normal break-words" style={{ fontSize: '9.5px' }}>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ height: '16px', width: '27.8125px', fontSize: '9.5px' }}>S.No</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ height: '16px', width: '52.578125px', fontSize: '9.5px' }}>Date</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '9.5px', width: '35.46875px' }}>Day</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '6.8px', width: '28.875px' }}>Roll Pri</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '5.5px', width: '22.109375px', height: '16px' }}>Roll Up.Pri</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '5.2px', textAlign: 'left', width: '28.171875px' }}>Total Roll</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '6.8px', width: '28.015625px' }}>Att Pri</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '8px', width: '32.90625px' }}>Att Up.Pri</th>
                <th className="p-0.5 border-r border-slate-900 w-[36px] whitespace-normal break-words align-middle" style={{ fontSize: '8px' }}>Present</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '7.5px', textAlign: 'center', width: '30.90625px' }}>Meals Taken</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '7.5px', width: '18.671875px' }}>Meals Not Taken</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ width: '41.625px', height: '16px', fontSize: '8px', textAlign: 'left' }}>Rice Used</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '7.5px', width: '31.25px' }}>Eggs Used</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ fontSize: '7.2px', width: '30.78125px', height: '16px' }}>Chikki Used</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ width: '38.796875px', fontSize: '8px' }}>Raagi Used</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ width: '37.734375px', fontSize: '8px' }}>Jaggery Used</th>
                <th className="p-0.5 border-r border-slate-900 whitespace-normal break-words align-middle" style={{ width: '48.078125px', fontSize: '8px', textAlign: 'center' }}>Amount per Child (₹)</th>
                <th className="p-0.5 w-[58px] whitespace-normal break-words align-middle" style={{ width: '58.703125px', fontSize: '8.5px', height: '16px', textAlign: 'center', lineHeight: '10px', padding: '1px' }}>Amount per Day (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-400 font-semibold text-slate-900">
              {dayRows.map((row) => {
                const isHolidayRow = !row.isWorkingDay;
                return (
                  <tr
                    key={row.sNo}
                    style={{
                      height: isHolidayRow ? '11px' : '14px',
                      lineHeight: isHolidayRow ? '10px' : '13px'
                    }}
                    className={
                      isHolidayRow
                        ? 'bg-red-50/70 font-semibold'
                        : 'hover:bg-slate-50'
                    }
                  >
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-bold ${isHolidayRow ? 'text-red-600 bg-red-100/60' : ''}`} style={{ fontSize: isHolidayRow ? '8.5px' : '10.5px' }}>{row.sNo}</td>
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-mono font-bold ${isHolidayRow ? 'text-red-600 bg-red-100/60' : ''}`} style={{ fontSize: isHolidayRow ? '8.5px' : '10px', width: '79.5px' }}>{row.formattedDate}</td>
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-bold ${isHolidayRow ? 'text-red-600 bg-red-100/60' : ''}`} style={{ fontSize: isHolidayRow ? '8px' : '10px' }}>{row.shortDay}</td>
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-bold`} style={{ fontSize: isHolidayRow ? '8.5px' : '10.5px' }}>{row.rollPri}</td>
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-bold`} style={{ fontSize: isHolidayRow ? '8px' : '10px' }}>{row.rollUpPri}</td>
                    <td className={`p-0.5 ${isHolidayRow ? 'py-0' : 'py-0'} border-r border-slate-400 font-bold`} style={{ fontSize: isHolidayRow ? '8.5px' : '10.5px' }}>{row.roll}</td>

                    {row.isWorkingDay ? (
                      <>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.attPri > 0 ? row.attPri : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold">{row.attUpPri > 0 ? row.attUpPri : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-black" style={{ fontSize: '10.5px' }}>{row.present}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-black" style={{ fontSize: '10.5px' }}>{row.mealsTaken}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400" style={{ fontSize: '10px' }}>{row.mealsNotTaken}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.riceUsed > 0 ? row.riceUsed : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.eggUsed > 0 ? row.eggUsed : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.chikkiUsed > 0 ? row.chikkiUsed : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.ragiUsed > 0 ? row.ragiUsed : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-bold" style={{ fontSize: '10px' }}>{row.jaggeryUsed > 0 ? row.jaggeryUsed : '-'}</td>
                        <td className="p-0.5 py-0 border-r border-slate-400 font-mono font-bold" style={{ fontSize: '10px', width: '48px' }}>₹{row.amountPerChild.toFixed(2)}</td>
                        <td className="p-0.5 py-0 font-mono font-black" style={{ fontSize: '10.5px' }}>₹{row.amountPerDay.toFixed(2)}</td>
                      </>
                    ) : (
                      <>
                        <td colSpan={11} className={`p-0.5 py-0 border-r border-slate-400 text-center font-bold italic tracking-wide ${row.isSunday || row.isHoliday ? 'text-red-600 bg-red-100' : 'text-slate-800'}`} style={{ fontSize: '8.5px', height: '11px', lineHeight: '10px' }}>
                          {row.label}
                        </td>
                        <td className="p-0.5 py-0 font-mono text-slate-400" style={{ fontSize: '8.5px', height: '11px', lineHeight: '10px' }}>-</td>
                      </>
                    )}
                  </tr>
                );
              })}
            </tbody>
            {/* TOTAL ROW */}
            <tfoot>
              <tr className="bg-slate-200 font-black text-slate-900 border-t-2 border-slate-900" style={{ fontSize: dynamicHeaderFontSize }}>
                <td colSpan={3} className="p-0.5 border-r border-slate-900 text-center uppercase tracking-wider" style={{ height: '18px', fontSize: '10px', width: '149.40625px' }}>
                  TOTAL
                </td>
                <td className="p-0.5 border-r border-slate-900"></td>
                <td className="p-0.5 border-r border-slate-900"></td>
                <td className="p-0.5 border-r border-slate-900"></td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalPrimaryAttendanceCount}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '8px' }}>{totalUpperPrimaryAttendanceCount}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalPresentCount}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalMealsServedCount}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '8px' }}>{totalMealsNotTakenCount}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalRiceUsed.toFixed(1)}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalEggsUsed}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalChikkiUsed}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalRagiUsed.toFixed(1)}</td>
                <td className="p-0.5 border-r border-slate-900 font-black" style={{ fontSize: '10px' }}>{totalJaggeryUsed.toFixed(1)}</td>
                <td className="p-0.5 border-r border-slate-900" style={{ height: '12px', fontSize: '8px' }}>-</td>
                <td className="p-0.5 font-mono font-black" style={{ fontSize: '11px', height: '18px', fontStyle: 'normal', fontWeight: 'bold', fontFamily: 'Arial', width: '71.09375px' }}>₹{grandTotalAmount.toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* FOOTER SECTION: Amount in Words, Student Strength Matrix & Signatures */}
        <div className="space-y-0 print:space-y-0 pt-0" style={{ height: '137px', marginTop: '-7px' }}>
          {/* Amount in Words Row */}
          <div className="p-1 bg-slate-100 border-2 border-slate-900 font-bold text-[12px] print:text-[8.5px] flex items-center justify-between gap-2 [word-spacing:2px]" style={{ width: '761.84375px', height: '34.5px', paddingLeft: '7px', paddingRight: '20px', paddingTop: '-11.72px', paddingBottom: '3.28px', marginLeft: '0px', marginRight: '-28px', marginTop: '4px', marginBottom: '-6px' }}>
            <div className="flex items-center" style={{ marginLeft: '0px', marginTop: '0px', fontSize: '12px' }}>
              <span className="text-slate-900 font-extrabold text-[12px] print:text-[9px] [word-spacing:2.5px]" style={{ width: '588.59375px', fontSize: '15.5px', height: '32px', lineHeight: '15.5px', textAlign: 'center', fontFamily: 'Arial', fontStyle: 'normal', marginLeft: '0px', marginRight: '15px', paddingLeft: '2px', paddingRight: '219px', marginTop: '0px' }}>{numToWords(roundedGrandTotal)}</span>
            </div>
            <div className="font-mono text-[12px] print:text-[9px] font-black text-slate-900 shrink-0" style={{ width: '171.328125px', fontSize: '15.5px', marginLeft: '-48px', lineHeight: '15.5px', marginTop: '-2px', fontFamily: 'Arial', textAlign: 'right', paddingRight: '5px' }}>
              Amount Claimed (INR): ₹{roundedGrandTotal}
            </div>
          </div>

          {/* Signature Blocks */}
          <div className="grid grid-cols-3 gap-3 items-end pt-4 pb-2 text-center text-[8.5px] print:text-[6.5px] font-bold text-slate-900" style={{ height: '93px', marginTop: '11px' }}>
            {/* Left Corner Signature: Implementing Agency */}
            <div className="flex flex-col justify-end items-center text-center h-[100px] p-1" style={{ height: '63px', marginTop: '-15px', paddingTop: '11.76px', marginLeft: '6px', paddingLeft: '2.2799999999999994px', paddingRight: '6.28px', paddingBottom: '37px', marginBottom: '2px', marginRight: '7px' }}>
              <div className="leading-tight font-extrabold flex flex-col items-center justify-center">
                <span style={{ fontSize: '9.5px' }}>Signature & Seal of</span>
                <span style={{ fontSize: '9.5px' }}>Implementing Agency</span>
              </div>
            </div>

            {/* Middle Signature: Headmaster / HM */}
            <div className="flex flex-col justify-end items-center text-center h-[100px] p-1" style={{ height: '59px', paddingBottom: '36px', marginTop: '0px', paddingLeft: '-17.240000000000002px' }}>
              <div className="leading-tight font-extrabold flex flex-col items-center justify-start">
                <span style={{ fontSize: '9.5px' }}>Signature & Seal of</span>
                <span style={{ fontSize: '9.5px' }}>Headmaster / HM</span>
              </div>
            </div>

            {/* Right Signature: Mandal Educational Officer */}
            <div className="flex flex-col justify-end items-center text-center h-[100px] p-1" style={{ height: '61px', paddingBottom: '38px', marginTop: '1px', marginLeft: '-1px', marginRight: '9px', marginBottom: '-1px', paddingLeft: '-9.72px', paddingRight: '-4.72px' }}>
              <div className="leading-tight font-extrabold flex flex-col items-center justify-start">
                <span style={{ fontSize: '9.5px' }}>Signature & Seal of</span>
                <span className="whitespace-nowrap" style={{ fontSize: '9.5px' }}>Mandal Educational Officer</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      </div>
      </div>
      {/* Opening / Monthly Commodity Balances Modal */}
      <OpeningBalanceModal
        isOpen={showOpeningModal}
        onClose={() => setShowOpeningModal(false)}
        commodities={commodities}
        baseCommodities={effectiveBaseCommodities}
        dailyEntries={dailyEntries}
        stockTransactions={stockTransactions}
        selectedMonth={selectedMonth}
        monthlyOverrides={monthlyOverrides}
        onSaveOpeningBalances={onSaveOpeningBalances}
        onSaveMonthlyBalances={onSaveMonthlyBalances}
        onResetMonthlyOverride={onResetMonthlyOverride}
      />
    </div>
  );
};
