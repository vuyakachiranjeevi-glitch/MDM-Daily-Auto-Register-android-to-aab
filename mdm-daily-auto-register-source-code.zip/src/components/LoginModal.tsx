import React, { useState, useEffect } from 'react';
import { User } from '../types';
import {
  Lock,
  KeyRound,
  Eye,
  EyeOff,
  ShieldCheck,
  School,
  RefreshCw,
} from 'lucide-react';
import {
  getStoredCredentials,
  verifyLoginCredentials,
  StoredCredentials,
  getSchoolAccounts,
  saveSchoolAccounts,
  getActiveSchoolId,
  setActiveSchoolId,
  SchoolAccount,
  saveStoredSchoolProfile,
} from '../lib/storage';
import { loginUser, registerSchoolDirect, setStoredSessionToken, getStoredSessionToken } from '../lib/authApi';
import { ChangeCredentialsModal } from './ChangeCredentialsModal';
import { RegisterSchoolModal } from './RegisterSchoolModal';
import { ForgotPasswordModal } from './ForgotPasswordModal';

interface LoginModalProps {
  onLogin: (user: User) => void;
  schoolName: string;
  udiseCode: string;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  onLogin,
  schoolName: initialSchoolName,
  udiseCode: initialUdiseCode,
}) => {
  const [schoolAccounts, setSchoolAccounts] = useState<SchoolAccount[]>(getSchoolAccounts);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>(() => getActiveSchoolId());
  const [creds, setCreds] = useState<StoredCredentials>(() => getStoredCredentials(selectedSchoolId));

  // Initialize credentials - restore remembered username if opted
  const [identifier, setIdentifier] = useState<string>(() => {
    return localStorage.getItem('mdm_remembered_username') || initialUdiseCode || '28261800503';
  });
  const [password, setPassword] = useState<string>('');

  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showChangeCredsModal, setShowChangeCredsModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const [changeCredsRole, setChangeCredsRole] = useState<'HEADMASTER' | 'MDM_INCHARGE'>('HEADMASTER');
  const [error, setError] = useState('');
  const [loginSuccessMsg, setLoginSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync accounts and credentials when school changes
  useEffect(() => {
    const accounts = getSchoolAccounts();
    setSchoolAccounts(accounts);
    const updatedCreds = getStoredCredentials(selectedSchoolId);
    setCreds(updatedCreds);
  }, [selectedSchoolId]);

  const activeSchool = schoolAccounts.find((a) => a.schoolId === selectedSchoolId);
  const currentSchoolName = activeSchool?.schoolName || initialSchoolName;
  const currentUdiseCode = activeSchool?.udiseCode || initialUdiseCode || '28261800503';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setError('');
    setLoginSuccessMsg('');

    const trimmedIdent = identifier.trim();
    if (!trimmedIdent || !password) {
      setError('Please enter your School UDISE Code and password.');
      return;
    }

    const digitsOnly = trimmedIdent.replace(/\D/g, '');
    if ((!digitsOnly || digitsOnly.length < 6) && trimmedIdent.length < 3) {
      setError('School login username must be your School UDISE Code.');
      return;
    }

    setIsSubmitting(true);

    // Save or clear remembered username
    if (rememberMe) {
      localStorage.setItem('mdm_remembered_username', trimmedIdent);
    } else {
      localStorage.removeItem('mdm_remembered_username');
    }

    let apiError: string | null = null;
    try {
      // 1. Production Backend Authentication Verification
      const apiResult = await loginUser(trimmedIdent, password);

      if (apiResult.success && apiResult.user) {
        const targetSchoolId = apiResult.user.schoolId;
        const resolvedUdise = apiResult.user.udiseCode || trimmedIdent;
        const resolvedSchoolName = apiResult.user.schoolName || (apiResult as any).schoolAccount?.schoolName || `School ${resolvedUdise}`;

        setActiveSchoolId(targetSchoolId);

        // Ensure this school account is saved in local registry so profile/data belong to this school
        const currentAccounts = getSchoolAccounts();
        const existingIdx = currentAccounts.findIndex(
          (a) => a.schoolId === targetSchoolId || a.udiseCode === resolvedUdise
        );
        if (existingIdx === -1) {
          const newAccountEntry: SchoolAccount = {
            schoolId: targetSchoolId,
            schoolName: resolvedSchoolName,
            udiseCode: resolvedUdise,
            village: (apiResult as any).schoolAccount?.village || '',
            mandal: (apiResult as any).schoolAccount?.mandal || 'PALAKONDA',
            district: (apiResult as any).schoolAccount?.district || 'PARVATHI PURAM MANYAM',
            state: (apiResult as any).schoolAccount?.state || 'ANDHRA PRADESH',
            headmasterName: apiResult.user.name,
            headmasterMobile: apiResult.user.mobile || '',
            createdAt: new Date().toISOString(),
            lastLoginAt: new Date().toISOString(),
            status: 'ACTIVE',
            credentials: {
              headmaster: {
                role: 'HEADMASTER',
                username: resolvedUdise,
                password: password,
                name: apiResult.user.name,
                mobile: apiResult.user.mobile || '',
              },
              incharge: {
                role: 'MDM_INCHARGE',
                username: resolvedUdise,
                password: password,
                name: 'MDM Incharge',
                mobile: '',
              },
            },
          };
          currentAccounts.push(newAccountEntry);
          saveSchoolAccounts(currentAccounts);
        } else {
          currentAccounts[existingIdx].lastLoginAt = new Date().toISOString();
          if (resolvedSchoolName) currentAccounts[existingIdx].schoolName = resolvedSchoolName;
          currentAccounts[existingIdx].udiseCode = resolvedUdise;
          if (password) {
            currentAccounts[existingIdx].credentials.headmaster.password = password;
          }
          currentAccounts[existingIdx].credentials.headmaster.username = resolvedUdise;
          saveSchoolAccounts(currentAccounts);
        }

        // Initialize and persist individual school profile
        const fullProf = {
          schoolName: resolvedSchoolName,
          udiseCode: resolvedUdise,
          headmasterName: apiResult.user.name || '',
          phoneNumber: apiResult.user.mobile || '',
          village: (apiResult as any).schoolAccount?.village || '',
          mandal: (apiResult as any).schoolAccount?.mandal || 'PALAKONDA',
          district: (apiResult as any).schoolAccount?.district || 'PARVATHI PURAM MANYAM',
          state: (apiResult as any).schoolAccount?.state || 'ANDHRA PRADESH',
          address: `${resolvedSchoolName}, PARVATHI PURAM MANYAM`,
        };
        saveStoredSchoolProfile(fullProf as any, targetSchoolId);

        setLoginSuccessMsg(
          `Welcome, ${apiResult.user.name}! Access granted for ${resolvedSchoolName}.`
        );
        setTimeout(() => {
          setIsSubmitting(false);
          onLogin({
            ...apiResult.user!,
            username: resolvedUdise,
            schoolName: resolvedSchoolName,
            udiseCode: resolvedUdise,
            schoolId: targetSchoolId,
          });
        }, 300);
        return;
      }

      if (apiResult.error) {
        apiError = apiResult.error;
      }
    } catch (err: any) {
      apiError = err?.message || null;
    }

    // 2. Resilient Local / Offline Verification Fallback
    let localResult = verifyLoginCredentials(trimmedIdent, password, selectedSchoolId);
    if (!localResult.success) {
      localResult = verifyLoginCredentials(trimmedIdent, password);
    }

    if (localResult.success && localResult.user) {
      // Sync local account to backend if backend was missing it or rejected credentials
      const acc = schoolAccounts.find((a) => a.schoolId === localResult.user!.schoolId || a.udiseCode === localResult.user!.udiseCode);
      if (acc) {
        registerSchoolDirect({
          name: acc.headmasterName || localResult.user.name,
          username: localResult.user.username,
          udiseCode: acc.udiseCode,
          mobile: acc.headmasterMobile,
          password: password,
          confirmPassword: password,
          schoolName: acc.schoolName,
          village: acc.village,
          mandal: acc.mandal,
          district: acc.district,
        }).then((syncRes) => {
          if (syncRes.success && syncRes.token) {
            setStoredSessionToken(syncRes.token);
          }
        }).catch(() => {});
      }

      // Ensure active session token exists for seamless offline authentication
      if (!getStoredSessionToken()) {
        setStoredSessionToken(`local_session_${Date.now()}_${localResult.user.udiseCode || 'auth'}`);
      }

      setLoginSuccessMsg(
        `Welcome, ${localResult.user.name}! Access granted for ${localResult.user.schoolName || currentSchoolName}.`
      );
      setTimeout(() => {
        setIsSubmitting(false);
        onLogin(localResult.user!);
      }, 300);
      return;
    }

    setError(localResult.error || apiError || 'Invalid credentials. Please enter your password or click "Forgot Password" to reset.');
    setIsSubmitting(false);
  };

  const handleOpenChangeCreds = (role: 'HEADMASTER' | 'MDM_INCHARGE') => {
    setChangeCredsRole(role);
    setShowChangeCredsModal(true);
  };

  const handleCredentialsUpdated = (updatedCreds: StoredCredentials, targetRole: 'HEADMASTER' | 'MDM_INCHARGE') => {
    setCreds(updatedCreds);
    if (targetRole === 'HEADMASTER') {
      setIdentifier(updatedCreds.headmaster.username);
      setPassword(updatedCreds.headmaster.password);
    } else {
      setIdentifier(updatedCreds.incharge.username);
      setPassword(updatedCreds.incharge.password);
    }
    setError('');
    setLoginSuccessMsg('Credentials updated successfully! You can now log in.');
  };

  const handleSchoolRegistered = (registeredUser: User) => {
    setSchoolAccounts(getSchoolAccounts());
    if (registeredUser.schoolId) {
      setSelectedSchoolId(registeredUser.schoolId);
      setActiveSchoolId(registeredUser.schoolId);
    }
    onLogin(registeredUser);
  };

  const isEnteringDigits = /^\d+$/.test(identifier.trim());

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 pb-8 sm:pb-10 md:pb-12 overflow-y-auto">
      {/* Blurry App Icon in background - gently pulsates & enhances blur when logging in */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden z-0">
        <img
          src="/app-logo.png"
          alt=""
          aria-hidden="true"
          className={`w-72 h-72 sm:w-96 sm:h-96 rounded-full object-cover select-none transition-all duration-700 ${
            isSubmitting
              ? 'opacity-35 blur-2xl scale-110 animate-pulse'
              : 'opacity-20 blur-xl scale-100'
          }`}
        />
      </div>

      {/* Decorative ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 sm:w-96 h-72 sm:h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-64 sm:w-80 h-64 sm:h-80 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Simplified, Attractive Login Tile - Clean bottom room for ads */}
      <div className="w-full max-w-[390px] sm:max-w-[440px] md:max-w-[460px] bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden relative z-10 my-0.5 sm:my-3 mb-7 sm:mb-8 md:mb-10 transition-all animate-in fade-in zoom-in-95 duration-200 max-h-[calc(100dvh-3.5rem)] sm:max-h-[calc(100dvh-4rem)] flex flex-col justify-between">
        {/* Top Gradient Banner with Logo & Official Branding */}
        <div className="bg-gradient-to-br from-indigo-700 via-blue-700 to-indigo-800 px-2 py-1.5 sm:px-4 sm:py-2.5 text-white text-center relative border-b border-white/10 shrink-0 flex flex-col justify-center items-center h-[82px] sm:h-[112px]">
          <div className="inline-flex p-0.5 bg-white/20 backdrop-blur-md rounded-lg shadow-sm ring-1 ring-white/30 mb-0.5">
            <img
              src="/app-logo.png"
              alt="PM POSHAN MDM"
              className="w-6 h-6 sm:w-8 sm:h-8 rounded-md object-cover"
            />
          </div>
          <div>
            <h2 className="text-[11.5px] sm:text-sm font-black tracking-tight text-white leading-tight">MDM Daily Auto Register</h2>
            <p className="text-[8.5px] sm:text-[10px] font-medium text-blue-100">PM POSHAN School Mid-Day Meal Portal</p>
          </div>
        </div>

        {/* Form Body - Perfectly compact on mobile so every item shows at a glance */}
        <div className="p-2.5 sm:p-5 space-y-2 sm:space-y-3.5 overflow-y-auto">
          {error && (
            <div className="p-1.5 sm:p-2.5 bg-rose-500/10 border border-rose-500/20 rounded-lg sm:rounded-xl text-[11px] sm:text-xs text-rose-600 dark:text-rose-400 font-medium flex items-center gap-1.5">
              <span className="shrink-0 text-sm">⚠️</span>
              <span className="leading-tight">{error}</span>
            </div>
          )}

          {loginSuccessMsg && (
            <div className="p-1.5 sm:p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg sm:rounded-xl text-[11px] sm:text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-center gap-1.5">
              <span className="shrink-0 text-sm">✅</span>
              <span className="leading-tight">{loginSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-1.5 sm:space-y-3">
            {/* Identifier input */}
            <div>
              <label className="block text-[10px] sm:text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-0.5 sm:mb-1">
                School UDISE Code (Username)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-2.5 sm:pl-3 flex items-center pointer-events-none text-slate-400">
                  <School className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value.trim());
                    setError('');
                  }}
                  placeholder="Enter School UDISE Code"
                  className="w-full pl-8 sm:pl-9 pr-3 h-[36px] sm:h-[42px] bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg sm:rounded-xl text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all outline-hidden font-medium placeholder:text-slate-400 text-left font-mono"
                  required
                  maxLength={18}
                />
              </div>
            </div>

            {/* Password input */}
            <div>
              <div className="flex items-center justify-between mb-0.5 sm:mb-1">
                <label className="block text-[10px] sm:text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  <span>Password</span>
                </label>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-2.5 sm:pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  placeholder="Password"
                  aria-label="Password"
                  className="w-full pl-8 sm:pl-9 pr-9 sm:pr-10 h-[36px] sm:h-[41px] bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg sm:rounded-xl text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all outline-hidden font-medium placeholder:text-slate-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-2.5 sm:pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                </button>
              </div>
            </div>

            {/* Quick Demo Credentials Pill for Default School */}
            {(!identifier || identifier === '28261800503' || identifier === 'headmaster') && (
              <div className="flex items-center justify-between p-1.5 sm:p-2 bg-blue-50/90 dark:bg-blue-950/50 border border-blue-200/90 dark:border-blue-800/70 rounded-lg text-[10px] sm:text-[11px] text-blue-700 dark:text-blue-300">
                <span className="truncate">Demo UDISE: <strong className="font-mono">28261800503</strong> • Pwd: <strong className="font-mono">Password@123</strong></span>
                <button
                  type="button"
                  onClick={() => {
                    setIdentifier('28261800503');
                    setPassword('Password@123');
                    setError('');
                  }}
                  className="ml-1 px-2 py-0.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded text-[9.5px] font-bold cursor-pointer shrink-0 transition-all shadow-xs"
                >
                  Fill Demo
                </button>
              </div>
            )}

            {/* Remember Username & Forgot Password */}
            <div className="flex items-center justify-between text-xs pt-0">
              <label className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <span className="text-[10px] sm:text-[11.5px]">Remember Username</span>
              </label>

              <button
                type="button"
                onClick={() => setShowForgotPasswordModal(true)}
                className="text-[10px] sm:text-[11.5px] text-blue-600 dark:text-sky-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <KeyRound className="w-3 h-3" />
                <span>Forgot Password?</span>
              </button>
            </div>

            {/* Primary Sign In Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-[36px] sm:h-[44px] px-4 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 shadow-md shadow-blue-600/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer mt-1"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span>Sign In to MDM Portal</span>
                </>
              )}
            </button>
          </form>

          {/* New Registration Prompt */}
          <div className="pt-0.5 text-center text-xs">
            <span className="text-slate-500 dark:text-slate-400 text-[10.5px] sm:text-[11.5px]">
              Don't have an account?{' '}
            </span>
            <button
              type="button"
              onClick={() => setShowRegisterModal(true)}
              className="text-[10.5px] sm:text-[11.5px] font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 hover:underline cursor-pointer"
            >
              New Registration
            </button>
          </div>

          {/* Secure & Isolated Badge */}
          <div className="pt-0.5 text-center">
            <span className="inline-flex items-center gap-1 text-[9.5px] sm:text-[10.5px] font-medium text-slate-500 dark:text-slate-400">
              <ShieldCheck className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Isolated school records • Secure local & cloud sync</span>
            </span>
          </div>
        </div>
      </div>

      {/* Change Credentials Modal */}
      <ChangeCredentialsModal
        isOpen={showChangeCredsModal}
        onClose={() => setShowChangeCredsModal(false)}
        defaultRole={changeCredsRole}
        schoolId={selectedSchoolId}
        onCredentialsUpdated={handleCredentialsUpdated}
      />

      {/* Register New School Modal */}
      <RegisterSchoolModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onSchoolRegistered={handleSchoolRegistered}
      />

      {/* Forgot Password Modal */}
      <ForgotPasswordModal
        isOpen={showForgotPasswordModal}
        onClose={() => setShowForgotPasswordModal(false)}
        onSuccess={() => {
          setShowForgotPasswordModal(false);
          setError('');
          setLoginSuccessMsg('Password reset successfully! Please sign in with your new password.');
        }}
        initialIdentifier={identifier}
      />
    </div>
  );
};
