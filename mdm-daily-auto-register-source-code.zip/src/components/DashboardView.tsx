import React from 'react';
import {
  CommodityItem,
  DailyEntry,
  MealRates,
  NavigationTab,
  SchoolProfile,
  StockTransaction,
  StudentClassStrength,
} from '../types';
import { MonthlyCommodityOverrides } from '../lib/storage';
import { MonthlySummaryView } from './MonthlySummaryView';

export interface DashboardViewProps {
  schoolProfile: SchoolProfile;
  dailyEntries: DailyEntry[];
  mealRates: MealRates;
  commodities: CommodityItem[];
  baseCommodities?: CommodityItem[];
  stockTransactions?: StockTransaction[];
  monthlyOverrides?: MonthlyCommodityOverrides;
  studentStrengths?: StudentClassStrength[];
  onSaveEntry?: (entry: DailyEntry) => void;
  onDeleteEntry?: (entryId: string) => void;
  onSaveStudentStrengths?: (strengths: StudentClassStrength[], monthStr?: string) => void;
  onNavigate: (tab: NavigationTab) => void;
  onPrintDashboard?: (orientation?: 'landscape' | 'portrait') => void;
  onPrintRegister?: (orientation?: 'landscape' | 'portrait') => void;
  onSaveOpeningBalances?: (updated: CommodityItem[]) => void;
  onSaveMonthlyBalances?: (monthStr: string, openingBalances: Record<string, number>) => void;
  onResetMonthlyOverride?: (monthStr: string) => void;
  onSaveStockTransactions?: (txs: StockTransaction[]) => void;
  onUpdateMealRates?: (rates: MealRates) => void;
  onUpdateSchoolProfile?: (profile: SchoolProfile) => void;
  onToggleDarkMode?: () => void;
  onResetAllData?: () => void;
  darkMode?: boolean;
  showInstallButton?: boolean;
  onInstallClick?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  schoolProfile,
  dailyEntries,
  mealRates,
  commodities,
  baseCommodities = commodities,
  stockTransactions = [],
  monthlyOverrides = {},
  studentStrengths = [],
  onSaveEntry = () => {},
  onDeleteEntry = () => {},
  onSaveStudentStrengths = () => {},
  onNavigate,
  onPrintDashboard,
  onPrintRegister = onPrintDashboard || (() => window.print()),
  onSaveOpeningBalances = () => {},
  onSaveMonthlyBalances = () => {},
  onResetMonthlyOverride = () => {},
  onSaveStockTransactions = () => {},
  onUpdateMealRates = () => {},
  onUpdateSchoolProfile,
  onToggleDarkMode,
  onResetAllData,
  darkMode,
  showInstallButton = false,
  onInstallClick,
}) => {
  return (
    <div className="pb-8 sm:pb-12">
      {/* Official Day-by-Day MDM Register in Dashboard */}
      <MonthlySummaryView
        schoolProfile={schoolProfile}
        dailyEntries={dailyEntries}
        mealRates={mealRates}
        commodities={commodities}
        baseCommodities={baseCommodities}
        stockTransactions={stockTransactions}
        monthlyOverrides={monthlyOverrides}
        studentStrengths={studentStrengths}
        onSaveEntry={onSaveEntry}
        onDeleteEntry={onDeleteEntry}
        onSaveStudentStrengths={onSaveStudentStrengths}
        onNavigate={onNavigate}
        onPrintRegister={onPrintRegister}
        onSaveOpeningBalances={onSaveOpeningBalances}
        onSaveMonthlyBalances={onSaveMonthlyBalances}
        onResetMonthlyOverride={onResetMonthlyOverride}
        onSaveStockTransactions={onSaveStockTransactions}
        onUpdateMealRates={onUpdateMealRates}
        onUpdateSchoolProfile={onUpdateSchoolProfile}
        onToggleDarkMode={onToggleDarkMode}
        onResetAllData={onResetAllData}
        darkMode={darkMode}
        showInstallButton={showInstallButton}
        onInstallClick={onInstallClick}
      />
    </div>
  );
};
