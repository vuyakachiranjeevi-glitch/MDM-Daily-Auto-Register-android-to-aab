import React, { useState, useRef } from 'react';
import { School, Upload, Link, Trash2, Check, X, Sparkles, Image as ImageIcon } from 'lucide-react';
import { SchoolProfile } from '../types';

interface ChangeSchoolImageModalProps {
  schoolProfile: SchoolProfile;
  isOpen: boolean;
  onClose: () => void;
  onSaveImage: (newPhotoUrl: string) => void;
}

const PRESET_EMBLEMS = [
  {
    id: 'school-campus',
    title: 'School Campus',
    category: 'Campus',
    url: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'classroom-chalkboard',
    title: 'Classroom & Learning',
    category: 'Academic',
    url: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'mdm-nutritious-food',
    title: 'Nutrition & Meal',
    category: 'MDM',
    url: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'students-studying',
    title: 'Students & Books',
    category: 'Students',
    url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'school-library',
    title: 'Library & Heritage',
    category: 'Campus',
    url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'graduation-academy',
    title: 'Excellence Academy',
    category: 'Emblem',
    url: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=800',
  },
];

export const ChangeSchoolImageModal: React.FC<ChangeSchoolImageModalProps> = ({
  schoolProfile,
  isOpen,
  onClose,
  onSaveImage,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'url' | 'presets'>('upload');
  const [previewUrl, setPreviewUrl] = useState<string>(schoolProfile.schoolPhotoUrl || '');
  const [customUrlInput, setCustomUrlInput] = useState<string>(
    schoolProfile.schoolPhotoUrl && !schoolProfile.schoolPhotoUrl.startsWith('data:')
      ? schoolProfile.schoolPhotoUrl
      : ''
  );
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [imgError, setImgError] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Process and compress image file to manageable base64 data URL
  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (PNG, JPG, WEBP, etc.)');
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      const result = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        // Resize image to max 800px dimension to maintain speed and save storage
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDim = 800;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setPreviewUrl(compressedDataUrl);
          setImgError(false);
        } else {
          setPreviewUrl(result);
          setImgError(false);
        }
        setIsProcessing(false);
      };

      img.onerror = () => {
        setPreviewUrl(result);
        setImgError(false);
        setIsProcessing(false);
      };

      img.src = result;
    };

    reader.onerror = () => {
      alert('Failed to read selected image file.');
      setIsProcessing(false);
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleApplyUrl = () => {
    if (customUrlInput.trim()) {
      setPreviewUrl(customUrlInput.trim());
      setImgError(false);
    }
  };

  const handleSelectPreset = (url: string) => {
    setPreviewUrl(url);
    setImgError(false);
  };

  const handleRemovePhoto = () => {
    setPreviewUrl('');
    setCustomUrlInput('');
    setImgError(false);
  };

  const handleSave = () => {
    onSaveImage(previewUrl.trim());
    onClose();
  };

  return (
    <div
      id="change-school-image-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-fade-in font-sans"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-700 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-white/15 backdrop-blur-md rounded-xl text-white">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight">
                Change School Icon / Photo
              </h2>
              <p className="text-[11px] text-blue-100 font-medium">
                {schoolProfile.schoolName} ({schoolProfile.udiseCode})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 text-white transition-all cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
          {/* Live Preview Display */}
          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3.5 border border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row items-center gap-3.5">
            <div className="relative group shrink-0">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xl overflow-hidden shadow-md ring-2 ring-blue-400/40">
                {previewUrl && !imgError ? (
                  <img
                    src={previewUrl}
                    alt="School Emblem Preview"
                    className="w-full h-full object-cover"
                    onError={() => setImgError(true)}
                  />
                ) : (
                  <School className="w-10 h-10 text-sky-200" />
                )}
              </div>
              {previewUrl && (
                <button
                  type="button"
                  onClick={handleRemovePhoto}
                  className="absolute -top-1.5 -right-1.5 p-1 bg-rose-500 hover:bg-rose-600 text-white rounded-full shadow-md cursor-pointer transition-transform hover:scale-110"
                  title="Remove image and use default icon"
                  aria-label="Remove image"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="text-center sm:text-left flex-1 min-w-0">
              <span className="inline-flex items-center gap-1 text-[10.5px] font-extrabold uppercase tracking-wider text-blue-600 dark:text-sky-400 bg-blue-50 dark:bg-sky-950/60 px-2 py-0.5 rounded-md border border-blue-200 dark:border-sky-800">
                <Sparkles className="w-3 h-3" /> Live Register Badge Preview
              </span>
              <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white mt-1 truncate">
                {schoolProfile.schoolName}
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                {previewUrl
                  ? 'Custom photo will appear on the register header & reports.'
                  : 'Currently displaying official default School emblem.'}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-200 dark:border-slate-700 text-xs font-bold">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`flex-1 pb-2.5 pt-1 px-3 border-b-2 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'upload'
                  ? 'border-blue-600 text-blue-600 dark:text-sky-400 dark:border-sky-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Photo</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`flex-1 pb-2.5 pt-1 px-3 border-b-2 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'url'
                  ? 'border-blue-600 text-blue-600 dark:text-sky-400 dark:border-sky-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <Link className="w-3.5 h-3.5" />
              <span>Web Link / URL</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className={`flex-1 pb-2.5 pt-1 px-3 border-b-2 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'presets'
                  ? 'border-blue-600 text-blue-600 dark:text-sky-400 dark:border-sky-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>School Presets</span>
            </button>
          </div>

          {/* Tab 1: File Upload */}
          {activeTab === 'upload' && (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />

              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-6 sm:p-8 text-center cursor-pointer transition-all ${
                  isDragging
                    ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-900/30 scale-[1.01]'
                    : 'border-slate-300 dark:border-slate-700 hover:border-blue-400 bg-slate-50/50 dark:bg-slate-800/40'
                }`}
              >
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-2 shadow-xs">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">
                  {isProcessing ? 'Processing image...' : 'Touch or click to choose photo'}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  Supports PNG, JPG, JPEG, WEBP files
                </p>

                <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-xs hover:bg-blue-700">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Browse Photos</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: URL Input */}
          {activeTab === 'url' && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Direct Image Web Address (URL)
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={customUrlInput}
                    onChange={(e) => setCustomUrlInput(e.target.value)}
                    placeholder="https://example.com/school-logo.png"
                    className="flex-1 p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-900 dark:text-white outline-hidden focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyUrl}
                    className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-all shadow-xs"
                  >
                    Preview
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Paste any valid HTTPS image URL from your school website or cloud drive.
              </p>
            </div>
          )}

          {/* Tab 3: Presets Gallery */}
          {activeTab === 'presets' && (
            <div className="space-y-2">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Select from standard educational and school insignia badges:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {PRESET_EMBLEMS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset.url)}
                    className={`p-2 rounded-xl border text-left flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      previewUrl === preset.url
                        ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/60 ring-2 ring-blue-500/40 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:border-blue-400'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.title}
                      className="w-12 h-12 rounded-lg object-cover shadow-xs"
                    />
                    <span className="text-[10px] font-bold text-slate-800 dark:text-slate-200 text-center truncate w-full">
                      {preset.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-3.5 sm:p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={handleRemovePhoto}
            className="px-3 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset to Default</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer transition-all"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:from-blue-700 active:to-indigo-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-blue-500/20 cursor-pointer transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Apply & Save Photo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
