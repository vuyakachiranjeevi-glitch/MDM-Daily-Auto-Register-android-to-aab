import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MealRates, CommodityItem } from '../types';
import { formatDateReadable, getDayDetails, formatCurrency, formatQtyVal } from '../lib/utils';
import { getStoredCustomHolidays, saveStoredCustomHolidays } from '../lib/storage';
import {
  X,
  Calendar,
  Save,
  RotateCcw,
  ArrowRight,
  Sparkles,
  Users,
  CheckCircle2,
  Check,
  AlertTriangle,
  Flame,
  Wheat,
  Egg,
  Cookie,
  Droplet,
  Coffee,
  PackagePlus,
  Layers,
  Coins,
  IndianRupee,
  Calculator,
  Sliders,
  Receipt,
  HelpCircle,
} from 'lucide-react';

export interface DayCommodityDetail {
  commodityId: string;
  name: string;
  unit: string;
  ob: number;
  isObEdited?: boolean;
  received: number;
  supplierInvoice?: string;
  used: number;
  spoiled: number;
  spoilReason?: string;
  cb: number;
}

export interface DayEditorState {
  date: string;
  isHoliday: boolean;
  isSunday: boolean;
  holidayName: string;
  primaryRoll: number;
  upperPrimaryRoll: number;
  primaryAttendance: number;
  upperPrimaryAttendance: number;
  mealsServed: number;
  autoCalcCommodities: boolean;
  riceUsedKg: number;
  eggUsedQty: number;
  chikkiUsedQty: number;
  ragiUsedKg: number;
  jaggeryUsedKg: number;
  oilUsedLitres: number;
  pulsesUsedKg: number;
  commoditiesStock?: Record<string, DayCommodityDetail>;
  remarks: string;
  isExistingSaved: boolean;
  // Expenditure / Cooking Cost & Norms per Day
  autoCalcExpenditure?: boolean;
  customCookingCost?: number;
  primaryRatePerMeal?: number;
  upperPrimaryRatePerMeal?: number;
  eggRate?: number;
  chikkiRate?: number;
  ragiRatePerKg?: number;
  jaggeryRatePerKg?: number;
  cchCost?: number;
  otherCost?: number;
  costRemarks?: string;
  updateMasterMealRates?: boolean;
}

interface DayRegisterEditorModalProps {
  isOpen: boolean;
  editorState: DayEditorState | null;
  mealRates: MealRates;
  commodities?: CommodityItem[];
  onClose: () => void;
  onSave: (state: DayEditorState, updateBaseRoll: boolean, andGoToNext: boolean) => void;
  onResetToAuto: (dateStr: string) => void;
  onUpdateMealRates?: (rates: MealRates) => void;
}

export const DayRegisterEditorModal: React.FC<DayRegisterEditorModalProps> = ({
  isOpen,
  editorState,
  mealRates,
  commodities = [],
  onClose,
  onSave,
  onResetToAuto,
  onUpdateMealRates,
}) => {
  const getInitialFormState = (state?: DayEditorState | null): DayEditorState => {
    if (!state) {
      return {
        date: new Date().toISOString().split('T')[0],
        isHoliday: false,
        isSunday: false,
        holidayName: '',
        primaryRoll: 0,
        upperPrimaryRoll: 0,
        primaryAttendance: 0,
        upperPrimaryAttendance: 0,
        mealsServed: 0,
        autoCalcCommodities: true,
        riceUsedKg: 0,
        eggUsedQty: 0,
        chikkiUsedQty: 0,
        ragiUsedKg: 0,
        jaggeryUsedKg: 0,
        oilUsedLitres: 0,
        pulsesUsedKg: 0,
        remarks: '',
        isExistingSaved: false,
        autoCalcExpenditure: true,
        primaryRatePerMeal: mealRates?.primaryRatePerMeal ?? 5.45,
        upperPrimaryRatePerMeal: mealRates?.upperPrimaryRatePerMeal ?? 8.17,
        eggRate: mealRates?.eggRate ?? 6.00,
        chikkiRate: mealRates?.chikkiRate ?? 5.00,
        ragiRatePerKg: mealRates?.ragiRatePerKg ?? 35.00,
        jaggeryRatePerKg: mealRates?.jaggeryRatePerKg ?? 60.00,
        cchCost: 0,
        otherCost: 0,
        costRemarks: '',
        updateMasterMealRates: false,
      };
    }
    return {
      ...state,
      autoCalcExpenditure: state.autoCalcExpenditure ?? (state.customCookingCost === undefined),
      primaryRatePerMeal: state.primaryRatePerMeal ?? mealRates?.primaryRatePerMeal ?? 5.45,
      upperPrimaryRatePerMeal: state.upperPrimaryRatePerMeal ?? mealRates?.upperPrimaryRatePerMeal ?? 8.17,
      eggRate: state.eggRate ?? mealRates?.eggRate ?? 6.00,
      chikkiRate: state.chikkiRate ?? mealRates?.chikkiRate ?? 5.00,
      ragiRatePerKg: state.ragiRatePerKg ?? mealRates?.ragiRatePerKg ?? 35.00,
      jaggeryRatePerKg: state.jaggeryRatePerKg ?? mealRates?.jaggeryRatePerKg ?? 60.00,
      cchCost: state.cchCost ?? 0,
      otherCost: state.otherCost ?? 0,
      costRemarks: state.costRemarks ?? '',
      updateMasterMealRates: false,
    };
  };

  const [_form, _setForm] = useState<DayEditorState>(() => getInitialFormState(editorState));
  const isDirtyRef = useRef<boolean>(false);
  const formRef = useRef<DayEditorState>(_form);
  formRef.current = _form;

  const [updateBaseRoll, setUpdateBaseRoll] = useState<boolean>(true);
  const updateBaseRollRef = useRef<boolean>(updateBaseRoll);
  updateBaseRollRef.current = updateBaseRoll;

  const [isAutoSaving, setIsAutoSaving] = useState<boolean>(false);
  const [lastAutoSavedTime, setLastAutoSavedTime] = useState<string | null>(null);

  // Wrapper for setForm that flags form as dirty for automatic saving
  const setForm = useCallback((updater: DayEditorState | ((prev: DayEditorState) => DayEditorState), markDirty = true) => {
    if (markDirty) {
      isDirtyRef.current = true;
    }
    _setForm((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      formRef.current = next;
      return next;
    });
  }, []);

  const form = _form;

  const [activeTab, setActiveTab] = useState<'attendance' | 'commodities' | 'expenditure'>('attendance');
  const [rawCommInputs, setRawCommInputs] = useState<Record<string, { ob: string; received: string; used: string; spoiled: string }>>({});
  const [rawRateInputs, setRawRateInputs] = useState<Record<string, string>>({
    customCookingCost: '',
    primaryRatePerMeal: '',
    upperPrimaryRatePerMeal: '',
    eggRate: '',
    chikkiRate: '',
    ragiRatePerKg: '',
    jaggeryRatePerKg: '',
  });

  const handleRateFieldChange = (
    field: 'customCookingCost' | 'primaryRatePerMeal' | 'upperPrimaryRatePerMeal' | 'eggRate' | 'chikkiRate' | 'ragiRatePerKg' | 'jaggeryRatePerKg',
    valStr: string
  ) => {
    const sanitized = valStr.replace(/[^0-9.]/g, '');
    const parts = sanitized.split('.');
    const cleanStr = parts.length > 2 ? `${parts[0]}.${parts.slice(1).join('')}` : sanitized;

    setRawRateInputs((prev) => ({ ...prev, [field]: cleanStr }));
    const parsed = parseFloat(cleanStr);
    const numVal = isNaN(parsed) ? 0 : parsed;
    if (field === 'customCookingCost') {
      setForm({ ...form, customCookingCost: cleanStr === '' ? undefined : numVal });
    } else {
      setForm({ ...form, [field]: numVal });
    }
  };

  // Sync state if editorState changes
  useEffect(() => {
    if (editorState) {
      isDirtyRef.current = false;
      setForm(getInitialFormState(editorState), false);

      const initialRaw: Record<string, { ob: string; received: string; used: string; spoiled: string }> = {};
      if (editorState.commoditiesStock) {
        Object.keys(editorState.commoditiesStock).forEach((id) => {
          const c = editorState.commoditiesStock![id];
          initialRaw[id] = {
            ob: c.ob !== undefined && c.ob !== null ? String(c.ob) : '0',
            received: c.received ? String(c.received) : '',
            used: c.used !== undefined && c.used !== null ? String(c.used) : '0',
            spoiled: c.spoiled ? String(c.spoiled) : '',
          };
        });
      }
      setRawCommInputs(initialRaw);

      setRawRateInputs({
        customCookingCost: editorState.customCookingCost !== undefined && editorState.customCookingCost !== null ? String(editorState.customCookingCost) : '',
        primaryRatePerMeal: String(typeof editorState.primaryRatePerMeal === 'number' ? editorState.primaryRatePerMeal : (mealRates.primaryRatePerMeal ?? 5.45)),
        upperPrimaryRatePerMeal: String(typeof editorState.upperPrimaryRatePerMeal === 'number' ? editorState.upperPrimaryRatePerMeal : (mealRates.upperPrimaryRatePerMeal ?? 8.17)),
        eggRate: String(typeof editorState.eggRate === 'number' ? editorState.eggRate : (mealRates.eggRate ?? 6.00)),
        chikkiRate: String(typeof editorState.chikkiRate === 'number' ? editorState.chikkiRate : (mealRates.chikkiRate ?? 5.00)),
        ragiRatePerKg: String(typeof editorState.ragiRatePerKg === 'number' ? editorState.ragiRatePerKg : (mealRates.ragiRatePerKg ?? 35.00)),
        jaggeryRatePerKg: String(typeof editorState.jaggeryRatePerKg === 'number' ? editorState.jaggeryRatePerKg : (mealRates.jaggeryRatePerKg ?? 60.00)),
      });
    }
  }, [editorState?.date, editorState, setForm]);

  const dayInfo = getDayDetails(form.date);

  // Recalculate AP MDM Norms
  const recalcNorms = (
    pAtt: number,
    upAtt: number,
    isHol: boolean,
    dayOfWeek: number
  ) => {
    if (isHol) {
      return {
        rice: 0,
        egg: 0,
        chikki: 0,
        ragi: 0,
        jaggery: 0,
        oil: 0,
        pulses: 0,
      };
    }

    const totalMeals = pAtt + upAtt;
    const riceP = (mealRates.riceNormPrimaryGrams ?? 100) / 1000;
    const riceUp = (mealRates.riceNormUpperPrimaryGrams ?? 150) / 1000;
    const rice = Number(((pAtt * riceP) + (upAtt * riceUp)).toFixed(3));

    const eggNorm = mealRates.eggNormQty ?? 1;
    const isEggDay = dayOfWeek >= 1 && dayOfWeek <= 5;
    const egg = isEggDay ? totalMeals * eggNorm : 0;

    const chikkiNorm = mealRates.chikkiNormQty ?? 1;
    const isChikkiDay = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5;
    const chikki = isChikkiDay ? totalMeals * chikkiNorm : 0;

    const ragiNorm = (mealRates.ragiNormGrams ?? 10) / 1000;
    const jaggeryNorm = (mealRates.jaggeryNormGrams ?? 10) / 1000;
    const isRagiDay = dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6;
    const ragi = isRagiDay ? Number((totalMeals * ragiNorm).toFixed(3)) : 0;
    const jaggery = isRagiDay ? Number((totalMeals * jaggeryNorm).toFixed(3)) : 0;

    // Oil & Pulses norms
    const oil = Number(((pAtt * 0.005) + (upAtt * 0.0075)).toFixed(3));
    const pulses = Number(((pAtt * 0.02) + (upAtt * 0.03)).toFixed(3));

    return { rice, egg, chikki, ragi, jaggery, oil, pulses };
  };

  const updateCommodityStockField = (
    commId: string,
    field: 'ob' | 'received' | 'used' | 'spoiled' | 'supplierInvoice' | 'spoilReason',
    value: string | number
  ) => {
    if (field === 'supplierInvoice' || field === 'spoilReason') {
      const prevStock = form.commoditiesStock || {};
      const curComm = prevStock[commId] || {
        commodityId: commId,
        name: commId.toUpperCase(),
        unit: 'Kg',
        ob: 0,
        received: 0,
        used: 0,
        spoiled: 0,
        cb: 0,
      };
      const updatedComm = { ...curComm, [field]: String(value) };
      setForm({ ...form, commoditiesStock: { ...prevStock, [commId]: updatedComm } });
      return;
    }

    const valStr = String(value ?? '');
    setRawCommInputs((prev) => ({
      ...prev,
      [commId]: {
        ...(prev[commId] || { ob: '0', received: '', used: '0', spoiled: '' }),
        [field]: valStr,
      },
    }));

    // Parse float; allow negative / minus numbers and decimal fractions
    const trimmed = valStr.trim();
    let numValue = 0;
    if (trimmed === '-' || trimmed === '-.' || trimmed === '.' || trimmed === '') {
      numValue = 0;
    } else {
      const parsed = parseFloat(trimmed);
      numValue = isNaN(parsed) ? 0 : parsed;
    }

    const prevStock = form.commoditiesStock || {};
    const curComm = prevStock[commId] || {
      commodityId: commId,
      name: commId.toUpperCase(),
      unit: 'Kg',
      ob: 0,
      received: 0,
      used: 0,
      spoiled: 0,
      cb: 0,
    };

    let updatedComm: DayCommodityDetail = { ...curComm, [field]: numValue };
    if (field === 'ob') {
      updatedComm.isObEdited = true;
    }

    const ob = field === 'ob' ? numValue : (typeof updatedComm.ob === 'number' ? updatedComm.ob : parseFloat(updatedComm.ob as any) || 0);
    const received = field === 'received' ? numValue : (typeof updatedComm.received === 'number' ? updatedComm.received : parseFloat(updatedComm.received as any) || 0);
    const used = field === 'used' ? numValue : (typeof updatedComm.used === 'number' ? updatedComm.used : parseFloat(updatedComm.used as any) || 0);
    const spoiled = field === 'spoiled' ? numValue : (typeof updatedComm.spoiled === 'number' ? updatedComm.spoiled : parseFloat(updatedComm.spoiled as any) || 0);
    const cb = Number((ob + received - used - spoiled).toFixed(3));

    updatedComm = { ...updatedComm, ob, received, used, spoiled, cb };

    const updatedStockMap = { ...prevStock, [commId]: updatedComm };

    // Also sync the dedicated fields on form if standard commodity
    const updatedForm: DayEditorState = {
      ...form,
      commoditiesStock: updatedStockMap,
    };

    if (commId === 'rice') updatedForm.riceUsedKg = used;
    if (commId === 'egg') updatedForm.eggUsedQty = used;
    if (commId === 'chikki') updatedForm.chikkiUsedQty = used;
    if (commId === 'ragi') updatedForm.ragiUsedKg = used;
    if (commId === 'jaggery') updatedForm.jaggeryUsedKg = used;
    if (commId === 'oil') updatedForm.oilUsedLitres = used;
    if (commId === 'pulses') updatedForm.pulsesUsedKg = used;

    setForm(updatedForm);
  };

  // Helper to block negative signs (-), plus (+), exponential (e/E), decimal point (.) for integer-only fields (roll & attendance)
  const blockNonIntegerKeys = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (['-', '+', 'e', 'E', '.', ','].includes(e.key)) {
      e.preventDefault();
    }
  };

  const parseWholeNumber = (val: string): number => {
    const cleaned = String(val || '').replace(/[^0-9]/g, '');
    if (!cleaned) return 0;
    return Math.max(0, parseInt(cleaned, 10));
  };

  const handleAttendanceChange = (field: 'primaryAttendance' | 'upperPrimaryAttendance', val: number) => {
    const numVal = Math.max(0, Math.floor(Number(val) || 0));
    const maxCap = field === 'primaryAttendance' ? (form.primaryRoll || 0) : (form.upperPrimaryRoll || 0);
    const clampedVal = maxCap > 0 ? Math.min(maxCap, numVal) : numVal;
    const newPAtt = field === 'primaryAttendance' ? clampedVal : form.primaryAttendance;
    const newUpAtt = field === 'upperPrimaryAttendance' ? clampedVal : form.upperPrimaryAttendance;
    const newTotalMeals = newPAtt + newUpAtt;

    if (form.autoCalcCommodities) {
      const norms = recalcNorms(newPAtt, newUpAtt, form.isHoliday, dayInfo.dayOfWeek);
      
      // Update commodity stocks too
      const updatedStock = { ...(form.commoditiesStock || {}) };
      const nextRaw = { ...rawCommInputs };
      const syncCommUsed = (commId: string, usedVal: number) => {
        if (updatedStock[commId]) {
          const item = updatedStock[commId];
          const cb = Number((item.ob + item.received - usedVal - item.spoiled).toFixed(3));
          updatedStock[commId] = { ...item, used: usedVal, cb };
        }
        nextRaw[commId] = {
          ...(nextRaw[commId] || { ob: '0', received: '', used: '0', spoiled: '' }),
          used: String(usedVal),
        };
      };
      syncCommUsed('rice', norms.rice);
      syncCommUsed('egg', norms.egg);
      syncCommUsed('chikki', norms.chikki);
      syncCommUsed('ragi', norms.ragi);
      syncCommUsed('jaggery', norms.jaggery);
      syncCommUsed('oil', norms.oil);
      syncCommUsed('pulses', norms.pulses);
      setRawCommInputs(nextRaw);

      setForm({
        ...form,
        [field]: numVal,
        mealsServed: newTotalMeals,
        riceUsedKg: norms.rice,
        eggUsedQty: norms.egg,
        chikkiUsedQty: norms.chikki,
        ragiUsedKg: norms.ragi,
        jaggeryUsedKg: norms.jaggery,
        oilUsedLitres: norms.oil,
        pulsesUsedKg: norms.pulses,
        commoditiesStock: updatedStock,
      });
    } else {
      setForm({
        ...form,
        [field]: numVal,
        mealsServed: newTotalMeals,
      });
    }
  };

  const handleToggleHoliday = (isHoliday: boolean) => {
    if (isHoliday) {
      const updatedStock = { ...(form.commoditiesStock || {}) };
      const nextRaw = { ...rawCommInputs };
      Object.keys(updatedStock).forEach((k) => {
        const item = updatedStock[k];
        const cb = Number((item.ob + item.received - 0 - item.spoiled).toFixed(3));
        updatedStock[k] = { ...item, used: 0, cb };
        nextRaw[k] = {
          ...(nextRaw[k] || { ob: '0', received: '', used: '0', spoiled: '' }),
          used: '0',
        };
      });
      setRawCommInputs(nextRaw);

      setForm({
        ...form,
        isHoliday: true,
        primaryAttendance: 0,
        upperPrimaryAttendance: 0,
        mealsServed: 0,
        riceUsedKg: 0,
        eggUsedQty: 0,
        chikkiUsedQty: 0,
        ragiUsedKg: 0,
        jaggeryUsedKg: 0,
        oilUsedLitres: 0,
        pulsesUsedKg: 0,
        commoditiesStock: updatedStock,
        holidayName: form.holidayName || (dayInfo.isSunday ? 'Sunday Holiday' : 'School Holiday'),
        remarks: form.remarks || (dayInfo.isSunday ? 'Sunday Holiday' : 'School Holiday'),
      });
    } else {
      const pAtt = form.primaryRoll;
      const upAtt = form.upperPrimaryRoll;
      const norms = recalcNorms(pAtt, upAtt, false, dayInfo.dayOfWeek);

      const updatedStock = { ...(form.commoditiesStock || {}) };
      const nextRaw = { ...rawCommInputs };
      const syncCommUsed = (commId: string, usedVal: number) => {
        if (updatedStock[commId]) {
          const item = updatedStock[commId];
          const cb = Number((item.ob + item.received - usedVal - item.spoiled).toFixed(3));
          updatedStock[commId] = { ...item, used: usedVal, cb };
        }
        nextRaw[commId] = {
          ...(nextRaw[commId] || { ob: '0', received: '', used: '0', spoiled: '' }),
          used: String(usedVal),
        };
      };
      syncCommUsed('rice', norms.rice);
      syncCommUsed('egg', norms.egg);
      syncCommUsed('chikki', norms.chikki);
      syncCommUsed('ragi', norms.ragi);
      syncCommUsed('jaggery', norms.jaggery);
      syncCommUsed('oil', norms.oil);
      syncCommUsed('pulses', norms.pulses);
      setRawCommInputs(nextRaw);

      setForm({
        ...form,
        isHoliday: false,
        primaryAttendance: pAtt,
        upperPrimaryAttendance: upAtt,
        mealsServed: pAtt + upAtt,
        riceUsedKg: norms.rice,
        eggUsedQty: norms.egg,
        chikkiUsedQty: norms.chikki,
        ragiUsedKg: norms.ragi,
        jaggeryUsedKg: norms.jaggery,
        oilUsedLitres: norms.oil,
        pulsesUsedKg: norms.pulses,
        commoditiesStock: updatedStock,
        remarks: 'MDM Served',
      });
    }
  };

  const handleApplyAttendancePercent = (pct: number) => {
    const pAtt = Math.round((form.primaryRoll * pct) / 100);
    const upAtt = Math.round((form.upperPrimaryRoll * pct) / 100);
    const totalM = pAtt + upAtt;
    const norms = recalcNorms(pAtt, upAtt, form.isHoliday, dayInfo.dayOfWeek);

    const updatedStock = { ...(form.commoditiesStock || {}) };
    const nextRaw = { ...rawCommInputs };
    const syncCommUsed = (commId: string, usedVal: number) => {
      if (updatedStock[commId]) {
        const item = updatedStock[commId];
        const cb = Number((item.ob + item.received - usedVal - item.spoiled).toFixed(3));
        updatedStock[commId] = { ...item, used: usedVal, cb };
      }
      nextRaw[commId] = {
        ...(nextRaw[commId] || { ob: '0', received: '', used: '0', spoiled: '' }),
        used: String(usedVal),
      };
    };
    syncCommUsed('rice', norms.rice);
    syncCommUsed('egg', norms.egg);
    syncCommUsed('chikki', norms.chikki);
    syncCommUsed('ragi', norms.ragi);
    syncCommUsed('jaggery', norms.jaggery);
    syncCommUsed('oil', norms.oil);
    syncCommUsed('pulses', norms.pulses);
    setRawCommInputs(nextRaw);

    setForm({
      ...form,
      isHoliday: false,
      primaryAttendance: pAtt,
      upperPrimaryAttendance: upAtt,
      mealsServed: totalM,
      riceUsedKg: norms.rice,
      eggUsedQty: norms.egg,
      chikkiUsedQty: norms.chikki,
      ragiUsedKg: norms.ragi,
      jaggeryUsedKg: norms.jaggery,
      oilUsedLitres: norms.oil,
      pulsesUsedKg: norms.pulses,
      commoditiesStock: updatedStock,
      remarks: pct === 100 ? 'Full 100% Attendance' : `${pct}% Attendance recorded`,
    });
  };

  // Rates & Expenditure Calculations
  const curPrimaryRate = typeof form.primaryRatePerMeal === 'number' ? form.primaryRatePerMeal : (mealRates.primaryRatePerMeal ?? 5.45);
  const curUpperPrimaryRate = typeof form.upperPrimaryRatePerMeal === 'number' ? form.upperPrimaryRatePerMeal : (mealRates.upperPrimaryRatePerMeal ?? 8.17);
  const curEggRate = typeof form.eggRate === 'number' ? form.eggRate : (mealRates.eggRate ?? 6.00);
  const curChikkiRate = typeof form.chikkiRate === 'number' ? form.chikkiRate : (mealRates.chikkiRate ?? 5.00);
  const curRagiRate = typeof form.ragiRatePerKg === 'number' ? form.ragiRatePerKg : (mealRates.ragiRatePerKg ?? 35.00);
  const curJaggeryRate = typeof form.jaggeryRatePerKg === 'number' ? form.jaggeryRatePerKg : (mealRates.jaggeryRatePerKg ?? 60.00);

  const calcPrimaryCost = !form.isHoliday ? Number((form.primaryAttendance * curPrimaryRate).toFixed(2)) : 0;
  const calcUpperPrimaryCost = !form.isHoliday ? Number((form.upperPrimaryAttendance * curUpperPrimaryRate).toFixed(2)) : 0;
  const calcCchCost = !form.isHoliday ? Number((form.cchCost || 0).toFixed(2)) : 0;
  const calcOtherCost = !form.isHoliday ? Number((form.otherCost || 0).toFixed(2)) : 0;

  const autoCalculatedTotalCookingCost = Number((calcPrimaryCost + calcUpperPrimaryCost + calcCchCost + calcOtherCost).toFixed(2));

  const finalDayCookingCost = (form.isHoliday || form.mealsServed === 0)
    ? 0
    : (!form.autoCalcExpenditure && typeof form.customCookingCost === 'number'
        ? form.customCookingCost
        : autoCalculatedTotalCookingCost);

  // Material item costs
  const calcEggCost = !form.isHoliday ? Number((form.eggUsedQty * curEggRate).toFixed(2)) : 0;
  const calcChikkiCost = !form.isHoliday ? Number((form.chikkiUsedQty * curChikkiRate).toFixed(2)) : 0;
  const calcRagiCost = !form.isHoliday ? Number((form.ragiUsedKg * curRagiRate).toFixed(2)) : 0;
  const calcJaggeryCost = !form.isHoliday ? Number((form.jaggeryUsedKg * curJaggeryRate).toFixed(2)) : 0;
  const totalMaterialValue = Number((calcEggCost + calcChikkiCost + calcRagiCost + calcJaggeryCost).toFixed(2));

  const dayTotalRoll = (form.primaryRoll || 0) + (form.upperPrimaryRoll || 0);
  const dayTotalAttendance = (form.primaryAttendance || 0) + (form.upperPrimaryAttendance || 0);
  const attendancePct = dayTotalRoll > 0 ? Math.round((dayTotalAttendance / dayTotalRoll) * 100) : 0;

  // List of commodities for the editor (excluding cooking oil and pulses/dal)
  const stockList: DayCommodityDetail[] = Object.values(form.commoditiesStock || {}).filter(
    (comm) => comm.commodityId !== 'oil' && comm.commodityId !== 'pulses'
  );

  const handleResetToStandardGovtRates = () => {
    setRawRateInputs((prev) => ({
      ...prev,
      primaryRatePerMeal: '5.45',
      upperPrimaryRatePerMeal: '8.17',
      eggRate: '6.00',
      chikkiRate: '5.00',
      ragiRatePerKg: '35.00',
      jaggeryRatePerKg: '60.00',
      customCookingCost: '',
    }));
    setForm({
      ...form,
      autoCalcExpenditure: true,
      customCookingCost: undefined,
      primaryRatePerMeal: 5.45,
      upperPrimaryRatePerMeal: 8.17,
      eggRate: 6.00,
      chikkiRate: 5.00,
      ragiRatePerKg: 35.00,
      jaggeryRatePerKg: 60.00,
      cchCost: 0,
      otherCost: 0,
    });
  };

  const commitAutoSave = useCallback((stateToSave: DayEditorState, updateRoll: boolean) => {
    setIsAutoSaving(true);
    try {
      if (stateToSave.updateMasterMealRates && onUpdateMealRates) {
        onUpdateMealRates({
          ...mealRates,
          primaryRatePerMeal: curPrimaryRate,
          upperPrimaryRatePerMeal: curUpperPrimaryRate,
          eggRate: curEggRate,
          chikkiRate: curChikkiRate,
          ragiRatePerKg: curRagiRate,
          jaggeryRatePerKg: curJaggeryRate,
        });
      }
      const customMap = getStoredCustomHolidays();
      if (stateToSave.isHoliday) {
        customMap[stateToSave.date] = stateToSave.holidayName?.trim() || 'School Holiday';
      } else {
        customMap[stateToSave.date] = 'WORKING_DAY';
      }
      saveStoredCustomHolidays(customMap);

      onSave(stateToSave, updateRoll, false);
      isDirtyRef.current = false;
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastAutoSavedTime(timeStr);
    } finally {
      setTimeout(() => setIsAutoSaving(false), 300);
    }
  }, [onSave, onUpdateMealRates, mealRates, curPrimaryRate, curUpperPrimaryRate, curEggRate, curChikkiRate, curRagiRate, curJaggeryRate]);

  // Debounced auto-save effect whenever form changes
  useEffect(() => {
    if (!isDirtyRef.current) return;
    const timer = setTimeout(() => {
      if (isDirtyRef.current) {
        commitAutoSave(formRef.current, updateBaseRollRef.current);
      }
    }, 450);
    return () => clearTimeout(timer);
  }, [form, commitAutoSave]);

  // Flush any pending changes on unmount
  useEffect(() => {
    return () => {
      if (isDirtyRef.current) {
        onSave(formRef.current, updateBaseRollRef.current, false);
      }
    };
  }, [onSave]);

  const handleSaveModal = (andGoToNext: boolean) => {
    // If updateMasterMealRates is checked, update master meal rates in App
    if (form.updateMasterMealRates && onUpdateMealRates) {
      onUpdateMealRates({
        ...mealRates,
        primaryRatePerMeal: curPrimaryRate,
        upperPrimaryRatePerMeal: curUpperPrimaryRate,
        eggRate: curEggRate,
        chikkiRate: curChikkiRate,
        ragiRatePerKg: curRagiRate,
        jaggeryRatePerKg: curJaggeryRate,
      });
    }

    const customMap = getStoredCustomHolidays();
    if (form.isHoliday) {
      customMap[form.date] = form.holidayName?.trim() || 'School Holiday';
    } else {
      customMap[form.date] = 'WORKING_DAY';
    }
    saveStoredCustomHolidays(customMap);

    isDirtyRef.current = false;
    onSave(form, updateBaseRoll, andGoToNext);
  };

  const getCommodityIcon = (id: string) => {
    switch (id) {
      case 'rice':
        return <Wheat className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
      case 'egg':
        return <Egg className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'chikki':
        return <Cookie className="w-4 h-4 text-orange-600 dark:text-orange-400" />;
      case 'ragi':
        return <Flame className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
      case 'jaggery':
        return <Coffee className="w-4 h-4 text-pink-600 dark:text-pink-400" />;
      case 'oil':
        return <Droplet className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />;
      case 'pulses':
        return <Layers className="w-4 h-4 text-teal-600 dark:text-teal-400" />;
      default:
        return <PackagePlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
    }
  };

  if (!isOpen || !editorState) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-700 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-white/15 backdrop-blur-md rounded-xl">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg">
                  Edit Daily MDM Register, Stocks & Expenditure Norms
                </h3>
                {form.isExistingSaved ? (
                  <span className="px-2 py-0.5 bg-amber-400/30 text-amber-100 text-[11px] font-bold rounded-full border border-amber-300/40">
                    Custom Saved
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-emerald-400/30 text-emerald-100 text-[11px] font-bold rounded-full border border-emerald-300/40">
                    Dynamic Auto-Mode
                  </span>
                )}
                {/* Real-time Auto-save Indicator */}
                {isAutoSaving ? (
                  <span className="px-2 py-0.5 bg-amber-300/30 text-amber-100 text-[11px] font-bold rounded-full border border-amber-300/40 animate-pulse flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-300"></span>
                    <span>Saving...</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-emerald-300/30 text-emerald-100 text-[11px] font-bold rounded-full border border-emerald-300/40 flex items-center gap-1" title={lastAutoSavedTime ? `Auto-saved at ${lastAutoSavedTime}` : 'All changes save automatically'}>
                    <Check className="w-3 h-3 text-emerald-200" />
                    <span>{lastAutoSavedTime ? `Saved ${lastAutoSavedTime}` : 'Auto-save active'}</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-purple-100 mt-0.5">
                {formatDateReadable(form.date)} ({dayInfo.dayName})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-purple-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-100 dark:bg-slate-800/80 px-4 sm:px-5 pt-3 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('attendance')}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-t-xl transition-colors flex items-center gap-1.5 sm:gap-2 border-t border-x cursor-pointer ${
              activeTab === 'attendance'
                ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 border-slate-200 dark:border-slate-700 -mb-px shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border-transparent'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Attendance & Meals</span>
            <span className="px-1.5 py-0.2 bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200 text-[10px] font-extrabold rounded-full">
              {form.mealsServed} Meals
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('commodities')}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-t-xl transition-colors flex items-center gap-1.5 sm:gap-2 border-t border-x cursor-pointer ${
              activeTab === 'commodities'
                ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-300 border-slate-200 dark:border-slate-700 -mb-px shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border-transparent'
            }`}
          >
            <PackagePlus className="w-4 h-4" />
            <span>Commodities Stock (OB/Rec/Spoil)</span>
            <span className="px-1.5 py-0.2 bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-200 text-[10px] font-extrabold rounded-full">
              {stockList.length} Items
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('expenditure')}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-t-xl transition-colors flex items-center gap-1.5 sm:gap-2 border-t border-x cursor-pointer ${
              activeTab === 'expenditure'
                ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 border-slate-200 dark:border-slate-700 -mb-px shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border-transparent'
            }`}
          >
            <IndianRupee className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Expenditure / Day Norms (₹)</span>
            <span className="px-1.5 py-0.2 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 text-[10px] font-extrabold rounded-full">
              {finalDayCookingCost > 0 ? `₹${finalDayCookingCost.toFixed(2)}` : '₹0'}
            </span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          
          {/* Day Status Switcher (Available on all tabs) */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-200 block">
                School Working Status for {formatDateReadable(form.date)}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                {form.isHoliday ? 'Marked as Non-Working Day / School Closure' : 'Marked as Working School Day (MDM Meals Served)'}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => handleToggleHoliday(false)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  !form.isHoliday
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Working Day
              </button>

              <button
                type="button"
                onClick={() => handleToggleHoliday(true)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  form.isHoliday
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                Holiday / Closed
              </button>
            </div>
          </div>

          {/* Holiday Name Banner if Holiday */}
          {form.isHoliday && (
            <div className="p-3.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-xl space-y-2">
              <label className="block text-[11px] font-bold text-red-600 dark:text-red-400">
                Holiday / Reason for School Closure:
              </label>
              <input
                type="text"
                value={form.holidayName}
                onChange={(e) => setForm({ ...form, holidayName: e.target.value, remarks: e.target.value })}
                placeholder="e.g. Sunday Holiday, National Holiday, Local Festival"
                className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 border border-red-300 dark:border-red-700 rounded-lg text-red-600 dark:text-red-300 font-bold focus:border-red-500"
              />
              <p className="text-[10px] text-red-600/90 dark:text-red-400/90">
                Attendance, MDM meal consumption, and daily expenditure are automatically zeroed out for holidays. Opening and Closing stock balances carry forward unchanged.
              </p>
            </div>
          )}

          {/* TAB 1: ATTENDANCE & MEALS */}
          {activeTab === 'attendance' && (
            <>
              {/* 1. Student Enrollment Strength */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                      1. Enrolled Student Strength (Roll)
                    </span>
                  </div>
                  <span className="text-xs font-extrabold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-800">
                    Total Roll: {dayTotalRoll} Students
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Primary Roll (Class 1-5):
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={form.primaryRoll === 0 ? '' : form.primaryRoll}
                      onKeyDown={blockNonIntegerKeys}
                      onChange={(e) => {
                        const val = parseWholeNumber(e.target.value);
                        setForm((prev) => ({
                          ...prev,
                          primaryRoll: val,
                          primaryAttendance: Math.min(val, prev.primaryAttendance),
                        }));
                      }}
                      placeholder="0"
                      className="w-full px-3 py-1.5 text-sm font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Upper Primary Roll (Class 6-8):
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={form.upperPrimaryRoll === 0 ? '' : form.upperPrimaryRoll}
                      onKeyDown={blockNonIntegerKeys}
                      onChange={(e) => {
                        const val = parseWholeNumber(e.target.value);
                        setForm((prev) => ({
                          ...prev,
                          upperPrimaryRoll: val,
                          upperPrimaryAttendance: Math.min(val, prev.upperPrimaryAttendance),
                        }));
                      }}
                      placeholder="0"
                      className="w-full px-3 py-1.5 text-sm font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                    <input
                      type="checkbox"
                      id="updateBaseRollCheckbox"
                      checked={updateBaseRoll}
                      onChange={(e) => setUpdateBaseRoll(e.target.checked)}
                      className="w-3.5 h-3.5 rounded text-purple-600"
                    />
                    <label htmlFor="updateBaseRollCheckbox" className="cursor-pointer">
                      Apply this enrollment strength update to master student roster forward
                    </label>
                  </div>
                  <span className="text-[10px] text-purple-600 dark:text-purple-300 font-bold bg-purple-50 dark:bg-purple-950/40 px-1.5 py-0.5 rounded">
                    Whole Students Only
                  </span>
                </div>
              </div>

              {/* 2. Attendance & Meals Served */}
              <div className="bg-blue-50/60 dark:bg-blue-950/30 p-4 rounded-xl border border-blue-100 dark:border-blue-900/50 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span className="text-xs font-extrabold text-blue-900 dark:text-blue-200 uppercase tracking-wide">
                      2. Daily Attendance & Meals Served
                    </span>
                  </div>

                  {/* Quick Attendance Percentage Presets */}
                  <div className="flex items-center space-x-1.5">
                    <span className="text-[10.5px] font-bold text-slate-500 mr-1">Quick:</span>
                    {[100, 95, 90, 85].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => handleApplyAttendancePercent(pct)}
                        className="px-2 py-0.5 text-[11px] font-extrabold bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 rounded border border-blue-200 dark:border-blue-800 transition-colors shadow-2xs cursor-pointer"
                      >
                        {pct}%
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Primary Attendance:
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      max={form.primaryRoll}
                      value={form.primaryAttendance === 0 ? '' : form.primaryAttendance}
                      onKeyDown={blockNonIntegerKeys}
                      onChange={(e) => handleAttendanceChange('primaryAttendance', parseWholeNumber(e.target.value))}
                      placeholder="0"
                      className="w-full px-3 py-1.5 text-sm font-bold bg-white dark:bg-slate-800 border border-blue-300 dark:border-blue-700 rounded-lg text-blue-900 dark:text-blue-200"
                    />
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      Max: {form.primaryRoll} ({form.primaryRoll > 0 ? Math.round((form.primaryAttendance / form.primaryRoll) * 100) : 0}%)
                    </span>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Upper Primary Attendance:
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      max={form.upperPrimaryRoll}
                      value={form.upperPrimaryAttendance === 0 ? '' : form.upperPrimaryAttendance}
                      onKeyDown={blockNonIntegerKeys}
                      onChange={(e) => handleAttendanceChange('upperPrimaryAttendance', parseWholeNumber(e.target.value))}
                      placeholder="0"
                      className="w-full px-3 py-1.5 text-sm font-bold bg-white dark:bg-slate-800 border border-blue-300 dark:border-blue-700 rounded-lg text-blue-900 dark:text-blue-200"
                    />
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      Max: {form.upperPrimaryRoll} ({form.upperPrimaryRoll > 0 ? Math.round((form.upperPrimaryAttendance / form.upperPrimaryRoll) * 100) : 0}%)
                    </span>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-800 dark:text-emerald-300 mb-1">
                      MDM Meals Served:
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={form.mealsServed === 0 ? '' : form.mealsServed}
                      onKeyDown={blockNonIntegerKeys}
                      onChange={(e) => {
                        const val = parseWholeNumber(e.target.value);
                        setForm((prev) => ({ ...prev, mealsServed: val }));
                      }}
                      placeholder="0"
                      className="w-full px-3 py-1.5 text-sm font-extrabold bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 rounded-lg text-emerald-700 dark:text-emerald-300"
                    />
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5 block">
                      Total Att: {dayTotalAttendance} ({attendancePct}%)
                    </span>
                  </div>

                  <div className="bg-rose-50/80 dark:bg-rose-950/40 p-2 rounded-lg border border-rose-200 dark:border-rose-800/60 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-rose-700 dark:text-rose-300 uppercase block leading-tight">
                        Meals Not Served
                      </span>
                      <span className="text-base font-black text-rose-700 dark:text-rose-300 block mt-0.5">
                        {Math.max(0, dayTotalAttendance - (form.mealsServed || 0))}
                      </span>
                    </div>
                    <span className="text-[9px] text-rose-600 dark:text-rose-400 font-semibold block leading-tight">
                      ({dayTotalAttendance} Attn − {form.mealsServed || 0} Meals)
                    </span>
                  </div>
                </div>
              </div>

              {/* Day Financial & Stock Quick Summary Banner */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Cost summary card */}
                <div className="bg-emerald-50/70 dark:bg-emerald-950/30 p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900/50 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-extrabold text-emerald-900 dark:text-emerald-200 uppercase tracking-wide flex items-center gap-1.5">
                      <IndianRupee className="w-3.5 h-3.5 text-emerald-600" />
                      Day Expenditure
                    </span>
                    <span className="text-lg font-black text-emerald-700 dark:text-emerald-300 block mt-0.5">
                      {formatCurrency(finalDayCookingCost)}
                    </span>
                    <span className="text-[10px] text-emerald-800 dark:text-emerald-400">
                      Pri: ₹{curPrimaryRate.toFixed(2)} | Up: ₹{curUpperPrimaryRate.toFixed(2)} / head
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('expenditure')}
                    className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                  >
                    <span>Edit Norms</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* Stock summary card */}
                <div className="bg-amber-50/70 dark:bg-amber-950/30 p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/50 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-extrabold text-amber-900 dark:text-amber-200 uppercase tracking-wide flex items-center gap-1.5">
                      <Wheat className="w-3.5 h-3.5 text-amber-600" />
                      Day Commodities Stock
                    </span>
                    <span className="text-xs font-bold text-amber-800 dark:text-amber-300 block mt-1">
                      🌾 {form.riceUsedKg}kg Rice | 🥚 {form.eggUsedQty} Eggs
                    </span>
                    <span className="text-[10px] text-slate-500">
                      🥜 {form.chikkiUsedQty} Chikki | 🥣 {form.ragiUsedKg}kg Ragi
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('commodities')}
                    className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                  >
                    <span>Edit Stock</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Day Remarks */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Day Remarks / Notes:
                </label>
                <input
                  type="text"
                  value={form.remarks}
                  onChange={(e) => setForm({ ...form, remarks: e.target.value })}
                  placeholder="e.g. Regular meal served, Egg boiled properly"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
                />
              </div>
            </>
          )}

          {/* TAB 2: COMMODITIES STOCK MANAGEMENT */}
          {activeTab === 'commodities' && (
            <div className="space-y-4">
              {/* Top Banner Guide & Actions */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40 p-4 rounded-xl border border-indigo-200 dark:border-indigo-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <PackagePlus className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    <h4 className="text-sm font-extrabold text-indigo-950 dark:text-indigo-200">
                      Day Commodities Ledger: Opening, Received, Used & Spoiled
                    </h4>
                  </div>
                  <p className="text-xs text-indigo-800 dark:text-indigo-300 mt-1">
                    Balance Formula: <span className="font-bold text-indigo-950 dark:text-white">Closing Balance = Opening Balance (OB) + Received (Rec) - Used - Spoiled</span>
                  </p>
                  <p className="text-[11px] text-purple-700 dark:text-purple-300 font-semibold mt-0.5">
                    ✨ Supports decimal digits (e.g., 0.125 kg, 0.05 kg) and minus/negative numbers (e.g., -1.5, -0.25 kg) for stock adjustments & returns.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => {
                      const norms = recalcNorms(form.primaryAttendance, form.upperPrimaryAttendance, false, dayInfo.dayOfWeek);
                      const updatedStock = { ...(form.commoditiesStock || {}) };
                      const nextRaw = { ...rawCommInputs };
                      const syncCommUsed = (commId: string, usedVal: number) => {
                        if (updatedStock[commId]) {
                          const item = updatedStock[commId];
                          const cb = Number((item.ob + item.received - usedVal - item.spoiled).toFixed(3));
                          updatedStock[commId] = { ...item, used: usedVal, cb };
                        }
                        nextRaw[commId] = {
                          ...(nextRaw[commId] || { ob: '0', received: '', used: '0', spoiled: '' }),
                          used: String(usedVal),
                        };
                      };
                      syncCommUsed('rice', norms.rice);
                      syncCommUsed('egg', norms.egg);
                      syncCommUsed('chikki', norms.chikki);
                      syncCommUsed('ragi', norms.ragi);
                      syncCommUsed('jaggery', norms.jaggery);
                      syncCommUsed('oil', norms.oil);
                      syncCommUsed('pulses', norms.pulses);
                      setRawCommInputs(nextRaw);

                      setForm({
                        ...form,
                        autoCalcCommodities: true,
                        riceUsedKg: norms.rice,
                        eggUsedQty: norms.egg,
                        chikkiUsedQty: norms.chikki,
                        ragiUsedKg: norms.ragi,
                        jaggeryUsedKg: norms.jaggery,
                        oilUsedLitres: norms.oil,
                        pulsesUsedKg: norms.pulses,
                        commoditiesStock: updatedStock,
                      });
                    }}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Auto-calculate usage for all commodities using official AP Menu norms"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Norms AP Menu</span>
                  </button>
                </div>
              </div>

              {/* Commodities List Cards */}
              <div className="space-y-3">
                {stockList.map((comm) => {
                  return (
                    <div
                      key={comm.commodityId}
                      className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 transition-all hover:border-indigo-300 dark:hover:border-indigo-700"
                    >
                      {/* Commodity Card Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 bg-white dark:bg-slate-700 rounded-lg shadow-2xs">
                            {getCommodityIcon(comm.commodityId)}
                          </div>
                          <div>
                            <span className="text-sm font-black text-slate-900 dark:text-white">
                              {comm.name}
                            </span>
                            <span className="text-[11px] font-bold text-slate-400 ml-1.5">
                              ({comm.unit})
                            </span>
                          </div>
                        </div>

                        {/* Calculated Closing Balance Pill */}
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-500">
                            Closing Balance (CB):
                          </span>
                          <span
                            className={`px-2.5 py-1 rounded-lg text-xs font-black font-mono border ${
                              comm.cb >= 0
                                ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-800 dark:text-cyan-200 border-cyan-300 dark:border-cyan-700'
                                : 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-200 border-red-300 dark:border-red-700'
                            }`}
                          >
                            {formatQtyVal(comm.cb)} {comm.unit}
                          </span>
                        </div>
                      </div>

                      {/* 4-Column Stock Grid: OB | Received | Used | Spoiled */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {/* 1. Opening Balance (OB) */}
                        <div className="bg-indigo-50/50 dark:bg-indigo-950/20 p-2.5 rounded-lg border border-indigo-100 dark:border-indigo-900/40">
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-indigo-900 dark:text-indigo-300">
                              Opening Balance (OB):
                            </label>
                            <div className="flex items-center gap-1">
                              {(comm.commodityId === 'egg' || comm.commodityId === 'chikki') && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const curOb = typeof comm.ob === 'number' ? comm.ob : parseFloat(comm.ob as any) || 0;
                                    const toggled = -curOb;
                                    updateCommodityStockField(comm.commodityId, 'ob', String(toggled));
                                  }}
                                  className="px-1.5 py-0.2 text-[9px] font-bold font-mono bg-indigo-100 hover:bg-indigo-200 dark:bg-indigo-900/60 dark:hover:bg-indigo-800 text-indigo-700 dark:text-indigo-300 rounded border border-indigo-300 dark:border-indigo-700 cursor-pointer"
                                  title="Toggle +/- minus sign (for deficit/loan)"
                                >
                                  ± Sign
                                </button>
                              )}
                              <span className="text-[9.5px] font-mono text-indigo-500 font-bold">{comm.unit}</span>
                            </div>
                          </div>
                          <input
                            type="text"
                            inputMode="decimal"
                            pattern="[0-9.-]*"
                            placeholder="0.00"
                            value={rawCommInputs[comm.commodityId]?.ob ?? (comm.ob !== undefined && comm.ob !== null ? String(comm.ob) : '0')}
                            onChange={(e) => updateCommodityStockField(comm.commodityId, 'ob', e.target.value)}
                            className={`w-full px-2.5 py-1 text-xs font-bold bg-white dark:bg-slate-800 border rounded-md font-mono ${
                              comm.ob < 0
                                ? 'border-rose-400 dark:border-rose-600 text-rose-700 dark:text-rose-300 font-black'
                                : 'border-indigo-300 dark:border-indigo-700 text-indigo-900 dark:text-indigo-200'
                            }`}
                          />
                          <span className="text-[9.5px] text-indigo-600 dark:text-indigo-400 block mt-0.5">
                            {(comm.commodityId === 'egg' || comm.commodityId === 'chikki')
                              ? 'Supports minus numbers (e.g. -10 for deficit/loan)'
                              : (comm.isObEdited ? 'Custom edited OB' : 'Start of day stock')}
                          </span>
                        </div>

                        {/* 2. Received Inward (+) */}
                        <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-2.5 rounded-lg border border-emerald-100 dark:border-emerald-900/40">
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-emerald-900 dark:text-emerald-300">
                              + Received ({comm.unit}):
                            </label>
                            <span className="text-[9.5px] text-emerald-600 font-bold">Inward</span>
                          </div>
                          <input
                            type="text"
                            inputMode="decimal"
                            pattern="[0-9.-]*"
                            placeholder="0.00"
                            value={rawCommInputs[comm.commodityId]?.received ?? (comm.received ? String(comm.received) : '')}
                            onChange={(e) => updateCommodityStockField(comm.commodityId, 'received', e.target.value)}
                            className="w-full px-2.5 py-1 text-xs font-bold bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 rounded-md text-emerald-700 dark:text-emerald-200 font-mono"
                          />
                          <input
                            type="text"
                            placeholder="Invoice / Supplier"
                            value={comm.supplierInvoice || ''}
                            onChange={(e) => updateCommodityStockField(comm.commodityId, 'supplierInvoice', e.target.value)}
                            className="w-full mt-1 px-2 py-0.5 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-700 dark:text-slate-300"
                          />
                        </div>

                        {/* 3. Used / Consumed (-) */}
                        <div className="bg-blue-50/50 dark:bg-blue-950/20 p-2.5 rounded-lg border border-blue-100 dark:border-blue-900/40">
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-blue-900 dark:text-blue-300">
                              - Used ({comm.unit}):
                            </label>
                            <span className="text-[9.5px] text-blue-600 font-bold">Usage / Decimals</span>
                          </div>
                          <input
                            type="text"
                            inputMode="decimal"
                            pattern="[0-9.-]*"
                            placeholder="0.00"
                            value={rawCommInputs[comm.commodityId]?.used ?? (comm.used !== undefined && comm.used !== null ? String(comm.used) : '0')}
                            onChange={(e) => {
                              setForm((prev) => ({ ...prev, autoCalcCommodities: false }));
                              updateCommodityStockField(comm.commodityId, 'used', e.target.value);
                            }}
                            className={`w-full px-2.5 py-1 text-xs font-bold border rounded-md font-mono ${
                              form.autoCalcCommodities
                                ? 'bg-blue-100/50 dark:bg-blue-900/40 text-blue-900 dark:text-blue-100 border-blue-300 dark:border-blue-700'
                                : 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-200 border-blue-300 dark:border-blue-700'
                            }`}
                          />
                          <span className="text-[9.5px] text-blue-600 dark:text-blue-400 block mt-0.5">
                            {form.autoCalcCommodities ? 'Auto AP Menu Norms' : 'Custom manual used'}
                          </span>
                        </div>

                        {/* 4. Spoiled / Damaged / Wastage */}
                        <div className="bg-rose-50/50 dark:bg-rose-950/20 p-2.5 rounded-lg border border-rose-100 dark:border-rose-900/40">
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-rose-900 dark:text-rose-300">
                              ⚠️ Spoiled ({comm.unit}):
                            </label>
                            <span className="text-[9.5px] text-rose-600 font-bold">Damage</span>
                          </div>
                          <input
                            type="text"
                            inputMode="decimal"
                            pattern="[0-9.-]*"
                            placeholder="0.00"
                            value={rawCommInputs[comm.commodityId]?.spoiled ?? (comm.spoiled ? String(comm.spoiled) : '')}
                            onChange={(e) => updateCommodityStockField(comm.commodityId, 'spoiled', e.target.value)}
                            className="w-full px-2.5 py-1 text-xs font-bold bg-white dark:bg-slate-800 border border-rose-300 dark:border-rose-700 rounded-md text-rose-700 dark:text-rose-200 font-mono"
                          />
                          <input
                            type="text"
                            placeholder="Damage reason (e.g. Broken)"
                            value={comm.spoilReason || ''}
                            onChange={(e) => updateCommodityStockField(comm.commodityId, 'spoilReason', e.target.value)}
                            className="w-full mt-1 px-2 py-0.5 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-700 dark:text-slate-300"
                          />
                        </div>
                      </div>

                      {/* Quick Adjustment Helpers for minus / decimal entries */}
                      <div className="pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-1.5 text-[10.5px]">
                        <span className="text-slate-500 dark:text-slate-400 font-semibold">
                          Quick {comm.name} adjustments:
                        </span>
                        <div className="flex flex-wrap items-center gap-1">
                          {[
                            { label: '+1', delta: 1 },
                            { label: '-1', delta: -1 },
                            { label: '+0.5', delta: 0.5 },
                            { label: '-0.5', delta: -0.5 },
                            { label: '+0.1', delta: 0.1 },
                            { label: '-0.1', delta: -0.1 },
                            { label: '+0.05', delta: 0.05 },
                            { label: '-0.05', delta: -0.05 },
                          ].map((adj) => (
                            <button
                              key={`${comm.commodityId}-${adj.label}`}
                              type="button"
                              onClick={() => {
                                setForm((prev) => ({ ...prev, autoCalcCommodities: false }));
                                const curUsed = typeof comm.used === 'number' ? comm.used : parseFloat(comm.used as any) || 0;
                                const nextUsed = Number((curUsed + adj.delta).toFixed(3));
                                updateCommodityStockField(comm.commodityId, 'used', String(nextUsed));
                              }}
                              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold transition-colors cursor-pointer ${
                                adj.delta < 0
                                  ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-200 border border-rose-200 dark:border-rose-800'
                                  : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-200 border border-emerald-200 dark:border-emerald-800'
                              }`}
                              title={`Adjust ${comm.name} used quantity by ${adj.label} ${comm.unit}`}
                            >
                              Used {adj.label}
                            </button>
                          ))}
                          <button
                            type="button"
                            onClick={() => {
                              setForm((prev) => ({ ...prev, autoCalcCommodities: false }));
                              const curUsed = typeof comm.used === 'number' ? comm.used : parseFloat(comm.used as any) || 0;
                              const nextUsed = Number((-curUsed).toFixed(3));
                              updateCommodityStockField(comm.commodityId, 'used', String(nextUsed));
                            }}
                            className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 hover:bg-purple-200 border border-purple-200 dark:border-purple-800 transition-colors cursor-pointer"
                            title={`Invert +/- sign for ${comm.name} used`}
                          >
                            +/- Sign
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: EXPENDITURE & COST NORMS PER DAY */}
          {activeTab === 'expenditure' && (
            <div className="space-y-4">
              
              {/* Header Banner & Mode Switcher */}
              <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-cyan-700 text-white p-4 sm:p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <IndianRupee className="w-6 h-6 text-emerald-200" />
                    <h4 className="text-base font-black uppercase tracking-wide text-white">
                      Expenditure & Cooking Cost Norms for {formatDateReadable(form.date)}
                    </h4>
                  </div>
                  <p className="text-xs text-emerald-100 mt-1 max-w-xl">
                    Configure daily cooking cost rates per child (Primary & Upper Primary), egg/chikki norms, helper honorarium, and custom day expenditure overrides.
                  </p>
                </div>

                {/* Total Day Expenditure Hero Badge */}
                <div className="bg-white/15 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/25 text-right shrink-0">
                  <span className="text-[10px] uppercase font-extrabold text-emerald-200 block">
                    Day Total Expenditure (₹)
                  </span>
                  <span className="text-xl sm:text-2xl font-black text-white font-mono" style={{ color: '#39ff14' }}>
                    {formatCurrency(finalDayCookingCost)}
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-100 block">
                    {form.autoCalcExpenditure ? '⚡ Auto AP Norms' : '✍️ Custom Override'}
                  </span>
                </div>
              </div>

              {/* Mode Switcher Toggle: Auto Norms vs Custom Manual Total */}
              <div className="bg-slate-50 dark:bg-slate-800/70 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <label className="text-xs font-extrabold text-slate-800 dark:text-slate-200 block uppercase tracking-wide">
                      Expenditure Calculation Mode
                    </label>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      Choose how the register computes day expenditure:
                    </span>
                  </div>

                  <div className="flex items-center bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-300 dark:border-slate-700">
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, autoCalcExpenditure: true, customCookingCost: undefined })}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                        form.autoCalcExpenditure
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Auto Norms (Rate × Att)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const targetCost = form.customCookingCost ?? autoCalculatedTotalCookingCost;
                        setRawRateInputs((prev) => ({ ...prev, customCookingCost: String(targetCost) }));
                        setForm({
                          ...form,
                          autoCalcExpenditure: false,
                          customCookingCost: targetCost,
                        });
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                        !form.autoCalcExpenditure
                          ? 'bg-purple-600 text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span>Custom Fixed Amount (₹)</span>
                    </button>
                  </div>
                </div>

                {/* Custom Fixed Amount Input if active */}
                {!form.autoCalcExpenditure && (
                  <div className="bg-purple-50 dark:bg-purple-950/40 p-3 rounded-lg border border-purple-200 dark:border-purple-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-150">
                    <div>
                      <span className="text-xs font-extrabold text-purple-900 dark:text-purple-200 block">
                        Enter Custom Daily Expenditure Override (₹):
                      </span>
                      <span className="text-[10px] text-purple-700 dark:text-purple-300">
                        Directly sets the daily expenditure in the register and cash vouchers.
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-extrabold text-purple-900 dark:text-purple-200">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.customCookingCost ?? (form.customCookingCost !== undefined ? String(form.customCookingCost) : '')}
                        onChange={(e) => handleRateFieldChange('customCookingCost', e.target.value)}
                        placeholder="0.00"
                        className="w-36 px-3 py-1.5 text-sm font-black bg-white dark:bg-slate-800 border border-purple-300 dark:border-purple-700 rounded-lg text-purple-950 dark:text-purple-100 font-mono"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* 1. Per-Meal Cooking Cost Rates (₹ / Child) */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                      1. Per-Student Daily Cooking Cost Norm Rates (₹)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetToStandardGovtRates}
                    className="px-2 py-1 text-[10.5px] font-bold text-slate-600 dark:text-slate-300 hover:text-emerald-600 bg-white dark:bg-slate-700 rounded border border-slate-200 dark:border-slate-600 flex items-center gap-1 cursor-pointer transition-colors"
                    title="Reset rates to standard MDM government norms"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset to Govt Norms</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Primary Rate */}
                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300">
                        Primary (Class 1-5) Rate:
                      </label>
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
                        Govt Norm: ₹5.45
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.primaryRatePerMeal ?? String(curPrimaryRate)}
                        onChange={(e) => handleRateFieldChange('primaryRatePerMeal', e.target.value)}
                        className="w-full px-2.5 py-1 text-sm font-black bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-indigo-700 dark:text-indigo-300 font-mono"
                      />
                      <span className="text-[11px] text-slate-400 whitespace-nowrap">/ child</span>
                    </div>
                    <div className="text-[10px] text-slate-500 pt-0.5 flex justify-between">
                      <span>Att: {form.primaryAttendance} students</span>
                      <strong className="text-indigo-600 dark:text-indigo-400 font-mono">Cost: ₹{calcPrimaryCost.toFixed(2)}</strong>
                    </div>
                  </div>

                  {/* Upper Primary Rate */}
                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-extrabold text-slate-700 dark:text-slate-300">
                        Upper Primary (Class 6-8) Rate:
                      </label>
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300">
                        Govt Norm: ₹8.17
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.upperPrimaryRatePerMeal ?? String(curUpperPrimaryRate)}
                        onChange={(e) => handleRateFieldChange('upperPrimaryRatePerMeal', e.target.value)}
                        className="w-full px-2.5 py-1 text-sm font-black bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-purple-700 dark:text-purple-300 font-mono"
                      />
                      <span className="text-[11px] text-slate-400 whitespace-nowrap">/ child</span>
                    </div>
                    <div className="text-[10px] text-slate-500 pt-0.5 flex justify-between">
                      <span>Att: {form.upperPrimaryAttendance} students</span>
                      <strong className="text-purple-600 dark:text-purple-400 font-mono">Cost: ₹{calcUpperPrimaryCost.toFixed(2)}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Commodity Norm Rates (Egg, Chikki, Ragi, Jaggery) */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <IndianRupee className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                      2. Special Menu Item Unit Rates (₹)
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Used for supplementary bill vouchers
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-amber-800 dark:text-amber-300 mb-1">
                      🥚 Egg Rate:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.eggRate ?? String(curEggRate)}
                        onChange={(e) => handleRateFieldChange('eggRate', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded text-amber-900 dark:text-amber-200 font-mono"
                      />
                      <span className="text-[10px] text-slate-400">/egg</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-orange-800 dark:text-orange-300 mb-1">
                      🥜 Chikki Rate:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.chikkiRate ?? String(curChikkiRate)}
                        onChange={(e) => handleRateFieldChange('chikkiRate', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-orange-300 dark:border-orange-700 rounded text-orange-900 dark:text-orange-200 font-mono"
                      />
                      <span className="text-[10px] text-slate-400">/pcs</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-purple-800 dark:text-purple-300 mb-1">
                      🥣 Ragi Flour:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.ragiRatePerKg ?? String(curRagiRate)}
                        onChange={(e) => handleRateFieldChange('ragiRatePerKg', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-purple-300 dark:border-purple-700 rounded text-purple-900 dark:text-purple-200 font-mono"
                      />
                      <span className="text-[10px] text-slate-400">/kg</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                    <label className="block text-[10.5px] font-bold text-pink-800 dark:text-pink-300 mb-1">
                      🍯 Jaggery:
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-slate-400">₹</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawRateInputs.jaggeryRatePerKg ?? String(curJaggeryRate)}
                        onChange={(e) => handleRateFieldChange('jaggeryRatePerKg', e.target.value)}
                        className="w-full px-2 py-0.5 text-xs font-black bg-slate-50 dark:bg-slate-800 border border-pink-300 dark:border-pink-700 rounded text-pink-900 dark:text-pink-200 font-mono"
                      />
                      <span className="text-[10px] text-slate-400">/kg</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Master Update Checkbox Option */}
              <div className="p-3 bg-indigo-50/70 dark:bg-indigo-950/30 rounded-xl border border-indigo-200 dark:border-indigo-800 flex items-center gap-2.5 text-xs text-indigo-950 dark:text-indigo-200">
                <input
                  type="checkbox"
                  id="updateMasterMealRatesCheckbox"
                  checked={form.updateMasterMealRates || false}
                  onChange={(e) => setForm({ ...form, updateMasterMealRates: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 cursor-pointer"
                />
                <label htmlFor="updateMasterMealRatesCheckbox" className="cursor-pointer font-semibold">
                  Save these expenditure rates / norms as school-wide defaults for subsequent days & cash vouchers
                </label>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-50 dark:bg-slate-800/80 p-4 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            {form.isExistingSaved && (
              <button
                type="button"
                onClick={() => onResetToAuto(form.date)}
                className="px-3 py-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg border border-rose-200 dark:border-rose-800/50 flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Remove custom overrides and restore dynamic automatic calculations"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Revert to Dynamic Auto</span>
              </button>
            )}

            {/* Auto-save status feedback */}
            {isAutoSaving ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                <span>Saving changes automatically...</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400" title={lastAutoSavedTime ? `Auto-saved at ${lastAutoSavedTime}` : 'All changes are automatically saved'}>
                <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{lastAutoSavedTime ? `Auto-saved at ${lastAutoSavedTime}` : 'Changes save automatically'}</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={() => {
                if (isDirtyRef.current) {
                  commitAutoSave(formRef.current, updateBaseRollRef.current);
                }
                onClose();
              }}
              className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
            >
              Done & Close
            </button>

            <button
              type="button"
              onClick={() => handleSaveModal(true)}
              className="px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs hover:shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
              title="Save this day and jump to editing the next day"
            >
              <span>Save & Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
