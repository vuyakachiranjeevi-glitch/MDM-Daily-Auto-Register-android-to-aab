import React from 'react';
import { NavigationTab } from '../types';
import {
  LayoutDashboard,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { MDMAppLogo } from './MDMAppLogo';

interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onLogout: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onOpenFlashScreen?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onLogout,
  collapsed,
  onToggleCollapse,
  onOpenFlashScreen,
}) => {
  const navItems: { id: NavigationTab; label: string; shortLabel: string; icon: React.ReactNode; color: string }[] = [
    { id: 'dashboard', label: 'Dashboard', shortLabel: 'Dashboard', icon: <LayoutDashboard className="w-4.5 h-4.5" />, color: 'text-blue-600 dark:text-blue-400' },
  ];

  return (
    <aside
      className={`glass-3d-tile bg-gradient-to-b from-[#FFFDF8] via-[#FAF5EB] to-[#F4ECE0] dark:from-[#09122a] dark:via-[#060d21] dark:to-[#030614] border-r border-amber-200/90 dark:border-sky-500/30 shadow-lg shadow-amber-950/5 transition-all duration-300 flex flex-col justify-between sticky top-16 z-20 ${
        collapsed ? 'w-12 md:w-13' : 'w-44 lg:w-48'
      }`}
    >
      <div className="p-1.5 sm:p-2">
        {/* Brand Header */}
        <div className="flex items-center justify-between mb-2 px-1 py-0.5">
          {!collapsed ? (
            <div
              className="flex items-center space-x-2 min-w-0 cursor-pointer group"
              onClick={onOpenFlashScreen}
              title="Click to view MDM Flash Screen"
            >
              <MDMAppLogo size={28} rounded="rounded-lg" />
              <div className="flex flex-col min-w-0">
                <span className="font-black text-slate-800 dark:text-white text-xs tracking-tight bg-gradient-to-r from-blue-700 to-indigo-800 dark:from-sky-300 dark:to-cyan-200 bg-clip-text text-transparent truncate leading-tight">
                  MDM Register
                </span>
                <span className="text-[9px] font-bold text-sky-600 dark:text-sky-400 truncate">
                  Daily Auto
                </span>
              </div>
            </div>
          ) : (
            <div
              className="mx-auto cursor-pointer"
              onClick={onOpenFlashScreen}
              title="Click to view MDM Flash Screen"
            >
              <MDMAppLogo size={26} rounded="rounded-lg" />
            </div>
          )}
          <button
            onClick={onToggleCollapse}
            className="p-1 rounded-lg text-blue-700 dark:text-sky-300 hover:text-blue-800 dark:hover:text-sky-200 transition-all shadow-md shrink-0 flex items-center justify-center glass-3d-btn border border-sky-300/80 dark:border-sky-500/50 ml-1"
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4 stroke-[2.5]" /> : <ChevronLeft className="w-4 h-4 stroke-[2.5]" />}
          </button>
        </div>

        {/* Nav Items */}
        <nav className="space-y-1.5">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl font-black text-xs sm:text-sm transition-all cursor-pointer active:scale-95 ${
                  isActive
                    ? 'btn-3d-glass-blue !text-white shadow-blue-900/60'
                    : 'glass-3d-btn text-slate-800 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-300'
                }`}
                title={item.label}
              >
                <span className={`shrink-0 ${isActive ? 'text-white' : item.color}`}>{item.icon}</span>
                {!collapsed && <span className="truncate leading-tight font-extrabold">{item.shortLabel}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer / Logout */}
      <div className="p-2 border-t border-slate-200/80 dark:border-slate-800/80">
        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-xl font-black text-xs sm:text-sm btn-3d-glass-rose cursor-pointer active:scale-95"
          title="Logout"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span className="truncate leading-tight">Logout</span>}
        </button>
      </div>
    </aside>
  );
};
