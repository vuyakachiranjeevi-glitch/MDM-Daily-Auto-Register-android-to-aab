export interface SchoolProfile {
  schoolName: string;
  udiseCode: string;
  headmasterName: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  implementingAgency: string;
  address: string;
  village?: string;
  mandal?: string;
  district?: string;
  state?: string;
  pincode?: string;
  phoneNumber: string;
  schoolPhotoUrl: string;
  academicYear: string;
}

export interface StudentClassStrength {
  classLevel: string; // 'Class 1', 'Class 2', ... 'Class 10'
  category: 'Primary' | 'Upper Primary' | 'High School';
  boys: number;
  girls: number;
  total: number;
}

export interface StudentStrengthUpdateRecord {
  id: string;
  date: string; // 'YYYY-MM-DD'
  strengths: StudentClassStrength[];
  remarks?: string;
  previousDate?: string;
  primaryBoys: number;
  primaryGirls: number;
  primaryTotal: number;
  upperBoys: number;
  upperGirls: number;
  upperTotal: number;
  totalBoys: number;
  totalGirls: number;
  grandTotal: number;
  changesSummary?: string;
  updatedAt?: string;
}

export interface DailyEntry {
  id: string;
  date: string; // 'YYYY-MM-DD'
  primaryAttendance: number;
  upperPrimaryAttendance: number;
  highSchoolAttendance: number;
  totalAttendance: number;
  mealsServed: number;
  riceUsedKg: number;
  oilUsedLitres?: number;
  pulsesUsedKg?: number;
  eggUsedQty: number;
  chikkiUsedQty: number;
  ragiUsedKg: number;
  jaggeryUsedKg: number;
  condimentsUsedKg?: number;
  commodityUsage?: Record<string, number>;
  remarks: string;
  createdAt?: string;
  updatedAt?: string;
  isManual?: boolean;
  // Daily Expenditure & Cost Norms
  customCookingCost?: number;
  primaryRatePerMeal?: number;
  upperPrimaryRatePerMeal?: number;
  eggRate?: number;
  chikkiRate?: number;
  ragiRatePerKg?: number;
  jaggeryRatePerKg?: number;
  cchCost?: number;
  otherCost?: number;
  costRemarks?: string;
}

export interface CommodityItem {
  id: 'rice' | 'oil' | 'pulses' | 'egg' | 'chikki' | 'ragi' | 'jaggery' | 'condiments' | string;
  name: string;
  unit: 'Kg' | 'Qty' | 'Packs' | 'Litres' | string;
  openingBalance: number;
  received: number;
  used: number;
  spoiled: number;
  closingBalance: number;
  minThreshold: number;
  normPerStudentGramOrUnitPrimary: number;
  normPerStudentGramOrUnitUpperPrimary: number;
}

export interface StockTransaction {
  id: string;
  date: string;
  commodityId: 'rice' | 'oil' | 'pulses' | 'egg' | 'chikki' | 'ragi' | 'jaggery' | 'condiments' | string;
  type: 'RECEIVED' | 'ADJUSTMENT' | 'SPOILED';
  quantity: number;
  invoiceNo?: string;
  supplier?: string;
  bagsCount?: number;
  remarks?: string;
  adjustmentReason?: string;
  previousRecordDate?: string;
  previousClosingBalance?: number;
  openingBalanceSource?: 'INITIAL' | 'CARRIED_FORWARD' | 'ADJUSTMENT' | 'MONTHLY_OVERRIDE';
}

export interface StockAuditInfo {
  commodityId: string;
  commodityName: string;
  unit: string;
  targetDate: string;
  openingBalance: number;
  received: number;
  used: number;
  spoiled: number;
  closingBalance: number;
  prevDate: string;
  lastActiveDate?: string;
  lastActiveCb?: number;
  sourceType: 'INITIAL' | 'CARRIED_FORWARD' | 'MONTHLY_OVERRIDE' | 'ADJUSTMENT';
  sourceDescription: string;
  isValid: boolean;
  expectedOpening: number;
  difference: number;
}

export interface MonthEndCarryForwardValidation {
  monthStr: string;
  commodityId: string;
  commodityName: string;
  unit: string;
  monthOpeningBalance: number;
  monthClosingBalance: number;
  nextMonthOpeningBalance: number;
  isCarryForwardCorrect: boolean;
  validationStatus: 'VALID' | 'MISMATCH' | 'REQUIRES_REVIEW';
  message: string;
}

export interface MealRates {
  primaryRatePerMeal: number; // e.g. 5.45
  upperPrimaryRatePerMeal: number; // e.g. 8.17
  highSchoolRatePerMeal: number; // e.g. 8.17
  eggRate: number; // e.g. 6.00
  chikkiRate: number; // e.g. 5.00
  ragiRatePerKg: number; // e.g. 35.00
  jaggeryRatePerKg: number; // e.g. 60.00
  riceNormPrimaryGrams?: number; // e.g. 100
  riceNormUpperPrimaryGrams?: number; // e.g. 150
  oilNormPrimaryGrams?: number; // e.g. 5
  oilNormUpperPrimaryGrams?: number; // e.g. 7.5
  pulsesNormPrimaryGrams?: number; // e.g. 20
  pulsesNormUpperPrimaryGrams?: number; // e.g. 30
  eggNormQty?: number; // e.g. 1
  chikkiNormQty?: number; // e.g. 1
  ragiNormGrams?: number; // e.g. 10
  jaggeryNormGrams?: number; // e.g. 10
  condimentsNormPrimaryGrams?: number; // e.g. 2
  condimentsNormUpperPrimaryGrams?: number; // e.g. 3
}

export interface CashVoucher {
  id: string;
  voucherNo: string;
  month: string; // 'YYYY-MM'
  workingDays: number;
  totalMealsServed: number;
  primaryAmount: number;
  upperPrimaryAmount: number;
  eggAmount: number;
  chikkiAmount: number;
  ragiJaggeryAmount: number;
  totalAmount: number;
  amountInWords: string;
  generatedAt: string;
  status: 'PAID' | 'PENDING' | 'SUBMITTED';
}

export interface AutomationSettings {
  autoCalculateNorms: boolean; // Auto-calculate commodity usage from official AP MDM Menu Indent & attendance
  autoSave: boolean; // Auto-save daily entries in real-time as you type
  autoMorningAttendanceRoll: boolean; // Automatically pull biometric/class roll attendance after morning cutoff time
  morningRollCutoffTime: string; // e.g. "07:30" (7:30 AM)
  autoCarryForwardStock: boolean; // Automatically carry forward closing stock as opening stock continuously day-by-day and month-by-month
  autoCloudSync: boolean; // Automatically sync data with Firebase Firestore cloud on load and reconnect
  autoFillFullAttendanceOnNewDay: boolean; // Automatically populate 100% active student strength on new working days
  autoMenuIndentAlignment: boolean; // Automatically keep daily menu items aligned with official Government indent schedule
  autoCalculateExpenditure: boolean; // Automatically compute daily cooking cost and CCH cost
}

export interface AppSettings {
  schoolProfile: SchoolProfile;
  mealRates: MealRates;
  academicYear: string;
  darkMode: boolean;
  autoCalculateStock: boolean;
  autoSave: boolean;
  automation?: AutomationSettings;
}

export interface RoleCredential {
  role: 'HEADMASTER' | 'MDM_INCHARGE';
  name: string;
  username: string;
  mobile: string;
  password: string;
  updatedAt?: string;
}

export interface StoredCredentials {
  headmaster: RoleCredential;
  incharge: RoleCredential;
}

export interface SchoolAccount {
  schoolId: string;
  schoolName: string;
  udiseCode: string;
  village?: string;
  mandal?: string;
  district?: string;
  state?: string;
  headmasterName: string;
  headmasterMobile: string;
  credentials: StoredCredentials;
  createdAt: string;
  lastLoginAt?: string;
  status?: string;
}

export interface User {
  username: string;
  mobile?: string;
  name: string;
  role: 'HEADMASTER' | 'MDM_INCHARGE';
  isLoggedIn: boolean;
  schoolId?: string;
  schoolName?: string;
  udiseCode?: string;
}

export interface DailyClassAttendance {
  classLevel: string;
  category: 'Primary' | 'Upper Primary' | 'High School';
  boysPresent: number;
  girlsPresent: number;
  totalPresent: number;
}

export type NavigationTab = 
  | 'dashboard'
  | 'daily-entry'
  | 'student-strength'
  | 'commodity-stock'
  | 'monthly-summary'
  | 'cash-voucher'
  | 'reports'
  | 'settings';
