// Suppress benign internal Firestore idle stream timeout warnings
const filterBenignFirestoreLogs = (method: 'warn' | 'error') => {
  const original = console[method];
  console[method] = (...args: any[]) => {
    const msg = args.map((a) => (typeof a === 'string' ? a : (a?.message || ''))).join(' ');
    if (
      msg.includes('Disconnecting idle stream') ||
      msg.includes('Timed out waiting for new targets') ||
      msg.includes('GrpcConnection RPC') ||
      (msg.includes('@firebase/firestore') && msg.includes('CANCELLED'))
    ) {
      return;
    }
    original.apply(console, args);
  };
};
filterBenignFirestoreLogs('warn');
filterBenignFirestoreLogs('error');

import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);

