/**
 * Preserves native cursor targeting when inputs are touched or selected.
 * Disables automated whole-text selection so cursor stays exactly where
 * touched or clicked, allowing smooth entry of digits one after another.
 */
export function useNumberInputSelection() {
  // Native cursor placement is preserved:
  // Cursor activates directly where touched or clicked, without forced whole-field selection
  // or cursor displacement when editing one digit after another.
}
