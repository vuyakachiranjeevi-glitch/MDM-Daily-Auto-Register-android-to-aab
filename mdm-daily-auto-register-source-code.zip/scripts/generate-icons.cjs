const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const svgPath = path.join(__dirname, '../public/app-logo.svg');
const publicDir = path.join(__dirname, '../public');

async function generateIcons() {
  console.log('Generating PWA icons from app-logo.svg...');
  const svgBuffer = fs.readFileSync(svgPath);

  // 1. Standard icons (Any purpose)
  const standardSizes = [
    { name: 'favicon-16x16.png', size: 16 },
    { name: 'favicon-32x32.png', size: 32 },
    { name: 'badge-72x72.png', size: 72 },
    { name: 'apple-touch-icon-120x120.png', size: 120 },
    { name: 'apple-touch-icon-152x152.png', size: 152 },
    { name: 'apple-touch-icon.png', size: 180 },
    { name: 'pwa-192x192.png', size: 192 },
    { name: 'pwa-512x512.png', size: 512 },
    { name: 'app-logo.png', size: 512 },
    { name: 'splash-screen.png', size: 512 }
  ];

  for (const { name, size } of standardSizes) {
    await sharp(svgBuffer)
      .resize(size, size)
      .png({ quality: 100, compressionLevel: 9 })
      .toFile(path.join(publicDir, name));
    console.log(`Generated: ${name} (${size}x${size})`);
  }

  // 2. Maskable icons with 15% safe zone padding and brand background (#0284c7)
  const maskableSizes = [
    { name: 'pwa-maskable-192x192.png', size: 192 },
    { name: 'pwa-maskable-512x512.png', size: 512 }
  ];

  for (const { name, size } of maskableSizes) {
    const innerSize = Math.round(size * 0.78); // 78% inner size for 11% padding on each side (safe zone)
    const innerBuffer = await sharp(svgBuffer)
      .resize(innerSize, innerSize)
      .png()
      .toBuffer();

    await sharp({
      create: {
        width: size,
        height: size,
        channels: 4,
        background: { r: 2, g: 132, b: 199, alpha: 1 } // #0284c7
      }
    })
      .composite([{
        input: innerBuffer,
        top: Math.round((size - innerSize) / 2),
        left: Math.round((size - innerSize) / 2)
      }])
      .png({ quality: 100, compressionLevel: 9 })
      .toFile(path.join(publicDir, name));
    console.log(`Generated maskable icon: ${name} (${size}x${size})`);
  }

  console.log('All PWA icons generated successfully!');
}

generateIcons().catch((err) => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
