import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const publicDir = path.resolve('public');
const distDir = path.resolve('dist');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

// Master SVG matching the reference image accurately with 3D gradients, School, Thali, MDM Plaque, and 3 Feature Cards
const masterSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="1024" height="1024">
  <defs>
    <!-- Background Outer Gradients -->
    <linearGradient id="appBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="35%" stop-color="#0369a1" />
      <stop offset="70%" stop-color="#1d4ed8" />
      <stop offset="100%" stop-color="#1e1b4b" />
    </linearGradient>

    <linearGradient id="innerDomeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#67e8f9" />
      <stop offset="30%" stop-color="#bae6fd" />
      <stop offset="60%" stop-color="#e0f2fe" />
      <stop offset="100%" stop-color="#ffffff" />
    </linearGradient>

    <!-- Gold Accent Gradients -->
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="40%" stop-color="#fbbf24" />
      <stop offset="80%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>

    <linearGradient id="laurelGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#86efac" />
      <stop offset="50%" stop-color="#22c55e" />
      <stop offset="100%" stop-color="#15803d" />
    </linearGradient>

    <!-- School Roof Gradient -->
    <linearGradient id="roofGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#f97316" />
      <stop offset="60%" stop-color="#ea580c" />
      <stop offset="100%" stop-color="#c2410c" />
    </linearGradient>

    <!-- School Wall Gradient -->
    <linearGradient id="wallGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="100%" stop-color="#fde047" />
    </linearGradient>

    <!-- Plate Gradient -->
    <linearGradient id="plateSilverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="40%" stop-color="#e2e8f0" />
      <stop offset="70%" stop-color="#94a3b8" />
      <stop offset="100%" stop-color="#cbd5e1" />
    </linearGradient>

    <linearGradient id="dalGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="40%" stop-color="#eab308" />
      <stop offset="100%" stop-color="#ca8a04" />
    </linearGradient>

    <linearGradient id="eggGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="70%" stop-color="#f8fafc" />
      <stop offset="100%" stop-color="#e2e8f0" />
    </linearGradient>

    <!-- MDM Plaque Gradient -->
    <linearGradient id="mdmPlaqueGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#2563eb" />
      <stop offset="50%" stop-color="#1d4ed8" />
      <stop offset="100%" stop-color="#1e3a8a" />
    </linearGradient>

    <!-- Bottom Buttons Gradients -->
    <linearGradient id="btnBlueGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="40%" stop-color="#0284c7" />
      <stop offset="100%" stop-color="#0369a1" />
    </linearGradient>

    <linearGradient id="btnOrangeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fde047" />
      <stop offset="35%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>

    <linearGradient id="btnGreenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#4ade80" />
      <stop offset="40%" stop-color="#16a34a" />
      <stop offset="100%" stop-color="#15803d" />
    </linearGradient>

    <!-- Filters & Shadows -->
    <filter id="masterShadow" x="-10%" y="-10%" width="130%" height="130%">
      <feDropShadow dx="0" dy="16" stdDeviation="20" flood-color="#0f172a" flood-opacity="0.5" />
    </filter>
    <filter id="badgeShadow" x="-10%" y="-10%" width="130%" height="130%">
      <feDropShadow dx="0" dy="10" stdDeviation="12" flood-color="#000000" flood-opacity="0.35" />
    </filter>
    <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Base App Icon Rounded Container -->
  <rect width="1024" height="1024" rx="220" fill="url(#appBgGrad)" />
  
  <!-- Outer Bevel Rim -->
  <rect x="20" y="20" width="984" height="984" rx="205" fill="none" stroke="#60a5fa" stroke-opacity="0.5" stroke-width="8" />
  <rect x="36" y="36" width="952" height="952" rx="190" fill="none" stroke="#93c5fd" stroke-opacity="0.25" stroke-width="4" />

  <!-- Inner Light Blue & White Dome Area -->
  <g filter="url(#badgeShadow)">
    <path d="M 120 460 C 120 180, 260 50, 512 50 C 764 50, 904 180, 904 460 C 904 680, 830 750, 512 750 C 194 750, 120 680, 120 460 Z" fill="url(#innerDomeGrad)" />
    <path d="M 120 460 C 120 180, 260 50, 512 50 C 764 50, 904 180, 904 460 C 904 680, 830 750, 512 750 C 194 750, 120 680, 120 460 Z" fill="none" stroke="url(#goldGrad)" stroke-width="12" />
  </g>

  <!-- Left & Right Laurel / Grain Wreath Accents -->
  <!-- Left Wreath -->
  <g fill="url(#laurelGrad)" stroke="#14532d" stroke-width="2" opacity="0.95">
    <path d="M 80 340 C 60 300 70 260 110 270 C 100 310 80 340 80 340 Z" />
    <path d="M 75 420 C 50 380 60 340 105 350 C 95 390 75 420 75 420 Z" />
    <path d="M 80 500 C 55 460 65 420 110 430 C 100 470 80 500 80 500 Z" />
    <path d="M 95 580 C 70 540 80 500 125 510 C 115 550 95 580 95 580 Z" />
  </g>
  <!-- Right Wreath -->
  <g fill="url(#laurelGrad)" stroke="#14532d" stroke-width="2" opacity="0.95">
    <path d="M 944 340 C 964 300 954 260 914 270 C 924 310 944 340 944 340 Z" />
    <path d="M 949 420 C 974 380 964 340 919 350 C 929 390 949 420 949 420 Z" />
    <path d="M 944 500 C 969 460 959 420 914 430 C 924 470 944 500 944 500 Z" />
    <path d="M 929 580 C 954 540 944 500 899 510 C 909 550 929 580 929 580 Z" />
  </g>

  <!-- Green Lush Hills Behind School -->
  <path d="M 200 320 C 260 250 360 270 420 310 C 480 270 580 250 640 300 C 700 260 800 280 840 330 L 840 360 L 200 360 Z" fill="#22c55e" opacity="0.85" />
  <path d="M 280 330 C 330 280 400 290 460 320 C 520 280 600 280 660 320 L 760 340 L 280 340 Z" fill="#16a34a" />

  <!-- School Building -->
  <g filter="url(#badgeShadow)">
    <!-- Main Wall -->
    <rect x="372" y="220" width="280" height="120" rx="8" fill="url(#wallGrad)" stroke="#ca8a04" stroke-width="4" />
    
    <!-- Red/Orange Roof -->
    <polygon points="512,120 332,224 692,224" fill="url(#roofGrad)" stroke="#9a3412" stroke-width="5" />
    
    <!-- Roof Flag -->
    <line x1="512" y1="120" x2="512" y2="80" stroke="#b45309" stroke-width="5" stroke-linecap="round" />
    <polygon points="512,80 546,94 512,108" fill="#ef4444" />

    <!-- Clock Tower on Roof -->
    <rect x="472" y="160" width="80" height="60" rx="6" fill="#fef08a" stroke="#ca8a04" stroke-width="3" />
    <circle cx="512" cy="188" r="22" fill="#ffffff" stroke="#1e3a8a" stroke-width="4" />
    <!-- Clock Hands at 10:10 -->
    <line x1="512" y1="188" x2="502" y2="178" stroke="#1e3a8a" stroke-width="4" stroke-linecap="round" />
    <line x1="512" y1="188" x2="524" y2="180" stroke="#1e3a8a" stroke-width="4" stroke-linecap="round" />

    <!-- School Signboard -->
    <rect x="442" y="230" width="140" height="28" rx="6" fill="#1e3a8a" stroke="#ffffff" stroke-width="2" />
    <text x="512" y="250" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="16" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="2">SCHOOL</text>

    <!-- School Windows -->
    <rect x="396" y="270" width="40" height="46" rx="4" fill="#38bdf8" stroke="#0284c7" stroke-width="3" />
    <line x1="416" y1="270" x2="416" y2="316" stroke="#ffffff" stroke-width="2" />
    <line x1="396" y1="293" x2="436" y2="293" stroke="#ffffff" stroke-width="2" />

    <rect x="588" y="270" width="40" height="46" rx="4" fill="#38bdf8" stroke="#0284c7" stroke-width="3" />
    <line x1="608" y1="270" x2="608" y2="316" stroke="#ffffff" stroke-width="2" />
    <line x1="588" y1="293" x2="628" y2="293" stroke="#ffffff" stroke-width="2" />

    <!-- School Door -->
    <path d="M 488 340 L 488 286 C 488 274 536 274 536 286 L 536 340 Z" fill="#b45309" stroke="#78350f" stroke-width="3" />
  </g>

  <!-- Two Cute Schoolchildren Walking with Backpacks (Left Side) -->
  <g filter="url(#badgeShadow)">
    <!-- Boy (Left) -->
    <!-- Head -->
    <circle cx="224" cy="274" r="18" fill="#fbcfe8" />
    <path d="M 206 272 C 206 254 242 254 242 272 C 238 262 210 262 206 272 Z" fill="#1e293b" />
    <!-- Shirt -->
    <rect x="210" y="292" width="28" height="34" rx="4" fill="#ffffff" />
    <!-- Backpack -->
    <rect x="202" y="294" width="18" height="26" rx="6" fill="#0284c7" stroke="#0369a1" stroke-width="2" />
    <circle cx="211" cy="307" r="4" fill="#f59e0b" />

    <!-- Girl (Right) -->
    <!-- Head with Pigtails -->
    <circle cx="286" cy="278" r="17" fill="#fbcfe8" />
    <!-- Hair -->
    <path d="M 269 276 C 269 258 303 258 303 276 Z" fill="#1e293b" />
    <circle cx="268" cy="286" r="6" fill="#1e293b" />
    <circle cx="304" cy="286" r="6" fill="#1e293b" />
    <!-- Pink Ribbon on hair -->
    <circle cx="268" cy="282" r="3" fill="#ec4899" />
    <circle cx="304" cy="282" r="3" fill="#ec4899" />
    <!-- Dress / Uniform -->
    <rect x="272" y="295" width="28" height="34" rx="4" fill="#ffffff" />
    <!-- Backpack -->
    <rect x="268" y="298" width="18" height="26" rx="6" fill="#0284c7" stroke="#0369a1" stroke-width="2" />
    <circle cx="277" cy="311" r="4" fill="#f59e0b" />
  </g>

  <!-- Big Mid-Day Meal Thali & Milk Glass (Centerpiece) -->
  <g filter="url(#masterShadow)">
    <!-- Thali Outer Silver Tray -->
    <ellipse cx="488" cy="368" rx="180" ry="80" fill="url(#plateSilverGrad)" stroke="#cbd5e1" stroke-width="5" />
    <ellipse cx="488" cy="366" rx="168" ry="72" fill="#f8fafc" stroke="#94a3b8" stroke-width="4" />

    <!-- Fluffy Steaming Rice Mound -->
    <ellipse cx="420" cy="358" rx="65" ry="34" fill="#ffffff" stroke="#e2e8f0" stroke-width="3" />
    <circle cx="400" cy="352" r="3" fill="#cbd5e1" />
    <circle cx="425" cy="360" r="3" fill="#cbd5e1" />
    <circle cx="445" cy="350" r="3" fill="#cbd5e1" />

    <!-- Katori with Dal Tadka -->
    <g>
      <ellipse cx="560" cy="344" rx="55" ry="30" fill="url(#plateSilverGrad)" stroke="#94a3b8" stroke-width="3" />
      <ellipse cx="560" cy="343" rx="48" ry="24" fill="url(#dalGrad)" />
      <!-- Coriander leaf on dal -->
      <circle cx="560" cy="342" r="4" fill="#15803d" />
      <circle cx="554" cy="344" r="3" fill="#16a34a" />
      <circle cx="566" cy="344" r="3" fill="#22c55e" />
    </g>

    <!-- Boiled Egg -->
    <ellipse cx="466" cy="382" rx="26" ry="18" fill="url(#eggGrad)" stroke="#cbd5e1" stroke-width="2" />

    <!-- Vegetable Fry (Carrots, Peas, Beans) -->
    <g>
      <ellipse cx="380" cy="388" rx="34" ry="18" fill="#15803d" />
      <circle cx="366" cy="386" r="5" fill="#f97316" />
      <circle cx="378" cy="384" r="5" fill="#22c55e" />
      <circle cx="390" cy="388" r="4" fill="#ea580c" />
      <circle cx="372" cy="392" r="4" fill="#84cc16" />
      <circle cx="386" cy="392" r="4" fill="#f97316" />
    </g>

    <!-- Potato / Corn Sabzi -->
    <g>
      <ellipse cx="505" cy="400" rx="30" ry="16" fill="#ca8a04" />
      <circle cx="495" cy="398" r="5" fill="#fde047" />
      <circle cx="508" cy="396" r="6" fill="#eab308" />
      <circle cx="518" cy="400" r="5" fill="#fde047" />
    </g>

    <!-- Glass of Fresh Milk (Right of Thali) -->
    <g filter="url(#badgeShadow)">
      <!-- Glass Shape -->
      <path d="M 664 286 L 766 286 L 748 420 L 682 420 Z" fill="#e0f2fe" fill-opacity="0.6" stroke="#93c5fd" stroke-width="4" />
      <!-- Milk Liquid -->
      <path d="M 668 316 L 762 316 L 745 416 L 685 416 Z" fill="#ffffff" />
      <!-- Glass Top Rim Ellipse -->
      <ellipse cx="715" cy="286" rx="51" ry="14" fill="#bae6fd" stroke="#93c5fd" stroke-width="3" />
      <!-- Glass Milk Level Rim -->
      <ellipse cx="715" cy="316" rx="47" ry="12" fill="#f8fafc" />
      <!-- Glass Reflection Highlight -->
      <line x1="684" y1="324" x2="696" y2="408" stroke="#ffffff" stroke-width="6" stroke-linecap="round" opacity="0.8" />
    </g>
  </g>

  <!-- Large 3D Blue "MDM" Banner Plaque (Center) -->
  <g filter="url(#masterShadow)">
    <!-- Main Plaque Oval Container -->
    <path d="M 120 540 C 120 460 904 460 904 540 C 904 680 120 680 120 540 Z" fill="url(#mdmPlaqueGrad)" stroke="url(#goldGrad)" stroke-width="12" />
    
    <!-- Inner Accent Rim -->
    <path d="M 136 540 C 136 476 888 476 888 540 C 888 664 136 664 136 540 Z" fill="none" stroke="#60a5fa" stroke-width="4" opacity="0.6" />

    <!-- Open Book Symbol (Left of MDM) -->
    <g transform="translate(68, 510)">
      <!-- Student Silhouette above book -->
      <circle cx="100" cy="18" r="14" fill="#ffffff" />
      <!-- Open Book Wings -->
      <path d="M 100 48 C 80 32 50 34 35 40 L 35 68 C 50 62 80 60 100 76 C 120 60 150 62 165 68 L 165 40 C 150 34 120 32 100 48 Z" fill="#ffffff" />
      <path d="M 100 48 L 100 76" stroke="#1d4ed8" stroke-width="3" />
    </g>

    <!-- MDM Main Typography (Large Bold 3D White Letters with Blue Depth) -->
    <!-- 3D Extrusion Shadow Behind Text -->
    <text x="516" y="602" font-family="-apple-system, BlinkMacSystemFont, 'Outfit', 'Montserrat', Roboto, sans-serif" font-size="185" font-weight="950" fill="#1e3a8a" text-anchor="middle" letter-spacing="8">MDM</text>
    <text x="514" y="598" font-family="-apple-system, BlinkMacSystemFont, 'Outfit', 'Montserrat', Roboto, sans-serif" font-size="185" font-weight="950" fill="#1d4ed8" text-anchor="middle" letter-spacing="8">MDM</text>
    <!-- Crisp White Face -->
    <text x="512" y="594" font-family="-apple-system, BlinkMacSystemFont, 'Outfit', 'Montserrat', Roboto, sans-serif" font-size="185" font-weight="950" fill="#ffffff" text-anchor="middle" letter-spacing="8">MDM</text>

    <!-- Green Leaf Symbol (Right of MDM) -->
    <g transform="translate(800, 508)">
      <path d="M 30 70 C 10 30 50 0 75 0 C 95 35 70 75 30 70 Z" fill="url(#laurelGrad)" stroke="#ffffff" stroke-width="3" />
      <path d="M 30 70 Q 55 40 75 0" stroke="#ffffff" stroke-width="3" fill="none" />
    </g>

    <!-- "— MID DAY MEAL —" Subtitle Ribbon -->
    <g transform="translate(0, 10)">
      <line x1="230" y1="640" x2="300" y2="640" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
      <text x="512" y="648" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="34" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="6">MID DAY MEAL</text>
      <line x1="724" y1="640" x2="794" y2="640" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
    </g>
  </g>

  <!-- Bottom Three Feature Tiles (Cards) -->
  <!-- 1. Daily Auto Register (Blue Card - Left) -->
  <g filter="url(#badgeShadow)" transform="translate(136, 690)">
    <!-- Rounded Button Shape -->
    <rect width="230" height="230" rx="42" fill="url(#btnBlueGrad)" stroke="#bae6fd" stroke-width="6" />
    <rect x="6" y="6" width="218" height="218" rx="36" fill="none" stroke="#0284c7" stroke-width="3" />

    <!-- Calendar + User Icon with Plus Badge -->
    <g transform="translate(55, 30)">
      <!-- Calendar Base -->
      <rect x="8" y="14" width="104" height="96" rx="20" fill="#ffffff" />
      <!-- Calendar Top Header -->
      <path d="M 8 34 L 112 34 L 112 28 C 112 18 102 14 92 14 L 28 14 C 18 14 8 18 8 28 Z" fill="#0284c7" />
      <!-- Rings -->
      <rect x="28" y="4" width="10" height="18" rx="5" fill="#ffffff" stroke="#0284c7" stroke-width="3" />
      <rect x="82" y="4" width="10" height="18" rx="5" fill="#ffffff" stroke="#0284c7" stroke-width="3" />
      <!-- User Avatar Inside -->
      <circle cx="60" cy="58" r="16" fill="#0284c7" />
      <path d="M 36 94 C 36 78 84 78 84 94 Z" fill="#0284c7" />
      <!-- Green (+) Plus Badge -->
      <circle cx="94" cy="88" r="18" fill="#22c55e" stroke="#ffffff" stroke-width="4" />
      <line x1="94" y1="78" x2="94" y2="98" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
      <line x1="84" y1="88" x2="104" y2="88" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
    </g>

    <!-- Card Label -->
    <text x="115" y="174" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="22" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="1">Daily</text>
    <text x="115" y="202" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="20" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="0.5">Auto Register</text>
  </g>

  <!-- 2. Cash Voucher (Orange/Gold Card - Middle) -->
  <g filter="url(#badgeShadow)" transform="translate(397, 690)">
    <!-- Rounded Button Shape -->
    <rect width="230" height="230" rx="42" fill="url(#btnOrangeGrad)" stroke="#fef08a" stroke-width="6" />
    <rect x="6" y="6" width="218" height="218" rx="36" fill="none" stroke="#d97706" stroke-width="3" />

    <!-- Rupee Invoice Paper + Pen Icon -->
    <g transform="translate(55, 30)">
      <!-- White Paper with Rupee Symbol -->
      <path d="M 18 10 L 90 10 L 106 28 L 106 104 L 18 104 Z" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
      <!-- Rupee Symbol -->
      <text x="46" y="52" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="34" font-weight="900" fill="#0284c7" text-anchor="middle">₹</text>
      <!-- Invoice lines -->
      <line x1="30" y1="68" x2="80" y2="68" stroke="#0284c7" stroke-width="5" stroke-linecap="round" />
      <line x1="30" y1="82" x2="72" y2="82" stroke="#0284c7" stroke-width="5" stroke-linecap="round" />

      <!-- Blue and Gold Stylus Pen -->
      <g transform="rotate(32 94 74)">
        <rect x="86" y="20" width="16" height="70" rx="5" fill="#1d4ed8" stroke="#1e3a8a" stroke-width="2" />
        <polygon points="86,90 102,90 94,106" fill="#f59e0b" stroke="#b45309" stroke-width="2" />
        <circle cx="94" cy="104" r="2" fill="#1e293b" />
        <rect x="88" y="24" width="12" height="12" fill="#fde047" />
      </g>
    </g>

    <!-- Card Label -->
    <text x="115" y="174" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="24" font-weight="900" fill="#1e293b" text-anchor="middle" letter-spacing="1">Cash</text>
    <text x="115" y="202" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="24" font-weight="900" fill="#1e293b" text-anchor="middle" letter-spacing="1">Voucher</text>
  </g>

  <!-- 3. Reports (Green Card - Right) -->
  <g filter="url(#badgeShadow)" transform="translate(658, 690)">
    <!-- Rounded Button Shape -->
    <rect width="230" height="230" rx="42" fill="url(#btnGreenGrad)" stroke="#bbf7d0" stroke-width="6" />
    <rect x="6" y="6" width="218" height="218" rx="36" fill="none" stroke="#15803d" stroke-width="3" />

    <!-- Analytics Document + Bar Chart + Pie Chart + Upward Green Arrow -->
    <g transform="translate(55, 30)">
      <!-- White Document Base -->
      <rect x="16" y="10" width="94" height="96" rx="14" fill="#ffffff" />
      <!-- Document Header lines -->
      <line x1="28" y1="24" x2="68" y2="24" stroke="#0284c7" stroke-width="4" stroke-linecap="round" />
      <line x1="28" y1="34" x2="56" y2="34" stroke="#0284c7" stroke-width="4" stroke-linecap="round" />

      <!-- Bar Charts -->
      <rect x="28" y="64" width="12" height="30" rx="3" fill="#0284c7" />
      <rect x="44" y="48" width="12" height="46" rx="3" fill="#38bdf8" />
      <rect x="60" y="56" width="12" height="38" rx="3" fill="#0284c7" />

      <!-- Pie Chart -->
      <circle cx="82" cy="74" r="18" fill="#f59e0b" />
      <path d="M 82 74 L 82 56 A 18 18 0 0 1 100 74 Z" fill="#38bdf8" />
      <path d="M 82 74 L 100 74 A 18 18 0 0 1 82 92 Z" fill="#ef4444" />

      <!-- Upward Green Growth Arrow -->
      <g transform="translate(68, 20)">
        <polygon points="20,0 34,14 26,14 26,30 14,30 14,14 6,14" fill="#22c55e" stroke="#15803d" stroke-width="2" />
      </g>
    </g>

    <!-- Card Label -->
    <text x="115" y="190" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="26" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="1">Reports</text>
  </g>
</svg>`;

// Maskable version with 20% safe margin
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="1024" height="1024">
  <defs>
    <linearGradient id="mBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="35%" stop-color="#0369a1" />
      <stop offset="70%" stop-color="#1d4ed8" />
      <stop offset="100%" stop-color="#1e1b4b" />
    </linearGradient>
  </defs>
  <!-- Full edge-to-edge background -->
  <rect width="1024" height="1024" fill="url(#mBgGrad)" />
  <!-- Centered content with 15% safe padding -->
  <g transform="translate(102.4, 102.4) scale(0.8)">
    ${masterSvg.substring(masterSvg.indexOf('<defs>'), masterSvg.lastIndexOf('</svg>'))}
  </g>
</svg>`;

async function run() {
  console.log('Generating MDM Daily Auto Register PWA Icons & Logo Assets...');

  // Save raw vector files
  fs.writeFileSync(path.join(publicDir, 'app-logo.svg'), masterSvg, 'utf8');
  fs.writeFileSync(path.join(publicDir, 'favicon.svg'), masterSvg, 'utf8');
  fs.writeFileSync(path.join(distDir, 'app-logo.svg'), masterSvg, 'utf8');
  fs.writeFileSync(path.join(distDir, 'favicon.svg'), masterSvg, 'utf8');

  const svgBuffer = Buffer.from(masterSvg);
  const maskableBuffer = Buffer.from(maskableSvg);

  const targets = [
    { name: 'pwa-512x512.png', size: 512, buf: svgBuffer },
    { name: 'pwa-192x192.png', size: 192, buf: svgBuffer },
    { name: 'app-logo.png', size: 512, buf: svgBuffer },
    { name: 'splash-screen.png', size: 512, buf: svgBuffer },
    { name: 'apple-touch-icon.png', size: 180, buf: svgBuffer },
    { name: 'apple-touch-icon-152x152.png', size: 152, buf: svgBuffer },
    { name: 'apple-touch-icon-120x120.png', size: 120, buf: svgBuffer },
    { name: 'favicon-32x32.png', size: 32, buf: svgBuffer },
    { name: 'favicon-16x16.png', size: 16, buf: svgBuffer },
    { name: 'badge-72x72.png', size: 72, buf: svgBuffer },
    { name: 'pwa-maskable-512x512.png', size: 512, buf: maskableBuffer },
    { name: 'pwa-maskable-192x192.png', size: 192, buf: maskableBuffer },
  ];

  for (const t of targets) {
    const pubDest = path.join(publicDir, t.name);
    const distDest = path.join(distDir, t.name);
    await sharp(t.buf).resize(t.size, t.size).png().toFile(pubDest);
    await sharp(t.buf).resize(t.size, t.size).png().toFile(distDest);
    console.log(`✓ Generated ${t.name} (${t.size}x${t.size})`);
  }

  // Desktop & Mobile Preview Mockups
  await sharp({
    create: {
      width: 1280,
      height: 720,
      channels: 4,
      background: { r: 15, g: 23, b: 42, alpha: 1 }
    }
  })
  .composite([
    {
      input: await sharp(svgBuffer).resize(480, 480).png().toBuffer(),
      top: 120,
      left: 400,
    }
  ])
  .png()
  .toFile(path.join(publicDir, 'screenshot-desktop.png'));

  fs.copyFileSync(path.join(publicDir, 'screenshot-desktop.png'), path.join(distDir, 'screenshot-desktop.png'));
  console.log('✓ Generated screenshot-desktop.png');

  await sharp({
    create: {
      width: 640,
      height: 1136,
      channels: 4,
      background: { r: 15, g: 23, b: 42, alpha: 1 }
    }
  })
  .composite([
    {
      input: await sharp(svgBuffer).resize(400, 400).png().toBuffer(),
      top: 368,
      left: 120,
    }
  ])
  .png()
  .toFile(path.join(publicDir, 'screenshot-mobile.png'));

  fs.copyFileSync(path.join(publicDir, 'screenshot-mobile.png'), path.join(distDir, 'screenshot-mobile.png'));
  console.log('✓ Generated screenshot-mobile.png');

  console.log('All MDM Daily Auto Register Icons generated successfully!');
}

run().catch((err) => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
