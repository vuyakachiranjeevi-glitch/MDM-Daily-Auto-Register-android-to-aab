#!/usr/bin/env python3
"""
Generate a clean, sanitized source code ZIP archive for the MDM Application.
Excludes node_modules, .data, .backup, secrets, and transient build artifacts.
"""

import os
import zipfile

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUTPUT_PUBLIC_ZIP = os.path.join(PROJECT_ROOT, 'public', 'mdm-source-code.zip')
OUTPUT_DIST_ZIP = os.path.join(PROJECT_ROOT, 'dist', 'mdm-source-code.zip')

EXCLUDE_DIRS = {
    'node_modules',
    '.git',
    '.data',
    'data',
    '.backup',
    '.aistudio',
    '.cache',
    'dist',
    'dist-ssr',
    '__pycache__',
    '.firebase',
    'build',
}

EXCLUDE_EXTENSIONS = {
    '.zip',
    '.tar.gz',
    '.tgz',
    '.keystore',
    '.jks',
    '.pyc',
    '.DS_Store',
}

EXCLUDE_FILES = {
    '.env',
    '.env.local',
    '.env.production',
    'npm-debug.log',
    'auth_store.json',
    'audit-report.json',
    'audit-report-post.json',
}

def create_sanitized_zip():
    print(f"Creating sanitized source archive from: {PROJECT_ROOT}")
    total_files = 0
    total_uncompressed_bytes = 0

    os.makedirs(os.path.join(PROJECT_ROOT, 'public'), exist_ok=True)

    with zipfile.ZipFile(OUTPUT_PUBLIC_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            # Modify dirs in-place to prevent os.walk from entering excluded folders
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.data')]

            for file in files:
                if file in EXCLUDE_FILES or 'auth_store' in file:
                    continue
                _, ext = os.path.splitext(file)
                if ext in EXCLUDE_EXTENSIONS:
                    continue

                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, PROJECT_ROOT)

                # Skip root zip files or files in excluded dirs
                parts = rel_path.split(os.sep)
                if any(p in EXCLUDE_DIRS for p in parts) or any('auth_store' in p for p in parts):
                    continue

                zipf.write(abs_path, rel_path)
                total_files += 1
                total_uncompressed_bytes += os.path.getsize(abs_path)

    zip_size = os.path.getsize(OUTPUT_PUBLIC_ZIP)
    print(f"Archived {total_files} source files ({total_uncompressed_bytes / (1024*1024):.2f} MB uncompressed)")
    print(f"Output: {OUTPUT_PUBLIC_ZIP} ({zip_size / (1024*1024):.2f} MB)")

    # Copy archive to all required locations
    targets = [
        os.path.join(PROJECT_ROOT, 'public', 'mdm-daily-auto-register-source-code.zip'),
        os.path.join(PROJECT_ROOT, 'public', 'midday-meal-app.zip'),
        os.path.join(PROJECT_ROOT, 'public', 'aab-source-code.zip'),
        os.path.join(PROJECT_ROOT, 'public', 'code.zip'),
    ]

    dist_dir = os.path.join(PROJECT_ROOT, 'dist')
    if os.path.exists(dist_dir):
        targets.extend([
            OUTPUT_DIST_ZIP,
            os.path.join(dist_dir, 'mdm-daily-auto-register-source-code.zip'),
            os.path.join(dist_dir, 'midday-meal-app.zip'),
            os.path.join(dist_dir, 'aab-source-code.zip'),
            os.path.join(dist_dir, 'code.zip'),
        ])

    with open(OUTPUT_PUBLIC_ZIP, 'rb') as src:
        zip_bytes = src.read()

    for target in targets:
        with open(target, 'wb') as dst:
            dst.write(zip_bytes)
        print(f"Synchronized archive to: {target}")

if __name__ == '__main__':
    create_sanitized_zip()
