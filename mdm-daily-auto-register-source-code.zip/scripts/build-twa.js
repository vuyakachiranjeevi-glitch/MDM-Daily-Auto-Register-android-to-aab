#!/usr/bin/env node

/**
 * Play Store Trusted Web Activity (TWA) Builder & Validator
 *
 * Verifies that the PWA manifests, icons, Digital Asset Links, and TWA configuration
 * satisfy 100% of Google Play Store & Google Play Console criteria for upload.
 */

import fs from 'fs';
import path from 'path';

console.log('====================================================');
console.log('  MDM App - Play Store Android 16+ Pre-Flight Check ');
console.log('====================================================\n');

let hasError = false;
const releaseBlockers = [];
const releaseWarnings = [];
const isDevMode = process.argv.includes('--dev') || process.argv.includes('--diagnostic');

function checkFile(filePath, label) {
  const resolved = path.resolve(filePath);
  if (fs.existsSync(resolved)) {
    const stats = fs.statSync(resolved);
    console.log(`[PASS] ${label}: ${filePath} (${stats.size} bytes)`);
    return true;
  } else {
    console.error(`[FAIL] Missing required file for Play Store: ${filePath}`);
    releaseBlockers.push(`Missing file: ${filePath}`);
    hasError = true;
    return false;
  }
}

// 1. Check manifests
checkFile('public/manifest.json', 'Web App Manifest (manifest.json)');
checkFile('public/manifest.webmanifest', 'PWA Spec Manifest (manifest.webmanifest)');
checkFile('twa-manifest.json', 'Bubblewrap TWA Manifest (twa-manifest.json)');
checkFile('public/.well-known/assetlinks.json', 'Digital Asset Links (.well-known/assetlinks.json)');

// 2. Check Play Store Required Icon assets
checkFile('public/pwa-192x192.png', '192x192 App Icon');
checkFile('public/pwa-512x512.png', '512x512 High-Res Play Store Icon');
checkFile('public/pwa-maskable-192x192.png', '192x192 Maskable Icon');
checkFile('public/pwa-maskable-512x512.png', '512x512 Maskable Icon');
checkFile('public/screenshot-desktop.png', 'Desktop / Tablet Listing Screenshot');
checkFile('public/screenshot-mobile.png', 'Mobile Listing Screenshot');

// 3. Validate manifest content
try {
  const manifestData = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf8'));
  if (!manifestData.name || !manifestData.short_name) {
    console.error('[FAIL] Manifest missing name or short_name');
    hasError = true;
  } else {
    console.log(`[PASS] App Name: "${manifestData.name}" | Short Name: "${manifestData.short_name}"`);
  }

  if (manifestData.display !== 'standalone') {
    console.warn(`[WARN] Recommended display for Play Store is "standalone", found: ${manifestData.display}`);
  } else {
    console.log('[PASS] Display mode: standalone (full-screen native experience)');
  }
} catch (e) {
  console.error('[FAIL] Error parsing public/manifest.json:', e.message);
  hasError = true;
}

// 4. Validate assetlinks.json and check for placeholder fingerprint
try {
  const assetlinks = JSON.parse(fs.readFileSync(path.resolve('public/.well-known/assetlinks.json'), 'utf8'));
  if (Array.isArray(assetlinks) && assetlinks.length > 0 && assetlinks[0].target?.package_name) {
    console.log(`[PASS] Digital Asset Links target package: "${assetlinks[0].target.package_name}"`);
    const fingerprints = assetlinks[0].target.sha256_cert_fingerprints || [];
    if (fingerprints.some((fp) => fp.startsWith('14:6D:E9:7F:0F:CF'))) {
      console.warn('[NEEDS OWNER INPUT] Placeholder SHA-256 fingerprint detected in assetlinks.json.');
      releaseWarnings.push('Operator must provide real Google Play App Signing SHA-256 fingerprint before publishing.');
    } else {
      console.log(`[PASS] Real Play Store SHA-256 signing fingerprint configured.`);
    }
  } else {
    console.error('[FAIL] Invalid assetlinks structure');
    hasError = true;
  }
} catch (e) {
  console.error('[FAIL] Error parsing public/.well-known/assetlinks.json:', e.message);
  hasError = true;
}

// 5. Validate Android 14+ (API 34/35/36) Play Store SDK Requirements and Production Domain
try {
  const twaData = JSON.parse(fs.readFileSync(path.resolve('twa-manifest.json'), 'utf8'));
  const targetSdk = twaData.targetSdkVersion || 35;
  const compileSdk = twaData.compileSdkVersion || 35;
  if (targetSdk < 34) {
    console.error(`[FAIL] Target SDK (${targetSdk}) is lower than Google Play policy minimum Android 14 (API 34).`);
    hasError = true;
  } else {
    console.log(`[PASS] Play Store Target SDK: ${targetSdk} (API Level ${targetSdk} - Android 14+ compliant)`);
    console.log(`[PASS] Play Store Compile SDK: ${compileSdk}`);
  }

  // Validate AGP and Gradle versions
  if (fs.existsSync('android-build.gradle')) {
    const gradleContent = fs.readFileSync('android-build.gradle', 'utf8');
    if (gradleContent.includes("com.android.tools.build:gradle:8.10.") || gradleContent.includes("com.android.tools.build:gradle:8.11.")) {
      console.log('[PASS] Android Gradle Plugin (AGP): 8.10.0 (API 36 & JDK 17+ compatible)');
    } else {
      console.error('[FAIL] AGP version in android-build.gradle must be 8.10.x or newer for API 36 support.');
      releaseBlockers.push('Upgrade AGP to 8.10.x in android-build.gradle.');
      hasError = true;
    }
  }

  if (fs.existsSync('gradle/wrapper/gradle-wrapper.properties')) {
    const wrapperContent = fs.readFileSync('gradle/wrapper/gradle-wrapper.properties', 'utf8');
    if (wrapperContent.includes('gradle-8.11') || wrapperContent.includes('gradle-8.12')) {
      console.log('[PASS] Gradle Wrapper: 8.11.1 (Officially supported for AGP 8.10+)');
    } else {
      console.error('[FAIL] Gradle wrapper must be 8.11.1 or newer.');
      releaseBlockers.push('Update Gradle wrapper to 8.11.1.');
      hasError = true;
    }
  }

  const isPreviewHost = twaData.host?.includes('ais-dev-') || twaData.host?.includes('ais-pre-') || twaData.host?.includes('.run.app');
  if (isPreviewHost) {
    if (isDevMode) {
      console.warn(`[DIAGNOSTIC WARNING] Current host (${twaData.host}) is a Cloud Run preview domain.`);
      releaseWarnings.push('Production Google Play release requires owner to configure permanent production custom domain (cannot use ephemeral ais-dev / ais-pre preview hosts).');
    } else {
      console.error(`[FAIL - RELEASE BLOCKED] Production host cannot be a Cloud Run preview domain: ${twaData.host}`);
      releaseBlockers.push('Production release blocked: Owner must configure approved permanent production custom HTTPS domain in twa-manifest.json and android-build.gradle.');
      hasError = true;
    }
  } else if (!twaData.host || twaData.host.includes('example.com') || twaData.host.includes('placeholder')) {
    console.error(`[FAIL] Unconfigured production domain in twa-manifest.json: ${twaData.host}`);
    releaseBlockers.push('Owner must configure permanent HTTPS production domain.');
    hasError = true;
  } else {
    console.log(`[PASS] Approved Permanent Production Domain: ${twaData.host}`);
  }
} catch (e) {
  console.error('[FAIL] Error parsing twa-manifest.json for Android 16 configuration:', e.message);
  hasError = true;
}

// 6. Check SMS Provider Configuration
const env = process.env;
const hasSms = !!(
  env.FAST2SMS_API_KEY ||
  env.SMS_API_KEY ||
  (env.TWILIO_ACCOUNT_SID && env.TWILIO_AUTH_TOKEN) ||
  env.MSG91_AUTH_KEY ||
  env.TEXTLOCAL_API_KEY ||
  env.SMS_GATEWAY_URL
);

if (!hasSms) {
  if (isDevMode) {
    console.warn('[DIAGNOSTIC WARNING] Live SMS gateway API credentials are not set in environment.');
    releaseWarnings.push('SMS gateway credentials required for live mobile OTP delivery on production.');
  } else if (process.env.NODE_ENV === 'production') {
    console.error('[FAIL - RELEASE BLOCKED] Production deployment requires live SMS gateway credentials.');
    releaseBlockers.push('Configure FAST2SMS_API_KEY, TWILIO, or MSG91 credentials in production environment.');
    hasError = true;
  } else {
    console.warn('[NEEDS OWNER INPUT] Live SMS gateway credentials not set (required for production OTP dispatch).');
    releaseWarnings.push('Configure FAST2SMS_API_KEY, TWILIO, or MSG91 credentials before production release.');
  }
} else {
  console.log('[PASS] Live SMS gateway configured.');
}

console.log('\n----------------------------------------------------');
if (hasError || releaseBlockers.length > 0) {
  console.error('Play Store deployment pre-flight check FAILED with release blockers:');
  releaseBlockers.forEach((b) => console.error(`  - ${b}`));
  console.log('----------------------------------------------------\n');
  process.exit(1);
} else {
  console.log('Play Store manifest & build structure check PASSED.');
  if (releaseWarnings.length > 0) {
    console.log('\nPending operator release items before Play Console upload:');
    releaseWarnings.forEach((w) => console.log(`  * ${w}`));
  }
  console.log('----------------------------------------------------\n');
}
