import {
  calculateDailyCommodityStock,
  numToWords,
  safeRound3,
  defaultCommodities
} from '../src/lib/utils';
import { DailyEntry, StockTransaction, CommodityItem } from '../src/types';

interface TestResult {
  testId: string;
  category: string;
  commodity?: string;
  input: string;
  expected: string;
  actual: string;
  status: 'PASS' | 'FAIL';
}

const testResults: TestResult[] = [];

function recordTest(
  testId: string,
  category: string,
  commodity: string | undefined,
  input: string,
  expected: string,
  actual: string,
  condition: boolean
) {
  testResults.push({
    testId,
    category,
    commodity,
    input,
    expected,
    actual,
    status: condition ? 'PASS' : 'FAIL'
  });
}

console.log('Starting MDM Calculation Regression Test Suite...\n');

// 1. COMMODITY TEST SUITE - All Supported Commodities
const allCommIds = defaultCommodities.map(c => c.id);

// Test 1: Baseline Single-Day Stock Math for all commodities
allCommIds.forEach((commId) => {
  const customCommodities: CommodityItem[] = defaultCommodities.map((c) => ({
    ...c,
    openingBalance: (c.id === commId || (commId === 'jaggery' && c.id === 'ragi')) ? 100.0 : 0
  }));

  const entries: DailyEntry[] = [
    {
      id: 'entry-1',
      date: '2026-08-01',
      primaryAttendance: 50,
      upperPrimaryAttendance: 30,
      highSchoolAttendance: 0,
      totalAttendance: 80,
      mealsServed: 80,
      riceUsedKg: commId === 'rice' ? 9.5 : 0,
      oilUsedLitres: commId === 'oil' ? 0.475 : 0,
      pulsesUsedKg: commId === 'pulses' ? 1.9 : 0,
      eggUsedQty: commId === 'egg' ? 80 : 0,
      chikkiUsedQty: commId === 'chikki' ? 80 : 0,
      ragiUsedKg: (commId === 'ragi' || commId === 'jaggery') ? 0.8 : 0,
      jaggeryUsedKg: (commId === 'ragi' || commId === 'jaggery') ? 0.8 : 0,
      condimentsUsedKg: commId === 'condiments' ? 0.19 : 0,
      remarks: 'Normal working day'
    }
  ];

  const txs: StockTransaction[] = [
    {
      id: `tx-rec-${commId}`,
      date: '2026-08-01',
      commodityId: commId === 'jaggery' ? 'ragi' : commId,
      type: 'RECEIVED',
      quantity: 50.0
    },
    {
      id: `tx-spoil-${commId}`,
      date: '2026-08-01',
      commodityId: commId === 'jaggery' ? 'ragi' : commId,
      type: 'SPOILED',
      quantity: 0.5
    }
  ];

  const stockMap = calculateDailyCommodityStock(entries, txs, customCommodities);
  const dayStock = stockMap['2026-08-01']?.[commId];

  let expectedUsed = 0;
  if (commId === 'rice') expectedUsed = 9.5;
  else if (commId === 'oil') expectedUsed = 0.475;
  else if (commId === 'pulses') expectedUsed = 1.9;
  else if (commId === 'egg') expectedUsed = 80;
  else if (commId === 'chikki') expectedUsed = 80;
  else if (commId === 'ragi') expectedUsed = 0.8;
  else if (commId === 'jaggery') expectedUsed = 0.8;

  // Expected: 100.0 (OB) + 50.0 (Rec) - used - 0.5 (Spoiled)
  const expectedCb = safeRound3(100.0 + 50.0 - expectedUsed - 0.5);
  const actualCb = dayStock?.cb ?? -999;

  recordTest(
    `REG-COMM-${commId.toUpperCase()}`,
    'Commodity Balance Calculation',
    commId,
    `OB: 100, Rec: 50, Used: ${expectedUsed}, Spoil: 0.5`,
    `${expectedCb}`,
    `${actualCb}`,
    actualCb === expectedCb
  );
});

// Test 2: Negative Opening Balance Preservation (NON-NEGOTIABLE RULE)
{
  const customCommodities: CommodityItem[] = defaultCommodities.map((c) => ({
    ...c,
    openingBalance: c.id === 'rice' ? -15.25 : 0
  }));

  const entries: DailyEntry[] = [
    {
      id: 'entry-neg-1',
      date: '2026-08-01',
      primaryAttendance: 50,
      upperPrimaryAttendance: 0,
      highSchoolAttendance: 0,
      totalAttendance: 50,
      mealsServed: 50,
      riceUsedKg: 5.0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      remarks: 'Negative balance day'
    }
  ];

  const txs: StockTransaction[] = [
    {
      id: 'tx-rec-neg',
      date: '2026-08-01',
      commodityId: 'rice',
      type: 'RECEIVED',
      quantity: 2.0
    }
  ];

  const stockMap = calculateDailyCommodityStock(entries, txs, customCommodities);
  const dayStock = stockMap['2026-08-01']?.['rice'];

  // -15.25 + 2.0 - 5.0 = -18.25
  const expectedCb = -18.25;
  const actualCb = dayStock?.cb ?? 0;

  recordTest(
    'REG-NEG-PRESERVE-01',
    'Negative Balance Preservation',
    'rice',
    'OB: -15.250, Rec: 2.000, Used: 5.000',
    `${expectedCb}`,
    `${actualCb}`,
    actualCb === expectedCb && actualCb < 0
  );
}

// Test 3: Zero-crossing into negative balance without zero-clamping
{
  const customCommodities: CommodityItem[] = defaultCommodities.map((c) => ({
    ...c,
    openingBalance: c.id === 'oil' ? 1.0 : 0
  }));

  const entries: DailyEntry[] = [
    {
      id: 'entry-neg-cross',
      date: '2026-08-01',
      primaryAttendance: 100,
      upperPrimaryAttendance: 100,
      highSchoolAttendance: 0,
      totalAttendance: 200,
      mealsServed: 200,
      oilUsedLitres: 3.5,
      riceUsedKg: 0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      remarks: 'Exceeded opening balance'
    }
  ];

  const stockMap = calculateDailyCommodityStock(entries, [], customCommodities);
  const dayStock = stockMap['2026-08-01']?.['oil'];

  // 1.0 - 3.5 = -2.5
  const expectedCb = -2.5;
  const actualCb = dayStock?.cb ?? 0;

  recordTest(
    'REG-NEG-CROSS-02',
    'Zero Crossing to Negative',
    'oil',
    'OB: 1.000, Rec: 0.000, Used: 3.500',
    `${expectedCb}`,
    `${actualCb}`,
    actualCb === expectedCb && actualCb === -2.5
  );
}

// Test 4: Month Transition Seamless Carry-Forward (August 31 -> September 1)
{
  const customCommodities: CommodityItem[] = defaultCommodities.map((c) => ({
    ...c,
    openingBalance: c.id === 'rice' ? 50.0 : 0
  }));

  const entries: DailyEntry[] = [
    {
      id: 'entry-aug-31',
      date: '2026-08-31',
      primaryAttendance: 100,
      upperPrimaryAttendance: 0,
      highSchoolAttendance: 0,
      totalAttendance: 100,
      mealsServed: 100,
      riceUsedKg: 10.0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      remarks: 'Last day of August'
    },
    {
      id: 'entry-sep-01',
      date: '2026-09-01',
      primaryAttendance: 100,
      upperPrimaryAttendance: 0,
      highSchoolAttendance: 0,
      totalAttendance: 100,
      mealsServed: 100,
      riceUsedKg: 8.0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      remarks: 'First day of September'
    }
  ];

  const stockMap = calculateDailyCommodityStock(entries, [], customCommodities);
  const aug31Cb = stockMap['2026-08-31']?.['rice']?.cb; // 50.0 - 10.0 = 40.0
  const sep01Ob = stockMap['2026-09-01']?.['rice']?.ob; // should be 40.0
  const sep01Cb = stockMap['2026-09-01']?.['rice']?.cb; // 40.0 - 8.0 = 32.0

  recordTest(
    'REG-MONTH-TRANSITION-01',
    'Month Boundary Carry-Forward',
    'rice',
    `Aug 31 CB: ${aug31Cb}`,
    'Sep 01 OB matches Aug 31 CB (40.000)',
    `Sep 01 OB: ${sep01Ob}, Sep 01 CB: ${sep01Cb}`,
    aug31Cb === 40.0 && sep01Ob === 40.0 && sep01Cb === 32.0
  );
}

// Test 5: Holiday Handling (Zero attendance, zero consumption, preserved stock)
{
  const customCommodities: CommodityItem[] = defaultCommodities.map((c) => ({
    ...c,
    openingBalance: c.id === 'rice' ? 40.0 : 0
  }));

  const entries: DailyEntry[] = [
    {
      id: 'entry-holiday',
      date: '2026-08-15', // Independence Day
      primaryAttendance: 0,
      upperPrimaryAttendance: 0,
      highSchoolAttendance: 0,
      totalAttendance: 0,
      mealsServed: 0,
      riceUsedKg: 0,
      eggUsedQty: 0,
      chikkiUsedQty: 0,
      ragiUsedKg: 0,
      jaggeryUsedKg: 0,
      remarks: 'Independence Day Holiday'
    }
  ];

  const stockMap = calculateDailyCommodityStock(entries, [], customCommodities);
  const holidayStock = stockMap['2026-08-15']?.['rice'];

  recordTest(
    'REG-HOLIDAY-01',
    'Holiday Consumption Handling',
    'rice',
    'Attendance: 0, Meals: 0, Rice Used: 0',
    'OB = CB = 40.000',
    `OB: ${holidayStock?.ob}, CB: ${holidayStock?.cb}`,
    holidayStock?.ob === 40.0 && holidayStock?.cb === 40.0
  );
}

// Test 6: Safe 3-decimal rounding and float precision
{
  const testVal = safeRound3(0.1 + 0.2); // 0.30000000000000004 -> 0.3
  const testVal2 = safeRound3(12.34567); // -> 12.346
  recordTest(
    'REG-DECIMAL-FLOAT-01',
    '3-Decimal Precision',
    undefined,
    '0.1 + 0.2',
    '0.3',
    `${testVal}`,
    testVal === 0.3
  );
  recordTest(
    'REG-DECIMAL-ROUND-02',
    '3-Decimal Precision',
    undefined,
    '12.34567',
    '12.346',
    `${testVal2}`,
    testVal2 === 12.346
  );
}

// Test 7: Currency in Words (numToWords)
const currencyWordCases = [
  { inVal: 0, expected: 'Rupees Zero Only' },
  { inVal: 2450.50, expected: 'Rupees Two Thousand Four Hundred Fifty and Fifty Paise Only' },
  { inVal: 100000, expected: 'Rupees One Lakh Only' },
  { inVal: 15420.75, expected: 'Rupees Fifteen Thousand Four Hundred Twenty and Seventy Five Paise Only' }
];

currencyWordCases.forEach((tc, idx) => {
  const actual = numToWords(tc.inVal);
  recordTest(
    `REG-WORDS-0${idx + 1}`,
    'Currency to Words Conversion',
    undefined,
    `Amount: ${tc.inVal}`,
    tc.expected,
    actual,
    actual === tc.expected
  );
});

// Print Results Table
console.log('| Test ID | Category | Commodity | Input | Expected | Actual | Status |');
console.log('|---|---|---|---|---|---|---|');
testResults.forEach((tr) => {
  console.log(`| ${tr.testId} | ${tr.category} | ${tr.commodity || 'N/A'} | ${tr.input} | ${tr.expected} | ${tr.actual} | **${tr.status}** |`);
});

const failures = testResults.filter(t => t.status === 'FAIL');
console.log(`\nTotal Tests: ${testResults.length} | Passed: ${testResults.length - failures.length} | Failed: ${failures.length}`);
if (failures.length > 0) {
  process.exit(1);
} else {
  console.log('\nALL MDM CALCULATION REGRESSION TESTS PASSED (100%).');
}
