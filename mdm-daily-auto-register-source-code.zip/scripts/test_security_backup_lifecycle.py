#!/usr/bin/env python3
"""
Comprehensive Production Security Audit, Multi-Tenant Isolation, 
Backup/Restoration, Negative Balance Preservation, and Play Store Release Blocker Test Suite.
"""

import urllib.request
import urllib.error
import json
import time
import os
import shutil

BASE_URL = os.environ.get("TEST_APP_URL", "http://127.0.0.1:3000")

def post_json(endpoint, payload, token=None, custom_headers=None):
    url = f"{BASE_URL}{endpoint}"
    data = json.dumps(payload).encode('utf-8')
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['Authorization'] = f"Bearer {token}"
        headers['X-Session-Token'] = token
    if custom_headers:
        headers.update(custom_headers)
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = {}
        try:
            body = json.loads(e.read().decode('utf-8'))
        except Exception:
            pass
        return e.code, body
    except Exception as e:
        return 0, {'error': str(e)}

def get_json(endpoint, token=None):
    url = f"{BASE_URL}{endpoint}"
    headers = {}
    if token:
        headers['Authorization'] = f"Bearer {token}"
        headers['X-Session-Token'] = token
    req = urllib.request.Request(url, headers=headers, method='GET')
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = {}
        try:
            body = json.loads(e.read().decode('utf-8'))
        except Exception:
            pass
        return e.code, body
    except Exception as e:
        return 0, {'error': str(e)}

test_results = []

def record(test_id, name, expected, actual, condition):
    status = 'PASS' if condition else 'FAIL'
    test_results.append({
        'id': test_id,
        'name': name,
        'expected': expected,
        'actual': actual,
        'status': status
    })
    print(f"[{status}] {test_id}: {name} (Exp: {expected} | Act: {actual})")

print("=== STARTING COMPREHENSIVE SECURITY, BACKUP & RELEASE AUDIT SUITE ===\n")

suffix = str(int(time.time()))[-4:]
udise_alpha = f"28190{suffix}01"
udise_beta = f"28190{suffix}02"
mob_alpha = f"9870{suffix}01"
mob_beta = f"9870{suffix}02"

# 1. VERIFY OTP BYPASS IS BLOCKED
# Directly calling /register-direct without OTP verification must be rejected (403 Forbidden)
code_bypass, body_bypass = post_json('/api/auth/register-direct', {
    'name': 'Attacker Direct Bypass',
    'username': f'attacker_{suffix}',
    'schoolName': 'Unauthorized School',
    'udiseCode': f"281909{suffix}99",
    'mobile': f"98769{suffix}99",
    'password': 'Password@123',
    'confirmPassword': 'Password@123'
})
record('SEC-OTP-BYPASS-BLOCKED', 'Direct /register-direct OTP Bypass Blocked', '403 Forbidden', f"{code_bypass}", code_bypass == 403)

# 2. REGISTER SYNTHETIC SCHOOL ALPHA (SERVER-VERIFIED OTP FLOW)
code_init_a, body_init_a = post_json('/api/auth/register-initiate', {
    'name': 'Dr. Tester Alpha',
    'username': f'hm_alpha_{suffix}',
    'schoolName': 'Synthetic High School Alpha',
    'udiseCode': udise_alpha,
    'mobile': mob_alpha,
    'password': 'AlphaSecurePassword#2026',
    'confirmPassword': 'AlphaSecurePassword#2026',
    'village': 'Alpha Village',
    'mandal': 'Alpha Mandal',
    'district': 'Alpha District',
    'state': 'Andhra Pradesh',
    'forceTestMode': True
})
test_otp_a = body_init_a.get('testOtp')
record('AUTH-OTP-INIT-ALPHA', 'Alpha Initiates Registration & Receives OTP', '200 OK + testOtp', f"{code_init_a} (otp_received={bool(test_otp_a)})", code_init_a == 200 and bool(test_otp_a))

# Complete OTP verification for Alpha
code_verify_a, body_verify_a = post_json('/api/auth/register-verify-otp', {
    'mobile': mob_alpha,
    'otp': test_otp_a
})
token_a = body_verify_a.get('token')
record('AUTH-OTP-VERIFY-ALPHA', 'Alpha Verifies Server OTP & Activates Account', '200 OK + token', f"{code_verify_a} (has_token={bool(token_a)})", code_verify_a == 200 and bool(token_a))

# 3. REGISTER SYNTHETIC SCHOOL BETA (SERVER-VERIFIED OTP FLOW)
code_init_b, body_init_b = post_json('/api/auth/register-initiate', {
    'name': 'Mrs. Tester Beta',
    'username': f'hm_beta_{suffix}',
    'schoolName': 'Synthetic Primary School Beta',
    'udiseCode': udise_beta,
    'mobile': mob_beta,
    'password': 'BetaSecurePassword#2026',
    'confirmPassword': 'BetaSecurePassword#2026',
    'village': 'Beta Village',
    'mandal': 'Beta Mandal',
    'district': 'Beta District',
    'state': 'Andhra Pradesh',
    'forceTestMode': True
})
test_otp_b = body_init_b.get('testOtp')

code_verify_b, body_verify_b = post_json('/api/auth/register-verify-otp', {
    'mobile': mob_beta,
    'otp': test_otp_b
})
token_b = body_verify_b.get('token')
record('AUTH-OTP-VERIFY-BETA', 'Beta Verifies Server OTP & Activates Account', '200 OK + token', f"{code_verify_b} (has_token={bool(token_b)})", code_verify_b == 200 and bool(token_b))

# 4. WRITE DAILY ENTRY & PRESERVE NEGATIVE OPENING BALANCE (EGGS/CHIKKI)
code_entry, body_entry = post_json('/api/data/daily-entry', {
    'entry': {
        'date': '2026-08-01',
        'primaryAttendance': 45,
        'upperPrimaryAttendance': 35,
        'totalAttendance': 80,
        'mealsServed': 80,
        'riceUsedKg': 10.0,
        'eggUsedQty': 80,
        'remarks': 'Alpha Daily Entry Test'
    }
}, token=token_a)
record('DATA-WRITE-ALPHA', 'Alpha Writes Daily Entry', '200 OK', f"{code_entry}", code_entry == 200)

code_ob, body_ob = post_json('/api/data/commodity-overrides', {
    'overrides': {
        '2026-08': {
            'rice': 150.0,
            'egg': -10.0, # Legitimate negative opening balance
            'chikki': -5.0
        }
    }
}, token=token_a)
record('DATA-OB-ALPHA', 'Alpha Saves Monthly Overrides with Negative Eggs/Chikki', '200 OK', f"{code_ob}", code_ob == 200)

# 5. MULTI-TENANT ISOLATION: USER A vs USER B (BOLA/IDOR GATE)
code_b_read, body_b_read = get_json('/api/data/records', token=token_b)
entries_b = body_b_read.get('data', {}).get('dailyEntries', [])
has_alpha_entry = any(e.get('remarks') == 'Alpha Daily Entry Test' for e in entries_b)
record('ISOLATION-IDOR-01', 'Beta Reads Own Records (Zero Leakage of Alpha Data)', '0 entries from Alpha', f"{len(entries_b)} entries (has_alpha={has_alpha_entry})", code_b_read == 200 and not has_alpha_entry)

# 6. UNAUTHENTICATED BACKEND ACCESS REJECTION
code_unauth, body_unauth = get_json('/api/data/records', token=None)
record('ISOLATION-UNAUTH-02', 'Unauthenticated Request to Data Records Denied', '401 Unauthorized', f"{code_unauth}", code_unauth == 401)

# 7. IDEMPOTENCY / DOUBLE TAP PROTECTION
idem_key = f"idem_test_{suffix}"
code_dup1, _ = post_json('/api/data/daily-entry', {
    'entry': {
        'date': '2026-08-02',
        'primaryAttendance': 50,
        'mealsServed': 50,
        'remarks': 'Idempotent Entry'
    },
    'idempotencyKey': idem_key
}, token=token_a, custom_headers={'X-Idempotency-Key': idem_key})

code_dup2, body_dup2 = post_json('/api/data/daily-entry', {
    'entry': {
        'date': '2026-08-02',
        'primaryAttendance': 50,
        'mealsServed': 50,
        'remarks': 'Idempotent Entry'
    },
    'idempotencyKey': idem_key
}, token=token_a, custom_headers={'X-Idempotency-Key': idem_key})

code_read_a, body_read_a = get_json('/api/data/records', token=token_a)
entries_a = body_read_a.get('data', {}).get('dailyEntries', [])
idem_count = sum(1 for e in entries_a if e.get('date') == '2026-08-02')
record('IDEMPOTENCY-01', 'Duplicate Entry Submission Cached & Deduplicated', 'Exactly 1 entry created', f"{idem_count} entry", idem_count == 1 and code_dup1 == 200 and code_dup2 == 200)

# 8. BACKUP & RESTORATION CYCLE TEST
school_a_id = f"school_{udise_alpha}"
school_file = os.path.join('.data', 'schools', f"{school_a_id}.json")
backup_file = os.path.join('.backup', f"{school_a_id}.json.bak")
os.makedirs('.backup', exist_ok=True)

if os.path.exists(school_file):
    shutil.copyfile(school_file, backup_file)
    with open(school_file, 'r') as f:
        pre_restore_data = json.load(f)
    pre_count = len(pre_restore_data.get('dailyEntries', []))
    pre_egg = pre_restore_data.get('monthlyOverrides', {}).get('2026-08', {}).get('egg')

    # Mutate data artificially
    pre_restore_data['dailyEntries'].append({'date': '2026-08-99', 'remarks': 'Corrupt Temp'})
    with open(school_file, 'w') as f:
        json.dump(pre_restore_data, f)

    # Perform restoration from backup
    shutil.copyfile(backup_file, school_file)

    # Query through backend API to verify server-side state recovery
    code_api_restore, body_api_restore = get_json('/api/data/records', token=token_a)
    api_entries = body_api_restore.get('data', {}).get('dailyEntries', [])
    api_count = len(api_entries)
    api_egg = body_api_restore.get('data', {}).get('monthlyOverrides', {}).get('2026-08', {}).get('egg')

    record('BACKUP-RESTORE-COUNT', 'Restore Cycle Restores Exact Record Counts via API', f"{pre_count} entries", f"{api_count} entries", code_api_restore == 200 and api_count == pre_count)
    record('BACKUP-RESTORE-BALANCES', 'Restore Cycle Preserves Negative Commodity Balances via API', f"egg={pre_egg}", f"egg={api_egg}", api_egg == -10.0)

# 9. AUTHENTICATED ACCOUNT DELETION (GOOGLE PLAY COMPLIANCE)
code_del_bad, _ = post_json('/api/auth/delete-account', {'confirmationText': 'WRONG'}, token=token_a)
record('DELETE-REJECT-INVALID', 'Delete Request Rejected Without "DELETE MY ACCOUNT"', '400 Bad Request', f"{code_del_bad}", code_del_bad == 400)

code_del, body_del = post_json('/api/auth/delete-account', {'confirmationText': 'DELETE MY ACCOUNT'}, token=token_a)
record('DELETE-SUCCESS-ALPHA', 'Authenticated Account Deletion Executed', '200 OK + deleted=True', f"{code_del} (deleted={body_del.get('deleted')})", code_del == 200 and body_del.get('deleted') == True)

# Verification of session revocation after deletion
code_revoked, _ = get_json('/api/data/records', token=token_a)
record('DELETE-REVOCATION', 'Revocation of All Deleted Account Sessions', '401 Unauthorized', f"{code_revoked}", code_revoked == 401)

# Verification that Beta account remains intact
code_beta_check, body_beta_check = get_json('/api/data/records', token=token_b)
record('DELETE-NON-DESTRUCTION-BETA', 'Beta School Account Intact and Unaffected', '200 OK', f"{code_beta_check}", code_beta_check == 200)

# 9B. PUBLIC EXTERNAL WEB DELETION REQUEST VERIFICATION (PLAY POLICY COMPLIANCE)
code_pub_del_bad, _ = post_json('/api/auth/public-deletion-request', {
    'udiseCode': udise_beta,
    'registeredMobile': mob_beta,
    'confirmation': 'INVALID'
})
record('PUBLIC-DEL-REJECT-INVALID', 'Public Deletion Form Rejects Non-Confirmation', '400 Bad Request', f"{code_pub_del_bad}", code_pub_del_bad == 400)

code_pub_del_404, _ = post_json('/api/auth/public-deletion-request', {
    'udiseCode': '28999999999',
    'registeredMobile': '9999999999',
    'confirmation': 'CONFIRM DELETION'
})
record('PUBLIC-DEL-REJECT-UNKNOWN', 'Public Deletion Form Rejects Non-Existent Account', '404 Not Found', f"{code_pub_del_404}", code_pub_del_404 == 404)

code_pub_del_ok, body_pub_del_ok = post_json('/api/auth/public-deletion-request', {
    'udiseCode': udise_beta,
    'registeredMobile': mob_beta,
    'reason': 'test_account',
    'confirmation': 'CONFIRM DELETION'
})
has_req_id = bool(body_pub_del_ok.get('requestId')) and body_pub_del_ok.get('status') == 'PENDING_VERIFICATION'
record('PUBLIC-DEL-SUCCESS-BETA', 'Public Deletion Form Registers Verified Request ID', '200 OK + PENDING_VERIFICATION', f"{code_pub_del_ok} (has_id={has_req_id})", code_pub_del_ok == 200 and has_req_id)

# 10. DIGITAL ASSET LINKS VERIFICATION
code_al, body_al = get_json('/.well-known/assetlinks.json')
has_al_pkg = False
if isinstance(body_al, list) and len(body_al) > 0:
    has_al_pkg = body_al[0].get('target', {}).get('package_name') == 'com.mdm.dailyautoregister'
record('ASSETLINKS-DIRECT-200', 'AssetLinks HTTP 200 & Correct Package ID', '200 OK + com.mdm.dailyautoregister', f"{code_al} (pkg={has_al_pkg})", code_al == 200 and has_al_pkg)

# 11. ANDROID 16+ (API 36) PLAY STORE TARGET SDK CHECK
twa_path = 'twa-manifest.json'
is_api_36 = False
if os.path.exists(twa_path):
    with open(twa_path, 'r') as f:
        twa_json = json.load(f)
        is_api_36 = twa_json.get('targetSdkVersion', 0) >= 36 and twa_json.get('compileSdkVersion', 0) >= 36
record('ANDROID-API-36-TARGET', 'TWA Targets Android 16 (API 36) or Higher', 'targetSdkVersion >= 36', f"target={twa_json.get('targetSdkVersion')}", is_api_36)

# 12. PUBLIC SOURCE CODE DOWNLOAD ROUTE DISABLED
code_zip, _ = get_json('/api/download-zip')
record('SOURCE-DOWNLOAD-DISABLED', 'Public Source Code Download Route Disabled', '404 Not Found', f"{code_zip}", code_zip == 404)

print("\n=== SUMMARY TABLE ===")
print("| Test ID | Test Name | Expected | Actual | Status |")
print("|---|---|---|---|---|")
passed_count = 0
for t in test_results:
    if t['status'] == 'PASS':
        passed_count += 1
    print(f"| {t['id']} | {t['name']} | {t['expected']} | {t['actual']} | **{t['status']}** |")

print(f"\nTotal: {len(test_results)} | Passed: {passed_count} | Failed: {len(test_results) - passed_count}")

if passed_count == len(test_results):
    print("ALL VERIFICATION AND COMPLIANCE TESTS PASSED (100%).")
else:
    exit(1)
