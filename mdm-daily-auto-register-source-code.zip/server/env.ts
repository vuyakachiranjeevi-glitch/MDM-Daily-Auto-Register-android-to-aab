/**
 * Environment and runtime configuration helper.
 * Production is the strict DEFAULT. The app only runs in development
 * when NODE_ENV is explicitly set to 'development'.
 */

export function isProduction(): boolean {
  return process.env.NODE_ENV !== 'development';
}

export function isDevelopment(): boolean {
  return process.env.NODE_ENV === 'development';
}

export function getProductionHost(): string {
  return (
    process.env.PRODUCTION_HOST ||
    process.env.APP_DOMAIN ||
    'app.mdmregister.in'
  );
}

export function getSupportEmail(): string {
  return process.env.SUPPORT_EMAIL || 'support@mdmregister.in';
}

export function getSmsBrandName(): string {
  return process.env.SMS_BRAND_NAME || 'MDM Register';
}

export function getOtpPepper(): string {
  return process.env.OTP_PEPPER || 'mdm_default_secure_otp_pepper_prod_key_2026';
}
