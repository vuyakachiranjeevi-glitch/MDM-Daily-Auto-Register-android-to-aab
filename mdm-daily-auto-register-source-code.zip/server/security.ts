import crypto from 'node:crypto';
import type { AuditLogEntry, HashedCredential } from './types.ts';

// PBKDF2 Configuration
const PBKDF2_ITERATIONS = 100000;
const PBKDF2_KEYLEN = 64;
const PBKDF2_DIGEST = 'sha512';

/**
 * Generates a cryptographically secure random salt (16 bytes hex)
 */
export function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Securely hashes a password using PBKDF2 with SHA-512 and salt
 */
export function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, PBKDF2_ITERATIONS, PBKDF2_KEYLEN, PBKDF2_DIGEST).toString('hex');
}

/**
 * Validates a password against stored salt and hash using timing-safe comparison
 */
export function verifyPassword(password: string, credential: HashedCredential): boolean {
  if (!credential || !credential.hash || !credential.salt) return false;
  const computedHash = hashPassword(password, credential.salt);
  try {
    const a = Buffer.from(computedHash, 'hex');
    const b = Buffer.from(credential.hash, 'hex');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/**
 * Creates a complete HashedCredential object
 */
export function createHashedCredential(password: string): HashedCredential {
  const salt = generateSalt();
  const hash = hashPassword(password, salt);
  return {
    hash,
    salt,
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Generates a 6-digit cryptographically secure numeric OTP
 */
export function generateSecureOtp(): string {
  // Generates integer in range [100000, 999999]
  return crypto.randomInt(100000, 1000000).toString();
}

/**
 * Hashes an OTP so raw OTPs are NEVER stored in plaintext on disk/database
 */
export function hashOtp(otp: string, salt: string): string {
  return crypto.pbkdf2Sync(otp, salt, 10000, 32, 'sha256').toString('hex');
}

/**
 * Verifies an OTP against its hashed representation
 */
export function verifyOtp(enteredOtp: string, storedHash: string, salt: string): boolean {
  try {
    const computed = hashOtp(enteredOtp.trim(), salt);
    const a = Buffer.from(computed, 'hex');
    const b = Buffer.from(storedHash, 'hex');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/**
 * Generates a high-entropy 32-byte session or reset token (64 hex characters)
 */
export function generateSecureToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Sanitizes phone number or identifier for safe logging without leaking PII
 */
export function sanitizeIdentifier(input: string): string {
  if (!input) return 'anonymous';
  const clean = input.trim();
  if (clean.length === 10 && /^\d+$/.test(clean)) {
    return `${clean.substring(0, 3)}****${clean.substring(7)}`;
  }
  if (clean.length > 5) {
    return `${clean.substring(0, 3)}***${clean.slice(-2)}`;
  }
  return '***';
}

/**
 * In-memory sliding-window Rate Limiter for IP and Account Identifiers
 */
interface RateLimitBucket {
  count: number;
  firstRequestTime: number;
  blockedUntil?: number;
}

const rateLimitBuckets = new Map<string, RateLimitBucket>();

export interface RateLimitOptions {
  windowMs: number; // Duration of window in ms
  maxRequests: number; // Max requests allowed in window
  blockDurationMs?: number; // How long to block after limit exceeded
}

export function checkRateLimit(key: string, options: RateLimitOptions): { allowed: boolean; retryAfterSeconds?: number } {
  const now = Date.now();
  const bucket = rateLimitBuckets.get(key);

  if (!bucket) {
    rateLimitBuckets.set(key, { count: 1, firstRequestTime: now });
    return { allowed: true };
  }

  // Check if currently blocked
  if (bucket.blockedUntil && now < bucket.blockedUntil) {
    const retryAfter = Math.ceil((bucket.blockedUntil - now) / 1000);
    return { allowed: false, retryAfterSeconds: retryAfter };
  }

  // If window has passed, reset
  if (now - bucket.firstRequestTime > options.windowMs) {
    bucket.count = 1;
    bucket.firstRequestTime = now;
    bucket.blockedUntil = undefined;
    return { allowed: true };
  }

  // Within window: increment
  bucket.count += 1;
  if (bucket.count > options.maxRequests) {
    const blockDuration = options.blockDurationMs || options.windowMs;
    bucket.blockedUntil = now + blockDuration;
    const retryAfter = Math.ceil(blockDuration / 1000);
    return { allowed: false, retryAfterSeconds: retryAfter };
  }

  return { allowed: true };
}

// Clean up stale rate limit entries periodically (every 10 minutes)
const cleanupTimer = setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of rateLimitBuckets.entries()) {
    if (now - bucket.firstRequestTime > 3600000 && (!bucket.blockedUntil || now > bucket.blockedUntil)) {
      rateLimitBuckets.delete(key);
    }
  }
}, 600000);
if (cleanupTimer.unref) {
  cleanupTimer.unref();
}
