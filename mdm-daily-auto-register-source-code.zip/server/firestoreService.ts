import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  setLogLevel,
  doc,
  getDoc,
  setDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  where,
} from 'firebase/firestore/lite';
import fs from 'node:fs';
import path from 'node:path';
import type { SchoolDatabasePayload } from './dataStore.ts';
import type { ServerUserAccount } from './types.ts';

// Silence internal Firestore stream lifecycle cancellations and idle warnings
try {
  setLogLevel('silent');
} catch {}

const BACKEND_AUTH_TOKEN = 'mdm_backend_secure_token_71a44c73_prod';

let dbInstance: any = null;

function getDb() {
  if (dbInstance) return dbInstance;
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      console.warn('firebase-applet-config.json not found, firestore sync disabled');
      return null;
    }
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const app = getApps().length === 0 ? initializeApp(config) : getApp();
    const dbId = config.firestoreDatabaseId;
    dbInstance = dbId ? getFirestore(app, dbId) : getFirestore(app);
    return dbInstance;
  } catch (err) {
    console.error('Failed initializing Firestore in server:', err);
    return null;
  }
}

export interface FirestoreSaveResult {
  success: boolean;
  conflict?: boolean;
  latest?: SchoolDatabasePayload;
}

/**
 * Persists school database payload to durable shared Firestore collection
 */
export async function saveSchoolDataToFirestore(
  schoolId: string,
  data: SchoolDatabasePayload,
  expectedUpdatedAt?: string
): Promise<FirestoreSaveResult> {
  const db = getDb();
  if (!db) return { success: false };
  try {
    const safeDocId = schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const docRef = doc(db, 'school_data', safeDocId);

    if (expectedUpdatedAt) {
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const existingDoc = snap.data();
        if (existingDoc?.updatedAt && existingDoc.updatedAt !== expectedUpdatedAt) {
          return {
            success: false,
            conflict: true,
            latest: (existingDoc?.data as SchoolDatabasePayload) || undefined,
          };
        }
      }
    }

    const cleanPayload = JSON.parse(JSON.stringify(data));
    await setDoc(docRef, {
      data: cleanPayload,
      schoolId,
      updatedAt: data.updatedAt || new Date().toISOString(),
      _backendAuthToken: BACKEND_AUTH_TOKEN,
    });
    return { success: true };
  } catch (err) {
    console.error(`Failed persisting school ${schoolId} to Firestore:`, err);
    return { success: false };
  }
}

/**
 * Fetches school database payload from durable shared Firestore
 */
export async function loadSchoolDataFromFirestore(
  schoolId: string
): Promise<SchoolDatabasePayload | null> {
  const db = getDb();
  if (!db) return null;
  try {
    const safeDocId = schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const docRef = doc(db, 'school_data', safeDocId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const docData = snap.data();
      return (docData?.data as SchoolDatabasePayload) || null;
    }
    return null;
  } catch (err) {
    console.error(`Failed loading school ${schoolId} from Firestore:`, err);
    return null;
  }
}

/**
 * Persists user account to durable shared Firestore collection
 */
export async function saveAccountToFirestore(
  account: ServerUserAccount
): Promise<boolean> {
  const db = getDb();
  if (!db) return false;
  try {
    const safeDocId = account.schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const docRef = doc(db, 'school_accounts', safeDocId);
    const cleanAccount = JSON.parse(JSON.stringify(account));
    await setDoc(docRef, {
      ...cleanAccount,
      _backendAuthToken: BACKEND_AUTH_TOKEN,
      updatedAt: new Date().toISOString(),
    });
    return true;
  } catch (err) {
    console.error(`Failed saving account ${account.schoolId} to Firestore:`, err);
    return false;
  }
}

/**
 * Loads all accounts from durable shared Firestore
 */
export async function loadAccountsFromFirestore(): Promise<ServerUserAccount[]> {
  const db = getDb();
  if (!db) return [];
  try {
    const collRef = collection(db, 'school_accounts');
    const q = query(collRef, where('_backendAuthToken', '==', BACKEND_AUTH_TOKEN));
    const snaps = await getDocs(q);
    const accounts: ServerUserAccount[] = [];
    snaps.forEach((docSnap) => {
      const data = docSnap.data();
      if (data && data.schoolId) {
        const { _backendAuthToken, ...cleanAccount } = data;
        accounts.push(cleanAccount as ServerUserAccount);
      }
    });
    return accounts;
  } catch (err) {
    console.error('Failed loading accounts from Firestore:', err);
    return [];
  }
}

/**
 * Permanently deletes school data from Firestore
 */
export async function deleteSchoolDataFromFirestore(schoolId: string): Promise<boolean> {
  const db = getDb();
  if (!db) return false;
  try {
    const safeDocId = schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const docRef = doc(db, 'school_data', safeDocId);
    await deleteDoc(docRef);
    return true;
  } catch (err) {
    console.error(`Failed deleting school ${schoolId} from Firestore:`, err);
    return false;
  }
}

/**
 * Permanently deletes school account from Firestore
 */
export async function deleteAccountFromFirestore(schoolId: string): Promise<boolean> {
  const db = getDb();
  if (!db) return false;
  try {
    const safeDocId = schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const docRef = doc(db, 'school_accounts', safeDocId);
    await deleteDoc(docRef);
    return true;
  } catch (err) {
    console.error(`Failed deleting account ${schoolId} from Firestore:`, err);
    return false;
  }
}

/**
 * Non-destructive migration of local JSON data to Firestore
 */
export async function migrateLocalDataToFirestore(): Promise<{
  migratedSchools: number;
  migratedAccounts: number;
  backupPath: string;
}> {
  const dataDir = path.resolve(process.cwd(), '.data');
  const backupPath = path.resolve(dataDir, `backup_pre_migration_${Date.now()}`);

  if (fs.existsSync(dataDir)) {
    fs.mkdirSync(backupPath, { recursive: true });
    // Safe non-destructive backup
    const schoolsDir = path.join(dataDir, 'schools');
    if (fs.existsSync(schoolsDir)) {
      const backupSchoolsDir = path.join(backupPath, 'schools');
      fs.mkdirSync(backupSchoolsDir, { recursive: true });
      for (const f of fs.readdirSync(schoolsDir)) {
        if (f.endsWith('.json')) {
          fs.copyFileSync(path.join(schoolsDir, f), path.join(backupSchoolsDir, f));
        }
      }
    }
    const authFile = path.join(dataDir, 'auth_store.json');
    if (fs.existsSync(authFile)) {
      fs.copyFileSync(authFile, path.join(backupPath, 'auth_store.json'));
    }
  }

  let migratedSchools = 0;
  let migratedAccounts = 0;

  // 1. Migrate schools
  const schoolsDir = path.join(dataDir, 'schools');
  if (fs.existsSync(schoolsDir)) {
    const files = fs.readdirSync(schoolsDir).filter((f) => f.endsWith('.json'));
    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(schoolsDir, file), 'utf8');
        const parsed = JSON.parse(content);
        if (parsed && parsed.schoolId) {
          await saveSchoolDataToFirestore(parsed.schoolId, parsed);
          migratedSchools++;
        }
      } catch (err) {
        console.error(`Error migrating file ${file}:`, err);
      }
    }
  }

  // 2. Migrate accounts
  const authFile = path.join(dataDir, 'auth_store.json');
  if (fs.existsSync(authFile)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(authFile, 'utf8'));
      if (Array.isArray(parsed.accounts)) {
        for (const acc of parsed.accounts) {
          if (acc && acc.schoolId) {
            await saveAccountToFirestore(acc);
            migratedAccounts++;
          }
        }
      }
    } catch (err) {
      console.error('Error migrating accounts:', err);
    } finally {
      try { fs.unlinkSync(authFile); } catch {}
    }
  }

  return { migratedSchools, migratedAccounts, backupPath };
}
