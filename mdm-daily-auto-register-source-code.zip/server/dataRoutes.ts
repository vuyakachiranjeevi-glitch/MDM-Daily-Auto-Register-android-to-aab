import { Router } from 'express';
import type { Request, Response } from 'express';
import { authStore } from './authStore.ts';
import { dataStore } from './dataStore.ts';
import { sanitizeIdentifier } from './security.ts';

export const dataRouter = Router();

// Middleware: Authenticate & Authorize
function requireAuth(req: Request, res: Response, next: () => void) {
  const authHeader = req.headers.authorization || req.headers['x-session-token'];
  let token = '';
  if (typeof authHeader === 'string') {
    token = authHeader.startsWith('Bearer ') ? authHeader.substring(7) : authHeader;
  }

  if (!token) {
    return res.status(401).json({ success: false, error: 'Authentication required. No session token provided.' });
  }

  const session = authStore.getSession(token);
  if (!session) {
    return res.status(401).json({ success: false, error: 'Session expired or invalidated. Please log in again.' });
  }

  if (session.status !== 'ACTIVE') {
    return res.status(403).json({ success: false, error: 'Account is not in active state.' });
  }

  (req as any).userSession = session;
  next();
}

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

/* =========================================================================
   1. GET SCHOOL DATA (Strict IDOR / BOLA Isolation)
   User A can NEVER access User B's records. SchoolId is bound to session.
   ========================================================================= */
dataRouter.get('/records', requireAuth, async (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;

  const data = await dataStore.getSchoolDataAsync(schoolId);
  const acc = authStore.getAccount(schoolId);
  if (acc && !data.schoolProfile) {
    data.schoolProfile = {
      schoolName: acc.schoolName,
      udiseCode: acc.udiseCode,
      headmasterName: acc.headmasterName,
      phoneNumber: acc.headmasterMobile,
      village: acc.village || '',
      mandal: acc.mandal || 'PALAKONDA',
      district: acc.district || 'PARVATHI PURAM MANYAM',
      state: acc.state || 'ANDHRA PRADESH',
      address: acc.address || `${acc.schoolName}, ${acc.mandal || ''}`,
    };
    data.schoolName = acc.schoolName;
    data.udiseCode = acc.udiseCode;
  }
  return res.json({
    success: true,
    schoolId,
    data,
  });
});

/* =========================================================================
   2. SAVE DAILY ENTRY (Daily Auto Register Security & Idempotency)
   ========================================================================= */
dataRouter.post('/daily-entry', requireAuth, (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;
  const ip = getClientIp(req);
  const idempotencyKey = (req.headers['x-idempotency-key'] as string) || req.body.idempotencyKey;

  // 1. Check Idempotency Cache to avoid duplicate submissions on double taps / network retries
  if (idempotencyKey) {
    const cached = dataStore.getIdempotencyResult(`${schoolId}_${idempotencyKey}`);
    if (cached) {
      return res.json(cached);
    }
  }

  const entry = req.body.entry || req.body;
  if (!entry || !entry.date) {
    return res.status(400).json({ success: false, error: 'Invalid payload: entry date is required.' });
  }

  // Validate date format (YYYY-MM-DD)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(entry.date)) {
    return res.status(400).json({ success: false, error: 'Invalid date format. Expected YYYY-MM-DD.' });
  }

  // Validate non-negative numbers
  if (typeof entry.mealsServed === 'number' && entry.mealsServed < 0) {
    return res.status(400).json({ success: false, error: 'Meals served cannot be negative.' });
  }
  if (typeof entry.primaryAttendance === 'number' && entry.primaryAttendance < 0) {
    return res.status(400).json({ success: false, error: 'Primary attendance cannot be negative.' });
  }
  if (typeof entry.upperPrimaryAttendance === 'number' && entry.upperPrimaryAttendance < 0) {
    return res.status(400).json({ success: false, error: 'Upper primary attendance cannot be negative.' });
  }

  // Atomic upsert
  const { entry: savedEntry, isNew } = dataStore.upsertDailyEntry(schoolId, entry);

  authStore.addAuditLog({
    action: 'DAILY_ENTRY_SAVED',
    identifier: sanitizeIdentifier(session.username),
    schoolId,
    ip,
    userAgent: req.headers['user-agent'],
    details: `Date: ${entry.date}, Meals: ${entry.mealsServed || 0}, New: ${isNew}`,
  });

  const responsePayload = {
    success: true,
    message: isNew ? 'Daily entry created successfully.' : 'Daily entry updated successfully.',
    entry: savedEntry,
  };

  if (idempotencyKey) {
    dataStore.setIdempotencyResult(`${schoolId}_${idempotencyKey}`, responsePayload);
  }

  return res.json(responsePayload);
});

/* =========================================================================
   3. SAVE CASH VOUCHER (Integrity, Calculations & Duplicate Protection)
   ========================================================================= */
dataRouter.post('/cash-voucher', requireAuth, (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;
  const ip = getClientIp(req);
  const idempotencyKey = (req.headers['x-idempotency-key'] as string) || req.body.idempotencyKey;

  if (idempotencyKey) {
    const cached = dataStore.getIdempotencyResult(`${schoolId}_${idempotencyKey}`);
    if (cached) {
      return res.json(cached);
    }
  }

  const voucher = req.body.voucher || req.body;
  if (!voucher || !voucher.month || !voucher.voucherNo) {
    return res.status(400).json({ success: false, error: 'Voucher month and voucherNo are required.' });
  }

  // Amounts cannot be negative
  if (typeof voucher.totalAmount === 'number' && voucher.totalAmount < 0) {
    return res.status(400).json({ success: false, error: 'Voucher total amount cannot be negative.' });
  }

  const { voucher: savedVoucher, isNew } = dataStore.upsertCashVoucher(schoolId, voucher);

  authStore.addAuditLog({
    action: 'CASH_VOUCHER_CREATED',
    identifier: sanitizeIdentifier(session.username),
    schoolId,
    ip,
    userAgent: req.headers['user-agent'],
    details: `Voucher: ${voucher.voucherNo}, Month: ${voucher.month}, Total: ₹${voucher.totalAmount}`,
  });

  const responsePayload = {
    success: true,
    message: isNew ? 'Cash voucher generated and recorded successfully.' : 'Cash voucher updated successfully.',
    voucher: savedVoucher,
  };

  if (idempotencyKey) {
    dataStore.setIdempotencyResult(`${schoolId}_${idempotencyKey}`, responsePayload);
  }

  return res.json(responsePayload);
});

/* =========================================================================
   4. STOCK TRANSACTIONS (Preserves legitimate negative Eggs & Chikki OB)
   ========================================================================= */
dataRouter.post('/stock-transaction', requireAuth, (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;
  const ip = getClientIp(req);
  const tx = req.body.transaction || req.body;

  if (!tx || !tx.date || !tx.commodityId) {
    return res.status(400).json({ success: false, error: 'Transaction date and commodityId are required.' });
  }

  dataStore.addStockTransaction(schoolId, tx);

  authStore.addAuditLog({
    action: 'STOCK_TRANSACTION_RECORDED',
    identifier: sanitizeIdentifier(session.username),
    schoolId,
    ip,
    userAgent: req.headers['user-agent'],
    details: `Date: ${tx.date}, Comm: ${tx.commodityId}, Type: ${tx.type}, Qty: ${tx.quantity}`,
  });

  return res.json({
    success: true,
    message: 'Stock transaction saved successfully.',
    transaction: tx,
  });
});

/* =========================================================================
   5. MONTHLY COMMODITY OVERRIDES (Negative OB Eggs & Chikki Preservation)
   ========================================================================= */
dataRouter.post('/commodity-overrides', requireAuth, (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;
  const ip = getClientIp(req);
  const { overrides } = req.body;

  if (!overrides || typeof overrides !== 'object') {
    return res.status(400).json({ success: false, error: 'Valid overrides map is required.' });
  }

  // Validate: rice, oil, pulses cannot be negative. Eggs and Chikki CAN legitimately be negative.
  for (const [key, val] of Object.entries(overrides)) {
    if (val && typeof val === 'object') {
      const commMap = val as Record<string, number>;
      if (typeof commMap.rice === 'number' && commMap.rice < 0) {
        return res.status(400).json({ success: false, error: 'Rice stock cannot be negative.' });
      }
      if (typeof commMap.oil === 'number' && commMap.oil < 0) {
        return res.status(400).json({ success: false, error: 'Oil stock cannot be negative.' });
      }
      if (typeof commMap.pulses === 'number' && commMap.pulses < 0) {
        return res.status(400).json({ success: false, error: 'Pulses stock cannot be negative.' });
      }
      // Note: commMap.egg and commMap.chikki CAN be negative without error!
    }
  }

  dataStore.updateMonthlyOverrides(schoolId, overrides);

  authStore.addAuditLog({
    action: 'COMMODITIES_UPDATED',
    identifier: sanitizeIdentifier(session.username),
    schoolId,
    ip,
    userAgent: req.headers['user-agent'],
    details: 'Monthly opening balance overrides updated (negative Eggs/Chikki preserved)',
  });

  return res.json({
    success: true,
    message: 'Commodity overrides updated successfully.',
  });
});

/* =========================================================================
   6. ATOMIC FULL SYNC
   ========================================================================= */
dataRouter.post('/sync', requireAuth, async (req: Request, res: Response) => {
  const session = (req as any).userSession;
  const schoolId = session.schoolId;
  const ip = getClientIp(req);
  const { snapshot } = req.body;

  if (snapshot && typeof snapshot === 'object') {
    const current = await dataStore.getSchoolDataAsync(schoolId);

    if (snapshot.schoolProfile && typeof snapshot.schoolProfile === 'object') {
      current.schoolProfile = snapshot.schoolProfile;
      current.schoolName = snapshot.schoolProfile.schoolName || current.schoolName;
      current.udiseCode = snapshot.schoolProfile.udiseCode || current.udiseCode;

      // Also persist to account in authStore
      authStore.updateAccount(schoolId, {
        schoolName: snapshot.schoolProfile.schoolName,
        udiseCode: snapshot.schoolProfile.udiseCode,
        village: snapshot.schoolProfile.village,
        mandal: snapshot.schoolProfile.mandal,
        district: snapshot.schoolProfile.district,
        headmasterName: snapshot.schoolProfile.headmasterName,
      });
    }

    if (snapshot.mealRates && typeof snapshot.mealRates === 'object') {
      current.mealRates = snapshot.mealRates;
    }

    if (Array.isArray(snapshot.studentStrengths)) {
      current.studentStrengths = snapshot.studentStrengths;
    }

    if (Array.isArray(snapshot.dailyEntries)) {
      current.dailyEntries = snapshot.dailyEntries;
    }

    if (Array.isArray(snapshot.stockTransactions)) {
      current.stockTransactions = snapshot.stockTransactions;
    }

    if (Array.isArray(snapshot.cashVouchers)) {
      current.cashVouchers = snapshot.cashVouchers;
    }

    if (Array.isArray(snapshot.commodities)) {
      current.commodities = snapshot.commodities;
    }

    if (snapshot.monthlyOverrides && typeof snapshot.monthlyOverrides === 'object') {
      current.monthlyOverrides = snapshot.monthlyOverrides;
    }

    await dataStore.saveSchoolDataAsync(schoolId, current);

    authStore.addAuditLog({
      action: 'DATA_SYNC_COMPLETED',
      identifier: sanitizeIdentifier(session.username),
      schoolId,
      ip,
      userAgent: req.headers['user-agent'],
      details: 'Client data sync applied atomically to durable store',
    });
  }

  const latest = await dataStore.getSchoolDataAsync(schoolId);
  return res.json({
    success: true,
    schoolId,
    data: latest,
  });
});
