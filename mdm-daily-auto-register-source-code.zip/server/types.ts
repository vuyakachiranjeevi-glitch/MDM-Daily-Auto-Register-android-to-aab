export type AccountStatus = 'UNVERIFIED' | 'OTP_VERIFIED' | 'PROFILE_INCOMPLETE' | 'ACTIVE' | 'SUSPENDED';

export type UserRole = 'HEADMASTER' | 'MDM_INCHARGE';

export interface HashedCredential {
  hash: string;
  salt: string;
  updatedAt: string;
}

export interface ServerUserAccount {
  id: string; // schoolId e.g. school_28261800503
  schoolId: string;
  schoolName: string;
  udiseCode: string;
  village?: string;
  mandal?: string;
  district?: string;
  state?: string;
  address?: string;
  headmasterName: string;
  headmasterSurname?: string;
  headmasterMobile: string;
  headmasterEmail?: string;
  headmasterDesignation?: string;
  status: AccountStatus;
  roles: {
    headmaster: {
      username: string;
      mobile: string;
      name: string;
      credential: HashedCredential;
    };
    incharge: {
      username: string;
      mobile: string;
      name: string;
      credential: HashedCredential;
    };
  };
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
  failedLoginAttempts: number;
  lockoutUntil?: string | null;
}

export interface PendingOtpRecord {
  id: string;
  mobile: string;
  identifier: string; // username or mobile
  otpHash: string;
  otpSalt: string;
  purpose: 'REGISTRATION' | 'FORGOT_PASSWORD' | 'CHANGE_CREDENTIALS' | 'LOGIN';
  expiresAt: number; // epoch ms
  attempts: number;
  maxAttempts: number;
  createdAt: number;
  lastSentAt: number;
  meta?: any; // pending registration payload, etc.
}

export interface ActiveSession {
  token: string;
  schoolId: string;
  username: string;
  role: UserRole;
  name: string;
  status: AccountStatus;
  createdAt: number;
  expiresAt: number;
  lastActiveAt: number;
  ip: string;
  userAgent?: string;
}

export interface PasswordResetToken {
  token: string;
  identifier: string;
  schoolId: string;
  role: UserRole;
  createdAt: number;
  expiresAt: number;
  used: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action:
    | 'LOGIN_SUCCESS'
    | 'LOGIN_FAILED'
    | 'SIGNUP_INITIATED'
    | 'OTP_REQUESTED'
    | 'OTP_VERIFIED'
    | 'OTP_FAILED'
    | 'PASSWORD_RESET_INITIATED'
    | 'PASSWORD_RESET_COMPLETED'
    | 'CREDENTIALS_UPDATED'
    | 'MOBILE_CHANGE_INITIATED'
    | 'MOBILE_CHANGE_VERIFIED'
    | 'DAILY_ENTRY_SAVED'
    | 'CASH_VOUCHER_CREATED'
    | 'STOCK_TRANSACTION_RECORDED'
    | 'COMMODITIES_UPDATED'
    | 'DATA_SYNC_COMPLETED'
    | 'LOGOUT'
    | 'ALL_SESSIONS_REVOKED'
    | 'ACCOUNT_SUSPENDED'
    | 'ACCOUNT_ACTIVATED'
    | 'ACCOUNT_DELETED'
    | 'DELETION_REQUEST_SUBMITTED'
    | 'RATE_LIMIT_TRIGGERED';
  identifier: string; // sanitized e.g. "hm_2826..." or "98480*****"
  schoolId?: string;
  ip: string;
  userAgent?: string;
  details?: string;
}
