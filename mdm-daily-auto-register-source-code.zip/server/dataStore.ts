import fs from 'node:fs';
import path from 'node:path';
import {
  saveSchoolDataToFirestore,
  loadSchoolDataFromFirestore,
  deleteSchoolDataFromFirestore,
} from './firestoreService.ts';
import { authStore } from './authStore.ts';

export interface SchoolDatabasePayload {
  schoolId: string;
  udiseCode?: string;
  schoolName?: string;
  schoolProfile?: any;
  mealRates?: any;
  dailyEntries: any[];
  commodities: any[];
  stockTransactions: any[];
  cashVouchers: any[];
  studentStrengths: any[];
  monthlyOverrides: Record<string, Record<string, number>>;
  updatedAt: string;
}

const DATA_DIR = path.resolve(process.cwd(), '.data', 'schools');

// In-memory idempotency cache: key -> { result: any, timestamp: number }
interface IdempotencyRecord {
  result: any;
  timestamp: number;
}
const idempotencyMap = new Map<string, IdempotencyRecord>();

// Clean up idempotency records older than 15 minutes
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of idempotencyMap.entries()) {
    if (now - v.timestamp > 15 * 60 * 1000) {
      idempotencyMap.delete(k);
    }
  }
}, 300000).unref?.();

class DataStore {
  constructor() {
    this.ensureDir();
  }

  private ensureDir() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
      }
    } catch (err) {
      console.error('Error creating data directory:', err);
    }
  }

  private getFilePath(schoolId: string): string {
    const safeSchoolId = schoolId.replace(/[^a-zA-Z0-9_.-]/g, '_');
    return path.join(DATA_DIR, `${safeSchoolId}.json`);
  }

  public getSchoolData(schoolId: string): SchoolDatabasePayload {
    this.ensureDir();
    const filePath = this.getFilePath(schoolId);
    const backupPath = `${filePath}.bak`;

    if (fs.existsSync(filePath)) {
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(content);
        const acc = authStore.getAccount(schoolId);
        const resolvedProfile = parsed.schoolProfile || (acc ? {
          schoolName: acc.schoolName,
          udiseCode: acc.udiseCode,
          headmasterName: acc.headmasterName,
          phoneNumber: acc.headmasterMobile,
          village: acc.village || '',
          mandal: acc.mandal || 'PALAKONDA',
          district: acc.district || 'PARVATHI PURAM MANYAM',
          state: acc.state || 'ANDHRA PRADESH',
          address: acc.address || `${acc.schoolName}, ${acc.mandal || ''}`,
        } : undefined);

        return {
          schoolId,
          udiseCode: parsed.udiseCode || acc?.udiseCode || (schoolId.startsWith('school_') ? schoolId.replace('school_', '') : undefined),
          schoolName: parsed.schoolName || acc?.schoolName,
          schoolProfile: resolvedProfile,
          mealRates: parsed.mealRates,
          dailyEntries: Array.isArray(parsed.dailyEntries) ? parsed.dailyEntries : [],
          commodities: Array.isArray(parsed.commodities) ? parsed.commodities : [],
          stockTransactions: Array.isArray(parsed.stockTransactions) ? parsed.stockTransactions : [],
          cashVouchers: Array.isArray(parsed.cashVouchers) ? parsed.cashVouchers : [],
          studentStrengths: Array.isArray(parsed.studentStrengths) ? parsed.studentStrengths : [],
          monthlyOverrides: parsed.monthlyOverrides && typeof parsed.monthlyOverrides === 'object' ? parsed.monthlyOverrides : {},
          updatedAt: parsed.updatedAt || new Date().toISOString(),
        };
      } catch (err) {
        console.error(`Error reading data file for ${schoolId}, attempting recovery from backup:`, err);
        if (fs.existsSync(backupPath)) {
          try {
            const backupContent = fs.readFileSync(backupPath, 'utf-8');
            const backupParsed = JSON.parse(backupContent);
            console.warn(`Successfully recovered data for ${schoolId} from local backup.`);
            const acc = authStore.getAccount(schoolId);
            return {
              schoolId,
              udiseCode: backupParsed.udiseCode || acc?.udiseCode,
              schoolName: backupParsed.schoolName || acc?.schoolName,
              schoolProfile: backupParsed.schoolProfile,
              mealRates: backupParsed.mealRates,
              dailyEntries: Array.isArray(backupParsed.dailyEntries) ? backupParsed.dailyEntries : [],
              commodities: Array.isArray(backupParsed.commodities) ? backupParsed.commodities : [],
              stockTransactions: Array.isArray(backupParsed.stockTransactions) ? backupParsed.stockTransactions : [],
              cashVouchers: Array.isArray(backupParsed.cashVouchers) ? backupParsed.cashVouchers : [],
              studentStrengths: Array.isArray(backupParsed.studentStrengths) ? backupParsed.studentStrengths : [],
              monthlyOverrides: backupParsed.monthlyOverrides && typeof backupParsed.monthlyOverrides === 'object' ? backupParsed.monthlyOverrides : {},
              updatedAt: backupParsed.updatedAt || new Date().toISOString(),
            };
          } catch (bakErr) {
            console.error(`Backup recovery failed for ${schoolId}:`, bakErr);
            throw new Error(`Data for school ${schoolId} exists but is temporarily unreadable. Aborting to prevent silent empty overwrite.`);
          }
        }
        throw new Error(`Data for school ${schoolId} exists but could not be parsed. Aborting to prevent silent empty overwrite.`);
      }
    }

    // New school baseline structure
    const acc = authStore.getAccount(schoolId);
    const newProfile = acc ? {
      schoolName: acc.schoolName,
      udiseCode: acc.udiseCode,
      headmasterName: acc.headmasterName,
      phoneNumber: acc.headmasterMobile,
      village: acc.village || '',
      mandal: acc.mandal || 'PALAKONDA',
      district: acc.district || 'PARVATHI PURAM MANYAM',
      state: acc.state || 'ANDHRA PRADESH',
      address: acc.address || `${acc.schoolName}, ${acc.mandal || ''}`,
    } : undefined;

    return {
      schoolId,
      udiseCode: acc?.udiseCode || (schoolId.startsWith('school_') ? schoolId.replace('school_', '') : undefined),
      schoolName: acc?.schoolName,
      schoolProfile: newProfile,
      dailyEntries: [],
      commodities: [],
      stockTransactions: [],
      cashVouchers: [],
      studentStrengths: [],
      monthlyOverrides: {},
      updatedAt: new Date().toISOString(),
    };
  }

  public async getSchoolDataAsync(schoolId: string): Promise<SchoolDatabasePayload> {
    this.ensureDir();
    const filePath = this.getFilePath(schoolId);
    const backupPath = `${filePath}.bak`;

    let localResult: SchoolDatabasePayload | null = null;
    if (fs.existsSync(filePath)) {
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(content);
        const acc = authStore.getAccount(schoolId);
        const resolvedProfile = parsed.schoolProfile || (acc ? {
          schoolName: acc.schoolName,
          udiseCode: acc.udiseCode,
          headmasterName: acc.headmasterName,
          phoneNumber: acc.headmasterMobile,
          village: acc.village || '',
          mandal: acc.mandal || 'PALAKONDA',
          district: acc.district || 'PARVATHI PURAM MANYAM',
          state: acc.state || 'ANDHRA PRADESH',
          address: acc.address || `${acc.schoolName}, ${acc.mandal || ''}`,
        } : undefined);

        localResult = {
          schoolId,
          udiseCode: parsed.udiseCode || acc?.udiseCode || (schoolId.startsWith('school_') ? schoolId.replace('school_', '') : undefined),
          schoolName: parsed.schoolName || acc?.schoolName,
          schoolProfile: resolvedProfile,
          mealRates: parsed.mealRates,
          dailyEntries: Array.isArray(parsed.dailyEntries) ? parsed.dailyEntries : [],
          commodities: Array.isArray(parsed.commodities) ? parsed.commodities : [],
          stockTransactions: Array.isArray(parsed.stockTransactions) ? parsed.stockTransactions : [],
          cashVouchers: Array.isArray(parsed.cashVouchers) ? parsed.cashVouchers : [],
          studentStrengths: Array.isArray(parsed.studentStrengths) ? parsed.studentStrengths : [],
          monthlyOverrides: parsed.monthlyOverrides && typeof parsed.monthlyOverrides === 'object' ? parsed.monthlyOverrides : {},
          updatedAt: parsed.updatedAt || new Date().toISOString(),
        };
      } catch (err) {
        console.error(`Error reading data file for ${schoolId}, attempting recovery from backup:`, err);
        if (fs.existsSync(backupPath)) {
          try {
            const backupContent = fs.readFileSync(backupPath, 'utf-8');
            const backupParsed = JSON.parse(backupContent);
            const acc = authStore.getAccount(schoolId);
            localResult = {
              schoolId,
              udiseCode: backupParsed.udiseCode || acc?.udiseCode,
              schoolName: backupParsed.schoolName || acc?.schoolName,
              schoolProfile: backupParsed.schoolProfile,
              mealRates: backupParsed.mealRates,
              dailyEntries: Array.isArray(backupParsed.dailyEntries) ? backupParsed.dailyEntries : [],
              commodities: Array.isArray(backupParsed.commodities) ? backupParsed.commodities : [],
              stockTransactions: Array.isArray(backupParsed.stockTransactions) ? backupParsed.stockTransactions : [],
              cashVouchers: Array.isArray(backupParsed.cashVouchers) ? backupParsed.cashVouchers : [],
              studentStrengths: Array.isArray(backupParsed.studentStrengths) ? backupParsed.studentStrengths : [],
              monthlyOverrides: backupParsed.monthlyOverrides && typeof backupParsed.monthlyOverrides === 'object' ? backupParsed.monthlyOverrides : {},
              updatedAt: backupParsed.updatedAt || new Date().toISOString(),
            };
          } catch {}
        }
      }
    }

    // Always check authoritative Cloud Firestore to merge any entries saved from other sessions or cloud
    try {
      const remoteData = await loadSchoolDataFromFirestore(schoolId);
      if (remoteData) {
        if (!localResult) {
          this.saveLocalFile(schoolId, remoteData);
          return remoteData;
        }

        // Merge daily entries by date
        const entryMap = new Map<string, any>();
        if (Array.isArray(localResult.dailyEntries)) {
          for (const e of localResult.dailyEntries) {
            if (e && e.date) entryMap.set(e.date, e);
          }
        }
        if (Array.isArray(remoteData.dailyEntries)) {
          for (const r of remoteData.dailyEntries) {
            if (r && r.date) {
              const existing = entryMap.get(r.date);
              if (!existing) {
                entryMap.set(r.date, r);
              } else {
                // If remote has newer updatedAt or more fields, merge
                if (r.updatedAt && (!existing.updatedAt || r.updatedAt >= existing.updatedAt)) {
                  entryMap.set(r.date, { ...existing, ...r });
                }
              }
            }
          }
        }
        const mergedEntries = Array.from(entryMap.values()).sort((a, b) => a.date.localeCompare(b.date));

        const merged: SchoolDatabasePayload = {
          ...localResult,
          schoolProfile: remoteData.schoolProfile || localResult.schoolProfile,
          dailyEntries: mergedEntries,
          commodities: (Array.isArray(remoteData.commodities) && remoteData.commodities.length > 0) ? remoteData.commodities : localResult.commodities,
          stockTransactions: (Array.isArray(remoteData.stockTransactions) && remoteData.stockTransactions.length > 0) ? remoteData.stockTransactions : localResult.stockTransactions,
          studentStrengths: (Array.isArray(remoteData.studentStrengths) && remoteData.studentStrengths.length > 0) ? remoteData.studentStrengths : localResult.studentStrengths,
          monthlyOverrides: Object.keys(remoteData.monthlyOverrides || {}).length > 0 ? remoteData.monthlyOverrides : localResult.monthlyOverrides,
          mealRates: remoteData.mealRates || localResult.mealRates,
          updatedAt: (remoteData.updatedAt && remoteData.updatedAt > (localResult.updatedAt || '')) ? remoteData.updatedAt : localResult.updatedAt,
        };

        this.saveLocalFile(schoolId, merged);
        return merged;
      }
    } catch (err) {
      console.error(`Error syncing school ${schoolId} with Cloud Firestore:`, err);
    }

    if (localResult) {
      return localResult;
    }

    // Return baseline empty structure for new school
    const acc = authStore.getAccount(schoolId);
    const newProfile = acc ? {
      schoolName: acc.schoolName,
      udiseCode: acc.udiseCode,
      headmasterName: acc.headmasterName,
      phoneNumber: acc.headmasterMobile,
      village: acc.village || '',
      mandal: acc.mandal || 'PALAKONDA',
      district: acc.district || 'PARVATHI PURAM MANYAM',
      state: acc.state || 'ANDHRA PRADESH',
      address: acc.address || `${acc.schoolName}, ${acc.mandal || ''}`,
    } : undefined;

    return {
      schoolId,
      udiseCode: acc?.udiseCode || (schoolId.startsWith('school_') ? schoolId.replace('school_', '') : undefined),
      schoolName: acc?.schoolName,
      schoolProfile: newProfile,
      dailyEntries: [],
      commodities: [],
      stockTransactions: [],
      cashVouchers: [],
      studentStrengths: [],
      monthlyOverrides: {},
      updatedAt: new Date().toISOString(),
    };
  }

  private saveLocalFile(schoolId: string, data: SchoolDatabasePayload): void {
    this.ensureDir();
    const filePath = this.getFilePath(schoolId);
    const backupPath = `${filePath}.bak`;
    const tempPath = `${filePath}.tmp.${Date.now()}`;
    try {
      // Create backup copy of existing file before updating
      if (fs.existsSync(filePath)) {
        try {
          fs.copyFileSync(filePath, backupPath);
        } catch {}
      }
      fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), {
        encoding: 'utf-8',
        mode: 0o600,
      });
      fs.renameSync(tempPath, filePath);
    } catch (err) {
      console.error(`Error saving local file for ${schoolId}:`, err);
      try {
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
      } catch {}
    }
  }

  // Atomic write to disk using temp file + rename + durable shared Firestore sync
  public saveSchoolData(schoolId: string, data: SchoolDatabasePayload): void {
    data.updatedAt = new Date().toISOString();
    this.saveLocalFile(schoolId, data);

    // Persist to durable shared Cloud Firestore asynchronously
    saveSchoolDataToFirestore(schoolId, data).catch((err) => {
      console.error(`Background Firestore persistence failed for ${schoolId}:`, err);
    });
  }

  public async saveSchoolDataAsync(
    schoolId: string,
    data: SchoolDatabasePayload,
    expectedUpdatedAt?: string
  ): Promise<{ success: boolean; conflict?: boolean; latest?: SchoolDatabasePayload }> {
    data.updatedAt = new Date().toISOString();
    this.saveLocalFile(schoolId, data);
    try {
      const res = await saveSchoolDataToFirestore(schoolId, data, expectedUpdatedAt);
      if (res.conflict && res.latest) {
        this.saveLocalFile(schoolId, res.latest);
        return { success: false, conflict: true, latest: res.latest };
      }
      return { success: true };
    } catch (err) {
      console.error(`Firestore persistence failed for ${schoolId}:`, err);
      return { success: false };
    }
  }

  public deleteSchoolData(schoolId: string): boolean {
    const filePath = this.getFilePath(schoolId);
    let deletedLocal = true;
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {
        console.error(`Error deleting data file for school ${schoolId}:`, err);
        deletedLocal = false;
      }
    }
    deleteSchoolDataFromFirestore(schoolId).catch(() => {});
    return deletedLocal;
  }

  public async deleteSchoolDataAsync(schoolId: string): Promise<boolean> {
    const deletedLocal = this.deleteSchoolData(schoolId);
    try {
      await deleteSchoolDataFromFirestore(schoolId);
    } catch (err) {
      console.error(`Error deleting Firestore data for school ${schoolId}:`, err);
    }
    return deletedLocal;
  }

  public getIdempotencyResult(key: string): any | null {
    if (!key) return null;
    const item = idempotencyMap.get(key);
    if (item && Date.now() - item.timestamp < 15 * 60 * 1000) {
      return item.result;
    }
    return null;
  }

  public setIdempotencyResult(key: string, result: any): void {
    if (!key) return;
    idempotencyMap.set(key, {
      result,
      timestamp: Date.now(),
    });
  }

  // Atomic Daily Entry upsert
  public upsertDailyEntry(schoolId: string, entry: any): { entry: any; isNew: boolean } {
    const data = this.getSchoolData(schoolId);
    const existingIndex = data.dailyEntries.findIndex((e) => e.date === entry.date);
    let isNew = false;

    if (existingIndex >= 0) {
      data.dailyEntries[existingIndex] = {
        ...data.dailyEntries[existingIndex],
        ...entry,
        updatedAt: new Date().toISOString(),
      };
    } else {
      isNew = true;
      data.dailyEntries.push({
        ...entry,
        createdAt: entry.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      // Sort chronologically
      data.dailyEntries.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    }

    this.saveSchoolData(schoolId, data);
    return { entry, isNew };
  }

  // Atomic Cash Voucher upsert
  public upsertCashVoucher(schoolId: string, voucher: any): { voucher: any; isNew: boolean } {
    const data = this.getSchoolData(schoolId);
    const existingIndex = data.cashVouchers.findIndex(
      (v) => v.id === voucher.id || (v.month === voucher.month && v.voucherNo === voucher.voucherNo)
    );
    let isNew = false;

    if (existingIndex >= 0) {
      data.cashVouchers[existingIndex] = {
        ...data.cashVouchers[existingIndex],
        ...voucher,
        generatedAt: voucher.generatedAt || new Date().toISOString(),
      };
    } else {
      isNew = true;
      data.cashVouchers.push({
        ...voucher,
        generatedAt: voucher.generatedAt || new Date().toISOString(),
      });
    }

    this.saveSchoolData(schoolId, data);
    return { voucher, isNew };
  }

  // Atomic Stock Transaction addition
  public addStockTransaction(schoolId: string, tx: any): any {
    const data = this.getSchoolData(schoolId);
    const existing = data.stockTransactions.find((t) => t.id === tx.id);
    if (!existing) {
      data.stockTransactions.push(tx);
      this.saveSchoolData(schoolId, data);
    }
    return tx;
  }

  // Update monthly commodity overrides with negative value preservation for eggs/chikki
  public updateMonthlyOverrides(schoolId: string, overrides: Record<string, Record<string, number>>): void {
    const data = this.getSchoolData(schoolId);
    data.monthlyOverrides = {
      ...data.monthlyOverrides,
      ...overrides,
    };
    this.saveSchoolData(schoolId, data);
  }
}

export const dataStore = new DataStore();
