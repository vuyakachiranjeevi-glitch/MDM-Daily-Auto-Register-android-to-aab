import fs from 'node:fs';
import path from 'node:path';
import type {
  ServerUserAccount,
  ActiveSession,
  PendingOtpRecord,
  PasswordResetToken,
  AuditLogEntry,
} from './types.ts';
import {
  saveAccountToFirestore,
  deleteAccountFromFirestore,
  loadAccountsFromFirestore,
} from './firestoreService.ts';
import { createHashedCredential } from './security.ts';

interface AuthStorageData {
  accounts: ServerUserAccount[];
  sessions: ActiveSession[];
  pendingOtps: PendingOtpRecord[];
  resetTokens: PasswordResetToken[];
  auditLogs: AuditLogEntry[];
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'schools_auth.json');
const LEGACY_DATA_FILE = path.join(DATA_DIR, 'auth_store.json');

class AuthStore {
  private data: AuthStorageData = {
    accounts: [],
    sessions: [],
    pendingOtps: [],
    resetTokens: [],
    auditLogs: [],
  };

  private isInitialized = false;

  constructor() {
    this.init();
  }

  private init() {
    if (this.isInitialized) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
      }

      // Check primary secure store file
      if (fs.existsSync(DATA_FILE)) {
        try {
          const fileContent = fs.readFileSync(DATA_FILE, 'utf-8');
          const parsed = JSON.parse(fileContent);
          this.data = {
            accounts: Array.isArray(parsed.accounts) ? parsed.accounts : [],
            sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
            pendingOtps: Array.isArray(parsed.pendingOtps) ? parsed.pendingOtps : [],
            resetTokens: Array.isArray(parsed.resetTokens) ? parsed.resetTokens : [],
            auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
          };
        } catch (e) {
          console.warn('Failed reading schools_auth.json:', e);
        }
      } else if (fs.existsSync(LEGACY_DATA_FILE)) {
        // Safe migration from legacy store file
        try {
          const fileContent = fs.readFileSync(LEGACY_DATA_FILE, 'utf-8');
          const parsed = JSON.parse(fileContent);
          this.data = {
            accounts: Array.isArray(parsed.accounts) ? parsed.accounts : [],
            sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
            pendingOtps: Array.isArray(parsed.pendingOtps) ? parsed.pendingOtps : [],
            resetTokens: Array.isArray(parsed.resetTokens) ? parsed.resetTokens : [],
            auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
          };
          fs.unlinkSync(LEGACY_DATA_FILE);
        } catch {
          try { fs.unlinkSync(LEGACY_DATA_FILE); } catch {}
        }
      }
    } catch {}

    // Ensure default school account exists in database for seamless login
    const defaultSchoolId = 'school_28261800503';
    const hasDefault = this.data.accounts.some(
      (a) => a.schoolId === defaultSchoolId || a.udiseCode === '28261800503'
    );
    if (!hasDefault) {
      const defaultAccount: ServerUserAccount = {
        id: defaultSchoolId,
        schoolId: defaultSchoolId,
        schoolName: 'M. P. P. SCHOOL R.B.R.PETA',
        udiseCode: '28261800503',
        village: 'R.B.R.PETA',
        mandal: 'PALAKONDA',
        district: 'PARVATHI PURAM MANYAM',
        state: 'ANDHRA PRADESH',
        address: 'M. P. P. SCHOOL R.B.R.PETA, PALAKONDA, PARVATHI PURAM MANYAM',
        headmasterName: 'V. CHIRANJEEVI',
        headmasterSurname: '',
        headmasterMobile: '9848012345',
        headmasterEmail: '',
        headmasterDesignation: 'Headmaster',
        status: 'ACTIVE',
        roles: {
          headmaster: {
            username: '28261800503',
            mobile: '9848012345',
            name: 'V. CHIRANJEEVI',
            credential: createHashedCredential('Password@123'),
          },
          incharge: {
            username: '28261800503',
            mobile: '',
            name: 'MDM Incharge',
            credential: createHashedCredential('Password@123'),
          },
        },
        createdAt: '2026-01-01T00:00:00.000Z',
        failedLoginAttempts: 0,
        lockoutUntil: null,
      };
      this.data.accounts.unshift(defaultAccount);
    }

    // Ensure all accounts strictly enforce username as UDISE code only
    for (const acc of this.data.accounts) {
      if (acc.udiseCode) {
        if (!acc.roles) {
          acc.roles = {
            headmaster: { username: acc.udiseCode, mobile: acc.headmasterMobile || '', name: acc.headmasterName || 'Headmaster', credential: createHashedCredential('Password@123') },
            incharge: { username: acc.udiseCode, mobile: '', name: 'MDM Incharge', credential: createHashedCredential('Password@123') },
          };
        } else {
          if (acc.roles.headmaster) {
            acc.roles.headmaster.username = acc.udiseCode;
          }
          if (acc.roles.incharge) {
            acc.roles.incharge.username = acc.udiseCode;
          }
        }
      }
    }

    this.persist();
    this.isInitialized = true;

    // Asynchronously synchronize accounts with durable shared Cloud Firestore
    this.syncFromFirestore().catch(() => {});
  }

  public async syncFromFirestore(): Promise<void> {
    try {
      const remoteAccounts = await loadAccountsFromFirestore();
      if (remoteAccounts && remoteAccounts.length > 0) {
        let merged = false;
        for (const rem of remoteAccounts) {
          const idx = this.data.accounts.findIndex((a) => a.schoolId === rem.schoolId || a.udiseCode === rem.udiseCode);
          if (idx < 0) {
            this.data.accounts.push(rem);
            merged = true;
          } else {
            if (rem.updatedAt && (!this.data.accounts[idx].updatedAt || rem.updatedAt > (this.data.accounts[idx].updatedAt || ''))) {
              this.data.accounts[idx] = { ...this.data.accounts[idx], ...rem };
              merged = true;
            }
          }
        }
        if (merged) {
          for (const acc of this.data.accounts) {
            if (acc.udiseCode) {
              if (acc.roles?.headmaster) acc.roles.headmaster.username = acc.udiseCode;
              if (acc.roles?.incharge) acc.roles.incharge.username = acc.udiseCode;
            }
          }
          this.persist();
        }
      }
    } catch (err) {
      console.warn('Error syncing accounts from Firestore:', err);
    }
  }

  private persist() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), {
        encoding: 'utf-8',
        mode: 0o600,
      });
    } catch (err) {
      console.warn('Error persisting authStore:', err);
    }
  }

  // Account operations
  public getAccount(schoolId: string): ServerUserAccount | undefined {
    return this.data.accounts.find((a) => a.schoolId === schoolId || a.udiseCode === schoolId || a.schoolId === `school_${schoolId}`);
  }

  public getAllAccounts(): ServerUserAccount[] {
    return this.data.accounts;
  }

  public findAccountByIdentifier(identifier: string): {
    account: ServerUserAccount;
    role: 'HEADMASTER' | 'MDM_INCHARGE';
  } | null {
    const raw = (identifier || '').trim();
    if (!raw) return null;
    const cleanLower = raw.toLowerCase();
    const digits = raw.replace(/\D/g, '');
    const cleanDigits = digits.length === 12 && digits.startsWith('91') ? digits.slice(2) : digits;

    // Prioritize non-default registered accounts over default demo school
    const nonDefaultAccounts = this.data.accounts.filter(
      (a) => a.schoolId !== 'school_28261800503' && a.udiseCode !== '28261800503'
    );
    const defaultAccounts = this.data.accounts.filter(
      (a) => a.schoolId === 'school_28261800503' || a.udiseCode === '28261800503'
    );
    const orderedAccounts = [...nonDefaultAccounts, ...defaultAccounts];

    for (const acc of orderedAccounts) {
      const accUdise = (acc.udiseCode || '').trim();
      const hmUsername = (acc.roles?.headmaster?.username || '').trim().toLowerCase();
      const incUsername = (acc.roles?.incharge?.username || '').trim().toLowerCase();
      const hmMobile = (acc.headmasterMobile || '').replace(/\D/g, '');

      // 1. Match by numeric UDISE code
      if (cleanDigits && accUdise && cleanDigits === accUdise) {
        return { account: acc, role: 'HEADMASTER' };
      }
      if (raw && accUdise && raw === accUdise) {
        return { account: acc, role: 'HEADMASTER' };
      }
      // 2. Match by schoolId
      if (raw && (raw === acc.schoolId || raw === `school_${accUdise}`)) {
        return { account: acc, role: 'HEADMASTER' };
      }
      // 3. Match by username
      if (cleanLower && (cleanLower === hmUsername || cleanLower === 'headmaster')) {
        return { account: acc, role: 'HEADMASTER' };
      }
      if (cleanLower && (cleanLower === incUsername || cleanLower === 'mdm_incharge' || cleanLower === 'incharge')) {
        return { account: acc, role: 'MDM_INCHARGE' };
      }
      // 4. Match by registered 10-digit mobile
      if (cleanDigits && cleanDigits.length === 10 && (hmMobile === cleanDigits || hmMobile.endsWith(cleanDigits))) {
        return { account: acc, role: 'HEADMASTER' };
      }
    }

    return null;
  }

  public resetAccountPassword(
    schoolId: string,
    role: 'HEADMASTER' | 'MDM_INCHARGE',
    newPassword: string
  ): boolean {
    const account = this.getAccount(schoolId);
    if (!account) return false;
    const hashed = createHashedCredential(newPassword);
    if (account.roles.headmaster) account.roles.headmaster.credential = hashed;
    if (account.roles.incharge) account.roles.incharge.credential = hashed;
    account.failedLoginAttempts = 0;
    account.lockoutUntil = null;
    this.updateAccount(schoolId, account);
    return true;
  }

  public createAccount(account: ServerUserAccount): void {
    const index = this.data.accounts.findIndex((a) => a.schoolId === account.schoolId);
    if (index >= 0) {
      this.data.accounts[index] = account;
    } else {
      this.data.accounts.push(account);
    }
    this.persist();
    saveAccountToFirestore(account).catch(() => {});
  }

  public async createAccountAsync(account: ServerUserAccount): Promise<void> {
    const index = this.data.accounts.findIndex((a) => a.schoolId === account.schoolId);
    if (index >= 0) {
      this.data.accounts[index] = account;
    } else {
      this.data.accounts.push(account);
    }
    this.persist();
    await saveAccountToFirestore(account).catch(() => {});
  }

  public updateAccount(schoolId: string, updates: Partial<ServerUserAccount>): ServerUserAccount | null {
    const acc = this.getAccount(schoolId);
    if (!acc) return null;
    Object.assign(acc, updates);
    this.persist();
    saveAccountToFirestore(acc).catch(() => {});
    return acc;
  }

  public deleteAccount(schoolId: string): boolean {
    const initialLen = this.data.accounts.length;
    this.data.accounts = this.data.accounts.filter((a) => a.schoolId !== schoolId);
    this.revokeAllSessionsForSchool(schoolId);
    this.persist();
    deleteAccountFromFirestore(schoolId).catch(() => {});
    return this.data.accounts.length < initialLen;
  }

  public async deleteAccountAsync(schoolId: string): Promise<boolean> {
    const initialLen = this.data.accounts.length;
    this.data.accounts = this.data.accounts.filter((a) => a.schoolId !== schoolId);
    this.revokeAllSessionsForSchool(schoolId);
    this.persist();
    await deleteAccountFromFirestore(schoolId).catch(() => {});
    return this.data.accounts.length < initialLen;
  }

  // Session operations
  public createSession(session: ActiveSession): void {
    this.data.sessions = this.data.sessions.filter((s) => s.token !== session.token);
    this.data.sessions.push(session);
    this.persist();
  }

  public getSession(token: string): ActiveSession | undefined {
    const session = this.data.sessions.find((s) => s.token === token);
    if (!session) return undefined;
    if (Date.now() > session.expiresAt) {
      this.revokeSession(token);
      return undefined;
    }
    session.lastActiveAt = Date.now();
    return session;
  }

  public revokeSession(token: string): void {
    this.data.sessions = this.data.sessions.filter((s) => s.token !== token);
    this.persist();
  }

  public revokeAllSessionsForSchool(schoolId: string): void {
    this.data.sessions = this.data.sessions.filter((s) => s.schoolId !== schoolId);
    this.persist();
  }

  // Pending OTP operations
  public savePendingOtp(record: PendingOtpRecord): void {
    this.data.pendingOtps = this.data.pendingOtps.filter(
      (p) => !(p.mobile === record.mobile && p.purpose === record.purpose)
    );
    this.data.pendingOtps.push(record);
    this.persist();
  }

  public getPendingOtp(mobile: string, purpose: 'REGISTRATION' | 'FORGOT_PASSWORD' | 'CHANGE_CREDENTIALS' | 'LOGIN'): PendingOtpRecord | undefined {
    const now = Date.now();
    const record = this.data.pendingOtps.find(
      (p) => p.mobile === mobile && p.purpose === purpose && p.expiresAt > now
    );
    return record;
  }

  public updatePendingOtp(record: PendingOtpRecord): void {
    const idx = this.data.pendingOtps.findIndex((p) => p.id === record.id);
    if (idx >= 0) {
      this.data.pendingOtps[idx] = record;
      this.persist();
    }
  }

  public removePendingOtp(id: string): void {
    this.data.pendingOtps = this.data.pendingOtps.filter((p) => p.id !== id);
    this.persist();
  }

  // Password Reset Token operations
  public saveResetToken(record: PasswordResetToken): void {
    this.data.resetTokens = this.data.resetTokens.filter((r) => r.schoolId !== record.schoolId);
    this.data.resetTokens.push(record);
    this.persist();
  }

  public getResetToken(token: string): PasswordResetToken | undefined {
    const now = Date.now();
    return this.data.resetTokens.find((r) => r.token === token && r.expiresAt > now && !r.used);
  }

  public invalidateResetToken(token: string): void {
    const record = this.data.resetTokens.find((r) => r.token === token);
    if (record) {
      record.used = true;
      this.persist();
    }
  }

  public markResetTokenUsed(token: string): void {
    this.invalidateResetToken(token);
  }

  // Audit Log operations
  public addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): void {
    const log: AuditLogEntry = {
      ...entry,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs.pop();
    }
    this.persist();
  }

  public getAuditLogs(schoolIdOrLimit?: string | number, limit = 50): AuditLogEntry[] {
    if (typeof schoolIdOrLimit === 'number') {
      return this.data.auditLogs.slice(0, schoolIdOrLimit);
    }
    if (typeof schoolIdOrLimit === 'string') {
      const filtered = this.data.auditLogs.filter((l) => l.schoolId === schoolIdOrLimit);
      return filtered.slice(0, limit);
    }
    return this.data.auditLogs.slice(0, limit);
  }
}

export const authStore = new AuthStore();
