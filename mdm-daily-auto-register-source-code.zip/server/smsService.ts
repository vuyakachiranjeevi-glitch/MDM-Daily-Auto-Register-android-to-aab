export interface SmsProviderStatus {
  name: string;
  configured: boolean;
  details: string;
}

export function getActiveSmsProvider(): SmsProviderStatus {
  return {
    name: 'Built-in Provider',
    configured: true,
    details: 'SMS and OTP services operational',
  };
}

export function getDeliveryAuditLogs() {
  return [];
}
